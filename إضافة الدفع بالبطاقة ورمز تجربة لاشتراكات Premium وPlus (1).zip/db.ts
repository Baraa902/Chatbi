import { and, asc, count, desc, eq, gt, gte, inArray, isNull, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  adminCodeAttempts,
  chatMessages,
  chatThreads,
  stories,
  storyRatings,
  storyReports,
  rateLimitWindows,
  InsertUser,
  trialCodeAttempts,
  trialRedemptions,
  userEntitlements,
  User,
  users,
  userSettings,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error instanceof Error ? error.message : "unknown error");
      _db = null;
    }
  }
  return _db;
}

function requireDb(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new Error("Database is not available");
  return db;
}

export async function consumeRateLimit(scopeKey: string, limit: number, windowMs: number) {
  if (!/^[a-z0-9:_-]{1,191}$/.test(scopeKey)) throw new Error("Invalid rate-limit scope");
  if (!Number.isInteger(limit) || limit < 1 || !Number.isInteger(windowMs) || windowMs < 1_000) {
    throw new Error("Invalid rate-limit configuration");
  }

  const db = requireDb(await getDb());
  const now = new Date();
  const cutoff = new Date(now.getTime() - windowMs);
  await db.insert(rateLimitWindows).values({ scopeKey, windowStartedAt: now, requestCount: 1 }).onDuplicateKeyUpdate({
    set: {
      requestCount: sql<number>`CASE WHEN ${rateLimitWindows.windowStartedAt} <= ${cutoff} THEN 1 ELSE LEAST(${limit + 1}, ${rateLimitWindows.requestCount} + 1) END`,
      windowStartedAt: sql<Date>`CASE WHEN ${rateLimitWindows.windowStartedAt} <= ${cutoff} THEN ${now} ELSE ${rateLimitWindows.windowStartedAt} END`,
    },
  });

  const rows = await db
    .select({ requestCount: rateLimitWindows.requestCount, windowStartedAt: rateLimitWindows.windowStartedAt })
    .from(rateLimitWindows)
    .where(eq(rateLimitWindows.scopeKey, scopeKey))
    .limit(1);
  const row = rows[0];
  if (!row) throw new Error("Rate-limit counter could not be read");
  const retryAfterSeconds = Math.max(1, Math.ceil((row.windowStartedAt.getTime() + windowMs - Date.now()) / 1_000));
  return { allowed: row.requestCount <= limit, remaining: Math.max(0, limit - row.requestCount), retryAfterSeconds };
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = requireDb(await getDb());
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };

  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = requireDb(await getDb());
  const rows = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return rows[0];
}

export async function getUserSettings(userId: number) {
  const db = requireDb(await getDb());
  const rows = await db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1);
  if (rows[0]) return rows[0];
  await db.insert(userSettings).values({ userId, replyLanguage: "auto" }).onDuplicateKeyUpdate({
    set: { replyLanguage: "auto" },
  });
  const created = await db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1);
  return created[0];
}

export async function setReplyLanguage(userId: number, replyLanguage: string) {
  const db = requireDb(await getDb());
  await db.insert(userSettings).values({ userId, replyLanguage }).onDuplicateKeyUpdate({
    set: { replyLanguage, updatedAt: new Date() },
  });
  return getUserSettings(userId);
}

export async function listChatThreads(userId: number) {
  const db = requireDb(await getDb());
  return db
    .select({ id: chatThreads.id, title: chatThreads.title, createdAt: chatThreads.createdAt, updatedAt: chatThreads.updatedAt })
    .from(chatThreads)
    .where(eq(chatThreads.userId, userId))
    .orderBy(desc(chatThreads.updatedAt))
    .limit(100);
}

export async function createChatThread(userId: number, id: string) {
  const db = requireDb(await getDb());
  await db.insert(chatThreads).values({ id, userId, title: "" });
  const rows = await db.select().from(chatThreads).where(and(eq(chatThreads.id, id), eq(chatThreads.userId, userId))).limit(1);
  return rows[0];
}

export async function getChatThread(userId: number, threadId: string) {
  const db = requireDb(await getDb());
  const rows = await db
    .select()
    .from(chatThreads)
    .where(and(eq(chatThreads.id, threadId), eq(chatThreads.userId, userId)))
    .limit(1);
  return rows[0];
}

export async function deleteChatThread(userId: number, threadId: string) {
  const db = requireDb(await getDb());
  const ownedThread = await db
    .select({ id: chatThreads.id })
    .from(chatThreads)
    .where(and(eq(chatThreads.id, threadId), eq(chatThreads.userId, userId)))
    .limit(1);
  if (!ownedThread[0]) return false;

  await db
    .delete(chatThreads)
    .where(and(eq(chatThreads.id, threadId), eq(chatThreads.userId, userId)));
  return true;
}

export async function listChatMessages(userId: number, threadId: string, limit = 50) {
  const db = requireDb(await getDb());
  const rows = await db
    .select()
    .from(chatMessages)
    .where(and(eq(chatMessages.threadId, threadId), eq(chatMessages.userId, userId)))
    .orderBy(asc(chatMessages.id))
    .limit(limit);
  return rows;
}

export async function getRecentChatMessages(userId: number, threadId: string, limit = 30) {
  const db = requireDb(await getDb());
  const rows = await db
    .select({ role: chatMessages.role, content: chatMessages.content })
    .from(chatMessages)
    .where(and(eq(chatMessages.threadId, threadId), eq(chatMessages.userId, userId)))
    .orderBy(desc(chatMessages.id))
    .limit(limit);
  return rows.reverse();
}

export async function ensureUserMessage(input: {
  userId: number;
  threadId: string;
  clientMessageId: string;
  content: string;
}) {
  const db = requireDb(await getDb());
  const existing = await db.select().from(chatMessages).where(eq(chatMessages.clientMessageId, input.clientMessageId)).limit(1);
  if (existing[0]) {
    if (existing[0].userId !== input.userId || existing[0].threadId !== input.threadId) {
      throw new Error("Message request identifier is already in use");
    }
    return existing[0];
  }

  try {
    await db.insert(chatMessages).values({
      userId: input.userId,
      threadId: input.threadId,
      clientMessageId: input.clientMessageId,
      role: "user",
      content: input.content,
    });
  } catch (error) {
    const raced = await db.select().from(chatMessages).where(eq(chatMessages.clientMessageId, input.clientMessageId)).limit(1);
    if (raced[0] && raced[0].userId === input.userId && raced[0].threadId === input.threadId) return raced[0];
    throw error;
  }

  const created = await db.select().from(chatMessages).where(eq(chatMessages.clientMessageId, input.clientMessageId)).limit(1);
  return created[0];
}

export async function getAssistantReply(userId: number, userMessageId: number) {
  const db = requireDb(await getDb());
  const rows = await db
    .select()
    .from(chatMessages)
    .where(and(eq(chatMessages.userId, userId), eq(chatMessages.replyToMessageId, userMessageId)))
    .limit(1);
  return rows[0];
}

export async function createAssistantReply(input: {
  userId: number;
  threadId: string;
  replyToMessageId: number;
  content: string;
}) {
  const db = requireDb(await getDb());
  try {
    await db.insert(chatMessages).values({
      userId: input.userId,
      threadId: input.threadId,
      role: "assistant",
      content: input.content,
      replyToMessageId: input.replyToMessageId,
    });
  } catch (error) {
    const raced = await getAssistantReply(input.userId, input.replyToMessageId);
    if (raced) return raced;
    throw error;
  }
  return getAssistantReply(input.userId, input.replyToMessageId);
}

export async function touchChatThread(userId: number, threadId: string, firstMessage: string) {
  const db = requireDb(await getDb());
  const thread = await getChatThread(userId, threadId);
  if (!thread) return;
  const title = thread.title || firstMessage.trim().replace(/\s+/g, " ").slice(0, 72);
  await db
    .update(chatThreads)
    .set({ title, updatedAt: new Date() })
    .where(and(eq(chatThreads.id, threadId), eq(chatThreads.userId, userId)));
}

export async function getMembershipSummary(userId: number) {
  const db = requireDb(await getDb());
  const now = new Date();
  const entitlements = await db
    .select()
    .from(userEntitlements)
    .where(and(eq(userEntitlements.userId, userId), eq(userEntitlements.status, "active")));
  const active = entitlements.filter((item) => !item.expiresAt || item.expiresAt > now);
  const plus = active.some((item) => item.plan === "plus");
  const premium = active.some((item) => item.plan === "premium");
  const redemptions = await db.select().from(trialRedemptions).where(eq(trialRedemptions.userId, userId)).limit(1);
  return {
    currentPlan: premium ? "premium" : plus ? "plus" : "free",
    plus,
    premium,
    trialRedeemed: Boolean(redemptions[0]),
    trialPlusGranted: redemptions[0]?.plusGranted ?? false,
    trialPremiumGranted: redemptions[0]?.premiumGranted ?? false,
    redeemedAt: redemptions[0]?.redeemedAt ?? null,
  } as const;
}

export async function getTrialRedemption(userId: number) {
  const db = requireDb(await getDb());
  const rows = await db.select().from(trialRedemptions).where(eq(trialRedemptions.userId, userId)).limit(1);
  return rows[0];
}

export async function countTrialFailures(since: Date, userId?: number) {
  const db = requireDb(await getDb());
  const where = userId === undefined
    ? gte(trialCodeAttempts.createdAt, since)
    : and(eq(trialCodeAttempts.userId, userId), gte(trialCodeAttempts.createdAt, since));
  const rows = await db.select({ total: count() }).from(trialCodeAttempts).where(where);
  return Number(rows[0]?.total ?? 0);
}

export async function recordTrialFailure(userId: number) {
  const db = requireDb(await getDb());
  await db.insert(trialCodeAttempts).values({ userId });
}

export async function countAdminCodeFailures(since: Date, userId: number) {
  const db = requireDb(await getDb());
  const rows = await db
    .select({ total: count() })
    .from(adminCodeAttempts)
    .where(and(eq(adminCodeAttempts.userId, userId), gte(adminCodeAttempts.createdAt, since)));
  return Number(rows[0]?.total ?? 0);
}

export async function recordAdminCodeFailure(userId: number) {
  const db = requireDb(await getDb());
  await db.insert(adminCodeAttempts).values({ userId });
}

export async function getAdminStatistics() {
  const db = requireDb(await getDb());
  const now = new Date();
  const [accounts, plusEver, premiumEver, plusActive, premiumActive] = await Promise.all([
    db.select({ total: count() }).from(users),
    db.select({ total: sql<number>`count(distinct ${userEntitlements.userId})` })
      .from(userEntitlements).where(eq(userEntitlements.plan, "plus")),
    db.select({ total: sql<number>`count(distinct ${userEntitlements.userId})` })
      .from(userEntitlements).where(eq(userEntitlements.plan, "premium")),
    db.select({ total: sql<number>`count(distinct ${userEntitlements.userId})` })
      .from(userEntitlements)
      .where(and(
        eq(userEntitlements.plan, "plus"),
        eq(userEntitlements.status, "active"),
        or(isNull(userEntitlements.expiresAt), gt(userEntitlements.expiresAt, now)),
      )),
    db.select({ total: sql<number>`count(distinct ${userEntitlements.userId})` })
      .from(userEntitlements)
      .where(and(
        eq(userEntitlements.plan, "premium"),
        eq(userEntitlements.status, "active"),
        or(isNull(userEntitlements.expiresAt), gt(userEntitlements.expiresAt, now)),
      )),
  ]);

  return {
    registeredAccounts: Number(accounts[0]?.total ?? 0),
    plusEver: Number(plusEver[0]?.total ?? 0),
    premiumEver: Number(premiumEver[0]?.total ?? 0),
    plusActive: Number(plusActive[0]?.total ?? 0),
    premiumActive: Number(premiumActive[0]?.total ?? 0),
  };
}

export async function updateTrialSelection(userId: number, selected: { plus: boolean; premium: boolean }) {
  const db = requireDb(await getDb());
  return db.transaction(async (tx) => {
    const existing = await tx.select().from(trialRedemptions).where(eq(trialRedemptions.userId, userId)).limit(1);
    if (!existing[0]) return false;

    await tx.update(trialRedemptions).set({ plusGranted: selected.plus, premiumGranted: selected.premium })
      .where(eq(trialRedemptions.userId, userId));

    for (const item of [
      { plan: "plus" as const, enabled: selected.plus },
      { plan: "premium" as const, enabled: selected.premium },
    ]) {
      if (item.enabled) {
        await tx.insert(userEntitlements).values({
          userId,
          plan: item.plan,
          source: "trial",
          status: "active",
          expiresAt: null,
        }).onDuplicateKeyUpdate({ set: { status: "active", expiresAt: null, updatedAt: new Date() } });
      } else {
        await tx.update(userEntitlements)
          .set({ status: "cancelled", updatedAt: new Date() })
          .where(and(
            eq(userEntitlements.userId, userId),
            eq(userEntitlements.plan, item.plan),
            eq(userEntitlements.source, "trial"),
          ));
      }
    }
    return true;
  });
}

export async function redeemTrial(userId: number, selected: { plus: boolean; premium: boolean }) {
  const db = requireDb(await getDb());
  return db.transaction(async (tx) => {
    const existing = await tx.select().from(trialRedemptions).where(eq(trialRedemptions.userId, userId)).limit(1);
    if (existing[0]) return false;

    await tx.insert(trialRedemptions).values({
      userId,
      plusGranted: selected.plus,
      premiumGranted: selected.premium,
    });

    const grants = ([(selected.plus ? "plus" : null), (selected.premium ? "premium" : null)] as const)
      .filter((plan): plan is "plus" | "premium" => plan !== null)
      .map((plan) => ({ userId, plan, source: "trial" as const, status: "active" as const, expiresAt: null }));
    if (grants.length) {
      await tx.insert(userEntitlements).values(grants).onDuplicateKeyUpdate({
        set: { status: "active", expiresAt: null, updatedAt: new Date() },
      });
    }
    return true;
  });
}

export async function submitStory(input: { userId: number; title: string; body: string; pseudonym: string | null }) {
  const database = requireDb(await getDb());
  const result = await database.insert(stories).values({ ...input, status: "pending" });
  const id = Number(result[0].insertId);
  const rows = await database.select({ id: stories.id, title: stories.title, body: stories.body, pseudonym: stories.pseudonym, status: stories.status, submittedAt: stories.submittedAt }).from(stories).where(eq(stories.id, id)).limit(1);
  return rows[0];
}

export async function listMyStories(userId: number) {
  const database = requireDb(await getDb());
  return database.select({ id: stories.id, title: stories.title, body: stories.body, pseudonym: stories.pseudonym, status: stories.status, submittedAt: stories.submittedAt, moderatedAt: stories.moderatedAt }).from(stories).where(eq(stories.userId, userId)).orderBy(desc(stories.submittedAt)).limit(100);
}

export async function listPublicStories(userId?: number) {
  const database = requireDb(await getDb());
  const published = await database.select({ id: stories.id, title: stories.title, body: stories.body, pseudonym: stories.pseudonym, submittedAt: stories.submittedAt, ownerId: stories.userId }).from(stories).where(eq(stories.status, "published")).orderBy(desc(stories.submittedAt)).limit(100);
  const result = [];
  for (const story of published) {
    const ratings = await database.select({ average: sql<number>`COALESCE(AVG(${storyRatings.rating}), 0)`, total: count() }).from(storyRatings).where(eq(storyRatings.storyId, story.id));
    const mine = userId === undefined ? [] : await database.select({ rating: storyRatings.rating }).from(storyRatings).where(and(eq(storyRatings.storyId, story.id), eq(storyRatings.userId, userId))).limit(1);
    const { ownerId, ...publicStory } = story;
    result.push({ ...publicStory, averageRating: Number(ratings[0]?.average ?? 0), ratingCount: Number(ratings[0]?.total ?? 0), myRating: mine[0]?.rating ?? null, isOwner: userId !== undefined && userId === ownerId });
  }
  return result;
}

export async function rateStory(storyId: number, userId: number, rating: number) {
  const database = requireDb(await getDb());
  const story = await database.select({ id: stories.id, userId: stories.userId }).from(stories).where(and(eq(stories.id, storyId), eq(stories.status, "published"))).limit(1);
  if (!story[0]) return "missing" as const;
  if (story[0].userId === userId) return "owner" as const;
  await database.insert(storyRatings).values({ storyId, userId, rating }).onDuplicateKeyUpdate({ set: { rating, updatedAt: new Date() } });
  return "ok" as const;
}

export async function reportStory(storyId: number, reporterId: number, reason: string) {
  const database = requireDb(await getDb());
  const story = await database.select({ id: stories.id }).from(stories).where(and(eq(stories.id, storyId), eq(stories.status, "published"))).limit(1);
  if (!story[0]) return "missing" as const;
  await database.insert(storyReports).values({ storyId, reporterId, reason }).onDuplicateKeyUpdate({ set: { reason, status: "open" } });
  return "ok" as const;
}

export async function getStoryModerationQueue() {
  const database = requireDb(await getDb());
  const pending = await database.select({ id: stories.id, title: stories.title, body: stories.body, pseudonym: stories.pseudonym, status: stories.status, submittedAt: stories.submittedAt }).from(stories).where(eq(stories.status, "pending")).orderBy(asc(stories.submittedAt)).limit(200);
  const reports = await database.select({ id: storyReports.id, storyId: storyReports.storyId, reason: storyReports.reason, createdAt: storyReports.createdAt, title: stories.title, body: stories.body, pseudonym: stories.pseudonym }).from(storyReports).innerJoin(stories, eq(storyReports.storyId, stories.id)).where(eq(storyReports.status, "open")).orderBy(asc(storyReports.createdAt)).limit(200);
  return { pending, reports };
}

export async function moderateStory(storyId: number, status: "published" | "rejected") {
  const database = requireDb(await getDb());
  const result = await database.update(stories).set({ status, moderatedAt: new Date() }).where(and(eq(stories.id, storyId), inArray(stories.status, ["pending", "published"])));
  return result[0].affectedRows > 0;
}

export async function closeStoryReport(reportId: number) {
  const database = requireDb(await getDb());
  await database.update(storyReports).set({ status: "closed" }).where(eq(storyReports.id, reportId));
}
