import { describe, expect, it } from "vitest";
import { renderSeoHtml, resolveSeoPage } from "./seo";

const PUBLIC_ORIGIN = (process.env.CHATBI_PUBLIC_ORIGIN ?? "https://chatbiapp-y4tmxkdn.manus.space").replace(/\/+$/, "");
const HTML_TEMPLATE = '<!doctype html><html><head><title>old</title><meta name="description" content="old"></head><body><div id="root"></div></body></html>';

describe("SEO server responses", () => {
  it("serves the public story page successfully without indexing it and supplies a canonical URL", () => {
    const page = resolveSeoPage("/stories");

    expect(page).toMatchObject({
      title: "قصص مجتمع chatbi.AI",
      robots: "noindex, nofollow",
      status: 200,
      private: false,
    });
    expect(page?.body).toContain("المراجعة قبل ظهورها للعامة");

    const stories = renderSeoHtml(HTML_TEMPLATE, "/stories?from=share");
    expect(stories.page.status).toBe(200);
    expect(stories.html).toContain("<h1>قصص مجتمع chatbi.AI</h1>");
    expect(stories.html).toContain('name="robots" content="noindex, nofollow"');
    expect(stories.html).toContain(`rel="canonical" href="${PUBLIC_ORIGIN}/stories"`);
    expect(stories.html).toContain(`property="og:url" content="${PUBLIC_ORIGIN}/stories"`);
  });

  it("canonicalizes indexable pages and excludes private pages and unknown routes", () => {
    const home = renderSeoHtml(HTML_TEMPLATE, "/");
    expect(home.page.status).toBe(200);
    expect(home.html).toContain(`rel="canonical" href="${PUBLIC_ORIGIN}/"`);

    const plans = renderSeoHtml(HTML_TEMPLATE, "/plus");
    expect(plans.html).toContain(`rel="canonical" href="${PUBLIC_ORIGIN}/plus"`);

    const settings = renderSeoHtml(HTML_TEMPLATE, "/settings");
    expect(settings.page.robots).toBe("noindex, nofollow");
    expect(settings.html).not.toContain('rel="canonical"');

    const missing = resolveSeoPage("/does-not-exist");
    expect(missing).toBeNull();
    expect(renderSeoHtml(HTML_TEMPLATE, "/does-not-exist", true).page.status).toBe(404);
  });
});
