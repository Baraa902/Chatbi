import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import { ACCENT_THEMES, useAccentTheme } from "@/contexts/AccentThemeContext";
import AdminAnalytics from "@/components/AdminAnalytics";
import ChatbiShell from "@/components/ChatbiShell";
import PlanCards from "@/components/PlanCards";
import StoryModeration from "@/components/StoryModeration";
import { INTERFACE_LANGUAGE_OPTIONS, useLocale } from "@/lib/locale";
import { usePageSeo } from "@/lib/seo";
import { trpc } from "@/lib/trpc";
import { LANGUAGE_OPTIONS } from "@shared/languages";
import { ArrowLeft, Check, Languages, Loader2, LockKeyhole, Palette, Search, ShieldCheck, UserRound } from "lucide-react";
import { useMemo, useState } from "react";
import { useLocation } from "wouter";

export default function SettingsPage() {
  const { user, loading } = useAuth();
  const { locale, setLocale, t } = useLocale();
  const [, setLocation] = useLocation();
  const { accentTheme, setAccentTheme } = useAccentTheme();
  usePageSeo({ title: `${t("settings")} | chatbi.AI`, description: t("settingsSubtitle"), robots: "noindex, nofollow" });
  const [search, setSearch] = useState("");
  const [interfaceSearch, setInterfaceSearch] = useState("");
  const [interfaceLanguageNotice, setInterfaceLanguageNotice] = useState(false);
  const [code, setCode] = useState("");
  const [verified, setVerified] = useState(false);
  const [plus, setPlus] = useState(false);
  const [premium, setPremium] = useState(false);
  const [manageTrial, setManageTrial] = useState(false);
  const [notice, setNotice] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const settings = trpc.settings.get.useQuery(undefined, { enabled: Boolean(user), retry: false });
  const membership = trpc.membership.summary.useQuery(undefined, { enabled: Boolean(user), retry: false });
  const storyOwner = trpc.stories.canModerate.useQuery(undefined, { enabled: Boolean(user), retry: false });
  const setLanguage = trpc.settings.setReplyLanguage.useMutation();
  const verifyCode = trpc.membership.verifyTrialCode.useMutation();
  const redeemCode = trpc.membership.redeemTrialCode.useMutation();
  const updateTrialSelection = trpc.membership.updateTrialSelection.useMutation();
  const utils = trpc.useUtils();

  const replyLanguage = settings.data?.replyLanguage ?? "auto";
  const selectedLanguage = LANGUAGE_OPTIONS.find((language) => language.code === replyLanguage);
  const filteredLanguages = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    if (!query) return LANGUAGE_OPTIONS;
    return LANGUAGE_OPTIONS.filter((language) =>
      `${language.nativeName} ${language.englishName} ${language.code}`.toLocaleLowerCase().includes(query),
    );
  }, [search]);
  const filteredInterfaceLanguages = useMemo(() => {
    const query = interfaceSearch.trim().toLocaleLowerCase();
    if (!query) return INTERFACE_LANGUAGE_OPTIONS;
    return INTERFACE_LANGUAGE_OPTIONS.filter((language) =>
      `${language.nativeName} ${language.englishName} ${language.code}`.toLocaleLowerCase().includes(query),
    );
  }, [interfaceSearch]);

  const saveLanguage = async (languageCode: string) => {
    setErrorMessage("");
    try {
      await setLanguage.mutateAsync({ languageCode });
      await utils.settings.get.invalidate();
      setNotice(t("languageSaved"));
      setSearch("");
    } catch {
      setErrorMessage(t("saveLanguageError"));
    }
  };

  const onVerify = async (event: React.FormEvent) => {
    event.preventDefault();
    setNotice("");
    setErrorMessage("");
    try {
      await verifyCode.mutateAsync({ code });
      setVerified(true);
      setNotice(t("codeAccepted"));
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.includes("already redeemed")) setErrorMessage(t("redeemed"));
      else if (message.includes("Too many")) setErrorMessage(t("tryAgainLater"));
      else setErrorMessage(t("invalidCode"));
    }
  };

  const onRedeem = async () => {
    setNotice("");
    setErrorMessage("");
    if (!plus && !premium) {
      setErrorMessage(t("chooseAtLeastOne"));
      return;
    }
    try {
      await redeemCode.mutateAsync({ code, plus, premium });
      setCode("");
      setVerified(false);
      setPlus(false);
      setPremium(false);
      setNotice(t("permanentAccess"));
      await utils.membership.summary.invalidate();
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (message.includes("already redeemed")) setErrorMessage(t("redeemed"));
      else if (message.includes("Too many")) setErrorMessage(t("tryAgainLater"));
      else setErrorMessage(t("activatePlanError"));
    }
  };

  const onSaveTrialSelection = async () => {
    setNotice("");
    setErrorMessage("");
    try {
      await updateTrialSelection.mutateAsync({ plus, premium });
      await utils.membership.summary.invalidate();
      setManageTrial(false);
      setNotice(t("planUpdated"));
    } catch {
      setErrorMessage(t("planUpdateError"));
    }
  };

  if (loading) {
    return <ChatbiShell activePath="/settings"><main className="mx-auto max-w-5xl px-4 pt-6 sm:px-7"><Button variant="outline" onClick={() => setLocation("/")} className="gap-2 border-white/10 bg-white/[.03] text-white/80"><ArrowLeft size={16} />{t("backToChat")}</Button><div className="flex min-h-[50vh] items-center justify-center"><Loader2 className="animate-spin text-violet-300" /></div></main></ChatbiShell>;
  }

  if (!user) {
    return (
      <ChatbiShell activePath="/settings">
        <main className="mx-auto flex min-h-[60vh] max-w-xl flex-col items-center justify-center px-5 text-center">
          <Button variant="outline" onClick={() => setLocation("/")} className="mb-6 gap-2 border-white/10 bg-white/[.03] text-white/80"><ArrowLeft size={16} />{t("backToChat")}</Button>
          <UserRound className="text-violet-300" size={32} />
          <h1 className="mt-4 text-2xl font-semibold">{t("signInTitle")}</h1>
          <p className="mt-2 text-sm leading-6 text-white/50">{t("signInBody")}</p>
          <p className="mt-2 text-xs leading-5 text-white/40">{t("settingsSignInHint")}</p>
          <Button onClick={() => startLogin()} className="mt-6 rounded-xl bg-violet-500 hover:bg-violet-400">{t("signIn")}</Button>
        </main>
      </ChatbiShell>
    );
  }

  return (
      <ChatbiShell activePath="/settings">
      <main className="mx-auto max-w-5xl px-4 pb-16 pt-8 sm:px-7 md:pt-12">
        <Button variant="outline" onClick={() => setLocation("/")} className="mb-6 gap-2 border-white/10 bg-white/[.03] text-white/80"><ArrowLeft size={16} />{t("backToChat")}</Button>
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[.2em] text-violet-300">chatbi.AI</p>
          <h1 className="mt-2 text-3xl font-semibold tracking-tight">{t("settings")}</h1>
          <p className="mt-2 text-sm text-white/45">{t("settingsSubtitle")}</p>
        </div>

        <AdminAnalytics />
        {storyOwner.data === true && <StoryModeration />}

        <section className="mb-5 rounded-2xl border border-white/10 bg-white/[.025] p-5 sm:p-6">
          <div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/7 text-white/70"><UserRound size={19} /></div><div><h2 className="font-semibold">{t("account")}</h2><p className="text-xs text-white/40">{user.name || t("guest")}{user.email ? ` · ${user.email}` : ""}</p></div></div>
          <div className="mt-5">
            <div><h3 className="text-sm font-medium text-white/80">{t("interfaceLanguage")}</h3><p className="mt-1 text-xs leading-5 text-white/40">{t("interfaceLanguageHelp")}</p></div>
            <div className="relative mt-3">
              <Search className="pointer-events-none absolute top-3.5 h-4 w-4 text-white/35 ltr:left-3 rtl:right-3" />
              <input value={interfaceSearch} onChange={(event) => setInterfaceSearch(event.target.value)} placeholder={t("searchLanguages")} aria-label={t("searchLanguages")} className="h-11 w-full rounded-xl border border-white/10 bg-[#141222] px-10 text-sm text-white outline-none placeholder:text-white/30 focus:border-violet-300/40" />
            </div>
            <div role="listbox" aria-label={t("interfaceLanguage")} className="mt-2 grid max-h-60 gap-1 overflow-y-auto rounded-xl border border-white/8 bg-[#0e0c18] p-1 sm:grid-cols-2">
              {filteredInterfaceLanguages.map((language) => {
                const selected = locale === language.code;
                return <button key={language.code} type="button" role="option" aria-selected={selected} onClick={() => { setLocale(language.code); setInterfaceLanguageNotice(true); }} className={`flex min-h-11 items-center justify-between gap-2 rounded-lg px-3 py-2 text-start text-sm transition hover:bg-white/5 ${selected ? "text-violet-200" : "text-white/70"}`}>
                  <span className="min-w-0 truncate">{language.nativeName} <span className="text-xs text-white/35">· {language.englishName}</span></span>{selected && <Check size={15} className="shrink-0" />}
                </button>;
              })}
              {filteredInterfaceLanguages.length === 0 && <p className="col-span-full px-3 py-5 text-center text-xs text-white/40">{t("noLanguageFound")}</p>}
            </div>
            {interfaceLanguageNotice && <p role="status" className="mt-2 text-xs text-emerald-200">{t("interfaceLanguageSaved")}</p>}
          </div>
        </section>

        <section className="mb-5 rounded-2xl border border-white/10 bg-white/[.025] p-5 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-500/12 text-violet-200"><Palette size={19} /></div>
            <div><h2 className="font-semibold">{t("appearance")}</h2><p className="mt-1 text-xs leading-5 text-white/45">{t("appearanceHelp")}</p></div>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {ACCENT_THEMES.map((theme) => {
              const selected = accentTheme === theme.id;
              return (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => setAccentTheme(theme.id)}
                  aria-pressed={selected}
                  aria-label={t(theme.labelKey)}
                  className={`flex min-h-12 items-center justify-between rounded-xl border px-3 py-3 text-start text-sm transition ${selected ? "border-violet-300/40 bg-violet-500/10 text-white" : "border-white/10 bg-white/[.02] text-white/70 hover:bg-white/[.05]"}`}
                >
                  <span className="flex items-center gap-3">
                    <span className="h-4 w-4 shrink-0 rounded-full ring-2 ring-white/15" style={{ backgroundColor: theme.color }} />
                    <span>{t(theme.labelKey)}</span>
                  </span>
                  {selected && <Check size={15} className="text-violet-200" />}
                </button>
              );
            })}
          </div>
        </section>

        <section className="mb-5 rounded-2xl border border-white/10 bg-white/[.025] p-5 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-500/12 text-violet-200"><Languages size={19} /></div>
            <div><h2 className="font-semibold">{t("replyLanguage")}</h2><p className="mt-1 text-xs leading-5 text-white/45">{t("replyLanguageHelp")}</p></div>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2 rounded-xl border border-violet-300/15 bg-violet-500/[.06] px-3 py-2.5 text-sm text-violet-100">
            <span className="text-white/45">{t("selected")}</span>
            {replyLanguage === "auto" ? t("autoDetect") : `${selectedLanguage?.nativeName ?? replyLanguage} · ${selectedLanguage?.englishName ?? ""}`}
          </div>
          <div className="relative mt-4">
            <Search className="pointer-events-none absolute top-3.5 h-4 w-4 text-white/35 ltr:left-3 rtl:right-3" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={t("searchLanguages")} className="h-11 w-full rounded-xl border border-white/10 bg-[#141222] px-10 text-sm text-white outline-none placeholder:text-white/30 focus:border-violet-300/40" />
          </div>
          <div className="mt-2 max-h-64 overflow-y-auto rounded-xl border border-white/8 bg-[#0e0c18] p-1">
            <button onClick={() => void saveLanguage("auto")} className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-start text-sm transition hover:bg-white/5 ${replyLanguage === "auto" ? "text-violet-200" : "text-white/70"}`}>
              <span>{t("autoDetect")}</span>{replyLanguage === "auto" && <Check size={15} />}
            </button>
            {filteredLanguages.map((language) => (
              <button key={language.code} onClick={() => void saveLanguage(language.code)} className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-start text-sm transition hover:bg-white/5 ${replyLanguage === language.code ? "text-violet-200" : "text-white/70"}`}>
                <span>{language.nativeName} <span className="text-xs text-white/35">· {language.englishName}</span></span>{replyLanguage === language.code && <Check size={15} />}
              </button>
            ))}
            {filteredLanguages.length === 0 && <p className="px-3 py-5 text-center text-xs text-white/40">{t("noLanguageFound")}</p>}
          </div>
        </section>

        <section className="mb-5 rounded-2xl border border-white/10 bg-white/[.025] p-5 sm:p-6">
          <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <div><h2 className="font-semibold">{t("currentPlan")}</h2><p className="mt-1 text-xs text-white/40">{t("planSectionHint")}</p></div>
            <span className="rounded-full border border-violet-300/20 bg-violet-500/10 px-3 py-1.5 text-xs font-medium text-violet-100">{t(membership.data?.currentPlan ?? "free")}</span>
          </div>
          <PlanCards membership={membership.data ? { plus: membership.data.plus, premium: membership.data.premium } : undefined} />
          <div className="mt-4 rounded-xl border border-amber-300/10 bg-amber-300/[.04] px-4 py-3 text-xs leading-5 text-amber-100/65"><LockKeyhole className="me-2 inline-block h-4 w-4 align-[-3px]" />{t("paymentPending")}</div>
        </section>

        <section className="rounded-2xl border border-white/10 bg-white/[.025] p-5 sm:p-6">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-400/10 text-emerald-200"><ShieldCheck size={19} /></div>
            <div><h2 className="font-semibold">{t("redeemTitle")}</h2><p className="mt-1 text-xs leading-5 text-white/45">{t("redeemHelp")}</p></div>
          </div>
          {membership.data?.trialRedeemed ? (
            <div className="mt-4 rounded-xl border border-emerald-300/15 bg-emerald-500/[.06] p-4 text-sm text-emerald-100/80">
              <p>{t("trialRedeemed")}</p>
              {!manageTrial ? (
                <Button type="button" onClick={() => { setPlus(membership.data?.trialPlusGranted ?? false); setPremium(membership.data?.trialPremiumGranted ?? false); setManageTrial(true); }} className="mt-3 rounded-xl bg-emerald-500/15 text-emerald-100 hover:bg-emerald-500/25">{t("manageTrial")}</Button>
              ) : (
                <div className="mt-4 rounded-xl border border-violet-300/15 bg-violet-500/[.06] p-4">
                  <p className="text-sm font-medium text-violet-100">{t("choosePlan")}</p>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2">
                    <button type="button" onClick={() => setPlus(!plus)} className={`flex items-center justify-between rounded-xl border px-4 py-3 text-sm transition ${plus ? "border-violet-300/40 bg-violet-500/15 text-white" : "border-white/10 bg-white/[.02] text-white/65"}`}><span>Plus</span>{plus && <Check size={16} />}</button>
                    <button type="button" onClick={() => setPremium(!premium)} className={`flex items-center justify-between rounded-xl border px-4 py-3 text-sm transition ${premium ? "border-violet-300/40 bg-violet-500/15 text-white" : "border-white/10 bg-white/[.02] text-white/65"}`}><span>Premium</span>{premium && <Check size={16} />}</button>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button type="button" onClick={() => void onSaveTrialSelection()} disabled={updateTrialSelection.isPending} className="rounded-xl bg-violet-500 hover:bg-violet-400">{updateTrialSelection.isPending ? <Loader2 size={16} className="animate-spin" /> : t("saveSelection")}</Button>
                    <Button type="button" variant="outline" onClick={() => { setPlus(false); setPremium(false); }} className="rounded-xl border-white/10 bg-white/[.03] text-white/75">{t("cancelPlan")}</Button>
                    <Button type="button" variant="outline" onClick={() => setManageTrial(false)} className="rounded-xl border-white/10 bg-white/[.03] text-white/75">{t("close")}</Button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <>
              <form onSubmit={onVerify} className="mt-4 flex flex-col gap-2 sm:flex-row">
                <input value={code} onChange={(event) => { setCode(event.target.value); setVerified(false); }} placeholder={t("enterCode")} maxLength={64} autoComplete="off" spellCheck={false} className="h-11 min-w-0 flex-1 rounded-xl border border-white/10 bg-[#141222] px-3 text-sm text-white outline-none placeholder:text-white/30 focus:border-violet-300/40" />
                <Button type="submit" disabled={!code.trim() || verifyCode.isPending} className="h-11 rounded-xl bg-white/8 px-4 text-white hover:bg-white/12 disabled:opacity-50">{verifyCode.isPending ? <Loader2 size={16} className="animate-spin" /> : t("verifyCode")}</Button>
              </form>
              {verified && (
                <div className="mt-4 rounded-xl border border-violet-300/15 bg-violet-500/[.06] p-4">
                  <p className="text-sm font-medium text-violet-100">{t("choosePlan")}</p>
                  <div className="mt-3 grid gap-2 sm:grid-cols-2">
                    <button type="button" onClick={() => setPlus(!plus)} className={`flex items-center justify-between rounded-xl border px-4 py-3 text-sm transition ${plus ? "border-violet-300/40 bg-violet-500/15 text-white" : "border-white/10 bg-white/[.02] text-white/65"}`}><span>Plus</span>{plus && <Check size={16} />}</button>
                    <button type="button" onClick={() => setPremium(!premium)} className={`flex items-center justify-between rounded-xl border px-4 py-3 text-sm transition ${premium ? "border-violet-300/40 bg-violet-500/15 text-white" : "border-white/10 bg-white/[.02] text-white/65"}`}><span>Premium</span>{premium && <Check size={16} />}</button>
                  </div>
                  <Button onClick={() => void onRedeem()} disabled={redeemCode.isPending} className="mt-3 h-11 w-full rounded-xl bg-violet-500 hover:bg-violet-400">{redeemCode.isPending ? <Loader2 size={16} className="animate-spin" /> : t("activate")}</Button>
                </div>
              )}
            </>
          )}
          {notice && <p role="status" className="mt-3 text-sm text-emerald-200">{notice}</p>}
          {errorMessage && <p role="alert" className="mt-3 text-sm text-rose-200">{errorMessage}</p>}
        </section>
        <footer className="pt-8 text-center text-xs text-white/35">chatbi.AI · {t("creator")}</footer>
      </main>
    </ChatbiShell>
  );
}
