CREATE TABLE `rate_limit_windows` (
	`scopeKey` varchar(191) NOT NULL,
	`windowStartedAt` timestamp NOT NULL,
	`requestCount` int NOT NULL,
	CONSTRAINT `rate_limit_windows_scopeKey` PRIMARY KEY(`scopeKey`)
);
