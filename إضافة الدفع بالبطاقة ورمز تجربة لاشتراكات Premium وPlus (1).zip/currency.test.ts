import { describe, expect, it } from "vitest";
import { parseTcmbUsdQuote } from "./currency";

const validFeed = `<?xml version="1.0" encoding="UTF-8"?>
<Tarih_Date Tarih="14.11.2026" Date="11/14/2026" Bulten_No="2026/217">
  <Currency CrossOrder="0" Kod="USD" CurrencyCode="USD">
    <ForexBuying>49.9824</ForexBuying>
    <ForexSelling>50.0724</ForexSelling>
    <BanknoteBuying>49.9474</BanknoteBuying>
    <BanknoteSelling>50.1475</BanknoteSelling>
  </Currency>
</Tarih_Date>`;
const referenceTime = new Date("2026-11-14T12:00:00Z");

describe("parseTcmbUsdQuote", () => {
  it("reads the dated USD forex selling rate", () => {
    expect(parseTcmbUsdQuote(validFeed, referenceTime)).toEqual({
      usdTry: 50.0724,
      rateDate: "14.11.2026",
      source: "TCMB",
    });
  });

  it("rejects feeds that do not include a usable USD selling quote", () => {
    expect(() => parseTcmbUsdQuote('<Tarih_Date Tarih="14.11.2026"></Tarih_Date>', referenceTime)).toThrow(
      "The TCMB feed did not contain a valid USD selling rate.",
    );
  });

  it("rejects impossible calendar dates instead of normalizing them", () => {
    const invalidDateFeed = validFeed.replace("14.11.2026", "31.02.2026");
    expect(() => parseTcmbUsdQuote(invalidDateFeed, referenceTime)).toThrow(
      "The TCMB feed did not contain a valid USD selling rate.",
    );
  });

  it("rejects stale rate feeds", () => {
    const staleFeed = validFeed.replace("14.11.2026", "01.01.2000");
    expect(() => parseTcmbUsdQuote(staleFeed, referenceTime)).toThrow("The TCMB USD selling rate is stale.");
  });
});
