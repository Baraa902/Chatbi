import { Button } from "@/components/ui/button";
import { useLocale } from "@/lib/locale";
import { usePageSeo } from "@/lib/seo";
import { AlertCircle, Home } from "lucide-react";
import { useEffect } from "react";
import { useLocation } from "wouter";

// Hosting answers this path with HTTP 404 while still serving the app.
const NOT_FOUND_PATH = "/404";

// Render for unknown routes and for items the server confirmed missing (e.g. `/page/:id`).
// The redirect is irreversible: never render while loading, on other errors, or before auth resolves.
export default function NotFound() {
  const [, setLocation] = useLocation();
  const { t } = useLocale();
  usePageSeo({ title: `${t("pageNotFound")} | chatbi.AI`, description: t("notFoundDescription"), robots: "noindex, nofollow" });

  useEffect(() => {
    // Full-page navigation: a client-side route change sends no request, so no 404 status.
    if (window.location.pathname.replace(/\/$/, "") !== NOT_FOUND_PATH) {
      window.location.replace(NOT_FOUND_PATH);
    }
  }, []);

  const handleGoHome = () => {
    setLocation("/");
  };

  return (
    <main className="flex min-h-screen w-full items-center justify-center bg-[#09080f] px-4 text-white">
      <section aria-labelledby="not-found-title" className="w-full max-w-lg rounded-2xl border border-white/10 bg-[#11101a] p-8 text-center shadow-[0_24px_80px_rgba(0,0,0,.45)] sm:p-10">
        <div className="mb-6 flex justify-center">
          <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-rose-400/10 text-rose-300 ring-1 ring-rose-300/20">
            <AlertCircle aria-hidden="true" className="h-11 w-11" />
          </div>
        </div>

        <p className="mb-2 text-xs font-semibold uppercase tracking-[.22em] text-violet-300">chatbi.AI</p>
        <h1 className="text-5xl font-bold tracking-tight text-white">404</h1>

        <h2 id="not-found-title" className="mb-4 mt-3 text-xl font-semibold text-white/90">
          {t("pageNotFound")}
        </h2>

        <p className="mb-2 leading-relaxed text-white/65">{t("notFoundDescription")}</p>
        <p className="mb-8 leading-relaxed text-white/45">{t("notFoundMoved")}</p>

        <div id="not-found-button-group" className="flex justify-center">
          <Button onClick={handleGoHome} className="rounded-lg bg-violet-500 px-6 py-2.5 text-white transition-colors hover:bg-violet-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-300 focus-visible:ring-offset-2 focus-visible:ring-offset-[#11101a]">
            <Home aria-hidden="true" className="mr-2 h-4 w-4" />
            {t("goHome")}
          </Button>
        </div>
      </section>
    </main>
  );
}
