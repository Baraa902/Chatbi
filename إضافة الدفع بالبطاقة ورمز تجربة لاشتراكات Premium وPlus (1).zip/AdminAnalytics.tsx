import { Button } from "@/components/ui/button";
import { useLocale } from "@/lib/locale";
import { trpc } from "@/lib/trpc";
import { BarChart3, LockKeyhole, Loader2, RotateCcw, Users, Sparkles, Crown } from "lucide-react";
import { useState } from "react";

type AnalyticsStats = {
  registeredAccounts: number;
  plusEver: number;
  premiumEver: number;
  plusActive: number;
  premiumActive: number;
};

export default function AdminAnalytics() {
  const { locale, t } = useLocale();
  const [code, setCode] = useState("");
  const [stats, setStats] = useState<AnalyticsStats | null>(null);
  const [error, setError] = useState("");
  const unlock = trpc.analytics.unlock.useMutation();

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");
    const candidate = code;
    setCode("");
    try {
      const result = await unlock.mutateAsync({ code: candidate });
      setStats(result);
    } catch (failure) {
      setStats(null);
      const message = failure instanceof Error ? failure.message : "";
      setError(message.includes("Too many") ? t("analyticsTooMany") : t("analyticsError"));
    }
  };

  const metrics = stats ? [
    { label: t("registeredAccounts"), value: stats.registeredAccounts, icon: Users },
    { label: t("plusEver"), value: stats.plusEver, icon: Sparkles },
    { label: t("plusActive"), value: stats.plusActive, icon: Sparkles },
    { label: t("premiumEver"), value: stats.premiumEver, icon: Crown },
    { label: t("premiumActive"), value: stats.premiumActive, icon: Crown },
  ] : [];

  return (
    <section className="mb-5 rounded-2xl border border-violet-300/20 bg-gradient-to-br from-violet-500/[.08] to-white/[.02] p-5 sm:p-6">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-500/15 text-violet-200"><BarChart3 size={19} /></div>
        <div className="min-w-0 flex-1">
          <h2 className="font-semibold">{t("analyticsTitle")}</h2>
          <p className="mt-1 text-xs leading-5 text-white/45">{t("analyticsDescription")}</p>
        </div>
      </div>

      {!stats ? (
        <form onSubmit={submit} className="mt-4 flex flex-col gap-2 sm:flex-row">
          <div className="relative min-w-0 flex-1">
            <LockKeyhole className="pointer-events-none absolute top-3.5 h-4 w-4 text-white/35 ltr:left-3 rtl:right-3" />
            <input
              type="password"
              value={code}
              onChange={(event) => setCode(event.target.value)}
              placeholder={t("analyticsCodePlaceholder")}
              autoComplete="off"
              maxLength={64}
              className="h-11 w-full rounded-xl border border-white/10 bg-[#141222] px-10 text-sm text-white outline-none placeholder:text-white/30 focus:border-violet-300/40"
            />
          </div>
          <Button type="submit" disabled={!code.trim() || unlock.isPending} className="h-11 rounded-xl bg-violet-500 px-4 hover:bg-violet-400">
            {unlock.isPending ? <Loader2 size={16} className="animate-spin" /> : t("unlockAnalytics")}
          </Button>
        </form>
      ) : (
        <div className="mt-5">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {metrics.map(({ label, value, icon: Icon }) => (
              <div key={label} className="rounded-xl border border-white/8 bg-[#0f0d1a]/75 p-4">
                <div className="flex items-center justify-between gap-2 text-xs text-white/45"><span>{label}</span><Icon size={15} className="shrink-0 text-violet-200/70" /></div>
                <div className="mt-3 text-3xl font-semibold tabular-nums tracking-tight">{new Intl.NumberFormat(locale).format(value)}</div>
              </div>
            ))}
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs text-white/40">
            <span>{t("registeredNotPageViews")}</span>
            <button type="button" onClick={() => setStats(null)} className="inline-flex items-center gap-2 rounded-lg px-3 py-2 text-violet-200 hover:bg-white/5"><RotateCcw size={14} />{t("lockDashboard")}</button>
          </div>
        </div>
      )}
      {error && <p role="alert" className="mt-3 text-sm text-rose-200">{error}</p>}
    </section>
  );
}
