import { readFile, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";

const { LlmClient, mapLimit, messageText } = await import(
  pathToFileURL("/home/ubuntu/skills/builtin-llm-models/lib/llm.mjs").href
);

const MODEL = "gpt-6-luna";
const CONCURRENCY = 4;
const source = JSON.parse(await readFile("/tmp/chatbi-ui-english.json", "utf8"));
const targets = JSON.parse(await readFile("/tmp/chatbi-ui-targets.json", "utf8"))
  .filter((target) => target.code !== "en");
const keys = Object.keys(source);
const schema = {
  type: "object",
  properties: Object.fromEntries(keys.map((key) => [key, { type: "string" }])),
  required: keys,
  additionalProperties: false,
};
const placeholderList = (text) => [...String(text).matchAll(/\{[^{}]+\}/g)].map(([value]) => value).sort();
const llm = new LlmClient({ timeoutMs: 240000, maxRetries: 3 });
let finished = 0;
let fatalError = null;

const results = await mapLimit(targets, CONCURRENCY, async (target) => {
  if (fatalError) return { code: target.code, skipped: true };
  let lastError = null;
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      const response = await llm.chat({
        model: MODEL,
        reasoning: { effort: "low" },
        max_completion_tokens: 8000,
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "chatbi_ui_translation",
            strict: true,
            schema,
          },
        },
        messages: [
          {
            role: "system",
            content: "You are a careful software-interface localizer. Translate every English UI string naturally and concisely into the exact target language and use its normal native script. The strings belong to a multilingual AI chat product. Keep the brand chatbi.AI, plan names Free/Plus/Premium, TCMB, currency codes and numbers unchanged. Preserve every brace-delimited placeholder exactly, including spelling and braces. Preserve warnings and deletion confirmations faithfully. Return only one JSON object containing every supplied key with a non-empty string value; do not omit keys, add keys, or include commentary.",
          },
          {
            role: "user",
            content: JSON.stringify({ target, source }, null, 2),
          },
        ],
      });
      const translated = JSON.parse(messageText(response));
      const translatedKeys = Object.keys(translated);
      if (translatedKeys.length !== keys.length || keys.some((key) => typeof translated[key] !== "string" || !translated[key].trim())) {
        throw new Error(`Missing or empty translation keys for ${target.code}`);
      }
      for (const key of keys) {
        if (JSON.stringify(placeholderList(source[key])) !== JSON.stringify(placeholderList(translated[key]))) {
          throw new Error(`Placeholder mismatch for ${target.code}.${key}`);
        }
      }
      finished += 1;
      if (finished % 10 === 0 || finished === targets.length) {
        console.log(`translated ${finished}/${targets.length}`);
      }
      return { code: target.code, translated, usage: response.usage ?? null };
    } catch (error) {
      lastError = error;
      if (error?.fatal) {
        fatalError = error;
        break;
      }
    }
  }
  finished += 1;
  if (finished % 10 === 0 || finished === targets.length) {
    console.log(`translated ${finished}/${targets.length}`);
  }
  return { code: target.code, error: lastError instanceof Error ? lastError.message : String(lastError) };
});

const translations = Object.fromEntries(
  results.filter((result) => result.translated).map((result) => [result.code, result.translated]),
);
const failures = results.filter((result) => !result.translated).map(({ code, error, skipped }) => ({ code, error, skipped }));
const output = {
  model: MODEL,
  sourceKeyCount: keys.length,
  targetCount: targets.length,
  translations,
  failures,
};
await writeFile("/tmp/chatbi-ui-translations-result.json", JSON.stringify(output, null, 2) + "\n", "utf8");
if (fatalError) {
  console.error(`Fatal Manus LLM error: ${fatalError.message}`);
  process.exitCode = 2;
} else if (failures.length) {
  console.error(`Translation incomplete: ${failures.length} language(s) failed; results saved to /tmp/chatbi-ui-translations-result.json`);
  process.exitCode = 1;
} else {
  const file = "/home/ubuntu/chatbiapp/client/src/lib/locale-messages.generated.json";
  await writeFile(file, JSON.stringify(translations, null, 2) + "\n", "utf8");
  console.log(JSON.stringify({ model: MODEL, languages: Object.keys(translations).length, sourceKeys: keys.length, output: file }));
}
