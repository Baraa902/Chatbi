import { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useLocale } from "@/lib/locale";
import { trpc } from "@/lib/trpc";
import { MessageSquarePlus, Settings, Sparkles, LogOut, CreditCard, BookOpen, Menu, X, Trash2 } from "lucide-react";
import { useLocation } from "wouter";

export type SidebarThread = {
  id: string;
  title: string;
  updatedAt: Date;
};

type ChatbiShellProps = {
  children: React.ReactNode;
  activePath: string;
  threads?: SidebarThread[];
  onNewChat?: () => void;
};

export default function ChatbiShell({ children, activePath, threads = [], onNewChat }: ChatbiShellProps) {
  const { user, logout } = useAuth();
  const { t, dir } = useLocale();
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();
  const deleteThread = trpc.chat.deleteThread.useMutation({
    onSuccess: async (_result, input) => {
      await utils.chat.listThreads.invalidate();
      if (activePath === `/chat/${input.threadId}`) setLocation("/");
      setDeletingThreadId(null);
    },
  });
  const [mobileOpen, setMobileOpen] = useState(false);
  const [deletingThreadId, setDeletingThreadId] = useState<string | null>(null);
  const [deleteError, setDeleteError] = useState("");
  useEffect(() => {
    if (!mobileOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMobileOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [mobileOpen]);

  const goNew = () => {
    setMobileOpen(false);
    if (onNewChat) onNewChat();
    else setLocation("/");
  };
  const goTo = (path: string) => {
    setMobileOpen(false);
    setLocation(path);
  };
  const beginDelete = (id: string) => {
    setDeleteError("");
    setDeletingThreadId(id);
  };
  const confirmDelete = () => {
    if (!deletingThreadId || deleteThread.isPending) return;
    setDeleteError("");
    deleteThread.mutate({ threadId: deletingThreadId }, {
      onError: () => setDeleteError(t("deleteConversationError")),
    });
  };

  const threadList = (mobile = false) => user ? (
    threads.length ? (
      <div className="space-y-1">
        {threads.map((thread) => {
          const selected = activePath === `/chat/${thread.id}`;
          return (
            <div key={thread.id} className={`flex min-w-0 items-center rounded-lg transition ${selected ? "bg-white/8 text-white" : "text-white/60 hover:bg-white/5 hover:text-white"}`}>
              <button type="button" onClick={() => goTo(`/chat/${thread.id}`)} aria-current={selected ? "page" : undefined} className="flex min-w-0 flex-1 items-center gap-3 px-3 py-2.5 text-start text-sm">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-violet-300/65" />
                <span className="truncate">{thread.title || t("newChat")}</span>
              </button>
              <button type="button" onClick={() => beginDelete(thread.id)} aria-label={`${t("deleteConversation")}: ${thread.title || t("newChat")}`} title={t("deleteConversation")} className="shrink-0 rounded-md p-2 text-white/40 hover:bg-red-500/15 hover:text-red-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-300">
                <Trash2 size={15} aria-hidden="true" />
              </button>
            </div>
          );
        })}
      </div>
    ) : <p className="px-3 py-3 text-xs leading-5 text-white/35">{t("emptyConversations")}</p>
  ) : <p className="px-3 py-3 text-xs leading-5 text-white/35">{t("signInBody")}</p>;

  const account = (mobile = false) => (
    <div className="mt-3 flex min-w-0 items-center gap-3 rounded-xl bg-white/[.035] px-3 py-3">
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-violet-400/60 to-fuchsia-500/40 text-sm font-semibold">{user?.name?.trim().charAt(0).toUpperCase() || "C"}</div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-medium">{user?.name || t("guest")}</div>
        <div className="truncate text-[11px] text-white/40">{user?.email || (user ? t("accountLabel") : t("signIn"))}</div>
      </div>
      {user ? (
        <button type="button" title={t("signOut")} onClick={() => { if (mobile) setMobileOpen(false); void logout(); }} className="rounded-lg p-2 text-white/45 hover:bg-white/8 hover:text-white" aria-label={t("signOut")}><LogOut size={16} /></button>
      ) : (
        <button type="button" title={t("signIn")} onClick={() => { if (mobile) setMobileOpen(false); startLogin(); }} className="rounded-lg p-2 text-violet-200 hover:bg-violet-500/15" aria-label={t("signIn")}><Sparkles size={16} /></button>
      )}
    </div>
  );

  const navLinks = () => <>
    <button type="button" onClick={() => goTo("/stories")} className={`mb-1 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${activePath === "/stories" ? "bg-violet-500/15 text-violet-200" : "text-white/60 hover:bg-white/5 hover:text-white"}`} aria-current={activePath === "/stories" ? "page" : undefined}><BookOpen size={17} /><span>{t("stories")}</span></button>
    <button type="button" onClick={() => goTo("/plus")} className={`mb-1 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${activePath === "/plus" ? "bg-violet-500/15 text-violet-200" : "text-white/60 hover:bg-white/5 hover:text-white"}`} aria-current={activePath === "/plus" ? "page" : undefined}><CreditCard size={17} /><span>{t("plans")}</span></button>
    <button type="button" onClick={() => goTo("/settings")} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${activePath === "/settings" ? "bg-violet-500/15 text-violet-200" : "text-white/60 hover:bg-white/5 hover:text-white"}`} aria-current={activePath === "/settings" ? "page" : undefined}><Settings size={17} /><span>{t("settings")}</span></button>
  </>;

  return (
    <div className="chatbi-shell min-h-[100dvh] overflow-x-hidden bg-[#090812] text-white" dir={dir}>
      <aside aria-label={t("mobileMenu")} className="fixed inset-y-0 z-30 hidden w-[272px] flex-col border-white/8 bg-[#0d0b18] md:flex ltr:left-0 ltr:border-r rtl:right-0 rtl:border-l">
        <div className="flex h-[76px] items-center gap-3 px-6">
          <img src="https://files.manuscdn.com/user_upload_by_module/session_file/310519664079402183/ONNeHqArLEOhoeit.png" alt="chatbi.AI" className="h-10 w-10 rounded-2xl object-cover ring-1 ring-violet-300/20" />
          <div><div className="text-lg font-semibold tracking-tight">chatbi.AI</div><div className="text-[11px] text-white/40">{t("aiTagline")}</div></div>
        </div>
        <div className="px-4 pb-4"><Button onClick={goNew} className="h-11 w-full justify-start gap-3 rounded-xl bg-violet-500 text-white shadow-[0_8px_24px_rgba(139,92,246,.16)] hover:bg-violet-400"><MessageSquarePlus size={17} /><span>{t("newChat")}</span></Button></div>
        <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden px-3"><div className="px-3 pb-2 pt-2 text-[11px] font-medium uppercase tracking-[.16em] text-white/35">{t("conversations")}</div>{threadList()}</div>
        <div className="border-t border-white/8 p-3">{navLinks()}{account()}</div>
      </aside>

      <div className="min-h-[100dvh] md:ltr:pl-[272px] md:rtl:pr-[272px]">
        <header className="sticky top-0 z-20 flex h-[62px] items-center justify-between border-b border-white/8 bg-[#090812]/90 px-3 backdrop-blur-xl md:hidden">
          <button type="button" onClick={goNew} className="flex min-w-0 items-center gap-2 text-sm font-semibold"><img src="https://files.manuscdn.com/user_upload_by_module/session_file/310519664079402183/ONNeHqArLEOhoeit.png" alt="" className="h-7 w-7 shrink-0 rounded-lg object-cover" /><span className="truncate">chatbi.AI</span></button>
          <button type="button" onClick={() => setMobileOpen(true)} aria-label={t("openMenu")} aria-expanded={mobileOpen} aria-controls="chatbi-mobile-drawer" className="shrink-0 rounded-lg p-2 text-white/75 hover:bg-white/8 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-300"><Menu size={20} /></button>
        </header>
        {mobileOpen && <div className="fixed inset-0 z-40 md:hidden">
          <button type="button" className="absolute inset-0 h-full w-full bg-black/65" aria-label={t("closeMenu")} onClick={() => setMobileOpen(false)} />
          <aside id="chatbi-mobile-drawer" aria-label={t("mobileMenu")} className="absolute inset-y-0 flex w-[min(88vw,340px)] max-w-full flex-col overflow-hidden border-white/10 bg-[#0d0b18] shadow-2xl ltr:left-0 ltr:border-r rtl:right-0 rtl:border-l">
            <div className="flex h-[62px] shrink-0 items-center justify-between border-b border-white/8 px-4"><span className="font-semibold">chatbi.AI</span><button type="button" onClick={() => setMobileOpen(false)} aria-label={t("closeMenu")} className="rounded-lg p-2 text-white/70 hover:bg-white/8"><X size={19} /></button></div>
            <div className="shrink-0 p-4"><Button onClick={goNew} className="h-11 w-full justify-start gap-3 rounded-xl bg-violet-500 text-white hover:bg-violet-400"><MessageSquarePlus size={17} /><span>{t("newChat")}</span></Button></div>
            <div className="min-h-0 flex-1 overflow-y-auto overflow-x-hidden px-3"><div className="px-3 pb-2 pt-2 text-[11px] font-medium uppercase tracking-[.16em] text-white/35">{t("conversations")}</div>{threadList(true)}</div>
            <div className="shrink-0 border-t border-white/8 p-3">{navLinks()}{account(true)}</div>
          </aside>
        </div>}
        {children}
      </div>

      <AlertDialog open={deletingThreadId !== null} onOpenChange={(open) => { if (!open && !deleteThread.isPending) { setDeletingThreadId(null); setDeleteError(""); } }}>
        <AlertDialogContent className="border-white/10 bg-[#151222] text-white">
          <AlertDialogHeader><AlertDialogTitle>{t("deleteConversationTitle")}</AlertDialogTitle><AlertDialogDescription className="text-white/65">{t("deleteConversationWarning")}</AlertDialogDescription></AlertDialogHeader>
          {deleteError && <p role="alert" className="text-sm text-red-300">{deleteError}</p>}
          {deleteThread.isPending && <p role="status" aria-live="polite" className="text-sm text-white/65">{t("deletingConversation")}</p>}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteThread.isPending} className="border-white/15 bg-transparent text-white hover:bg-white/10">{t("cancel")}</AlertDialogCancel>
            <AlertDialogAction disabled={deleteThread.isPending} onClick={(event) => { event.preventDefault(); confirmDelete(); }} className="bg-red-600 text-white hover:bg-red-500">{deleteThread.isPending ? t("deletingConversation") : t("deleteAction")}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
