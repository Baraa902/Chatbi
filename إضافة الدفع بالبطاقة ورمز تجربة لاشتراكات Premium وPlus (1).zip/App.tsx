import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import StoriesPage from "@/pages/StoriesPage";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AccentThemeProvider } from "./contexts/AccentThemeContext";
import { LocaleProvider } from "./lib/locale";
import ChatPage from "./pages/ChatPage";
import PlansPage from "./pages/PlansPage";
import SettingsPage from "./pages/SettingsPage";

function Router() {
  return (
    <Switch>
      <Route path="/" component={ChatPage} />
      <Route path="/chat/:id" component={ChatPage} />
      <Route path="/plus" component={PlansPage} />
      <Route path="/settings" component={SettingsPage} />
      <Route path="/stories" component={StoriesPage} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <AccentThemeProvider>
          <LocaleProvider>
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </LocaleProvider>
        </AccentThemeProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
