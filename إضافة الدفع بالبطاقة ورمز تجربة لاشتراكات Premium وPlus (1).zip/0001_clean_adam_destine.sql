CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`threadId` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`role` enum('user','assistant') NOT NULL,
	`content` longtext NOT NULL,
	`clientMessageId` varchar(36),
	`replyToMessageId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`),
	CONSTRAINT `chat_messages_client_message_unique` UNIQUE(`clientMessageId`),
	CONSTRAINT `chat_messages_reply_unique` UNIQUE(`replyToMessageId`)
);
--> statement-breakpoint
CREATE TABLE `chat_threads` (
	`id` varchar(36) NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `chat_threads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trial_code_attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trial_code_attempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `trial_redemptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`plusGranted` boolean NOT NULL,
	`premiumGranted` boolean NOT NULL,
	`redeemedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `trial_redemptions_id` PRIMARY KEY(`id`),
	CONSTRAINT `trial_redemptions_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `user_entitlements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`plan` enum('plus','premium') NOT NULL,
	`source` enum('trial','subscription') NOT NULL,
	`status` enum('active','expired','cancelled') NOT NULL DEFAULT 'active',
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_entitlements_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_entitlements_user_plan_source_unique` UNIQUE(`userId`,`plan`,`source`)
);
--> statement-breakpoint
CREATE TABLE `user_settings` (
	`userId` int NOT NULL,
	`replyLanguage` varchar(12) NOT NULL DEFAULT 'auto',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_settings_userId` PRIMARY KEY(`userId`)
);
--> statement-breakpoint
ALTER TABLE `chat_messages` ADD CONSTRAINT `chat_messages_threadId_chat_threads_id_fk` FOREIGN KEY (`threadId`) REFERENCES `chat_threads`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chat_messages` ADD CONSTRAINT `chat_messages_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `chat_threads` ADD CONSTRAINT `chat_threads_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `trial_code_attempts` ADD CONSTRAINT `trial_code_attempts_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `trial_redemptions` ADD CONSTRAINT `trial_redemptions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_entitlements` ADD CONSTRAINT `user_entitlements_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_settings` ADD CONSTRAINT `user_settings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `chat_messages_thread_order_idx` ON `chat_messages` (`threadId`,`id`);--> statement-breakpoint
CREATE INDEX `chat_threads_owner_updated_idx` ON `chat_threads` (`userId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `trial_code_attempts_user_created_idx` ON `trial_code_attempts` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `trial_code_attempts_created_idx` ON `trial_code_attempts` (`createdAt`);--> statement-breakpoint
CREATE INDEX `user_entitlements_user_status_idx` ON `user_entitlements` (`userId`,`status`);