CREATE TABLE `stories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(140) NOT NULL,
	`body` longtext NOT NULL,
	`pseudonym` varchar(50),
	`status` enum('pending','published','rejected') NOT NULL DEFAULT 'pending',
	`submittedAt` timestamp NOT NULL DEFAULT (now()),
	`moderatedAt` timestamp,
	CONSTRAINT `stories_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `story_ratings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`storyId` int NOT NULL,
	`userId` int NOT NULL,
	`rating` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `story_ratings_id` PRIMARY KEY(`id`),
	CONSTRAINT `story_ratings_story_user_unique` UNIQUE(`storyId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `story_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`storyId` int NOT NULL,
	`reporterId` int NOT NULL,
	`reason` varchar(500) NOT NULL,
	`status` enum('open','closed') NOT NULL DEFAULT 'open',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `story_reports_id` PRIMARY KEY(`id`),
	CONSTRAINT `story_reports_story_reporter_unique` UNIQUE(`storyId`,`reporterId`)
);
--> statement-breakpoint
ALTER TABLE `stories` ADD CONSTRAINT `stories_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `story_ratings` ADD CONSTRAINT `story_ratings_storyId_stories_id_fk` FOREIGN KEY (`storyId`) REFERENCES `stories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `story_ratings` ADD CONSTRAINT `story_ratings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `story_reports` ADD CONSTRAINT `story_reports_storyId_stories_id_fk` FOREIGN KEY (`storyId`) REFERENCES `stories`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `story_reports` ADD CONSTRAINT `story_reports_reporterId_users_id_fk` FOREIGN KEY (`reporterId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `stories_status_submitted_idx` ON `stories` (`status`,`submittedAt`);--> statement-breakpoint
CREATE INDEX `stories_owner_idx` ON `stories` (`userId`,`submittedAt`);--> statement-breakpoint
CREATE INDEX `story_ratings_story_idx` ON `story_ratings` (`storyId`);--> statement-breakpoint
CREATE INDEX `story_reports_status_created_idx` ON `story_reports` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `story_reports_story_idx` ON `story_reports` (`storyId`);