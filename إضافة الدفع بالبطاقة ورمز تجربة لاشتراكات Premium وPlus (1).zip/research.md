# ملاحظات مصادر خارجية للتكاملات

تمت مراجعة المصادر الرسمية في 2026-11-14. تستخدم هذه الملاحظات عند تنفيذ التكاملات، ولا تحتوي على أي مفاتيح أو بيانات اعتماد.

## Google Gemini API

- صفحة النماذج الرسمية: https://ai.google.dev/gemini-api/docs/models — تسرد Gemini 3.8 Flash بوصفه نموذجاً مستقراً، وتوصي للمشاريع الجديدة باستخدام نماذج Gemini الحالية مثل 3.8 Flash أو 3.5 Flash-Lite.
- توثيق Interactions API: https://ai.google.dev/gemini-api/docs/interactions — تصف Interactions API بأنه النهج الموصى به، وتوفر أمثلة JavaScript باستخدام `@google/genai` ابتداءً من الإصدار 2.3.0، عبر `interactions.create({ model, input })` وإرجاع `output_text`. يمكن ضبط `store:false` لمنع احتفاظ Gemini بسجل التفاعل، لكن يلزم إرسال سياق المحادثة المطلوب مع كل طلب بدلاً من الاعتماد على `previous_interaction_id`.
- دليل مفاتيح API: https://ai.google.dev/gemini-api/docs/api-key — توصي بوضع المفتاح في متغير بيئة أو مخزن أسرار، وتحذر من تضمينه في الواجهة أو تطبيقات العميل؛ يجب أن تتم اتصالات Gemini من خادم.

## بوابات الدفع التركية

- iyzico Subscription: https://docs.iyzico.com/en/products/subscription — يوثق إنشاء اشتراكات متكررة للمتاجر المقبولة، وخطط دفع يمكن ضبطها من لوحة iyzico أو API. تذكر الصفحة أن خدمة الاشتراكات برسوم بعد فترة تجريبية مجانية.
- iyzico Payment Plan: https://docs.iyzico.com/en/products/subscription/subscription-implementation/payment-plan — يذكر الفواصل الشهرية والعملات TRY وUSD وEUR؛ العملة الأجنبية تقتصر على البطاقات غير التركية وفق الوثائق.
- PayTR Subscription Method: https://www.paytr.com/en/subscription-method — يوثق المدفوعات المتكررة، ويذكر التقديم للحصول على الخدمة والحاجة إلى Virtual POS، وأن وثائق التكامل تُرسل بعد تفعيل العضوية.

يلزم مالك Chatbi اختيار بوابة الدفع والعملة، والحصول على حساب تاجر معتمد ومفاتيح API قبل تشغيل التحصيل الحقيقي.

## نتائج مراجعة صفحات Kuveyt Türk الرسمية (2026-11-14)

- صفحة Virtual POS الرسمية: https://www.kuveytturk.com.tr/en/business/commercial-cards-and-pos/pos-services/virtual-pos — تصف الخدمة كقبول بطاقات على موقع التجارة الإلكترونية؛ بعد اعتماد العملية يُحوّل المبلغ إلى حساب التاجر البنكي. تذكر قبول بطاقات Visa وMastercard وTroy، وميزة 3D Secure، وأن طلب الخدمة يتم عبر Kuveyt Türk Mobile أو الفرع. متطلبات الأهلية المذكورة تشمل صفحة دفع نشطة، أسعاراً منشورة، SSL، بيانات اتصال، اتفاقية خصوصية، اتفاقية بيع عن بُعد، وسياسة إرجاع/استرداد؛ ويطلب طلب Free POS مستندات الشركة والضرائب والتوقيع.
- وثائق API Market الرسمية: https://developer.kuveytturk.com.tr/documentation — تتضمن فئة Virtual POS (VPOS). يتطلب الاستخدام التسجيل وإنشاء تطبيق واختيار API، ثم Client ID/Client Secret واستخدام بيئة sandbox؛ طلب Go Live يُراجع من فريق البنك. الصفحة العامة لا تؤكد دعم اشتراكات البطاقات المتكررة الشهرية.
- إعلان تجديد API Market الرسمي: https://www.kuveytturk.com.tr/en/about-us/about-kuveyt-turk/news/kuveyt-turk-api-market-has-been-renewed — يصف واجهات الخدمات المصرفية المفتوحة للأعمال والتحويلات ونشاط الحساب؛ لا يثبت بحد ذاته دعم تحصيل اشتراكات بطاقات متكررة.

النتيجة التنفيذية المؤقتة: يمكن بحث تكامل بطاقات VPOS إلى حساب التاجر، لكن لا يُفترض أن التحصيل الشهري المتكرر متاح قبل تأكيده من البنك. يتطلب الموقع أيضاً صفحات الاتفاقيات والسياسات وبيانات الاتصال التي يسردها البنك قبل أهلية التاجر؛ لا تُخترع البيانات القانونية نيابة عن صاحب الموقع.

## Lirati — التحقق من التطبيق الذي ذكره المستخدم (2026-11-14)

- صفحة التطبيق الرسمية في Apple App Store: https://apps.apple.com/ae/app/lirati-%D9%84%D9%8A%D8%B1%D8%A7%D8%AA%D9%8A/id6748984547?l=ar — تصف Lirati بأنه تطبيق مالي للتجار والشركات في مرحلة Beta لإدارة المدفوعات والتحويلات والخدمات المالية. لا تذكر الصفحة واجهة Checkout للمواقع أو API للتجار أو اشتراكات شهرية.
- صفحة Google Play الرسمية: https://play.google.com/store/apps/details?id=com.lirati.wallet&hl=ar — تذكر Lirati Ltd وتصف التطبيق بأنه منصة مالية للتجار في Beta لإدارة المدفوعات والتحويلات والأصول الرقمية. لا تذكر تكاملاً لمتجر ويب أو فوترة متكررة.
- سياسة الخصوصية الرسمية: https://lirati.app/privacy.html — تسمي الجهة المشغلة Lirati Wallet Ltd وتذكر تركيا بوصفها البلد، وتوفر معلومات اتصال في Google Play؛ سياسة الخصوصية لا تصف واجهة دفع لموقع خارجي.

هذه المصادر تثبت هوية التطبيق ووصفه العام فقط، ولا تثبت أن بإمكان موقع Chatbi إنشاء طلبات دفع أو ربط اشتراكات به. يلزم توثيق رسمي أو تعليمات تاجر من Lirati قبل تنفيذ تكامل.

## موقع Lirati الرسمي وتكامل مزودي الخدمات (2026-11-14)

- موقع Lirati الرسمي: https://lirati.app/ — يصف Lirati بأنها محفظة رقمية مستقلة تحت تحكم المستخدم وفي مرحلة Beta. يذكر أن المستخدم يوافق ويوقّع العمليات، وأن Lirati لا تحتفظ بأموال المستخدمين؛ التعامل مع الخدمات الخارجية يتم مباشرة مع مزود الخدمة حيث يوجد تكامل. الصفحة لا تعرض وثائق API عامة لقبول دفعات لموقع إلكتروني أو فوترة اشتراكات.
- صفحة الموقع تربط إلى نموذج «مزودو الخدمات»: https://forms.gle/HfJCQN8Qa62hxYrp8، وهو مسار معلن للتقدم كمزود خدمة. دعم Lirati العام المعلن: info@lirati.app.

الاستنتاج: لا يكفي ربط الموقع بحساب تطبيق Lirati الشخصي لتشغيل Checkout؛ يلزم أن تؤكد Lirati أنها توفر تكاملاً مناسباً لمزود خدمة/موقع، وتسلّم وثائق API أو آلية الدفع. لا يُرسل المستخدم أو نطلب منه مفاتيح أو عبارات استرداد المحفظة.

## متطلبات تحويل الإيراد تلقائياً إلى Lirati (2026-11-14)

- نموذج «نقطة بيع | ليراتي»: https://forms.gle/HfJCQN8Qa62hxYrp8 — يشترط امتلاك حساب في التطبيق ومراجعة البيانات، ويطلب رقم حساب Lirati والاسم التجاري والعنوان والخريطة ورقم الهاتف والنشاط التجاري وصورة خارجية للمحل. لا يصف واجهة دفع لموقع أو API تحويل آلي؛ يبدو مسار اعتماد نقطة بيع فعلية.
- نموذج «خدمات ليراتي» المرتبط من الموقع: https://docs.google.com/forms/d/e/1FAIpQLScrUS6L2thq_O4kbF-uq-WxZ9svWMVoYyXpx1q8O_ihYieUhA/viewform?usp=header — يتطلب تسجيل الدخول إلى Google، لذلك لم تتوفر أسئلته العامة دون دخول.
- شروط Lirati الرسمية: https://lirati.app/terms.html?lang=ar — تؤكد مرحلة Beta وعدم حفظ Lirati لأموال المستخدمين، وتذكر أن التحويلات عند تفعيلها تتطلب التحقق من الأصل والشبكة والعنوان، وقد تكون معاملات البلوكشين غير قابلة للعكس. لا توجد في الصفحة وثائق عامة لـAPI تحويل دخل التاجر آلياً.

النتيجة: لا يمكن ربط عائدات البطاقة مباشرة بمحفظة Lirati من دون مزود دفع/تحويل يتيح سحباً إلى أصل رقمي مدعوم، وآلية مصرح بها من Lirati، وتحديد أصل وشبكة الاستلام. لا يجوز طلب أو تخزين عبارة الاسترداد أو المفتاح الخاص للمحفظة.

## Kuveyt Türk API للحوالات إلى IBAN (نتائج بحث أولية، 2026-11-14)

ظهرت في بوابة Kuveyt Türk الرسمية أقسام Account Management - Own Accounts وMoney Transfers، وصفحة المنتج تصف الاستعلام عن الرصيد وسجل العمليات والتحويلات. صفحة Money Transfer تصف بدء حوالة من حساب العميل، ولا تثبت وحدها وجود إشعار وارد أو مطابقة تلقائية لتحويلات العملاء. يلزم قراءة المستندات الرسمية قبل تقرير إمكانية تفعيل صلاحيات قراءة سجل الحساب.

- فهرس مستندات API: https://developer.kuveytturk.com.tr/documentation/api-integration-documents/documents
- تفاصيل إدارة الحسابات: https://developer.kuveytturk.com.tr/productdetail/account-managements
- مستند التحويلات: https://developer.kuveytturk.com.tr/documentation/money-transfers/all-money-transfer
- بوابة Kuveyt Türk API Market: https://developer.kuveytturk.com.tr/

## تحقق أعمق من مطابقة تحويلات IBAN عبر Kuveyt Türk (2026-11-14)

صفحة Account Management الرسمية تقول إن Account Transaction API تعيد قائمة معاملات الحسابات الجارية، وتذكر تحديثات آنية للرصيد وتاريخ العمليات. كما توضح أن المنتج يحتاج إلى التسجيل وتفعيل الحساب، وإنشاء التطبيق، واختبار APIs، ثم إرسال طلب GoLive. هذا يجعل رصد حوالة عميل واردة إلى حساب Kuveyt Türk احتمالاً تقنياً معقولاً إذا وافق البنك وفعّل صلاحيات الحساب المناسب.

لكن صفحة واجهة Money Transfer المنفصلة تصف عملية صادرة تبدأ حوالة من حساب العميل؛ لا ينبغي الخلط بينها وبين تأكيد تحويلات IBAN الواردة. مستندات Account Transactions وGoLive الرسمية لم تُستخرج عبر القراءة العامة، لذلك لم يتأكد بعد شكل الحقول أو آلية التفويض أو توفر إشعار فوري لكل عملية واردة. يجب أن يؤكد البنك هذه التفاصيل قبل وعد المستخدم بالتفعيل الآلي.

المصادر: https://developer.kuveytturk.com.tr/productdetail/account-managements وhttps://developer.kuveytturk.com.tr/documentation/money-transfers/all-money-transfer وhttps://developer.kuveytturk.com.tr/documentation/api-integration-documents/documents.

## تفعيل Account Transaction API — خطوات التسجيل والتفويض (2026-11-14)

تسلسل البنك المنشور: التسجيل وتفعيل ملف API Market؛ إنشاء تطبيق مع Redirect URL؛ اختيار واجهات Account Management - Own Accounts، وبالتحديد Account List وAccount Transaction؛ اختبارها في Sandbox؛ ثم تقديم طلب GoLive ومتابعة موافقة البنك. صفحة المنتج تصف Account Transaction API بأنها تعرض معاملات الحسابات الجارية وتذكر تحديثات آنية، لكن يجب سؤال البنك هل حساب العميل المعني مؤهل وكيف تُستلم التحديثات وما حقول المرجع المتاحة.

توثيق Authorization Code يوضح أن صاحب الحساب يُحوّل إلى صفحة تسجيل دخول Kuveyt Türk الرسمية، يراجع الصلاحيات ويضغط الموافقة، ثم يرجع رمز authorization إلى Redirect URL ويستبدله التطبيق خادميّاً بـAccess/Refresh Tokens. مثال البنك يستخدم scope=accounts؛ ينبغي استخدام scope الدقيق المعروض لواجهة الحساب. لاحتياجنا، اطلب صلاحية قراءة معاملات الحساب فقط، ولا تطلب صلاحية Outgoing Money Transfer. لا تُرسل إلى أي طرف كلمة مرور البنك أو رمز العميل أو Client Secret عبر الدردشة.

المصادر: https://developer.kuveytturk.com.tr/productdetail/account-managements وhttps://developer.kuveytturk.com.tr/documentation/introduction/creating-authorization-code-token وhttps://developer.kuveytturk.com.tr/documentation/api-integration-documents/documents.

## Binance Pay كخيار دفع (2026-11-14)

Binance Pay Merchant هو مسار لقبول مدفوعات الأصول الرقمية، وليس معالج بطاقات. صفحة Binance الرسمية تذكر التقديم لحساب تاجر، والتحقق من النشاط/الكيان، واتفاقية تاجر، ثم تكامل QR أو رابط أو API؛ كما تصف التسوية بأنها رقمية/مستقرة، وتذكر أن السحب إلى محفظة خارجية يتطلب تحديد الشبكة وتأكيداً ثنائياً. هذا لا يثبت توافره للتاجر في تركيا تحديداً.

نص اللائحة المنشور في الجريدة الرسمية التركية بتاريخ 16 أبريل 2021 يحظر الاستخدام المباشر أو غير المباشر للأصول المشفرة في المدفوعات، ويحظر تقديم خدمات لذلك الغرض؛ وبيان البنك المركزي يشرح اللائحة ومخاطر استخدام العملات المشفرة كوسيلة دفع. قبل قبول Binance Pay لاشتراكات تُباع من تركيا، يلزم تأكيد قانوني حديث من مختص في تركيا؛ لا يُقترح تفعيله حالياً كطريقة دفع للموقع.

المصادر: https://merchant.binance.com/en وhttps://www.binance.com/en/support/faq/detail/7a49148912214defa816f14ee51b9f9f وhttps://www.resmigazete.gov.tr/eskiler/2021/04/20210416-4.htm وhttps://tcmb.gov.tr/wps/wcm/connect/EN/TCMB+EN/Main+Menu/Announcements/Press+Releases/2021/ANO2021-17.

## مرجع تحويل الأسعار من USD إلى TRY (2026-11-14)

خلاصة أسعار TCMB اليومية الرسمية منشورة عبر https://www.tcmb.gov.tr/kurlar/today.xml وتحتوي على صف USD مع أسعار شراء/بيع. الخطة تستخدم سعر بيع USD المنشور كمرجع لحساب مبلغ التحويل بالليرة عند إصدار الطلب؛ تحفظ لقطة السعر والتاريخ مع الطلب حتى لا تتغير القيمة بعد إنشائها. هذا سعر مرجعي رسمي وقد يختلف عن سعر Kuveyt Türk، لذلك يجب عرض اسمه وتاريخ نشره للعميل. إذا تعذر جلب سعر صالح، لا يُنشأ طلب بمبلغ مخمّن.
