import { GoogleGenAI } from "@google/genai";
import ISO6391 from "iso-639-1";
import { readFile, writeFile, rename } from "node:fs/promises";
import path from "node:path";

const PROJECT = "/home/ubuntu/chatbiapp";
const SOURCE_PATH = path.join(PROJECT, "client/src/lib/ui-english.json");
const SOURCE_TS_PATH = path.join(PROJECT, "client/src/lib/ui-english.ts");
const PROGRESS_PATH = "/tmp/chatbi-ui-gemini-progress.json";
const OUTPUT_PATH = path.join(PROJECT, "client/src/lib/ui-translations.generated.ts");
const MODEL = "gemini-3.5-flash-lite";
const UI_LANGUAGE_CODES = [
  "ar", "en", "zh", "hi", "es", "fr", "pt", "ru", "de", "ja", "ko", "tr",
  "id", "bn", "ur", "fa", "sw", "it", "vi", "th", "nl", "he", "pl", "uk",
  "pa", "ms", "ta", "te", "mr", "jv", "tl", "ha", "yo", "ro", "el",
];
const KEY_BATCH_SIZE = 25;
const INTER_REQUEST_MS = 5_200;
const MAX_ATTEMPTS = 5;

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) throw new Error("GEMINI_API_KEY is unavailable in the project environment.");
const ai = new GoogleGenAI({ apiKey });
const source = JSON.parse(await readFile(SOURCE_PATH, "utf8"));
const sourceKeys = Object.keys(source);
const targets = UI_LANGUAGE_CODES.filter((code) => code !== "en");
const activeTargets = process.argv.includes("--pilot") ? ["ar"] : targets;
const placeholderSet = (value) => [...value.matchAll(/\{([A-Za-z0-9_]+)\}/g)].map((match) => match[1]).sort().join("|");

await writeFile(SOURCE_TS_PATH, `export const englishMessages = ${JSON.stringify(source, null, 2)} as const;\n`, "utf8");

let completed = {};
try {
  completed = JSON.parse(await readFile(PROGRESS_PATH, "utf8"));
} catch {
  completed = {};
}

function chunks(items, size) {
  const result = [];
  for (let index = 0; index < items.length; index += size) result.push(items.slice(index, index + size));
  return result;
}

function isValidValue(key, value) {
  return typeof value === "string" && value.trim().length > 0 && placeholderSet(value) === placeholderSet(source[key]);
}

function isComplete(dictionary) {
  return Boolean(dictionary && typeof dictionary === "object")
    && sourceKeys.every((key) => isValidValue(key, dictionary[key]))
    && Object.keys(dictionary).length === sourceKeys.length;
}

async function saveProgress() {
  const temp = `${PROGRESS_PATH}.tmp`;
  await writeFile(temp, JSON.stringify(completed), "utf8");
  await rename(temp, PROGRESS_PATH);
}

async function translateChunk(code, chunkKeys) {
  const sourceChunk = Object.fromEntries(chunkKeys.map((key) => [key, source[key]]));
  const languageName = ISO6391.getName(code) || code;
  const nativeName = ISO6391.getNativeName(code) || languageName;
  let previousIssue = "";

  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const prompt = [
      "You are a professional software localization translator. Translate every English UI string into the single requested language.",
      "Return valid JSON only, shaped exactly as {\"translations\": {\"<message-key>\": \"translated string\"}}.",
      "Include every requested key exactly once; do not add keys, comments, markdown fences, or explanations.",
      "Preserve every placeholder exactly, including braces and spelling, such as {formatted}, {date}, {count}, {average}, and {id}.",
      "Keep chatbi.AI, Free, Plus, Premium, TCMB, USD, TRY and +18 unchanged. Preserve codes and prices.",
      "Use concise, natural, respectful wording for UI labels, buttons, alerts, and help text. Use the target language's native writing system. Translate the adult-content policy accurately; do not soften or omit it.",
      `Target language: ${code}: ${nativeName} (${languageName})`,
      previousIssue ? `Your previous result failed validation. Correct these issues: ${previousIssue}` : "",
      "English message map:\n" + JSON.stringify(sourceChunk),
    ].filter(Boolean).join("\n\n");

    try {
      const response = await ai.models.generateContent({
        model: MODEL,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: {
          responseMimeType: "application/json",
          maxOutputTokens: 8192,
          temperature: 0.1,
          httpOptions: { timeout: 60_000 },
        },
      });
      const text = response.text?.trim();
      if (!text) throw new Error("Empty translation response");
      let parsed;
      try {
        parsed = JSON.parse(text);
      } catch {
        const firstBrace = text.indexOf("{");
        const lastBrace = text.lastIndexOf("}");
        if (firstBrace < 0 || lastBrace <= firstBrace) throw new Error("Response was not valid JSON");
        try {
          parsed = JSON.parse(text.slice(firstBrace, lastBrace + 1));
        } catch {
          throw new Error("Response was not valid JSON");
        }
      }
      const translations = parsed?.translations ?? parsed;
      const missing = chunkKeys.filter((key) => !Object.hasOwn(translations ?? {}, key));
      const extra = Object.keys(translations ?? {}).filter((key) => !Object.hasOwn(sourceChunk, key));
      const invalid = chunkKeys.filter((key) => Object.hasOwn(translations ?? {}, key) && !isValidValue(key, translations[key]));
      const issues = [
        missing.length ? `missing: ${missing.slice(0, 6).join(",")}` : "",
        extra.length ? `extra: ${extra.slice(0, 6).join(",")}` : "",
        invalid.length ? `invalid or placeholder mismatch: ${invalid.slice(0, 6).join(",")}` : "",
      ].filter(Boolean);
      if (issues.length) {
        previousIssue = issues.join("; ");
        if (attempt < MAX_ATTEMPTS) continue;
        throw new Error(`Translation validation failed: ${previousIssue}`);
      }
      return translations;
    } catch (error) {
      const name = error instanceof Error ? error.name : "unknown error";
      const message = error instanceof Error ? error.message : String(error);
      const safeMessage = message.replace(/AIza[0-9A-Za-z_-]{20,}/g, "[redacted]").slice(0, 500);
      const transient = /\b(408|409|429|500|502|503|504)\b|UNAVAILABLE|RESOURCE_EXHAUSTED|high demand|temporar|timeout|ECONNRESET|ETIMEDOUT/i.test(message);
      const validationRetry = /Translation validation failed|Empty translation response|Response was not valid JSON/i.test(message);
      if (attempt === MAX_ATTEMPTS && validationRetry && chunkKeys.length > 1) {
        const middle = Math.ceil(chunkKeys.length / 2);
        console.warn(`Splitting invalid ${code} translation batch (${chunkKeys.length} keys) into smaller batches.`);
        const left = await translateChunk(code, chunkKeys.slice(0, middle));
        const right = await translateChunk(code, chunkKeys.slice(middle));
        return { ...left, ...right };
      }
      if (attempt === MAX_ATTEMPTS || (!transient && !validationRetry)) {
        throw new Error(`Translation failed for ${code} (${chunkKeys[0]}..${chunkKeys.at(-1)}), ${name}: ${safeMessage}`);
      }
      const delay = transient
        ? Math.min(120_000, 15_000 * (2 ** (attempt - 1))) + Math.floor(Math.random() * 5_000)
        : 2_000;
      console.warn(`Temporary Gemini failure for ${code}; retry ${attempt + 1}/${MAX_ATTEMPTS} in ${Math.ceil(delay / 1000)}s.`);
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
  throw new Error(`Translation failed for ${code} (${chunkKeys[0]}..${chunkKeys.at(-1)}).`);
}

const needed = activeTargets.filter((code) => !isComplete(completed[code]));
const jobs = [];
for (const code of needed) {
  const existing = completed[code] && typeof completed[code] === "object" ? completed[code] : {};
  const validKeys = sourceKeys.filter((key) => isValidValue(key, existing[key]));
  const dictionary = Object.fromEntries(validKeys.map((key) => [key, existing[key]]));
  const missingKeys = sourceKeys.filter((key) => !isValidValue(key, dictionary[key]));
  for (const batch of chunks(missingKeys, KEY_BATCH_SIZE)) jobs.push({ code, batch });
  completed[code] = dictionary;
}

console.log(`Gemini localization: ${needed.length}/${targets.length} locales incomplete; ${sourceKeys.length} UI messages; ${jobs.length} key batches.`);
for (let index = 0; index < jobs.length; index++) {
  const { code, batch } = jobs[index];
  const translations = await translateChunk(code, batch);
  completed[code] = { ...completed[code], ...translations };
  await saveProgress();
  console.log(`Completed ${index + 1}/${jobs.length}: ${code} (${batch.length} keys)`);
  if (index < jobs.length - 1) await new Promise((resolve) => setTimeout(resolve, INTER_REQUEST_MS));
}

if (process.argv.includes("--pilot")) {
  console.log(`Pilot batch saved for ar; ${Object.keys(completed.ar ?? {}).length}/${sourceKeys.length} keys recorded.`);
  process.exit(0);
}

const incomplete = targets.filter((code) => !isComplete(completed[code]));
if (incomplete.length) throw new Error(`Incomplete locale dictionaries: ${incomplete.join(", ")}`);
const generated = {
  en: source,
  ...Object.fromEntries(targets.map((code) => [code, completed[code]])),
};
const output = `export const generatedTranslations: Record<string, Record<string, string>> = ${JSON.stringify(generated)};\n`;
const outputTemp = `${OUTPUT_PATH}.tmp`;
await writeFile(outputTemp, output, "utf8");
await rename(outputTemp, OUTPUT_PATH);
console.log(`Saved ${Object.keys(generated).length} complete locale dictionaries to ${OUTPUT_PATH}.`);
