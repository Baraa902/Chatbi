import React, { createContext, useContext, useEffect, useState } from "react";

export const ACCENT_THEMES = [
  { id: "pink", labelKey: "themePink", color: "#ec4899" },
  { id: "blue", labelKey: "themeBlue", color: "#38bdf8" },
  { id: "red", labelKey: "themeRed", color: "#f87171" },
  { id: "yellow", labelKey: "themeYellow", color: "#facc15" },
  { id: "green", labelKey: "themeGreen", color: "#4ade80" },
  { id: "purple", labelKey: "themePurple", color: "#a78bfa" },
] as const;

export type AccentThemeId = (typeof ACCENT_THEMES)[number]["id"];

interface AccentThemeContextValue {
  accentTheme: AccentThemeId;
  setAccentTheme: (theme: AccentThemeId) => void;
}

const STORAGE_KEY = "chatbi-accent-theme";
const AccentThemeContext = createContext<AccentThemeContextValue | undefined>(undefined);

function isAccentTheme(value: string | null): value is AccentThemeId {
  return ACCENT_THEMES.some((theme) => theme.id === value);
}

function readSavedAccentTheme(): AccentThemeId {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    return isAccentTheme(saved) ? saved : "purple";
  } catch {
    return "purple";
  }
}

export function AccentThemeProvider({ children }: { children: React.ReactNode }) {
  const [accentTheme, setAccentTheme] = useState<AccentThemeId>(readSavedAccentTheme);

  useEffect(() => {
    document.documentElement.dataset.chatbiAccent = accentTheme;
    try {
      window.localStorage.setItem(STORAGE_KEY, accentTheme);
    } catch {
      // The selected color still applies for the current page if storage is unavailable.
    }
  }, [accentTheme]);

  return (
    <AccentThemeContext.Provider value={{ accentTheme, setAccentTheme }}>
      {children}
    </AccentThemeContext.Provider>
  );
}

export function useAccentTheme() {
  const context = useContext(AccentThemeContext);
  if (!context) {
    throw new Error("useAccentTheme must be used within AccentThemeProvider");
  }
  return context;
}
