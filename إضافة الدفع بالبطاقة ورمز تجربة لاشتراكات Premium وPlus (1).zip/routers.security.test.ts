import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const { dbMock, generateGeminiReply } = vi.hoisted(() => ({
  dbMock: {
    consumeRateLimit: vi.fn(),
    getTrialRedemption: vi.fn(),
    recordTrialFailure: vi.fn(),
    redeemTrial: vi.fn(),
    getMembershipSummary: vi.fn(),
    updateTrialSelection: vi.fn(),
    recordAdminCodeFailure: vi.fn(),
    getAdminStatistics: vi.fn(),
    getChatThread: vi.fn(),
    deleteChatThread: vi.fn(),
    ensureUserMessage: vi.fn(),
    getAssistantReply: vi.fn(),
    touchChatThread: vi.fn(),
    getUserSettings: vi.fn(),
    getRecentChatMessages: vi.fn(),
    createAssistantReply: vi.fn(),
    listChatMessages: vi.fn(),
  },
  generateGeminiReply: vi.fn(),
}));

vi.mock("./db", () => dbMock);
vi.mock("./_core/gemini", () => ({ generateGeminiReply }));

import { appRouter } from "./routers";

type Role = "user" | "admin";

function createContext(role: Role = "user", id = 7): TrpcContext {
  const user: NonNullable<TrpcContext["user"]> = {
    id,
    openId: `test-user-${id}`,
    name: "Test User",
    email: "test@example.com",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const allowed = { allowed: true, remaining: 9, retryAfterSeconds: 60 };
const limited = { allowed: false, remaining: 0, retryAfterSeconds: 60 };

beforeEach(() => {
  vi.clearAllMocks();
  dbMock.consumeRateLimit.mockResolvedValue(allowed);
  dbMock.getTrialRedemption.mockResolvedValue(undefined);
  dbMock.recordTrialFailure.mockResolvedValue(undefined);
  dbMock.recordAdminCodeFailure.mockResolvedValue(undefined);
});

afterEach(() => {
  vi.unstubAllEnvs();
});

describe("owner analytics access", () => {
  it("allows a signed-in non-admin account with the correct code to view aggregate counts", async () => {
    vi.stubEnv("CHATBI_ADMIN_PANEL_CODE", "unit-test-admin-code");
    const statistics = { registeredAccounts: 12, plusEver: 4, premiumEver: 2, plusActive: 3, premiumActive: 2 };
    dbMock.getAdminStatistics.mockResolvedValue(statistics);
    const caller = appRouter.createCaller(createContext("user"));

    await expect(caller.analytics.unlock({ code: "unit-test-admin-code" })).resolves.toEqual(statistics);
    expect(dbMock.consumeRateLimit).toHaveBeenCalledTimes(2);
    expect(dbMock.getAdminStatistics).toHaveBeenCalledTimes(1);
  });

  it("returns aggregate statistics only after the admin role and code both pass", async () => {
    vi.stubEnv("CHATBI_ADMIN_PANEL_CODE", "unit-test-admin-code");
    const statistics = { registeredAccounts: 12, plusEver: 4, premiumEver: 2, plusActive: 3, premiumActive: 2 };
    dbMock.getAdminStatistics.mockResolvedValue(statistics);
    const caller = appRouter.createCaller(createContext("admin"));

    await expect(caller.analytics.unlock({ code: "unit-test-admin-code" })).resolves.toEqual(statistics);
    expect(dbMock.consumeRateLimit).toHaveBeenCalledTimes(2);
    expect(dbMock.getAdminStatistics).toHaveBeenCalledTimes(1);
  });

  it("records an invalid owner-code attempt without returning the statistics", async () => {
    vi.stubEnv("CHATBI_ADMIN_PANEL_CODE", "unit-test-admin-code");
    const caller = appRouter.createCaller(createContext("admin"));

    await expect(caller.analytics.unlock({ code: "wrong-code" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(dbMock.recordAdminCodeFailure).toHaveBeenCalledWith(7);
    expect(dbMock.getAdminStatistics).not.toHaveBeenCalled();
  });

  it("stops owner-code attempts when the atomic limiter is exhausted", async () => {
    vi.stubEnv("CHATBI_ADMIN_PANEL_CODE", "unit-test-admin-code");
    dbMock.consumeRateLimit.mockResolvedValue(limited);
    const caller = appRouter.createCaller(createContext("admin"));

    await expect(caller.analytics.unlock({ code: "unit-test-admin-code" })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(dbMock.getAdminStatistics).not.toHaveBeenCalled();
  });
});

describe("trial plan management", () => {
  it("records a wrong trial code and never grants an entitlement", async () => {
    vi.stubEnv("CHATBI_TRIAL_CODE", "unit-test-trial-code");
    const caller = appRouter.createCaller(createContext("user"));

    await expect(caller.membership.verifyTrialCode({ code: "wrong-code" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(dbMock.recordTrialFailure).toHaveBeenCalledWith(7);
    expect(dbMock.redeemTrial).not.toHaveBeenCalled();
  });

  it("lets only the account with a recorded redemption change or cancel its own trial selection", async () => {
    const summary = { currentPlan: "premium", plus: false, premium: true, trialRedeemed: true, trialPlusGranted: false, trialPremiumGranted: true, redeemedAt: new Date() };
    dbMock.updateTrialSelection.mockResolvedValue(true);
    dbMock.getMembershipSummary.mockResolvedValue(summary);
    const caller = appRouter.createCaller(createContext("user", 9));

    await expect(caller.membership.updateTrialSelection({ plus: true, premium: false })).resolves.toEqual(summary);
    expect(dbMock.updateTrialSelection).toHaveBeenCalledWith(9, { plus: true, premium: false });
  });

  it("does not allow plan switching on an account without a trial redemption", async () => {
    dbMock.updateTrialSelection.mockResolvedValue(false);
    const caller = appRouter.createCaller(createContext("user", 9));

    await expect(caller.membership.updateTrialSelection({ plus: false, premium: false })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(dbMock.getMembershipSummary).not.toHaveBeenCalled();
  });
});

describe("chat request protection", () => {
  it("does not reveal another account's conversation or call Gemini", async () => {
    dbMock.getChatThread.mockResolvedValue(undefined);
    const caller = appRouter.createCaller(createContext("user", 7));

    await expect(caller.chat.sendMessage({
      threadId: "ef2829a7-14a2-4a7f-a7b8-299a1643fb64",
      clientMessageId: "ca09db55-3269-471c-8c76-7d114105925b",
      content: "Hello",
    })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(generateGeminiReply).not.toHaveBeenCalled();
  });

  it("blocks over-limit Gemini calls before loading context or invoking the model", async () => {
    dbMock.getChatThread.mockResolvedValue({ id: "ef2829a7-14a2-4a7f-a7b8-299a1643fb64", userId: 7, title: "" });
    dbMock.ensureUserMessage.mockResolvedValue({ id: 25, userId: 7, role: "user", content: "Hello" });
    dbMock.getAssistantReply.mockResolvedValue(undefined);
    dbMock.consumeRateLimit.mockResolvedValue(limited);
    const caller = appRouter.createCaller(createContext("user", 7));

    await expect(caller.chat.sendMessage({
      threadId: "ef2829a7-14a2-4a7f-a7b8-299a1643fb64",
      clientMessageId: "ca09db55-3269-471c-8c76-7d114105925b",
      content: "Hello",
    })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(generateGeminiReply).not.toHaveBeenCalled();
    expect(dbMock.getRecentChatMessages).not.toHaveBeenCalled();
  });
});

describe("conversation deletion", () => {
  it("deletes only the selected conversation for the signed-in account", async () => {
    const threadId = "ef2829a7-14a2-4a7f-a7b8-299a1643fb64";
    dbMock.deleteChatThread.mockResolvedValue(true);
    const caller = appRouter.createCaller(createContext("user", 7));

    await expect(caller.chat.deleteThread({ threadId })).resolves.toEqual({ deleted: true });
    expect(dbMock.deleteChatThread).toHaveBeenCalledWith(7, threadId);
  });

  it("does not confirm deletion of a conversation that is not owned by the account", async () => {
    const threadId = "ef2829a7-14a2-4a7f-a7b8-299a1643fb64";
    dbMock.deleteChatThread.mockResolvedValue(false);
    const caller = appRouter.createCaller(createContext("user", 7));

    await expect(caller.chat.deleteThread({ threadId })).rejects.toMatchObject({ code: "NOT_FOUND" });
    expect(dbMock.deleteChatThread).toHaveBeenCalledWith(7, threadId);
  });
});
