import { createContext, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { LANGUAGE_OPTIONS } from "@shared/languages";
import { englishMessages } from "./ui-english";
import { generatedTranslations } from "./ui-translations.generated";

export const UI_LANGUAGE_CODES = [
  "ar", "en", "zh", "hi", "es", "fr", "pt", "ru", "de", "ja", "ko", "tr",
  "id", "bn", "ur", "fa", "sw", "it", "vi", "th", "nl", "he", "pl", "uk",
  "pa", "ms", "ta", "te", "mr", "jv", "tl", "ha", "yo", "ro", "el",
] as const;

export type Locale = (typeof UI_LANGUAGE_CODES)[number];
export type TranslationKey = keyof typeof englishMessages;
type TranslationValues = Record<string, string | number>;

export const INTERFACE_LANGUAGE_OPTIONS = UI_LANGUAGE_CODES.map((code) => {
  const language = LANGUAGE_OPTIONS.find((option) => option.code === code);
  if (code === "zh") {
    return { code, nativeName: "中文（普通话）", englishName: "Chinese (Mandarin)" };
  }
  if (code === "tl") {
    return { code, nativeName: "Filipino", englishName: "Filipino (Tagalog)" };
  }
  return {
    code,
    nativeName: language?.nativeName ?? code.toUpperCase(),
    englishName: language?.englishName ?? code.toUpperCase(),
  };
});

const rtlLocales = new Set<Locale>(["ar", "fa", "ur", "he"]);

type LocaleContextValue = {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  dir: "rtl" | "ltr";
  t: (key: TranslationKey, values?: TranslationValues) => string;
};

const LocaleContext = createContext<LocaleContextValue | null>(null);

function isLocale(value: string | null): value is Locale {
  return value !== null && (UI_LANGUAGE_CODES as readonly string[]).includes(value);
}

function initialLocale(): Locale {
  try {
    const saved = localStorage.getItem("chatbi-ui-locale");
    return isLocale(saved) ? saved : "ar";
  } catch {
    return "ar";
  }
}

function interpolate(template: string, values?: TranslationValues) {
  if (!values) return template;
  return template.replace(/\{([A-Za-z0-9_]+)\}/g, (placeholder, key: string) =>
    Object.hasOwn(values, key) ? String(values[key]) : placeholder,
  );
}

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocale] = useState<Locale>(initialLocale);
  const dir = rtlLocales.has(locale) ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
    try {
      localStorage.setItem("chatbi-ui-locale", locale);
    } catch {
      // The interface remains usable if browser storage is disabled.
    }
  }, [locale, dir]);

  const value = useMemo<LocaleContextValue>(() => {
    const dictionary = generatedTranslations[locale] ?? englishMessages;
    return {
      locale,
      setLocale,
      dir,
      t: (key, values) => interpolate(dictionary[key] ?? englishMessages[key] ?? key, values),
    };
  }, [locale, dir]);

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale() {
  const value = useContext(LocaleContext);
  if (!value) throw new Error("useLocale must be used within LocaleProvider");
  return value;
}
