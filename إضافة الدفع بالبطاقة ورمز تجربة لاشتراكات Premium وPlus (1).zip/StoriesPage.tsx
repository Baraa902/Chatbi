import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import ChatbiShell from "@/components/ChatbiShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useLocale } from "@/lib/locale";
import { usePageSeo } from "@/lib/seo";
import { trpc } from "@/lib/trpc";
import { BookOpen, Loader2, MessageSquareWarning, Send, Star } from "lucide-react";

export default function StoriesPage() {
  const { user } = useAuth();
  const { locale, dir, t } = useLocale();
  usePageSeo({ title: t("storiesTitle"), description: t("storiesSubtitle"), robots: "noindex, nofollow", canonical: true });
  const utils = trpc.useUtils();
  const stories = trpc.stories.listPublic.useQuery();
  const mine = trpc.stories.mySubmissions.useQuery(undefined, { enabled: !!user });
  const [title, setTitle] = useState(""); const [body, setBody] = useState(""); const [pseudonym, setPseudonym] = useState("");
  const [reportId, setReportId] = useState<number | null>(null); const [reportReason, setReportReason] = useState(""); const [feedback, setFeedback] = useState("");
  const submit = trpc.stories.submit.useMutation({ onSuccess: async () => { await Promise.all([utils.stories.listPublic.invalidate(), utils.stories.mySubmissions.invalidate()]); setTitle(""); setBody(""); setPseudonym(""); setFeedback(t("storySubmitSuccess")); } });
  const rate = trpc.stories.rate.useMutation({ onSuccess: async () => { setFeedback(t("ratingSaved")); await utils.stories.listPublic.invalidate(); } });
  const report = trpc.stories.report.useMutation({ onSuccess: () => { setReportId(null); setReportReason(""); setFeedback(t("reportSent")); } });
  const submitError = submit.error ? t("storySubmitError") : "";
  const ratingError = rate.error ? t("ratingError") : "";
  const reportError = report.error ? t("reportError") : "";
  return <ChatbiShell activePath="/stories">
    <main className="mx-auto w-full max-w-5xl px-4 py-8 sm:px-6 md:py-12" dir={dir}>
      <header className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div><div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-violet-500/15 text-violet-200"><BookOpen /></div><h1 className="text-3xl font-bold tracking-tight">{t("storiesTitle")}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-white/55">{t("storiesSubtitle")}</p></div>
        {!user && <Button onClick={() => startLogin()} className="rounded-xl bg-violet-500 hover:bg-violet-400">{t("signInToShare")}</Button>}
      </header>
      {user ? <section className="mb-10 rounded-2xl border border-white/10 bg-white/[.03] p-5 sm:p-6"><h2 className="mb-1 text-lg font-semibold">{t("shareStory")}</h2><p className="mb-5 text-sm text-white/45">{t("storyReviewNotice")}</p>
        <form onSubmit={e => { e.preventDefault(); setFeedback(""); submit.mutate({ title, body, pseudonym }); }} className="space-y-4">
          <label className="block text-sm"><span className="mb-1.5 block text-white/75">{t("storyTitleLabel")}</span><Input value={title} onChange={e => setTitle(e.target.value)} minLength={1} maxLength={140} required placeholder={t("storyTitlePlaceholder")} aria-label={t("storyTitleLabel")} className="border-white/10 bg-black/20 text-white" /></label>
          <label className="block text-sm"><span className="mb-1.5 block text-white/75">{t("storyBodyLabel")}</span><Textarea value={body} onChange={e => setBody(e.target.value)} minLength={50} maxLength={10000} required rows={7} placeholder={t("storyBodyPlaceholder")} aria-label={t("storyBodyLabel")} className="resize-y border-white/10 bg-black/20 text-white" /><span className="mt-1 block text-end text-xs text-white/35">{new Intl.NumberFormat(locale).format(body.length)}/{new Intl.NumberFormat(locale).format(10000)}</span><span className="mt-1 block text-xs leading-5 text-white/35">{t("storyLengthHelp")}</span></label>
          <label className="block max-w-md text-sm"><span className="mb-1.5 block text-white/75">{t("pseudonymLabel")}</span><Input value={pseudonym} onChange={e => setPseudonym(e.target.value)} maxLength={50} placeholder={t("pseudonymPlaceholder")} aria-label={t("pseudonymLabel")} className="border-white/10 bg-black/20 text-white" /></label>
          <p className="text-xs leading-5 text-white/35">{t("storyPrivacyNote")}</p>
          <div className="flex flex-wrap items-center gap-3"><Button type="submit" disabled={submit.isPending || title.trim().length < 1 || body.length < 50} className="gap-2 rounded-xl bg-violet-500 hover:bg-violet-400">{submit.isPending ? <Loader2 className="animate-spin" size={16} /> : <Send size={16} />}{submit.isPending ? t("submitting") : t("submitForReview")}</Button><span role="status" className="text-sm text-emerald-300">{feedback}</span>{submitError && <span role="alert" className="text-sm text-rose-300">{submitError}</span>}</div>
        </form>
        {!!mine.data?.length && <div className="mt-6 border-t border-white/10 pt-4"><h3 className="mb-2 text-sm font-semibold">{t("myStories")}</h3><ul className="space-y-2">{mine.data.map(s => <li key={s.id} className="flex justify-between gap-3 text-sm"><span className="truncate">{s.title}</span><span className="shrink-0 text-white/45">{s.status === "pending" ? t("storyPending") : s.status === "published" ? t("storyPublished") : s.status === "rejected" ? t("storyRejected") : s.status}</span></li>)}</ul></div>}
      </section> : <div className="mb-10 rounded-2xl border border-white/10 bg-white/[.03] p-5 text-sm text-white/60">{t("storiesPublicNote")}</div>}
      {stories.isLoading ? <div className="flex items-center gap-2 py-12 text-white/50"><Loader2 className="animate-spin" size={18} />{t("working")}</div> : stories.error ? <p role="alert" className="py-8 text-sm text-rose-300">{t("storiesLoadError")}</p> : !stories.data?.length ? <div className="rounded-2xl border border-dashed border-white/10 p-10 text-center text-white/45">{t("storiesEmpty")}</div> : <section aria-label={t("storiesPublishedTitle")} className="grid gap-4">{stories.data.map(story => { const average = new Intl.NumberFormat(locale, { minimumFractionDigits: 1, maximumFractionDigits: 1 }).format(story.averageRating); const count = new Intl.NumberFormat(locale).format(story.ratingCount); return <article key={story.id} className="rounded-2xl border border-white/10 bg-[#12101d] p-5 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-xl font-semibold leading-snug">{story.title}</h2><p className="mt-1 text-xs text-white/40">{story.pseudonym || t("anonymous")} · {new Date(story.submittedAt).toLocaleDateString(locale)}</p></div><div className="flex items-center gap-1 text-amber-300" aria-label={t("storyAverageAccessible", { average, count })}><Star size={16} fill="currentColor" /><span className="text-sm font-semibold">{average}</span><span className="text-xs text-white/40">{t("storyRatingCount", { count })}</span></div></div><p className="mt-4 whitespace-pre-wrap break-words text-sm leading-7 text-white/75">{story.body}</p>
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-white/8 pt-4"><div className="flex items-center gap-2"><span className="text-xs text-white/45">{t("yourRating")}</span>{story.isOwner ? <span className="text-xs text-white/40">{t("ownStoryRating")}</span> : user ? <div role="group" aria-label={t("rateStory")} className="flex">{[1,2,3,4,5].map(n => <button key={n} type="button" onClick={() => rate.mutate({ storyId: story.id, rating: n })} aria-label={t("storyRatingStars", { count: new Intl.NumberFormat(locale).format(n) })} aria-pressed={story.myRating === n} className="rounded p-1 text-amber-300 hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-violet-300"><Star size={18} fill={(story.myRating ?? 0) >= n ? "currentColor" : "none"} /></button>)}</div> : <button className="text-xs text-violet-300 underline" onClick={() => startLogin()}>{t("signInToRate")}</button>}</div>
          {user && <Button variant="ghost" size="sm" onClick={() => { setReportId(story.id); setReportReason(""); }} className="gap-2 text-white/45 hover:text-rose-300"><MessageSquareWarning size={15} />{t("reportStory")}</Button>}
        </div>{ratingError && <p role="alert" className="mt-2 text-xs text-rose-300">{ratingError}</p>}
        {reportId === story.id && <form onSubmit={e => { e.preventDefault(); report.mutate({ storyId: story.id, reason: reportReason }); }} className="mt-4 flex flex-col gap-2 rounded-xl bg-white/[.04] p-3 sm:flex-row"><label className="sr-only" htmlFor={`report-${story.id}`}>{t("reportReason")}</label><Input id={`report-${story.id}`} value={reportReason} onChange={e => setReportReason(e.target.value)} maxLength={500} required placeholder={t("reportReasonPlaceholder")} className="border-white/10 bg-black/20 text-white" /><Button type="submit" disabled={report.isPending || !reportReason.trim()} className="bg-rose-600 hover:bg-rose-500">{report.isPending ? <Loader2 size={15} className="animate-spin" /> : t("sendReport")}</Button><Button type="button" variant="ghost" onClick={() => setReportId(null)}>{t("cancel")}</Button>{reportError && <span role="alert" className="text-xs text-rose-300">{reportError}</span>}</form>}
      </article>; })}</section>}
    </main>
  </ChatbiShell>;
}
