import { Button } from "@/components/ui/button";
import { useLocale } from "@/lib/locale";
import { PLAN_CATALOG, type PlanId } from "@shared/plans";
import { trpc } from "@/lib/trpc";
import { Check, LockKeyhole, Sparkles } from "lucide-react";

type MembershipState = { plus: boolean; premium: boolean };

type PlanCardsProps = {
  membership?: MembershipState;
  onManage?: () => void;
};

export default function PlanCards({ membership, onManage }: PlanCardsProps) {
  const { locale, t } = useLocale();
  const quote = trpc.currency.usdTryQuote.useQuery(undefined, { staleTime: 60 * 60 * 1000, retry: false });
  const formatTryEstimate = (usdPrice: number) => {
    if (!quote.data) return null;
    const amount = Math.round(usdPrice * quote.data.usdTry * 100) / 100;
    const formatted = new Intl.NumberFormat(locale, {
      style: "currency",
      currency: "TRY",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
    const parsedDate = new Date(`${quote.data.rateDate}T00:00:00`);
    const date = Number.isNaN(parsedDate.getTime())
      ? quote.data.rateDate
      : new Intl.DateTimeFormat(locale, { dateStyle: "medium" }).format(parsedDate);
    return t("tryEstimate", { formatted, date });
  };
  const plans: PlanId[] = ["free", "plus", "premium"];

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {plans.map((plan) => {
        const details = PLAN_CATALOG[plan];
        const active = plan === "free"
          ? Boolean(membership && !membership.plus && !membership.premium)
          : Boolean(membership?.[plan]);
        const isFeatured = plan === "premium";
        return (
          <article key={plan} className={`relative flex h-full flex-col overflow-hidden rounded-2xl border p-5 ${isFeatured ? "border-violet-400/40 bg-gradient-to-b from-violet-500/12 to-[#11101d] shadow-[0_18px_60px_rgba(139,92,246,.08)]" : "border-white/10 bg-white/[.025]"}`}>
            {isFeatured && <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-300/70 to-transparent" />}
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="text-xl font-semibold">{t(plan)}</h3>
                <p className="mt-1 text-xs text-white/45">{plan === "free" ? t("startFree") : t("cardPayment")}</p>
              </div>
              {isFeatured ? <span className="rounded-full bg-violet-400/15 px-2.5 py-1 text-[10px] font-semibold tracking-wide text-violet-200">PREMIUM</span> : <Sparkles className="text-white/30" size={18} />}
            </div>
            <div className="mt-6 flex items-baseline gap-1">
              <span className="text-4xl font-semibold tracking-tight">${details.price}</span>
              {details.interval && <span className="text-sm text-white/45">/ {t("month")}</span>}
            </div>
            {plan !== "free" && (
              <p className="mt-2 min-h-4 text-[11px] leading-5 text-white/45">
                {formatTryEstimate(details.price) ?? (quote.isError ? t("rateUnavailable") : null)}
              </p>
            )}
            <div className="my-5 h-px bg-white/8" />
            <ul className="flex-1 space-y-3">
              {details.features.map((featureKey) => (
                <li key={featureKey} className="flex gap-2.5 text-sm leading-6 text-white/75">
                  <Check size={16} className="mt-1 shrink-0 text-violet-300" />
                  <span>{t(featureKey)}</span>
                </li>
              ))}
            </ul>
            {plan === "free" ? (
              <Button variant="outline" className="mt-6 w-full rounded-xl border-white/12 bg-white/[.03] text-white hover:bg-white/[.07]" disabled={active}>
                {active ? t("active") : t("freePlan")}
              </Button>
            ) : (
              <Button onClick={onManage} disabled className="mt-6 w-full rounded-xl bg-violet-500/55 text-white/75 disabled:cursor-not-allowed">
                <LockKeyhole size={15} /> {t("paymentSetup")}
              </Button>
            )}
            {active && plan !== "free" && <p className="mt-2 text-center text-xs text-emerald-300">{t("active")}</p>}
          </article>
        );
      })}
    </div>
  );
}
