import express, { type Express } from "express";
import fs from "fs";
import { type Server } from "http";
import { nanoid } from "nanoid";
import path from "path";
import { createServer as createViteServer } from "vite";
import viteConfig from "../../vite.config";
import { renderSeoHtml, resolveSeoPage } from "./seo";

function isHtmlGet(req: express.Request) {
  return req.method === "GET" && Boolean(req.accepts("html"));
}

function applySeoHeaders(res: express.Response, page: { robots: string; private: boolean }) {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.setHeader("X-Robots-Tag", page.robots);
  res.setHeader("Cache-Control", page.private ? "no-store" : "no-cache");
}

export async function setupVite(app: Express, server: Server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true as const,
  };

  const vite = await createViteServer({
    ...viteConfig,
    configFile: false,
    // Keep the file-serving limits of vite.config.ts; only the options above differ here.
    server: { ...viteConfig.server, ...serverOptions },
    appType: "custom",
  });

  // Return route-specific, content-bearing HTML before Vite's SPA fallback.
  app.use(async (req, res, next) => {
    if (!isHtmlGet(req)) return next();
    const page = resolveSeoPage(req.path);
    if (!page) return next();

    try {
      const clientTemplate = path.resolve(import.meta.dirname, "../..", "client", "index.html");
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(`src="/src/main.tsx"`, `src="/src/main.tsx?v=${nanoid()}"`);
      const { html } = renderSeoHtml(template, req.path);
      const transformed = await vite.transformIndexHtml(req.originalUrl, html);
      applySeoHeaders(res, page);
      res.status(page.status).end(transformed);
    } catch (error) {
      vite.ssrFixStacktrace(error as Error);
      next(error);
    }
  });

  app.use(vite.middlewares);

  // Unknown HTML routes receive a real 404, not the SPA's success shell.
  app.use("*", async (req, res, next) => {
    if (!isHtmlGet(req)) return next();
    if (req.path.startsWith("/api/") || req.path.startsWith("/manus-oauth/")) {
      return res.status(404).json({ error: "Not found" });
    }

    try {
      const clientTemplate = path.resolve(import.meta.dirname, "../..", "client", "index.html");
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(`src="/src/main.tsx"`, `src="/src/main.tsx?v=${nanoid()}"`);
      const { html, page } = renderSeoHtml(template, "/404", true);
      const transformed = await vite.transformIndexHtml(req.originalUrl, html);
      applySeoHeaders(res, page);
      res.status(404).end(transformed);
    } catch (error) {
      vite.ssrFixStacktrace(error as Error);
      next(error);
    }
  });
}

export function serveStatic(app: Express) {
  const distPath = path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(`Could not find the build directory: ${distPath}, make sure to build the client first`);
  }

  app.use(async (req, res, next) => {
    if (!isHtmlGet(req)) return next();
    const page = resolveSeoPage(req.path);
    if (!page) return next();

    try {
      const template = await fs.promises.readFile(path.resolve(distPath, "index.html"), "utf-8");
      const { html } = renderSeoHtml(template, req.path);
      applySeoHeaders(res, page);
      res.status(page.status).send(html);
    } catch (error) {
      next(error);
    }
  });

  app.use(express.static(distPath));

  // Unknown HTML routes receive a real 404, not the SPA's success shell.
  app.use("*", async (req, res, next) => {
    if (!isHtmlGet(req)) return next();
    if (req.path.startsWith("/api/") || req.path.startsWith("/manus-oauth/")) {
      return res.status(404).json({ error: "Not found" });
    }
    if (path.extname(req.path)) return res.status(404).type("text/plain").send("Not found");

    try {
      const template = await fs.promises.readFile(path.resolve(distPath, "index.html"), "utf-8");
      const { html, page } = renderSeoHtml(template, "/404", true);
      applySeoHeaders(res, page);
      res.status(404).send(html);
    } catch (error) {
      next(error);
    }
  });
}
