import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocale } from "@/lib/locale";
import { trpc } from "@/lib/trpc";
import { Check, Eye, Loader2, LockKeyhole, RefreshCw, ShieldAlert, X } from "lucide-react";
import { useState } from "react";

type Decision = "publish" | "reject" | "closeReport";
type ModerationQueue = {
  pending: Array<{ id: number; title: string; body: string; pseudonym: string | null }>;
  reports: Array<{ id: number; storyId: number; reason: string; title: string; body: string; pseudonym: string | null }>;
};

export default function StoryModeration() {
  const { t } = useLocale();
  const [draftCode, setDraftCode] = useState("");
  const [secretCode, setSecretCode] = useState("");
  const [queueData, setQueueData] = useState<ModerationQueue | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState("");
  const loadQueue = trpc.stories.moderationQueue.useMutation({ onSuccess: setQueueData });
  const moderate = trpc.stories.moderate.useMutation();

  const unlock = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const candidate = draftCode.trim();
    if (!candidate) return;
    setError("");
    setSecretCode(candidate);
    setDraftCode("");
    try {
      const result = await loadQueue.mutateAsync({ code: candidate });
      setQueueData(result);
      setUnlocked(true);
    } catch {
      setSecretCode("");
      setUnlocked(false);
      setError(t("moderationCodeError"));
    }
  };
  const lock = () => { setUnlocked(false); setSecretCode(""); setDraftCode(""); setQueueData(null); setError(""); };
  const refresh = async () => {
    if (!secretCode) return;
    setError("");
    try { const result = await loadQueue.mutateAsync({ code: secretCode }); setQueueData(result); }
    catch { setError(t("storyModerationError")); }
  };
  const act = async (storyId: number, decision: Decision, reportId?: number) => {
    setError("");
    try {
      await moderate.mutateAsync({ code: secretCode, storyId, decision, ...(reportId ? { reportId } : {}) });
      const result = await loadQueue.mutateAsync({ code: secretCode });
      setQueueData(result);
      return true;
    } catch { setError(t("storyModerationError")); return false; }
  };
  const rejectReportedStory = async (storyId: number, reportId: number) => {
    if (await act(storyId, "reject")) await act(storyId, "closeReport", reportId);
  };
  const pending = queueData?.pending ?? [];
  const reports = queueData?.reports ?? [];
  const busy = loadQueue.isPending || moderate.isPending;

  return (
    <Card className="mb-5 border-violet-300/20 bg-gradient-to-br from-violet-500/[.08] to-white/[.02] text-inherit">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><ShieldAlert size={18} aria-hidden="true" />{t("moderationTitle")}</CardTitle>
        <p className="text-sm text-muted-foreground">{t("moderationDescription")}</p>
      </CardHeader>
      <CardContent>
        {!unlocked ? (
          <form onSubmit={unlock} className="flex flex-col gap-2 sm:flex-row" aria-label={t("openModeration")}>
            <label className="sr-only" htmlFor="story-moderation-code">{t("moderationCodePlaceholder")}</label>
            <div className="relative min-w-0 flex-1">
              <LockKeyhole className="pointer-events-none absolute top-3 h-4 w-4 text-muted-foreground ltr:left-3 rtl:right-3" aria-hidden="true" />
              <input id="story-moderation-code" type="password" value={draftCode} onChange={(event) => setDraftCode(event.target.value)} autoComplete="off" maxLength={64} required className="h-10 w-full rounded-md border border-input bg-background px-10 text-sm outline-none focus-visible:ring-2 focus-visible:ring-ring" placeholder={t("moderationCodePlaceholder")} />
            </div>
            <Button type="submit" disabled={!draftCode.trim() || loadQueue.isPending}>
              {loadQueue.isPending ? <Loader2 size={16} className="animate-spin" aria-hidden="true" /> : <Eye size={16} aria-hidden="true" />}
              <span className="ms-2">{t("openModeration")}</span>
            </Button>
          </form>
        ) : (
          <>
            <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm text-muted-foreground">{t("queueUnlocked")}</p>
              <div className="flex gap-2">
                <Button type="button" variant="outline" size="sm" onClick={() => void refresh()} disabled={busy}>{loadQueue.isPending ? <Loader2 size={15} className="animate-spin" aria-hidden="true" /> : <RefreshCw size={15} aria-hidden="true" />}<span className="ms-2">{t("refreshQueue")}</span></Button>
                <Button type="button" variant="ghost" size="sm" onClick={lock}>{t("cancel")}</Button>
              </div>
            </div>
            <section aria-labelledby="pending-heading" className="mb-5">
              <h3 id="pending-heading" className="mb-2 font-semibold">{t("pendingStoriesCount", { count: pending.length })}</h3>
              {pending.length === 0 ? <p className="text-sm text-muted-foreground">{t("noPendingStories")}</p> : <ul className="space-y-3">{pending.map((story) => (
                <li key={story.id} className="rounded-lg border bg-background/50 p-4">
                  <h4 className="font-semibold break-words">{story.title}</h4>
                  <p className="mt-1 text-xs text-muted-foreground">{story.pseudonym || t("anonymous")} · {t("plus18Warning")}</p>
                  <p className="mt-3 whitespace-pre-wrap break-words text-sm leading-6">{story.body}</p>
                  <div className="mt-3 flex flex-wrap gap-2"><Button type="button" size="sm" onClick={() => act(story.id, "publish")} disabled={busy}><Check size={15} aria-hidden="true" /><span className="ms-1">{t("approveStory")}</span></Button><Button type="button" size="sm" variant="destructive" onClick={() => act(story.id, "reject")} disabled={busy}><X size={15} aria-hidden="true" /><span className="ms-1">{t("rejectStory")}</span></Button></div>
                </li>
              ))}</ul>}
            </section>
            <section aria-labelledby="reports-heading">
              <h3 id="reports-heading" className="mb-2 font-semibold">{t("openReportsCount", { count: reports.length })}</h3>
              {reports.length === 0 ? <p className="text-sm text-muted-foreground">{t("noOpenReports")}</p> : <ul className="space-y-3">{reports.map((report) => (
                <li key={report.id} className="rounded-lg border bg-background/50 p-4">
                  <h4 className="font-semibold break-words">{report.title}</h4>
                  <p className="mt-1 text-xs text-muted-foreground">{report.pseudonym || t("anonymous")} · {t("storyNumber", { id: report.storyId })}</p>
                  <div className="mt-3"><p className="text-xs font-medium text-muted-foreground">{t("storyContent")}</p><p className="mt-1 whitespace-pre-wrap break-words text-sm leading-6">{report.body}</p></div>
                  <div className="mt-3"><p className="text-xs font-medium text-muted-foreground">{t("reportReason")}</p><p className="mt-1 whitespace-pre-wrap break-words text-sm leading-6">{report.reason}</p></div>
                  <Button type="button" size="sm" variant="outline" className="mt-3" onClick={() => act(report.storyId, "closeReport", report.id)} disabled={busy}><Check size={15} aria-hidden="true" /><span className="ms-1">{t("closeReport")}</span></Button>
                  <Button type="button" size="sm" variant="destructive" className="ms-2 mt-3" onClick={() => void rejectReportedStory(report.storyId, report.id)} disabled={busy}><X size={15} aria-hidden="true" /><span className="ms-1">{t("rejectAndCloseReport")}</span></Button>
                </li>
              ))}</ul>}
            </section>
          </>
        )}
        {error && <p role="alert" className="mt-3 text-sm text-destructive">{error}</p>}
      </CardContent>
    </Card>
  );
}
