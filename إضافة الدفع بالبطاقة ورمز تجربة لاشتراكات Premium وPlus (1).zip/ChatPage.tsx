import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import ChatbiShell from "@/components/ChatbiShell";
import type { SidebarThread } from "@/components/ChatbiShell";
import { useLocale } from "@/lib/locale";
import { usePageSeo } from "@/lib/seo";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { ArrowUp, Loader2, Sparkles, UserRound, RotateCcw } from "lucide-react";
import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { useLocation, useRoute } from "wouter";

const Streamdown = lazy(() => import("streamdown").then((module) => ({ default: module.Streamdown })));

type UiMessage = { id: string | number; role: "user" | "assistant"; content: string };

export default function ChatPage() {
  const [match, params] = useRoute("/chat/:id");
  const threadId = match ? params?.id ?? null : null;
  const [location, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const { t, dir } = useLocale();
  const isPrivateConversation = location.startsWith("/chat/");
  usePageSeo({
    title: t(isPrivateConversation ? "privateChatSeoTitle" : "chatSeoTitle"),
    description: t(isPrivateConversation ? "privateChatSeoDescription" : "chatSeoDescription"),
    robots: isPrivateConversation ? "noindex, nofollow" : "index, follow",
    canonical: !isPrivateConversation,
  });
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [sendError, setSendError] = useState("");
  const [retryPayload, setRetryPayload] = useState<{ threadId: string; clientMessageId: string; content: string } | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const utils = trpc.useUtils();

  const threadsQuery = trpc.chat.listThreads.useQuery(undefined, { enabled: Boolean(user), retry: false });
  const threadQuery = trpc.chat.getThread.useQuery(
    { threadId: threadId ?? "" },
    { enabled: Boolean(user && threadId), retry: false },
  );
  const settingsQuery = trpc.settings.get.useQuery(undefined, { enabled: Boolean(user), retry: false });
  const createThread = trpc.chat.createThread.useMutation();
  const sendMessage = trpc.chat.sendMessage.useMutation();
  const isBusy = createThread.isPending || sendMessage.isPending;

  useEffect(() => {
    if (!threadId) {
      setMessages([]);
      setSendError("");
      setRetryPayload(null);
      return;
    }
    if (threadQuery.data) {
      setMessages(threadQuery.data.messages.map((message) => ({
        id: message.id,
        role: message.role,
        content: message.content,
      })));
      setSendError("");
    }
  }, [threadId, threadQuery.dataUpdatedAt]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, sendMessage.isPending]);

  const submitTurn = async (payload: { threadId: string; clientMessageId: string; content: string }, showUserMessage: boolean) => {
    setSendError("");
    setRetryPayload(payload);
    if (showUserMessage) {
      setMessages((current) => [...current, { id: payload.clientMessageId, role: "user", content: payload.content }]);
    }
    try {
      const result = await sendMessage.mutateAsync(payload);
      setMessages((current) => {
        const withoutDuplicate = current.filter((message) => message.id !== result.assistantMessage.id);
        return [...withoutDuplicate, { id: result.assistantMessage.id, role: "assistant", content: result.assistantMessage.content }];
      });
      setRetryPayload(null);
      await Promise.all([
        utils.chat.getThread.invalidate({ threadId: payload.threadId }),
        utils.chat.listThreads.invalidate(),
      ]);
    } catch {
      setSendError(t("chatError"));
      void utils.chat.getThread.invalidate({ threadId: payload.threadId });
    }
  };

  const handleSend = async (messageText: string) => {
    const content = messageText.trim();
    if (!content || isBusy) return;
    if (!user) {
      startLogin();
      return;
    }

    let activeThreadId = threadId;
    try {
      if (!activeThreadId) {
        const created = await createThread.mutateAsync();
        activeThreadId = created.id;
        setLocation(`/chat/${created.id}`);
      }
      setInput("");
      await submitTurn({ threadId: activeThreadId, clientMessageId: crypto.randomUUID(), content }, true);
    } catch {
      setSendError(t("chatError"));
    }
  };

  const handleNewChat = () => {
    setInput("");
    setMessages([]);
    setSendError("");
    setRetryPayload(null);
    setLocation("/");
  };

  const threadList = (threadsQuery.data ?? []) as SidebarThread[];
  const currentLanguage = settingsQuery.data?.replyLanguage ?? "auto";
  const isEmpty = messages.length === 0;

  return (
    <ChatbiShell activePath={threadId ? `/chat/${threadId}` : "/"} threads={threadList} onNewChat={handleNewChat}>
      {!user && !loading ? (
        <main className="chatbi-chat-viewport flex items-center justify-center px-5 py-12">
          <section className="w-full max-w-md rounded-3xl border border-white/10 bg-white/[.035] p-8 text-center shadow-2xl shadow-black/20">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-500/15 text-violet-200 ring-1 ring-violet-300/20"><Sparkles size={24} /></div>
            <h1 className="mt-6 text-2xl font-semibold">{t("signInTitle")}</h1>
            <p className="mt-3 text-sm leading-6 text-white/55">{t("signInBody")}</p>
            <Button onClick={() => startLogin()} className="mt-7 h-11 w-full rounded-xl bg-violet-500 hover:bg-violet-400">{t("signIn")}</Button>
          </section>
        </main>
      ) : loading ? (
        <div className="chatbi-chat-viewport flex items-center justify-center"><Loader2 className="animate-spin text-violet-300" /></div>
      ) : (
        <main className="chatbi-chat-viewport chatbi-conversation-screen flex flex-col">
          <div className="mx-auto flex w-full max-w-4xl flex-1 flex-col px-4 pb-4 pt-6 sm:px-7 md:pt-10">
            {threadId && threadQuery.isLoading ? (
              <div className="flex flex-1 items-center justify-center text-white/45"><Loader2 className="animate-spin" /></div>
            ) : isEmpty ? (
              <div className="flex flex-1 flex-col items-center justify-center pb-10 text-center">
                <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-[22px] bg-gradient-to-br from-violet-400/20 to-fuchsia-500/10 text-violet-200 ring-1 ring-violet-300/15 shadow-[0_0_50px_rgba(139,92,246,.1)]"><Sparkles size={27} /></div>
                <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{t("welcomeTitle")}</h1>
                <p className="mt-3 max-w-lg text-sm leading-6 text-white/45">{t("welcomeBody")}</p>
                <div className="mt-8 flex max-w-2xl flex-wrap justify-center gap-2">
                  {[t("shortPrompt"), t("planPrompt"), t("translatePrompt")].map((prompt) => (
                    <button key={prompt} onClick={() => void handleSend(prompt)} className="rounded-full border border-white/10 bg-white/[.025] px-4 py-2.5 text-xs text-white/65 transition hover:border-violet-300/25 hover:bg-violet-500/10 hover:text-white">{prompt}</button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex-1 space-y-7 pb-8 pt-2">
                {messages.map((message) => (
                  <article key={message.id} className={`flex gap-3 sm:gap-4 ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                    {message.role === "assistant" && <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-violet-500/15 text-violet-200"><Sparkles size={16} /></div>}
                    <div className={`max-w-[88%] sm:max-w-[80%] ${message.role === "user" ? "rounded-2xl bg-violet-500/20 px-4 py-3 ring-1 ring-violet-300/10" : "min-w-0 py-1 text-white/85"}`} dir="auto">
                      {message.role === "assistant" ? <div className="prose prose-invert prose-sm max-w-none leading-7"><Suspense fallback={<span className="text-white/45">{t("sending")}</span>}><Streamdown>{message.content}</Streamdown></Suspense></div> : <p className="whitespace-pre-wrap text-sm leading-6">{message.content}</p>}
                    </div>
                    {message.role === "user" && <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white/8 text-white/65"><UserRound size={16} /></div>}
                  </article>
                ))}
                {sendMessage.isPending && <div className="flex items-center gap-3 text-sm text-white/45"><div className="flex h-8 w-8 items-center justify-center rounded-xl bg-violet-500/15 text-violet-200"><Sparkles size={16} /></div><Loader2 size={16} className="animate-spin" />{t("sending")}</div>}
                <div ref={bottomRef} />
              </div>
            )}
            {sendError && (
              <div className="mb-3 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-rose-300/15 bg-rose-500/8 px-4 py-3 text-sm text-rose-100/85">
                <span>{sendError}</span>
                {retryPayload && <button onClick={() => void submitTurn(retryPayload, false)} disabled={isBusy} className="inline-flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold hover:bg-white/8"><RotateCcw size={14} />{t("retry")}</button>}
              </div>
            )}
            <div className="chatbi-message-composer sticky bottom-0 bg-gradient-to-t from-[#090812] via-[#090812] to-transparent pt-3">
              <form onSubmit={(event) => { event.preventDefault(); void handleSend(input); }} className="rounded-2xl border border-white/10 bg-[#141222] p-2 shadow-[0_16px_50px_rgba(0,0,0,.24)] focus-within:border-violet-300/30">
                <textarea
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" && !event.shiftKey) {
                      event.preventDefault();
                      void handleSend(input);
                    }
                  }}
                  placeholder={t("inputPlaceholder")}
                  aria-label={t("inputPlaceholder")}
                  rows={2}
                  maxLength={12000}
                  className="max-h-40 min-h-12 w-full resize-y bg-transparent px-3 py-2 text-sm leading-6 text-white outline-none placeholder:text-white/30"
                  dir={dir}
                />
                <div className="flex items-center justify-between px-2 pb-1 pt-1">
                  <span className="text-[11px] text-white/35">{currentLanguage === "auto" ? t("autoDetect") : currentLanguage.toUpperCase()}</span>
                  <Button type="submit" disabled={!input.trim() || isBusy} className="h-9 gap-2 rounded-xl bg-violet-500 px-3 text-white hover:bg-violet-400 disabled:bg-white/10 disabled:text-white/30">
                    {isBusy ? <Loader2 size={15} className="animate-spin" /> : <ArrowUp size={16} />}
                    <span className="text-xs">{t("send")}</span>
                  </Button>
                </div>
              </form>
              <p className="mt-2 text-center text-[10px] text-white/30">{t("paymentInfo")}</p>
            </div>
          </div>
        </main>
      )}
    </ChatbiShell>
  );
}
