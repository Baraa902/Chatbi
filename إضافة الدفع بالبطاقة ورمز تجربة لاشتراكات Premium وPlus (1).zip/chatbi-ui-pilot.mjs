import { readFile, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";

const { LlmClient, messageText } = await import(
  pathToFileURL("/home/ubuntu/skills/builtin-llm-models/lib/llm.mjs").href
);

const MODEL = "gpt-6-luna";
const source = JSON.parse(await readFile("/tmp/chatbi-ui-english.json", "utf8"));
const selectedKeys = [
  "newChat",
  "settings",
  "welcomeTitle",
  "inputPlaceholder",
  "replyLanguageHelp",
  "paymentPending",
  "interfaceLanguageHelp",
  "deleteConversationTitle",
  "deleteConversationWarning",
  "plansSubtitle",
  "featurePremiumResearch",
];
const targets = [
  { code: "tr", name: "Turkish", native: "Türkçe" },
  { code: "es", name: "Spanish", native: "Español" },
  { code: "fr", name: "French", native: "Français" },
  { code: "hi", name: "Hindi", native: "हिन्दी" },
  { code: "ja", name: "Japanese", native: "日本語" },
];
const pilotSource = Object.fromEntries(selectedKeys.map((key) => [key, source[key]]));
const schema = {
  type: "object",
  properties: Object.fromEntries(targets.map(({ code }) => [
    code,
    {
      type: "object",
      properties: Object.fromEntries(selectedKeys.map((key) => [key, { type: "string" }])),
      required: selectedKeys,
      additionalProperties: false,
    },
  ])),
  required: targets.map(({ code }) => code),
  additionalProperties: false,
};

const llm = new LlmClient({ timeoutMs: 180000, maxRetries: 3 });
const response = await llm.chat({
  model: MODEL,
  reasoning: { effort: "low" },
  max_completion_tokens: 5000,
  response_format: {
    type: "json_schema",
    json_schema: {
      name: "chatbi_ui_translation_pilot",
      strict: true,
      schema,
    },
  },
  messages: [
    {
      role: "system",
      content: "You are a careful software-interface localizer. Translate every supplied English UI string naturally and concisely into each target language. Use the language's normal native script. Preserve product names, chatbi.AI, Plus, Premium, Free, TCMB, currency codes, and any brace-delimited placeholders exactly. Preserve warnings and their meaning. Return only the required structured translations; do not omit any key or add commentary.",
    },
    {
      role: "user",
      content: JSON.stringify({ targets, source: pilotSource }, null, 2),
    },
  ],
});

const content = messageText(response);
const parsed = JSON.parse(content);
for (const target of targets) {
  const translatedKeys = Object.keys(parsed[target.code] ?? {});
  if (translatedKeys.length !== selectedKeys.length || selectedKeys.some((key) => typeof parsed[target.code]?.[key] !== "string" || !parsed[target.code][key].trim())) {
    throw new Error(`Incomplete translation for ${target.code}`);
  }
}
const result = {
  model: MODEL,
  usage: response.usage ?? null,
  source: pilotSource,
  targets,
  translations: parsed,
};
await writeFile("/tmp/chatbi-ui-pilot-result.json", JSON.stringify(result, null, 2) + "\n", "utf8");
console.log(JSON.stringify({ model: MODEL, usage: result.usage, targetCount: targets.length, keyCount: selectedKeys.length, output: "/tmp/chatbi-ui-pilot-result.json" }));
