// @ts-ignore
import type { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { GoogleAuthOptions } from 'google-auth-library';

/** Marks the end of user activity.

 This can only be sent if automatic (i.e. server-side) activity detection is
 disabled. */
export declare interface ActivityEnd {
}

/** The different ways of handling user activity. */
export declare enum ActivityHandling {
    /**
     * If unspecified, the default behavior is `START_OF_ACTIVITY_INTERRUPTS`.
     */
    ACTIVITY_HANDLING_UNSPECIFIED = "ACTIVITY_HANDLING_UNSPECIFIED",
    /**
     * If true, start of activity will interrupt the model's response (also called "barge in"). The model's current response will be cut-off in the moment of the interruption. This is the default behavior.
     */
    START_OF_ACTIVITY_INTERRUPTS = "START_OF_ACTIVITY_INTERRUPTS",
    /**
     * The model's response will not be interrupted.
     */
    NO_INTERRUPTION = "NO_INTERRUPTION"
}

/** Marks the start of user activity.

 This can only be sent if automatic (i.e. server-side) activity detection is
 disabled. */
export declare interface ActivityStart {
}

/** Adapter size for tuning. This enum is not supported in Gemini API. */
export declare enum AdapterSize {
    /**
     * Adapter size is unspecified.
     */
    ADAPTER_SIZE_UNSPECIFIED = "ADAPTER_SIZE_UNSPECIFIED",
    /**
     * Adapter size 1.
     */
    ADAPTER_SIZE_ONE = "ADAPTER_SIZE_ONE",
    /**
     * Adapter size 2.
     */
    ADAPTER_SIZE_TWO = "ADAPTER_SIZE_TWO",
    /**
     * Adapter size 4.
     */
    ADAPTER_SIZE_FOUR = "ADAPTER_SIZE_FOUR",
    /**
     * Adapter size 8.
     */
    ADAPTER_SIZE_EIGHT = "ADAPTER_SIZE_EIGHT",
    /**
     * Adapter size 16.
     */
    ADAPTER_SIZE_SIXTEEN = "ADAPTER_SIZE_SIXTEEN",
    /**
     * Adapter size 32.
     */
    ADAPTER_SIZE_THIRTY_TWO = "ADAPTER_SIZE_THIRTY_TWO"
}

declare type AfterErrorContext = HookContext & {};

declare interface AfterErrorHook {
    /**
     * A hook that is called after the SDK encounters an error, or a
     * non-successful response. The hook can introduce instrumentation code such
     * as logging, tracing and metrics or modify the response or error values.
     */
    afterError: (hookCtx: AfterErrorContext, response: Response | null, error: unknown) => Awaitable_2<{
        response: Response | null;
        error: unknown;
    }>;
}

declare type AfterSuccessContext = HookContext & {};

declare interface AfterSuccessHook {
    /**
     * A hook that is called after the SDK receives a response. The hook can
     * introduce instrumentation code such as logging, tracing and metrics or
     * modify the response before it is handled or throw an error to stop the
     * response from being handled.
     */
    afterSuccess: (hookCtx: AfterSuccessContext, response: Response) => Awaitable_2<Response>;
}

declare type Agent$ = Agent;

/**
 * An agent definition for the CreateAgent API.
 *
 * @remarks
 * This message is the target for annotation-parser-based JSON parsing.
 * New format:
 *   {
 *     "id": "customer-sentinel",
 *     "base_agent": "",
 *     "system_instruction": "...",
 *     "base_environment": { "type": "remote", "sources": [...] },
 *     "tools": [ {"type": "code_execution"} ]
 *   }
 */
declare type Agent = {
    /**
     * Configuration parameters for the agent.
     */
    agent_config?: interactions.AntigravityAgentConfig | undefined;
    /**
     * The base agent to extend.
     */
    base_agent?: string | undefined;
    /**
     * The environment configuration for the agent.
     */
    base_environment?: interactions.Environment | string | undefined;
    /**
     * Agent description for developers to quickly read and understand.
     */
    description?: string | undefined;
    /**
     * The unique identifier for the agent.
     */
    id?: string | undefined;
    /**
     * System instruction for the agent.
     */
    system_instruction?: string | undefined;
    /**
     * The tools available to the agent.
     */
    tools?: Array<AgentTool> | undefined;
};

/**
 * Configuration parameters for the agent.
 */
declare type AgentConfig = interactions.AntigravityAgentConfig;

declare type AgentCreateParams$ = CreateAgentParams;

declare type AgentDeleteParams$ = DeleteAgentParams;

declare type AgentDeleteResponse$ = Empty;

declare type AgentGetParams$ = GetAgentParams;

declare type AgentListParams$ = ListAgentsParams;

declare type AgentListResponse$ = AgentListResponse;

declare type AgentListResponse = {
    /**
     * The list of agents.
     */
    agents?: Array<Agent> | undefined;
    /**
     * A token to retrieve the next page of results.
     */
    next_page_token?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The agent to interact with.
 */
declare type AgentOption = "deep-research-pro-preview-12-2025" | "deep-research-preview-04-2026" | "deep-research-max-preview-04-2026" | "antigravity-preview-05-2026" | (string & {});

export declare namespace Agents {
    export type Agent = Agent$;
    export type AgentCreateParams = AgentCreateParams$;
    export type AgentDeleteParams = AgentDeleteParams$;
    export type AgentDeleteResponse = AgentDeleteResponse$;
    export type AgentGetParams = AgentGetParams$;
    export type AgentListParams = AgentListParams$;
    export type AgentListResponse = AgentListResponse$;
    export type AgentTool = AgentTool$;
}

declare namespace agents {
    export {
        AgentListResponse,
        AgentTool,
        AgentConfig,
        BaseEnvironment,
        Agent
    }
}

declare class Agents_2 extends ClientSDK {
    /**
     * Lists all Agents.
     */
    list(params?: ListAgentsParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<agents.AgentListResponse>;
    /**
     * Creates a new Agent (Typed version for SDK).
     */
    create(params: CreateAgentParams, options?: RequestOptions): APIPromise<agents.Agent>;
    /**
     * Deletes an Agent.
     */
    delete(id: string, params?: DeleteAgentParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<interactions.Empty>;
    /**
     * Gets a specific Agent.
     */
    get(id: string, params?: GetAgentParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<agents.Agent>;
}

declare type AgentTool$ = AgentTool;

/**
 * A tool that the agent can use.
 */
declare type AgentTool = interactions.CodeExecution | interactions.FunctionT | interactions.GoogleSearch | interactions.MCPServer | interactions.URLContext;

/** Aggregation metric. This enum is not supported in Gemini API. */
export declare enum AggregationMetric {
    /**
     * Unspecified aggregation metric.
     */
    AGGREGATION_METRIC_UNSPECIFIED = "AGGREGATION_METRIC_UNSPECIFIED",
    /**
     * Average aggregation metric. Not supported for Pairwise metric.
     */
    AVERAGE = "AVERAGE",
    /**
     * Mode aggregation metric.
     */
    MODE = "MODE",
    /**
     * Standard deviation aggregation metric. Not supported for pairwise metric.
     */
    STANDARD_DEVIATION = "STANDARD_DEVIATION",
    /**
     * Variance aggregation metric. Not supported for pairwise metric.
     */
    VARIANCE = "VARIANCE",
    /**
     * Minimum aggregation metric. Not supported for pairwise metric.
     */
    MINIMUM = "MINIMUM",
    /**
     * Maximum aggregation metric. Not supported for pairwise metric.
     */
    MAXIMUM = "MAXIMUM",
    /**
     * Median aggregation metric. Not supported for pairwise metric.
     */
    MEDIAN = "MEDIAN",
    /**
     * 90th percentile aggregation metric. Not supported for pairwise metric.
     */
    PERCENTILE_P90 = "PERCENTILE_P90",
    /**
     * 95th percentile aggregation metric. Not supported for pairwise metric.
     */
    PERCENTILE_P95 = "PERCENTILE_P95",
    /**
     * 99th percentile aggregation metric. Not supported for pairwise metric.
     */
    PERCENTILE_P99 = "PERCENTILE_P99"
}

/** The aggregation result for the entire dataset and all metrics. This data type is not supported in Gemini API. */
export declare interface AggregationOutput {
    /** One AggregationResult per metric. */
    aggregationResults?: AggregationResult[];
    /** The dataset used for evaluation & aggregation. */
    dataset?: EvaluationDataset;
}

/** The aggregation result for a single metric. This data type is not supported in Gemini API. */
export declare interface AggregationResult {
    /** Aggregation metric. */
    aggregationMetric?: AggregationMetric;
    /** Results for bleu metric. */
    bleuMetricValue?: BleuMetricValue;
    /** Result for code execution metric. */
    customCodeExecutionResult?: CustomCodeExecutionResult;
    /** Results for exact match metric. */
    exactMatchMetricValue?: ExactMatchMetricValue;
    /** Result for pairwise metric. */
    pairwiseMetricResult?: PairwiseMetricResult;
    /** Result for pointwise metric. */
    pointwiseMetricResult?: PointwiseMetricResult;
    /** Results for rouge metric. */
    rougeMetricValue?: RougeMetricValue;
}

declare type AllowedTools$ = AllowedTools;

/**
 * The configuration for allowed tools.
 */
declare type AllowedTools = {
    mode?: ToolChoiceType | undefined;
    /**
     * The names of the allowed tools.
     */
    tools?: Array<string> | undefined;
};

/**
 * List of allowed domains and their configurations. Set to `"disabled"`
 *
 * @remarks
 * to block all network egress.
 */
declare type Allowlist = Array<AllowlistEntry> | Disabled;

declare type AllowlistEntry$ = AllowlistEntry;

/**
 * A single domain allowlist rule with optional header injection.
 */
declare type AllowlistEntry = {
    /**
     * Optional. Reference to a server-managed Credential resource by ID.
     */
    credential?: string | undefined;
    /**
     * Domain to allow outbound requests to. Supports wildcards (e.g.
     *
     * @remarks
     * '*.googleapis.com'). Use '*' to allow all domains.
     */
    domain: string;
    /**
     * Headers to inject on all outbound requests matching this domain. Accepts a single dict or a list of dicts. The egress proxy injects these automatically.
     */
    transform?: Array<{
        [k: string]: string;
    }> | {
        [k: string]: string;
    } | undefined;
};

declare type Annotation$ = Annotation;

/**
 * Citation information for model-generated content.
 */
declare type Annotation = FileCitation | PlaceCitation | SpeechAnnotation | URLCitation | WordInfo_2;

declare type AntigravityAgentConfig$ = AntigravityAgentConfig;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for the Antigravity agent runtime.
 *
 * @remarks
 * Provides server-side control over the agent's execution environment
 * and tool configuration.
 */
declare type AntigravityAgentConfig = {
    /**
     * Max total tokens for the agent run.
     */
    max_total_tokens?: string | undefined;
    /**
     * The model to use for agent reasoning.
     */
    model?: string | undefined;
    type: "antigravity";
};

/** The generic reusable api auth config. Deprecated. Please use AuthConfig (google/cloud/aiplatform/master/auth.proto) instead. This data type is not supported in Gemini API. */
export declare interface ApiAuth {
    /** The API secret. */
    apiKeyConfig?: ApiAuthApiKeyConfig;
}

/** The API secret. This data type is not supported in Gemini API. */
export declare interface ApiAuthApiKeyConfig {
    /** Required. The SecretManager secret version resource name storing API key. e.g. projects/{project}/secrets/{secret}/versions/{version} */
    apiKeySecretVersion?: string;
    /** The API key string. Either this or `api_key_secret_version` must be set. */
    apiKeyString?: string;
}

declare type APICall = {
    status: "complete";
    request: Request;
    response: Response;
} | {
    status: "request-error";
    request: Request;
    response?: undefined;
} | {
    status: "invalid";
    request?: undefined;
    response?: undefined;
};

/**
 * The ApiClient class is used to send requests to the Gemini API or Vertex AI
 * endpoints.
 *
 * WARNING: This is an internal API and may change without notice. Direct usage
 * is not supported and may break your application.
 */
declare class ApiClient {
    readonly clientOptions: ApiClientInitOptions;
    private readonly customBaseUrl?;
    constructor(opts: ApiClientInitOptions);
    isVertexAI(): boolean;
    getProject(): string | undefined;
    getLocation(): string | undefined;
    getCustomBaseUrl(): string | undefined;
    getAuthHeaders(): Promise<Headers>;
    getApiVersion(): string;
    getBaseUrl(): string;
    getRequestUrl(): string;
    getHeaders(): Record<string, string>;
    getFetch(): types.Fetch | undefined;
    /**
     * Returns the configured HTTP timeout in milliseconds, if any.
     */
    getTimeout(): number | undefined;
    private getRequestUrlInternal;
    getBaseResourcePath(): string;
    getApiKey(): string | undefined;
    getWebsocketBaseUrl(): string;
    setBaseUrl(url: string): void;
    private constructUrl;
    private shouldPrependVertexProjectPath;
    request(request: HttpRequest): Promise<types.HttpResponse>;
    private patchHttpOptions;
    requestStream(request: HttpRequest): Promise<AsyncGenerator<types.HttpResponse>>;
    private includeExtraHttpOptionsToRequestInit;
    private unaryApiCall;
    private streamApiCall;
    processStreamResponse(response: Response): AsyncGenerator<types.HttpResponse>;
    private apiCall;
    getDefaultHeaders(): Record<string, string>;
    private getHeadersInternal;
    private getFileName;
    /**
     * Uploads a file asynchronously using Gemini API only, this is not supported
     * in Vertex AI.
     *
     * @param file The string path to the file to be uploaded or a Blob object.
     * @param config Optional parameters specified in the `UploadFileConfig`
     *     interface. @see {@link types.UploadFileConfig}
     * @return A promise that resolves to a `File` object.
     * @throws An error if called on a Vertex AI client.
     * @throws An error if the `mimeType` is not provided and can not be inferred,
     */
    uploadFile(file: string | Blob, config?: types.UploadFileConfig): Promise<types.File>;
    /**
     * Uploads a file to a given file search store asynchronously using Gemini API only, this is not supported
     * in Vertex AI.
     *
     * @param fileSearchStoreName The name of the file search store to upload the file to.
     * @param file The string path to the file to be uploaded or a Blob object.
     * @param config Optional parameters specified in the `UploadFileConfig`
     *     interface. @see {@link UploadFileConfig}
     * @return A promise that resolves to a `File` object.
     * @throws An error if called on a Vertex AI client.
     * @throws An error if the `mimeType` is not provided and can not be inferred,
     */
    uploadFileToFileSearchStore(fileSearchStoreName: string, file: string | Blob, config?: types.UploadToFileSearchStoreConfig): Promise<types.UploadToFileSearchStoreOperation>;
    /**
     * Downloads a file asynchronously to the specified path.
     *
     * @params params - The parameters for the download request, see {@link
     * types.DownloadFileParameters}
     */
    downloadFile(params: types.DownloadFileParameters): Promise<void>;
    private fetchUploadUrl;
}

/**
 * Options for initializing the ApiClient. The ApiClient uses the parameters
 * for authentication purposes as well as to infer if SDK should send the
 * request to Vertex AI or Gemini API.
 */
declare interface ApiClientInitOptions {
    /**
     * The object used for adding authentication headers to API requests.
     */
    auth: Auth;
    /**
     * The uploader to use for uploading files. This field is required for
     * creating a client, will be set through the Node_client or Web_client.
     */
    uploader: Uploader;
    /**
     * Optional. The downloader to use for downloading files. This field is
     * required for creating a client, will be set through the Node_client or
     * Web_client.
     */
    downloader: Downloader;
    /**
     * Optional. The Google Cloud project ID for Vertex AI users.
     * It is not the numeric project name.
     * If not provided, SDK will try to resolve it from runtime environment.
     */
    project?: string;
    /**
     * Optional. The Google Cloud project location for Vertex AI users.
     * If not provided, SDK will try to resolve it from runtime environment.
     */
    location?: string;
    /**
     * The API Key. This is required for Gemini API users.
     */
    apiKey?: string;
    /**
     * Optional. Set to true if you intend to call Vertex AI endpoints.
     * If unset, default SDK behavior is to call Gemini API.
     */
    vertexai?: boolean;
    /**
     * Optional. The API version for the endpoint.
     * If unset, SDK will choose a default api version.
     */
    apiVersion?: string;
    /**
     * Optional. A set of customizable configuration for HTTP requests.
     */
    httpOptions?: types.HttpOptions;
    /**
     * Optional. An extra string to append at the end of the User-Agent header.
     *
     * This can be used to e.g specify the runtime and its version.
     */
    userAgentExtra?: string;
}

/**
 * API errors raised by the GenAI API.
 */
export declare class ApiError extends Error {
    /** HTTP status code */
    status: number;
    constructor(options: ApiErrorInfo);
}

/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * Details for errors from calling the API.
 */
export declare interface ApiErrorInfo {
    /** The error message. */
    message: string;
    /** The HTTP status code. */
    status: number;
}

/** Config for authentication with API key. This data type is not supported in Gemini API. */
export declare interface ApiKeyConfig {
    /** Optional. The name of the SecretManager secret version resource storing the API key. Format: `projects/{project}/secrets/{secrete}/versions/{version}` - If both `api_key_secret` and `api_key_string` are specified, this field takes precedence over `api_key_string`. - If specified, the `secretmanager.versions.access` permission should be granted to Vertex AI Extension Service Agent (https://cloud.google.com/vertex-ai/docs/general/access-control#service-agents) on the specified resource. */
    apiKeySecret?: string;
    /** Optional. The API key to be used in the request directly. */
    apiKeyString?: string;
    /** Optional. The location of the API key. */
    httpElementLocation?: HttpElementLocation;
    /** Optional. The parameter name of the API key. E.g. If the API request is "https://example.com/act?api_key=", "api_key" would be the parameter name. */
    name?: string;
}

declare class APIPromise<T> implements Promise<T> {
    readonly _promise: Promise<[T, APICall]>;
    _unwrapped: Promise<T> | null;
    _callSource: Promise<APICall> | null;
    readonly [Symbol.toStringTag] = "APIPromise";
    constructor(p: [T, APICall] | Promise<[T, APICall]>, callSource?: Promise<APICall>);
    _getUnwrapped(): Promise<T>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | null | undefined, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null | undefined): Promise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | null | undefined): Promise<T | TResult>;
    finally(onfinally?: (() => void) | null | undefined): Promise<T>;
    $inspect(): Promise<[T, APICall]>;
    asResponse(): Promise<Response>;
    withResponse(): Promise<{
        data: T;
        response: Response;
    }>;
    _thenUnwrap<U>(transform: (value: T) => U): APIPromise<U>;
}

/** The API spec that the external API implements. This enum is not supported in Gemini API. */
export declare enum ApiSpec {
    /**
     * Unspecified API spec. This value should not be used.
     */
    API_SPEC_UNSPECIFIED = "API_SPEC_UNSPECIFIED",
    /**
     * Simple search API spec.
     */
    SIMPLE_SEARCH = "SIMPLE_SEARCH",
    /**
     * Elastic search API spec.
     */
    ELASTIC_SEARCH = "ELASTIC_SEARCH"
}

declare type Arguments$ = CodeExecutionCallArguments;

declare type Arguments$2 = GoogleMapsCallArguments;

declare type Arguments$3 = GoogleSearchCallArguments;

declare type Arguments$4 = RetrievalCallArguments;

declare type Arguments$5 = RetrievalCallArguments;

declare type Arguments$6 = URLContextCallArguments;

declare type ArgumentsDelta$ = ArgumentsDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ArgumentsDelta = {
    arguments?: string | undefined;
    type: "arguments_delta";
};

/** The aspect ratio for the image output. */
export declare enum AspectRatio {
    /**
     * Default value. This value is unused.
     */
    ASPECT_RATIO_UNSPECIFIED = "ASPECT_RATIO_UNSPECIFIED",
    /**
     * 1:1 aspect ratio.
     */
    ASPECT_RATIO_ONE_BY_ONE = "ASPECT_RATIO_ONE_BY_ONE",
    /**
     * 2:3 aspect ratio.
     */
    ASPECT_RATIO_TWO_BY_THREE = "ASPECT_RATIO_TWO_BY_THREE",
    /**
     * 3:2 aspect ratio.
     */
    ASPECT_RATIO_THREE_BY_TWO = "ASPECT_RATIO_THREE_BY_TWO",
    /**
     * 3:4 aspect ratio.
     */
    ASPECT_RATIO_THREE_BY_FOUR = "ASPECT_RATIO_THREE_BY_FOUR",
    /**
     * 4:3 aspect ratio.
     */
    ASPECT_RATIO_FOUR_BY_THREE = "ASPECT_RATIO_FOUR_BY_THREE",
    /**
     * 4:5 aspect ratio.
     */
    ASPECT_RATIO_FOUR_BY_FIVE = "ASPECT_RATIO_FOUR_BY_FIVE",
    /**
     * 5:4 aspect ratio.
     */
    ASPECT_RATIO_FIVE_BY_FOUR = "ASPECT_RATIO_FIVE_BY_FOUR",
    /**
     * 9:16 aspect ratio.
     */
    ASPECT_RATIO_NINE_BY_SIXTEEN = "ASPECT_RATIO_NINE_BY_SIXTEEN",
    /**
     * 16:9 aspect ratio.
     */
    ASPECT_RATIO_SIXTEEN_BY_NINE = "ASPECT_RATIO_SIXTEEN_BY_NINE",
    /**
     * 21:9 aspect ratio.
     */
    ASPECT_RATIO_TWENTY_ONE_BY_NINE = "ASPECT_RATIO_TWENTY_ONE_BY_NINE",
    /**
     * 1:8 aspect ratio.
     */
    ASPECT_RATIO_ONE_BY_EIGHT = "ASPECT_RATIO_ONE_BY_EIGHT",
    /**
     * 8:1 aspect ratio.
     */
    ASPECT_RATIO_EIGHT_BY_ONE = "ASPECT_RATIO_EIGHT_BY_ONE",
    /**
     * 1:4 aspect ratio.
     */
    ASPECT_RATIO_ONE_BY_FOUR = "ASPECT_RATIO_ONE_BY_FOUR",
    /**
     * 4:1 aspect ratio.
     */
    ASPECT_RATIO_FOUR_BY_ONE = "ASPECT_RATIO_FOUR_BY_ONE"
}

declare type Audio$ = AudioDelta;

/** Representation of an audio chunk. */
export declare interface AudioChunk {
    /** Raw bytes of audio data.
     * @remarks Encoded as base64 string. */
    data?: string;
    /** MIME type of the audio chunk. */
    mimeType?: string;
    /** Prompts and config used for generating this audio chunk. */
    sourceMetadata?: LiveMusicSourceMetadata;
}

declare type AudioContent$ = AudioContent;

/**
 * An audio content block.
 */
declare type AudioContent = {
    /**
     * The number of audio channels.
     */
    channels?: number | undefined;
    /**
     * The audio content.
     */
    data?: string | undefined;
    /**
     * The mime type of the audio.
     */
    mime_type?: AudioContentMimeType | undefined;
    /**
     * The sample rate of the audio.
     */
    sample_rate?: number | undefined;
    type: "audio";
    /**
     * The URI of the audio.
     */
    uri?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The mime type of the audio.
 */
declare type AudioContentMimeType = "audio/wav" | "audio/mp3" | "audio/aiff" | "audio/aac" | "audio/ogg" | "audio/flac" | "audio/mpeg" | "audio/m4a" | "audio/l16" | "audio/opus" | "audio/alaw" | "audio/mulaw" | "audio/webm" | (string & {});

declare type AudioData$ = AudioData_2;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Audio payload used for voice creation.
 */
declare type AudioData_2 = {
    /**
     * Required. The raw audio bytes.
     */
    data: string;
    /**
     * Required. The IANA MIME type of the audio data (for example, `audio/wav` or
     *
     * @remarks
     * `audio/mpeg`).
     */
    mime_type: string;
};

declare type AudioDelta = {
    /**
     * The number of audio channels.
     */
    channels?: number | undefined;
    data?: string | undefined;
    mime_type?: AudioDeltaMimeType | undefined;
    /**
     * Deprecated. Use sample_rate instead. The value is ignored.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    rate?: number | undefined;
    /**
     * The sample rate of the audio.
     */
    sample_rate?: number | undefined;
    type: "audio";
    uri?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type AudioDeltaMimeType = "audio/wav" | "audio/mp3" | "audio/aiff" | "audio/aac" | "audio/ogg" | "audio/flac" | "audio/mpeg" | "audio/m4a" | "audio/l16" | "audio/opus" | "audio/alaw" | "audio/mulaw" | "audio/webm" | (string & {});

declare type AudioResponseFormat$ = AudioResponseFormat_2;

/** Configuration for audio-specific output formatting. */
export declare class AudioResponseFormat {
    /** Optional. Bit rate in bits per second (bps). Only applicable for compressed formats (MP3, Opus). */
    bitRate?: number;
    /** Optional. Delivery mode for the generated content. */
    delivery?: Delivery;
    /** Optional. The MIME type of the audio output. */
    mimeType?: string;
    /** Optional. Sample rate for the generated audio in Hertz. */
    sampleRate?: number;
}

/**
 * Configuration for audio output format.
 */
declare type AudioResponseFormat_2 = {
    /**
     * Bit rate in bits per second (bps). Only applicable for compressed formats
     *
     * @remarks
     * (MP3, Opus).
     */
    bit_rate?: number | undefined;
    /**
     * The delivery mode for the audio output.
     */
    delivery?: AudioResponseFormatDelivery | undefined;
    /**
     * The MIME type of the audio output.
     */
    mime_type?: AudioResponseFormatMimeType | undefined;
    /**
     * Sample rate in Hz.
     */
    sample_rate?: number | undefined;
    type: "audio";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The delivery mode for the audio output.
 */
declare type AudioResponseFormatDelivery = "inline" | "uri" | (string & {});

/**
 * The MIME type of the audio output.
 */
declare type AudioResponseFormatMimeType = "audio/mp3" | "audio/ogg_opus" | "audio/l16" | "audio/wav" | "audio/alaw" | "audio/mulaw" | (string & {});

/** The audio transcription configuration in Setup. */
export declare interface AudioTranscriptionConfig {
    /** Optional. BCP-47 language codes providing hints about the languages present in the audio. If omitted or empty, defaults to automatic language detection. */
    languageCodes?: string[];
    /** Deprecated: Auto-detection is now the default when language_codes is omitted. This field will be removed in a future version. */
    languageAuto?: LanguageAuto;
    /** Deprecated: Use top-level language_codes instead. This field will be removed in a future version. */
    languageHints?: LanguageHints;
    /** A list of custom vocabulary phrases, which biases the ASR model to improve recognition of these specific terms. */
    customVocabulary?: string[];
    /** Deprecated. A list of phrases used for speech adaptation, which biases the ASR model to improve recognition of these specific terms. */
    adaptationPhrases?: string[];
    /** Configures word-level timestamp generation.
     */
    wordTimestamp?: boolean;
    /** Configures speaker diarization.
     */
    diarization?: boolean;
    /** Optional. Configures transcription mode. Supported values: `VERBATIM`, `SMART`. If unspecified, defaults to `VERBATIM` transcription. In `SMART` mode, the model performs disfluency removal (eliminating filler words, repetitions, and false starts), light grammatical cleanup, automatic formatting (paragraphs, bullet points, numbered lists), and minor user edits (inline self-corrections). Timestamps and diarization are incompatible with mode `SMART`. */
    mode?: AudioTranscriptionConfigMode;
}

/** Transcription mode. */
export declare enum AudioTranscriptionConfigMode {
    /**
     * Unspecified transcription mode.
     */
    MODE_UNSPECIFIED = "MODE_UNSPECIFIED",
    /**
     * Verbatim transcription mode.
     */
    VERBATIM = "VERBATIM",
    /**
     * Smart transcription mode.
     */
    SMART = "SMART"
}

/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * The Auth interface is used to authenticate with the API service.
 */
declare interface Auth {
    /**
     * Sets the headers needed to authenticate with the API service.
     *
     * @param headers - The Headers object that will be updated with the authentication headers.
     * @param url - The URL of the request.
     */
    addAuthHeaders(headers: Headers, url?: string): Promise<void>;
}

/** The authentication config to access the API. */
export declare interface AuthConfig {
    /** The authentication config to access the API. Only API key is supported. This field is not supported in Gemini API. */
    apiKey?: string;
    /** Config for API key auth. */
    apiKeyConfig?: ApiKeyConfig;
    /** Type of auth scheme. */
    authType?: AuthType;
    /** Config for Google Service Account auth. */
    googleServiceAccountConfig?: AuthConfigGoogleServiceAccountConfig;
    /** Config for HTTP Basic auth. */
    httpBasicAuthConfig?: AuthConfigHttpBasicAuthConfig;
    /** Config for user oauth. */
    oauthConfig?: AuthConfigOauthConfig;
    /** Config for user OIDC auth. */
    oidcConfig?: AuthConfigOidcConfig;
}

/** Config for Google Service Account Authentication. This data type is not supported in Gemini API. */
export declare interface AuthConfigGoogleServiceAccountConfig {
    /** Optional. The service account that the extension execution service runs as. - If the service account is specified, the `iam.serviceAccounts.getAccessToken` permission should be granted to Vertex AI Extension Service Agent (https://cloud.google.com/vertex-ai/docs/general/access-control#service-agents) on the specified service account. - If not specified, the Vertex AI Extension Service Agent will be used to execute the Extension. */
    serviceAccount?: string;
}

/** Config for HTTP Basic Authentication. This data type is not supported in Gemini API. */
export declare interface AuthConfigHttpBasicAuthConfig {
    /** Required. The name of the SecretManager secret version resource storing the base64 encoded credentials. Format: `projects/{project}/secrets/{secrete}/versions/{version}` - If specified, the `secretmanager.versions.access` permission should be granted to Vertex AI Extension Service Agent (https://cloud.google.com/vertex-ai/docs/general/access-control#service-agents) on the specified resource. */
    credentialSecret?: string;
}

/** Config for user oauth. This data type is not supported in Gemini API. */
export declare interface AuthConfigOauthConfig {
    /** Access token for extension endpoint. Only used to propagate token from [[ExecuteExtensionRequest.runtime_auth_config]] at request time. */
    accessToken?: string;
    /** The service account used to generate access tokens for executing the Extension. - If the service account is specified, the `iam.serviceAccounts.getAccessToken` permission should be granted to Vertex AI Extension Service Agent (https://cloud.google.com/vertex-ai/docs/general/access-control#service-agents) on the provided service account. */
    serviceAccount?: string;
}

/** Config for user OIDC auth. This data type is not supported in Gemini API. */
export declare interface AuthConfigOidcConfig {
    /** OpenID Connect formatted ID token for extension endpoint. Only used to propagate token from [[ExecuteExtensionRequest.runtime_auth_config]] at request time. */
    idToken?: string;
    /** The service account used to generate an OpenID Connect (OIDC)-compatible JWT token signed by the Google OIDC Provider (accounts.google.com) for extension endpoint (https://cloud.google.com/iam/docs/create-short-lived-credentials-direct#sa-credentials-oidc). - The audience for the token will be set to the URL in the server url defined in the OpenApi spec. - If the service account is provided, the service account should grant `iam.serviceAccounts.getOpenIdToken` permission to Vertex AI Extension Service Agent (https://cloud.google.com/vertex-ai/docs/general/access-control#service-agents). */
    serviceAccount?: string;
}

/** Config for auth_tokens.create parameters. */
export declare interface AuthToken {
    /** The name of the auth token. */
    name?: string;
    /** Optional. Input only. Immutable. An optional time after which, when using the resulting token, messages in BidiGenerateContent sessions will be rejected. (Gemini may preemptively close the session after this time.) If not set then this defaults to 30 minutes in the future. If set, this value must be less than 20 hours in the future. */
    expireTime?: string;
    /** Optional. Input only. Immutable. The time after which new Live API sessions using the token resulting from this request will be rejected. If not set this defaults to 60 seconds in the future. If set, this value must be less than 20 hours in the future. */
    newSessionExpireTime?: string;
    /** Optional. Input only. Immutable. The number of times the token can be used. If this value is zero then no limit is applied. Resuming a Live API session does not count as a use. If unspecified, the default is 1. */
    uses?: number;
}

/** Type of auth scheme. This enum is not supported in Gemini API. */
export declare enum AuthType {
    AUTH_TYPE_UNSPECIFIED = "AUTH_TYPE_UNSPECIFIED",
    /**
     * No Auth.
     */
    NO_AUTH = "NO_AUTH",
    /**
     * API Key Auth.
     */
    API_KEY_AUTH = "API_KEY_AUTH",
    /**
     * HTTP Basic Auth.
     */
    HTTP_BASIC_AUTH = "HTTP_BASIC_AUTH",
    /**
     * Google Service Account Auth.
     */
    GOOGLE_SERVICE_ACCOUNT_AUTH = "GOOGLE_SERVICE_ACCOUNT_AUTH",
    /**
     * OAuth auth.
     */
    OAUTH = "OAUTH",
    /**
     * OpenID Connect (OIDC) Auth.
     */
    OIDC_AUTH = "OIDC_AUTH"
}

/** Configures automatic detection of activity. */
export declare interface AutomaticActivityDetection {
    /** If enabled, detected voice and text input count as activity. If disabled, the client must send activity signals. */
    disabled?: boolean;
    /** Determines how likely speech is to be detected. */
    startOfSpeechSensitivity?: StartSensitivity;
    /** Determines how likely detected speech is ended. */
    endOfSpeechSensitivity?: EndSensitivity;
    /** The required duration of detected speech before start-of-speech is committed. The lower this value the more sensitive the start-of-speech detection is and the shorter speech can be recognized. However, this also increases the probability of false positives. */
    prefixPaddingMs?: number;
    /** The required duration of detected non-speech (e.g. silence) before end-of-speech is committed. The larger this value, the longer speech gaps can be without interrupting the user's activity but this will increase the model's latency. */
    silenceDurationMs?: number;
}

/**
 * SDK-only option of `interactions.create()` controlling automatic
 * continuation of long decodes.
 */
export declare type AutomaticContinuationOption = {
    /**
     * Defaults to `true`. When `true`, the SDK automatically resumes decoding
     * across multiple continuation hops whenever a response or stream stops at
     * the per-request decode token limit (`status: 'requires_continuation'`
     * with a `continuation_token`) until the interaction completes, reaches
     * `incomplete` (e.g. `max_output_tokens`), requires action, or fails. Pass
     * `automatic_continuation: false` to disable: the single server response is
     * then returned untouched (so callers can drive continuation themselves),
     * with a one-time console warning when it stops at `requires_continuation`.
     *
     * - For `stream: true`, the events of all continuation hops are yielded
     *   verbatim and in order on the returned `Stream`, including each hop's
     *   `interaction.created` and intermediate `interaction.completed` (with
     *   `status: 'requires_continuation'`); check `status` on
     *   `interaction.completed` events rather than treating the first one as the
     *   end of the output. A hop that drops before any output was yielded since
     *   its latest checkpoint is resumed from that checkpoint (up to 3
     *   consecutive reconnects without progress).
     * - For unary calls, each continuation hop is a separate interaction on the
     *   server that only contains that hop's output. The SDK merges the hops
     *   into one `Interaction`: `steps` are concatenated in hop order, `usage`
     *   token counts are summed across hops (with `usage.initial_input_tokens`
     *   set to the first hop's input tokens), and all other fields (`id`,
     *   `status`, ...) come from the final hop; the final hop's `id` can be
     *   passed as `previous_interaction_id` to continue the conversation.
     *   `continuation_ids` lists the ids of every hop in order (the last one is
     *   `id`); note that `interactions.get(id)` and `interactions.delete(id)`
     *   act on the final hop only. `previous_interaction_id`, `created` and
     *   `input` come from the first hop.
     * - With `store` enabled (the default), each continuation hop sends the hop
     *   that issued the `continuation_token` as `previous_interaction_id` and
     *   omits `input` (the server already has it). With `store: false`, the
     *   original `input` is resent with the token.
     * - Client-side continuation is skipped for `background: true` and agent
     *   interactions (`agent` / `agent_config`), whose loops are managed by the
     *   server. `background: true` with an explicit
     *   `automatic_continuation: false` is rejected.
     * - Timeouts: a numeric per-request `timeout_ms` (or `timeout`) in the
     *   request options is a wall-clock budget for the whole `create()` call.
     *   Each hop is sent with the time left, and once it runs out the call stops
     *   with a `ContinuationInterruptedError` (see below) so the work so far can
     *   be resumed. The client-level `httpOptions.timeout` and the retry options
     *   apply to each hop separately: transient errors on a continuation hop
     *   retry that hop using the latest `continuation_token` without restarting
     *   from the initial request.
     * - Billing note: with `background: false`, each continuation hop
     *   re-prefills the conversation and generated prefix, so input tokens are
     *   billed on every hop (and summed in `usage.total_input_tokens`). If an
     *   unrecoverable error occurs after one or more hops have completed, those
     *   completed hops are still billed. For server-managed continuation without
     *   client-side hop loops, use `background: true` (with `store: true`).
     * - Errors: a failure on the first request is thrown as usual. A failure
     *   after progress (a later hop, or a stream after a resumable checkpoint)
     *   is thrown as `ContinuationInterruptedError` (with the failure as
     *   `cause`) carrying `continuationToken`, `interactionId` and
     *   `continuationIds`, plus `partialInteraction` (the completed hops merged,
     *   for unary calls), so the output already produced is not lost and the
     *   call can be resumed manually. Running out of the per-request timeout
     *   after progress is reported the same way.
     */
    automatic_continuation?: boolean | undefined;
};

/** The configuration for automatic function calling. */
export declare interface AutomaticFunctionCallingConfig {
    /** Whether to disable automatic function calling.
     If not set or set to False, will enable automatic function calling.
     If set to True, will disable automatic function calling.
     */
    disable?: boolean;
    /** If automatic function calling is enabled,
     maximum number of remote calls for automatic function calling.
     This number should be a positive integer.
     If not set, SDK will set maximum number of remote calls to 10.
     */
    maximumRemoteCalls?: number;
    /** If automatic function calling is enabled,
     whether to ignore call history to the response.
     If not set, SDK will set ignore_call_history to false,
     and will append the call history to
     GenerateContentResponse.automatic_function_calling_history.
     */
    ignoreCallHistory?: boolean;
}

/** Autorater config used for evaluation. */
export declare interface AutoraterConfig {
    /** Number of samples for each instance in the dataset.
     If not specified, the default is 4. Minimum value is 1, maximum value
     is 32. */
    samplingCount?: number;
    /** Optional. Default is true. Whether to flip the candidate and baseline
     responses. This is only applicable to the pairwise metric. If enabled, also
     provide PairwiseMetricSpec.candidate_response_field_name and
     PairwiseMetricSpec.baseline_response_field_name. When rendering
     PairwiseMetricSpec.metric_prompt_template, the candidate and baseline
     fields will be flipped for half of the samples to reduce bias. */
    flipEnabled?: boolean;
    /** The fully qualified name of the publisher model or tuned autorater
     endpoint to use.

     Publisher model format:
     `projects/{project}/locations/{location}/publishers/{publisher}/models/{model}`

     Tuned model endpoint format:
     `projects/{project}/locations/{location}/endpoints/{endpoint}` */
    autoraterModel?: string;
    /** Configuration options for model generation and outputs. */
    generationConfig?: GenerationConfig;
}

/** Configures the avatar to be used in the session. */
export declare interface AvatarConfig {
    /** Pre-built avatar id. */
    avatarName?: string;
    /** Customized avatar appearance with a reference image. */
    customizedAvatar?: CustomizedAvatar;
    /** The bitrate of compressed audio. */
    audioBitrateBps?: number;
    /** The bitrate of compressed video output. */
    videoBitrateBps?: number;
}

declare type Awaitable<T> = T | Promise<T>;

declare type Awaitable_2<T> = T | Promise<T>;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
export declare type BackoffStrategy = {
    initialInterval: number;
    maxInterval: number;
    exponent: number;
    maxElapsedTime: number;
};

/**
 * The environment configuration for the agent.
 */
declare type BaseEnvironment = interactions.Environment | string;

/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
declare class BaseModule {
}

/**
 * Parameters for setting the base URLs for the Gemini API and Vertex AI API.
 */
export declare interface BaseUrlParameters {
    geminiUrl?: string;
    vertexUrl?: string;
}

export declare class Batches extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    /**
     * Lists batch jobs.
     *
     * @param params - The parameters for the list request.
     * @return - A pager of batch jobs.
     *
     * @example
     * ```ts
     * const batchJobs = await ai.batches.list({config: {'pageSize': 2}});
     * for await (const batchJob of batchJobs) {
     *   console.log(batchJob);
     * }
     * ```
     */
    list: (params?: types.ListBatchJobsParameters) => Promise<Pager<types.BatchJob>>;
    /**
     * Create batch job.
     *
     * @param params - The parameters for create batch job request.
     * @return The created batch job.
     *
     * @example
     * ```ts
     * const response = await ai.batches.create({
     *   model: 'gemini-flash-latest',
     *   src: {gcsUri: 'gs://bucket/path/to/file.jsonl', format: 'jsonl'},
     *   config: {
     *     dest: {gcsUri: 'gs://bucket/path/output/directory', format: 'jsonl'},
     *   }
     * });
     * console.log(response);
     * ```
     */
    create: (params: types.CreateBatchJobParameters) => Promise<types.BatchJob>;
    /**
     * **Experimental** Creates an embedding batch job.
     *
     * @param params - The parameters for create embedding batch job request.
     * @return The created batch job.
     *
     * @example
     * ```ts
     * const response = await ai.batches.createEmbeddings({
     *   model: 'text-embedding-004',
     *   src: {fileName: 'files/my_embedding_input'},
     * });
     * console.log(response);
     * ```
     */
    createEmbeddings: (params: types.CreateEmbeddingsBatchJobParameters) => Promise<types.BatchJob>;
    private createInlinedGenerateContentRequest;
    private getGcsUri;
    private getBigqueryUri;
    private formatDestination;
    /**
     * Internal method to create batch job.
     *
     * @param params - The parameters for create batch job request.
     * @return The created batch job.
     *
     */
    private createInternal;
    /**
     * Internal method to create batch job.
     *
     * @param params - The parameters for create batch job request.
     * @return The created batch job.
     *
     */
    private createEmbeddingsInternal;
    /**
     * Gets batch job configurations.
     *
     * @param params - The parameters for the get request.
     * @return The batch job.
     *
     * @example
     * ```ts
     * await ai.batches.get({name: '...'}); // The server-generated resource name.
     * ```
     */
    get(params: types.GetBatchJobParameters): Promise<types.BatchJob>;
    /**
     * Cancels a batch job.
     *
     * @param params - The parameters for the cancel request.
     * @return The empty response returned by the API.
     *
     * @example
     * ```ts
     * await ai.batches.cancel({name: '...'}); // The server-generated resource name.
     * ```
     */
    cancel(params: types.CancelBatchJobParameters): Promise<void>;
    private listInternal;
    /**
     * Deletes a batch job.
     *
     * @param params - The parameters for the delete request.
     * @return The empty response returned by the API.
     *
     * @example
     * ```ts
     * await ai.batches.delete({name: '...'}); // The server-generated resource name.
     * ```
     */
    delete(params: types.DeleteBatchJobParameters): Promise<types.DeleteResourceJob>;
}

/** Config for batches.create return value. */
export declare interface BatchJob {
    /** The resource name of the BatchJob. Output only.".
     */
    name?: string;
    /** The display name of the BatchJob.
     */
    displayName?: string;
    /** The state of the BatchJob.
     */
    state?: JobState;
    /** Output only. Only populated when the job's state is JOB_STATE_FAILED or JOB_STATE_CANCELLED. */
    error?: JobError;
    /** The time when the BatchJob was created.
     */
    createTime?: string;
    /** Output only. Time when the Job for the first time entered the `JOB_STATE_RUNNING` state. */
    startTime?: string;
    /** The time when the BatchJob was completed. This field is for Gemini Enterprise Agent Platform only.
     */
    endTime?: string;
    /** The time when the BatchJob was last updated.
     */
    updateTime?: string;
    /** The name of the model that produces the predictions via the BatchJob.
     */
    model?: string;
    /** Configuration for the input data. This field is for Gemini Enterprise Agent Platform only.
     */
    src?: BatchJobSource;
    /** Configuration for the output data.
     */
    dest?: BatchJobDestination;
    /** Information further describing the output of this job. Output only.
     */
    outputInfo?: BatchJobOutputInfo;
    /** Statistics on completed and failed prediction instances. This field is for Gemini Enterprise Agent Platform only.
     */
    completionStats?: CompletionStats;
}

/** Config for `dest` parameter. */
export declare interface BatchJobDestination {
    /** Storage format of the output files. Must be one of:
     'jsonl', 'bigquery', 'vertex-dataset'.
     */
    format?: string;
    /** The Google Cloud Storage URI to the output file.
     */
    gcsUri?: string;
    /** The BigQuery URI to the output table.
     */
    bigqueryUri?: string;
    /** This field is experimental and may change in future versions. The Vertex AI dataset destination.
     */
    vertexDataset?: VertexMultimodalDatasetDestination;
    /** The Gemini Developer API's file resource name of the output data
     (e.g. "files/12345"). The file will be a JSONL file with a single response
     per line. The responses will be GenerateContentResponse messages formatted
     as JSON. The responses will be written in the same order as the input
     requests.
     */
    fileName?: string;
    /** The responses to the requests in the batch. Returned when the batch was
     built using inlined requests. The responses will be in the same order as
     the input requests.
     */
    inlinedResponses?: InlinedResponse[];
    /** The responses to the requests in the batch. Returned when the batch was
     built using inlined requests. The responses will be in the same order as
     the input requests.
     */
    inlinedEmbedContentResponses?: InlinedEmbedContentResponse[];
}

export declare type BatchJobDestinationUnion = BatchJobDestination | string;

/** Represents the `output_info` field in batch jobs. */
export declare interface BatchJobOutputInfo {
    /** The full path of the Cloud Storage directory created, into which the prediction output is written. */
    gcsOutputDirectory?: string;
    /** The name of the BigQuery table created, in `predictions_TIMESTAMP` format, into which the prediction output is written. */
    bigqueryOutputTable?: string;
    /** This field is experimental and may change in future versions. The Vertex AI dataset name containing the output data. */
    vertexMultimodalDatasetName?: string;
}

/** Config for `src` parameter. */
export declare interface BatchJobSource {
    /** Storage format of the input files. Must be one of:
     'jsonl', 'bigquery', 'vertex-dataset'.
     */
    format?: string;
    /** The Google Cloud Storage URIs to input files.
     */
    gcsUri?: string[];
    /** The BigQuery URI to input table.
     */
    bigqueryUri?: string;
    /** This field is experimental and may change in future versions. The Vertex AI dataset resource name to use as input. Must be of type multimodal.
     */
    vertexDatasetName?: string;
    /** The Gemini Developer API's file resource name of the input data
     (e.g. "files/12345").
     */
    fileName?: string;
    /** The Gemini Developer API's inlined input data to run batch job.
     */
    inlinedRequests?: InlinedRequest[];
}

export declare type BatchJobSourceUnion = BatchJobSource | InlinedRequest[] | string;

declare type BeforeCreateRequestContext = HookContext & {};

declare interface BeforeCreateRequestHook {
    /**
     * A hook that is called before the SDK creates a `Request` object. The hook
     * can modify how a request is constructed since certain modifications, like
     * changing the request URL, cannot be done on a request object directly.
     */
    beforeCreateRequest: (hookCtx: BeforeCreateRequestContext, input: RequestInput) => RequestInput;
}

declare type BeforeRequestContext = HookContext & {};

declare type BeforeRequestHook = (req: Request) => Awaitable<Request | void>;

declare interface BeforeRequestHook_2 {
    /**
     * A hook that is called before the SDK sends a request. The hook can
     * introduce instrumentation code such as logging, tracing and metrics or
     * replace the request before it is sent or throw an error to stop the
     * request from being sent.
     */
    beforeRequest: (hookCtx: BeforeRequestContext, request: Request) => Awaitable_2<Request>;
}

/** Specifies the function Behavior. If not specified, the system keeps the current function call behavior. This field is currently only supported by the BidiGenerateContent method. */
export declare enum Behavior {
    /**
     * This value is unspecified.
     */
    UNSPECIFIED = "UNSPECIFIED",
    /**
     * If set, the system will wait to receive the function response before continuing the conversation.
     */
    BLOCKING = "BLOCKING",
    /**
     * If set, the system will not wait to receive the function response. Instead, it will attempt to handle function responses as they become available while maintaining the conversation between the user and the model.
     */
    NON_BLOCKING = "NON_BLOCKING"
}

/** The BigQuery location for the input content. This data type is not supported in Gemini API. */
export declare interface BigQuerySource {
    /** Required. BigQuery URI to a table, up to 2000 characters long. Accepted forms: * BigQuery path. For example: `bq://projectId.bqDatasetId.bqTableId`. */
    inputUri?: string;
}

/** Bleu metric value for an instance. This data type is not supported in Gemini API. */
export declare interface BleuMetricValue {
    /** Output only. Bleu score. */
    score?: number;
}

/** A content blob. A Blob contains data of a specific media type. It is used to represent images, audio, and video. */
declare interface Blob_2 {
    /** Required. The raw bytes of the data.
     * @remarks Encoded as base64 string. */
    data?: string;
    /** Optional. The display name of the blob. Used to provide a label or filename to distinguish blobs. This field is only returned in `PromptMessage` for prompt management. It is used in the Gemini calls only when server-side tools (`code_execution`, `google_search`, and `url_context`) are enabled. */
    displayName?: string;
    /** Required. The IANA standard MIME type of the source data. */
    mimeType?: string;
}
export { Blob_2 as Blob }

export declare type BlobImageUnion = Blob_2;

/** Output only. The reason why the prompt was blocked. */
export declare enum BlockedReason {
    /**
     * The blocked reason is unspecified.
     */
    BLOCKED_REASON_UNSPECIFIED = "BLOCKED_REASON_UNSPECIFIED",
    /**
     * The prompt was blocked for safety reasons.
     */
    SAFETY = "SAFETY",
    /**
     * The prompt was blocked for other reasons. For example, it may be due to the prompt's language, or because it contains other harmful content.
     */
    OTHER = "OTHER",
    /**
     * The prompt was blocked because it contains a term from the terminology blocklist.
     */
    BLOCKLIST = "BLOCKLIST",
    /**
     * The prompt was blocked because it contains prohibited content.
     */
    PROHIBITED_CONTENT = "PROHIBITED_CONTENT",
    /**
     * The prompt was blocked because it contains content that is unsafe for image generation.
     */
    IMAGE_SAFETY = "IMAGE_SAFETY",
    /**
     * The prompt was blocked by Model Armor. This enum value is not supported in Gemini API.
     */
    MODEL_ARMOR = "MODEL_ARMOR",
    /**
     * The prompt was blocked as a jailbreak attempt. This enum value is not supported in Gemini API.
     */
    JAILBREAK = "JAILBREAK"
}

/** A resource used in LLM queries for users to explicitly specify what to cache. */
export declare interface CachedContent {
    /** The server-generated resource name of the cached content. */
    name?: string;
    /** The user-generated meaningful display name of the cached content. */
    displayName?: string;
    /** The name of the publisher model to use for cached content. */
    model?: string;
    /** Creation time of the cache entry. */
    createTime?: string;
    /** When the cache entry was last updated in UTC time. */
    updateTime?: string;
    /** Expiration time of the cached content. */
    expireTime?: string;
    /** Metadata on the usage of the cached content. */
    usageMetadata?: CachedContentUsageMetadata;
}

/** Metadata on the usage of the cached content. */
export declare interface CachedContentUsageMetadata {
    /** Duration of audio in seconds. This field is not supported in Gemini API. */
    audioDurationSeconds?: number;
    /** Number of images. This field is not supported in Gemini API. */
    imageCount?: number;
    /** Number of text characters. This field is not supported in Gemini API. */
    textCount?: number;
    /** Total number of tokens that the cached content consumes. */
    totalTokenCount?: number;
    /** Duration of video in seconds. This field is not supported in Gemini API. */
    videoDurationSeconds?: number;
}

declare type CachedTokensByModality$ = ModalityTokens;

export declare class Caches extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    /**
     * Lists cached contents.
     *
     * @param params - The parameters for the list request.
     * @return - A pager of cached contents.
     *
     * @example
     * ```ts
     * const cachedContents = await ai.caches.list({config: {'pageSize': 2}});
     * for await (const cachedContent of cachedContents) {
     *   console.log(cachedContent);
     * }
     * ```
     */
    list: (params?: types.ListCachedContentsParameters) => Promise<Pager<types.CachedContent>>;
    /**
     * Creates a cached contents resource.
     *
     * @remarks
     * Context caching is only supported for specific models. See [Gemini
     * Developer API reference](https://ai.google.dev/gemini-api/docs/caching?lang=node/context-cac)
     * and [Gemini Enterprise Agent Platform reference](https://cloud.google.com/vertex-ai/generative-ai/docs/context-cache/context-cache-overview#supported_models)
     * for more information.
     *
     * @param params - The parameters for the create request.
     * @return The created cached content.
     *
     * @example
     * ```ts
     * const contents = ...; // Initialize the content to cache.
     * const response = await ai.caches.create({
     *   model: 'gemini-flash-latest',
     *   config: {
     *    'contents': contents,
     *    'displayName': 'test cache',
     *    'systemInstruction': 'What is the sum of the two pdfs?',
     *    'ttl': '86400s',
     *  }
     * });
     * ```
     */
    create(params: types.CreateCachedContentParameters): Promise<types.CachedContent>;
    /**
     * Gets cached content configurations.
     *
     * @param params - The parameters for the get request.
     * @return The cached content.
     *
     * @example
     * ```ts
     * await ai.caches.get({name: '...'}); // The server-generated resource name.
     * ```
     */
    get(params: types.GetCachedContentParameters): Promise<types.CachedContent>;
    /**
     * Deletes cached content.
     *
     * @param params - The parameters for the delete request.
     * @return The empty response returned by the API.
     *
     * @example
     * ```ts
     * await ai.caches.delete({name: '...'}); // The server-generated resource name.
     * ```
     */
    delete(params: types.DeleteCachedContentParameters): Promise<types.DeleteCachedContentResponse>;
    /**
     * Updates cached content configurations.
     *
     * @param params - The parameters for the update request.
     * @return The updated cached content.
     *
     * @example
     * ```ts
     * const response = await ai.caches.update({
     *   name: '...',  // The server-generated resource name.
     *   config: {'ttl': '7600s'}
     * });
     * ```
     */
    update(params: types.UpdateCachedContentParameters): Promise<types.CachedContent>;
    private listInternal;
}

/**
 * CallableTool is an invokable tool that can be executed with external
 * application (e.g., via Model Context Protocol) or local functions with
 * function calling.
 */
export declare interface CallableTool {
    /**
     * Returns tool that can be called by Gemini.
     */
    tool(): Promise<Tool>;
    /**
     * Executes the callable tool with the given function call arguments and
     * returns the response parts from the tool execution.
     */
    callTool(functionCalls: FunctionCall[]): Promise<Part[]>;
}

/**
 * CallableToolConfig is the configuration for a callable tool.
 */
export declare interface CallableToolConfig {
    /**
     * Specifies the model's behavior after invoking this tool.
     */
    behavior?: Behavior;
    /**
     * Timeout for remote calls in milliseconds. Note this timeout applies only to
     * tool remote calls, and not making HTTP requests to the API. */
    timeout?: number;
}

/** Optional parameters. */
export declare interface CancelBatchJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Config for batches.cancel parameters. */
export declare interface CancelBatchJobParameters {
    /** A fully-qualified BatchJob resource name or ID.
     Example: "projects/.../locations/.../batchPredictionJobs/456"
     or "456" when project and location are initialized in the client.
     */
    name: string;
    /** Optional parameters for the request. */
    config?: CancelBatchJobConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type CancelInteractionByIdGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type CancelInteractionByIdParams = Omit<CancelInteractionByIdRequest, "id">;

declare type CancelInteractionByIdRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The name of the interaction to cancel.
     */
    id: string;
};

/** Optional parameters for tunings.cancel method. */
export declare interface CancelTuningJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for the cancel method. */
export declare interface CancelTuningJobParameters {
    /** The resource name of the tuning job. */
    name: string;
    /** Optional parameters for the request. */
    config?: CancelTuningJobConfig;
}

/** Empty response for tunings.cancel method. */
export declare class CancelTuningJobResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** A response candidate generated from the model. */
export declare interface Candidate {
    /** Contains the multi-part content of the response.
     */
    content?: Content;
    /** Source attribution of the generated content.
     */
    citationMetadata?: CitationMetadata;
    /** Describes the reason the model stopped generating tokens.
     */
    finishMessage?: string;
    /** Number of tokens for this candidate.
     */
    tokenCount?: number;
    /** The reason why the model stopped generating tokens.
     If empty, the model has not stopped generating the tokens.
     */
    finishReason?: FinishReason;
    /** Output only. Metadata returned when grounding is enabled. It
     contains the sources used to ground the generated content.
     */
    groundingMetadata?: GroundingMetadata;
    /** Output only. The average log probability of the tokens in this candidate. This is a length-normalized score that can be used to compare the quality of candidates of different lengths. A higher average log probability suggests a more confident and coherent response. */
    avgLogprobs?: number;
    /** Output only. The 0-based index of this candidate in the list of generated responses. This is useful for distinguishing between multiple candidates when `candidate_count` > 1. */
    index?: number;
    /** Output only. The detailed log probability information for the tokens in this candidate. This is useful for debugging, understanding model uncertainty, and identifying potential "hallucinations". */
    logprobsResult?: LogprobsResult;
    /** Output only. A list of ratings for the safety of a response candidate. There is at most one rating per category. */
    safetyRatings?: SafetyRating[];
    /** Output only. Metadata returned when the model uses the `url_context` tool to get information from a user-provided URL. */
    urlContextMetadata?: UrlContextMetadata;
    /** Output only. An optional opaque continuation token returned when `finish_reason` is `CONTINUATION`. Clients can pass this token in a subsequent `GenerateContentRequest` to continue generation.
     * @remarks Encoded as base64 string. */
    continuationToken?: string;
}

/**
 * Chat session that enables sending messages to the model with previous
 * conversation context.
 *
 * @remarks
 * The session maintains all the turns between user and model.
 */
export declare class Chat {
    private readonly apiClient;
    private readonly modelsModule;
    private readonly model;
    private readonly config;
    private history;
    private sendPromise;
    constructor(apiClient: ApiClient, modelsModule: Models, model: string, config?: types.GenerateContentConfig, history?: types.Content[]);
    /**
     * Sends a message to the model and returns the response.
     *
     * @remarks
     * This method will wait for the previous message to be processed before
     * sending the next message. Automatic continuation
     * (`config.automaticContinuation`) is enabled by default (`true`); set
     * `config.automaticContinuation = false` to disable it.
     *
     * @see {@link Chat#sendMessageStream} for streaming method.
     * @param params - parameters for sending messages within a chat session.
     * @returns The model's response.
     *
     * @example
     * ```ts
     * const chat = ai.chats.create({model: 'gemini-2.0-flash'});
     * const response = await chat.sendMessage({
     *   message: 'Why is the sky blue?'
     * });
     * console.log(response.text);
     * ```
     */
    sendMessage(params: types.SendMessageParameters): Promise<types.GenerateContentResponse>;
    /**
     * Sends a message to the model and returns the response in chunks.
     *
     * @remarks
     * This method will wait for the previous message to be processed before
     * sending the next message. Automatic continuation
     * (`config.automaticContinuation`) is enabled by default (`true`); set
     * `config.automaticContinuation = false` to disable it.
     *
     * @see {@link Chat#sendMessage} for non-streaming method.
     * @param params - parameters for sending the message.
     * @return The model's response.
     *
     * @example
     * ```ts
     * const chat = ai.chats.create({model: 'gemini-2.0-flash'});
     * const response = await chat.sendMessageStream({
     *   message: 'Why is the sky blue?'
     * });
     * for await (const chunk of response) {
     *   console.log(chunk.text);
     * }
     * ```
     */
    sendMessageStream(params: types.SendMessageParameters): Promise<AsyncGenerator<types.GenerateContentResponse>>;
    /**
     * Returns the chat history.
     *
     * @remarks
     * The history is a list of contents alternating between user and model.
     *
     * There are two types of history:
     * - The `curated history` contains only the valid turns between user and
     * model, which will be included in the subsequent requests sent to the model.
     * - The `comprehensive history` contains all turns, including invalid or
     *   empty model outputs, providing a complete record of the history.
     *
     * The history is updated after receiving the response from the model,
     * for streaming response, it means receiving the last chunk of the response.
     *
     * The `comprehensive history` is returned by default. To get the `curated
     * history`, set the `curated` parameter to `true`.
     *
     * @param curated - whether to return the curated history or the comprehensive
     *     history.
     * @return History contents alternating between user and model for the entire
     *     chat session.
     */
    getHistory(curated?: boolean): types.Content[];
    private processStreamResponse;
    private recordHistory;
}

/**
 * A utility class to create a chat session.
 */
export declare class Chats {
    private readonly modelsModule;
    private readonly apiClient;
    constructor(modelsModule: Models, apiClient: ApiClient);
    /**
     * Creates a new chat session.
     *
     * @remarks
     * The config in the params will be used for all requests within the chat
     * session unless overridden by a per-request `config` in
     * @see {@link types.SendMessageParameters#config}.
     * Automatic continuation (`config.automaticContinuation`) is enabled by
     * default in chat sessions (`true`). Set `config.automaticContinuation =
     * false` to disable it.
     *
     * @param params - Parameters for creating a chat session.
     * @returns A new chat session.
     *
     * @example
     * ```ts
     * const chat = ai.chats.create({
     *   model: 'gemini-2.0-flash'
     *   config: {
     *     temperature: 0.5,
     *     maxOutputTokens: 1024,
     *   }
     * });
     * ```
     */
    create(params: types.CreateChatParameters): Chat;
}

/** Describes the machine learning model version checkpoint. */
export declare interface Checkpoint {
    /** The ID of the checkpoint.
     */
    checkpointId?: string;
    /** The epoch of the checkpoint.
     */
    epoch?: string;
    /** The step of the checkpoint.
     */
    step?: string;
}

/** Config for telling the service how to chunk the file. */
export declare interface ChunkingConfig {
    /** White space chunking configuration. */
    whiteSpaceConfig?: WhiteSpaceConfig;
}

/** A citation for a piece of generatedcontent. This data type is not supported in Gemini API. */
export declare interface Citation {
    /** Output only. The end index of the citation in the content. */
    endIndex?: number;
    /** Output only. The license of the source of the citation. */
    license?: string;
    /** Output only. The publication date of the source of the citation. */
    publicationDate?: GoogleTypeDate;
    /** Output only. The start index of the citation in the content. */
    startIndex?: number;
    /** Output only. The title of the source of the citation. */
    title?: string;
    /** Output only. The URI of the source of the citation. */
    uri?: string;
}

/** Citation information when the model quotes another source. */
export declare interface CitationMetadata {
    /** Contains citation information when the model directly quotes, at
     length, from another source. Can include traditional websites and code
     repositories.
     */
    citations?: Citation[];
}

declare class ClientSDK {
    readonly _httpClient: HTTPClient;
    readonly _hooks: SDKHooks;
    readonly _logger?: Logger | undefined;
    readonly _baseURL: URL | null;
    readonly _options: SDKOptions & {
        hooks?: SDKHooks;
    };
    constructor(options?: SDKOptions);
    _createRequest(context: HookContext, conf: RequestConfig, options?: RequestOptions): Result<Request, InvalidRequestError | UnexpectedClientError>;
    _do(request: Request, options: {
        context: HookContext;
        isErrorStatusCode: (statusCode: number) => boolean;
        retryConfig: RetryConfig;
        retryCodes: string[];
    }): Promise<Result<Response, RequestAbortedError | RequestTimeoutError | ConnectionError | UnexpectedClientError>>;
}

declare type CodeExecution$ = CodeExecution;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A tool that can be used by the model to execute code.
 */
declare type CodeExecution = {
    type: "code_execution";
};

declare type CodeExecutionCall$ = CodeExecutionCallDelta;

declare type CodeExecutionCallArguments$ = CodeExecutionCallArguments;

/**
 * The arguments to pass to the code execution.
 */
declare type CodeExecutionCallArguments = {
    /**
     * The code to be executed.
     */
    code?: string | undefined;
    /**
     * Programming language of the `code`.
     */
    language?: Language_2 | undefined;
};

declare type CodeExecutionCallDelta = {
    /**
     * The arguments to pass to the code execution.
     */
    arguments: CodeExecutionCallArguments;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "code_execution_call";
};

declare type CodeExecutionCallStep$ = CodeExecutionCallStep;

/**
 * Code execution call step.
 */
declare type CodeExecutionCallStep = {
    /**
     * The arguments to pass to the code execution.
     */
    arguments: CodeExecutionCallArguments;
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "code_execution_call";
};

declare type CodeExecutionResult$ = CodeExecutionResultDelta;

/** Result of executing the ExecutableCode. Generated only when the `CodeExecution` tool is used. */
export declare interface CodeExecutionResult {
    /** Required. Outcome of the code execution. */
    outcome?: Outcome;
    /** Optional. Contains stdout when code execution is successful, stderr or other description otherwise. */
    output?: string;
    /** Optional. The identifier of the `ExecutableCode` part this result is for. Only populated if the corresponding `ExecutableCode` has an id. */
    id?: string;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type CodeExecutionResultDelta = {
    is_error?: boolean | undefined;
    result: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "code_execution_result";
};

declare type CodeExecutionResultStep$ = CodeExecutionResultStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Code execution result step.
 */
declare type CodeExecutionResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * Whether the code execution resulted in an error.
     */
    is_error?: boolean | undefined;
    /**
     * Required. The output of the code execution.
     */
    result: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "code_execution_result";
};

declare type CodeMenderAgentConfig$ = CodeMenderAgentConfig;

/**
 * Configuration for the CodeMender agent.
 */
declare type CodeMenderAgentConfig = {
    /**
     * Request parameters specific to FIND sessions, used for discovering
     *
     * @remarks
     * vulnerabilities in a codebase.
     */
    find_request?: FindRequest | undefined;
    /**
     * Request parameters specific to FIX sessions, used for generating and
     *
     * @remarks
     * validating security patches.
     */
    fix_request?: FixRequest | undefined;
    /**
     * The name of the model to use for the CodeMender agent. One
     *
     * @remarks
     * CodeMender session will only use one model.
     */
    model?: string | undefined;
    /**
     * The configuration of CodeMender sessions.
     */
    session_config?: SessionConfig | undefined;
    /**
     * Parameter for grouping multiple interactions that belong to
     *
     * @remarks
     * the same CodeMender session.
     */
    session_id?: string | undefined;
    type: "code-mender";
};

/** Success and error statistics of processing multiple entities (for example, DataItems or structured data rows) in batch. This data type is not supported in Gemini API. */
export declare interface CompletionStats {
    /** Output only. The number of entities for which any error was encountered. */
    failedCount?: string;
    /** Output only. In cases when enough errors are encountered a job, pipeline, or operation may be failed as a whole. Below is the number of entities for which the processing had not been finished (either in successful or failed state). Set to -1 if the number is unknown (for example, the operation failed before the total entity number could be collected). */
    incompleteCount?: string;
    /** Output only. The number of entities that had been processed successfully. */
    successfulCount?: string;
    /** Output only. The number of the successful forecast points that are generated by the forecasting model. This is ONLY used by the forecasting batch prediction. */
    successfulForecastPointCount?: string;
}

/** Composite reinforcement tuning reward config. */
export declare interface CompositeReinforcementTuningRewardConfig {
    /** List of reward function configurations with weights. */
    weightedRewardConfigs?: CompositeReinforcementTuningRewardConfigWeightedRewardConfig[];
}

/** Composite reinforcement tuning reward config weighted reward config. */
export declare interface CompositeReinforcementTuningRewardConfigWeightedRewardConfig {
    /** Single reward configuration. */
    rewardConfig?: SingleReinforcementTuningRewardConfig;
    /** How much this single reward contributes to the total overall reward. Total reward is a linear combination of single rewards with their corresponding weights, i.e., ``` total_reward = ( weight_a * reward_a + weight_b * reward_b + ... ) / (weight_a + weight_b + ...) ``` */
    weight?: number;
}

declare type ComputerUse$ = ComputerUse_2;

/** A tool that enables the model to interact directly with a computer environment. */
export declare interface ComputerUse {
    /** Optional. Whether to enable the prompt injection detection check on the computer use request. */
    enablePromptInjectionDetection?: boolean;
    /** Required. The target environment where the computer use tool operates. */
    environment?: Environment;
    /** Optional. A list of predefined functions to explicitly exclude from the model call. By default, [predefined functions](https://cloud.google.com/vertex-ai/generative-ai/docs/computer-use#supported-actions) are included. Excluding functions allows for a more restricted action space or custom definitions for predefined functions. */
    excludedPredefinedFunctions?: string[];
    /** Optional. A list of safety policies to disable for the computer use tool. */
    disabledSafetyPolicies?: SafetyPolicy[];
}

/**
 * A tool that can be used by the model to interact with the computer.
 */
declare type ComputerUse_2 = {
    /**
     * Optional. Disabled safety policies for computer use.
     */
    disabled_safety_policies?: Array<DisabledSafetyPolicy> | undefined;
    /**
     * Whether enable the prompt injection detection check on computer-use
     *
     * @remarks
     * request.
     */
    enable_prompt_injection_detection?: boolean | undefined;
    /**
     * The environment being operated.
     */
    environment?: EnvironmentEnum | undefined;
    /**
     * The list of predefined functions that are excluded from the model call.
     */
    excluded_predefined_functions?: Array<string> | undefined;
    type: "computer_use";
};

/** Optional parameters for computing tokens. */
export declare interface ComputeTokensConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for computing tokens. */
export declare interface ComputeTokensParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** Input content. */
    contents: ContentListUnion;
    /** Optional parameters for the request.
     */
    config?: ComputeTokensConfig;
}

/** Response for computing tokens. */
export declare class ComputeTokensResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** Lists of tokens info from the input. A ComputeTokensRequest could have multiple instances with a prompt in each instance. We also need to return lists of tokens info for the request with multiple instances. */
    tokensInfo?: TokensInfo[];
}

/** Local tokenizer compute tokens result. */
export declare interface ComputeTokensResult {
    /** Lists of tokens info from the input. */
    tokensInfo?: TokensInfo[];
}

/**
 * An error that is raised when a HTTP client is unable to make a request to
 * a server.
 */
declare class ConnectionError extends HTTPClientError {
    readonly name = "ConnectionError";
}

declare type Content$ = Content_2;

/** Contains the multi-part content of a message. */
export declare interface Content {
    /** List of parts that constitute a single message. Each part may have
     a different IANA MIME type. */
    parts?: Part[];
    /** Optional. The producer of the content. Must be either 'user' or 'model'. If not set, the service will default to 'user'. */
    role?: string;
}

/**
 * The content of the response.
 */
declare type Content_2 = AudioContent | DocumentContent | ImageContent | TextContent | VideoContent;

/** The embedding generated from an input content. */
export declare interface ContentEmbedding {
    /** A list of floats representing an embedding.
     */
    values?: number[];
    /** Gemini Enterprise Agent Platform only. Statistics of the input text associated with this
     embedding.
     */
    statistics?: ContentEmbeddingStatistics;
}

/** Statistics of the input text associated with the result of content embedding. */
export declare interface ContentEmbeddingStatistics {
    /** Gemini Enterprise Agent Platform only. If the input text was truncated due to having
     a length longer than the allowed maximum input.
     */
    truncated?: boolean;
    /** Gemini Enterprise Agent Platform only. Number of tokens of the input text.
     */
    tokenCount?: number;
    /** Gemini Enterprise Agent Platform only. List of modalities and their token count for the input content.
     */
    tokensDetails?: ModalityTokenCount[];
}

export declare type ContentListUnion = Content | Content[] | PartUnion | PartUnion[];

/** A content reference image.

 A content reference image represents a subject to reference (ex. person,
 product, animal) provided by the user. It can optionally be provided in
 addition to a style reference image (ex. background, style reference). */
export declare class ContentReferenceImage {
    /** The reference image for the editing operation. */
    referenceImage?: Image_2;
    /** The id of the reference image. */
    referenceId?: number;
    /** The type of the reference image. Only set by the SDK. */
    referenceType?: string;
    /** Internal method to convert to ReferenceImageAPIInternal. */
    toReferenceImageAPI(): ReferenceImageAPIInternal;
}

export declare type ContentUnion = Content | PartUnion[] | PartUnion;

/** Enables context window compression -- mechanism managing model context window so it does not exceed given length. */
export declare interface ContextWindowCompressionConfig {
    /** Number of tokens (before running turn) that triggers context window compression mechanism. */
    triggerTokens?: string;
    /** Sliding window compression mechanism. */
    slidingWindow?: SlidingWindow;
}

/**
 * Thrown when Interactions automatic continuation fails after progress.
 *
 * `interactions.create()` with `automatic_continuation` enabled (the default)
 * may make several requests ("hops"), each one resuming the decode from the
 * previous hop's `continuation_token`. If a hop fails after the server already
 * produced (and billed) output in an earlier hop, or after a resumable
 * checkpoint was reached, this error is thrown instead of the underlying
 * error so the work is not lost. The underlying error is `cause`.
 *
 * To resume, pass `continuationToken` as `continuation_token` to
 * `interactions.create()`: with `store` enabled (the default), also pass
 * `interactionId` as `previous_interaction_id` and no `input`; with
 * `store: false`, resend the original `input`.
 */
export declare class ContinuationInterruptedError extends Error {
    /** The underlying error (the failed hop's API or transport error). */
    readonly cause: unknown;
    /**
     * For unary calls, the interaction merged from the hops that completed
     * (status `requires_continuation`, with the resumable `continuation_token`),
     * or undefined if no hop completed. Always undefined for streams, whose
     * events were already yielded.
     */
    readonly partialInteraction: unknown;
    /**
     * The latest resumable continuation token. For streams this may be a mid-hop
     * checkpoint: resuming from it re-generates any output yielded after the
     * checkpoint.
     */
    readonly continuationToken: string | undefined;
    /**
     * The id of the interaction that issued `continuationToken` (the value to
     * send as `previous_interaction_id`), or undefined if unknown or unstored
     * (`store: false`).
     */
    readonly interactionId: string | undefined;
    /** The ids of every hop created during the call, in order. */
    readonly continuationIds: string[];
    constructor(options: ContinuationInterruptedErrorInfo);
}

/**
 * Details for a `ContinuationInterruptedError`.
 */
export declare interface ContinuationInterruptedErrorInfo {
    /** The error message. */
    message: string;
    /** The underlying error (the failed hop's API or transport error). */
    cause?: unknown;
    /**
     * For unary calls, the interaction merged from the hops that completed;
     * undefined for streams.
     */
    partialInteraction?: unknown;
    /** The latest resumable continuation token. */
    continuationToken?: string;
    /** The id of the interaction that issued `continuationToken`. */
    interactionId?: string;
    /** The ids of every hop created during the call, in order. */
    continuationIds?: string[];
}

/** Configuration for a Control reference image. */
export declare interface ControlReferenceConfig {
    /** The type of control reference image to use. */
    controlType?: ControlReferenceType;
    /** Defaults to False. When set to True, the control image will be
     computed by the model based on the control type. When set to False,
     the control image must be provided by the user. */
    enableControlImageComputation?: boolean;
}

/** A control reference image.

 The image of the control reference image is either a control image provided
 by the user, or a regular image which the backend will use to generate a
 control image of. In the case of the latter, the
 enable_control_image_computation field in the config should be set to True.

 A control image is an image that represents a sketch image of areas for the
 model to fill in based on the prompt. */
export declare class ControlReferenceImage {
    /** The reference image for the editing operation. */
    referenceImage?: Image_2;
    /** The id of the reference image. */
    referenceId?: number;
    /** The type of the reference image. Only set by the SDK. */
    referenceType?: string;
    /** Configuration for the control reference image. */
    config?: ControlReferenceConfig;
    /** Internal method to convert to ReferenceImageAPIInternal. */
    toReferenceImageAPI(): ReferenceImageAPIInternal;
}

/** Enum representing the control type of a control reference image. */
export declare enum ControlReferenceType {
    CONTROL_TYPE_DEFAULT = "CONTROL_TYPE_DEFAULT",
    CONTROL_TYPE_CANNY = "CONTROL_TYPE_CANNY",
    CONTROL_TYPE_SCRIBBLE = "CONTROL_TYPE_SCRIBBLE",
    CONTROL_TYPE_FACE_MESH = "CONTROL_TYPE_FACE_MESH"
}

/** Config for the count_tokens method. */
export declare interface CountTokensConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** Instructions for the model to steer it toward better performance.
     */
    systemInstruction?: ContentUnion;
    /** Code that enables the system to interact with external systems to
     perform an action outside of the knowledge and scope of the model.
     */
    tools?: Tool[];
    /** Configuration that the model uses to generate the response. Not
     supported by the Gemini Developer API.
     */
    generationConfig?: GenerationConfig;
}

/** Parameters for counting tokens. */
export declare interface CountTokensParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** Input content. */
    contents: ContentListUnion;
    /** Configuration for counting tokens. */
    config?: CountTokensConfig;
}

/** Response for counting tokens. */
export declare class CountTokensResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** Total number of tokens. */
    totalTokens?: number;
    /** Number of tokens in the cached part of the prompt (the cached content). */
    cachedContentTokenCount?: number;
}

/** Local tokenizer count tokens result. */
export declare interface CountTokensResult {
    /** The total number of tokens. */
    totalTokens?: number;
}

declare type CreateAgentGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

/**
 * Interaction for generating the completion using agents.
 */
declare type CreateAgentInteraction = {
    /**
     * The agent to interact with.
     */
    agent: AgentOption;
    /**
     * Configuration parameters for the agent interaction.
     */
    agent_config?: AntigravityAgentConfig | CodeMenderAgentConfig | DeepResearchAgentConfig | DynamicAgentConfig | undefined;
    /**
     * Input only. Whether to run the model interaction in the background.
     */
    background?: boolean | undefined;
    /**
     * Opaque token to resume a long decode. Output: set when status is
     *
     * @remarks
     * REQUIRES_CONTINUATION and decoding can be resumed. Input: pass the latest
     * token back unchanged in CreateInteraction to continue decoding.
     */
    continuation_token?: string | undefined;
    /**
     * The environment configuration for the interaction. Can be an object
     *
     * @remarks
     * specifying remote environment sources or a string referencing an existing
     * environment ID.
     */
    environment?: Environment_2 | string | undefined;
    /**
     * The input for the interaction.
     */
    input?: InteractionsInput | undefined;
    /**
     * The labels with user-defined metadata for the request.
     *
     * @remarks
     *
     * Label keys and values can be no longer than 63 characters
     * (Unicode codepoints) and can only contain lowercase letters, numeric
     * characters, underscores, and dashes. International characters are allowed.
     * Label values are optional. Label keys must start with a letter.
     */
    labels?: {
        [k: string]: string;
    } | undefined;
    /**
     * The ID of the previous interaction, if any.
     */
    previous_interaction_id?: string | undefined;
    /**
     * Enforces that the generated response is a JSON object that complies with
     *
     * @remarks
     * the JSON schema specified in this field.
     */
    response_format?: ResponseFormat_2 | Array<ResponseFormat_2> | undefined;
    /**
     * The mime type of the response. This is required if response_format is set.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    response_mime_type?: string | undefined;
    /**
     * The requested modalities of the response (TEXT, IMAGE, AUDIO).
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    response_modalities?: Array<ResponseModality> | undefined;
    /**
     * Safety settings for the interaction.
     */
    safety_settings?: Array<SafetySetting_2> | undefined;
    service_tier?: ServiceTier_2 | undefined;
    /**
     * Input only. Whether to store the response and request for later retrieval.
     */
    store?: boolean | undefined;
    /**
     * Input only. Whether the interaction will be streamed.
     */
    stream?: boolean | undefined;
    /**
     * System instruction for the interaction.
     */
    system_instruction?: string | undefined;
    /**
     * A list of tool declarations the model may call during interaction.
     */
    tools?: Array<Tool_2> | undefined;
    /**
     * Message for configuring webhook events for a request.
     */
    webhook_config?: WebhookConfig_2 | undefined;
};

/**
 * Configuration parameters for the agent interaction.
 */
declare type CreateAgentInteractionAgentConfig = AntigravityAgentConfig | CodeMenderAgentConfig | DeepResearchAgentConfig | DynamicAgentConfig;

/**
 * The environment configuration for the interaction. Can be an object
 *
 * @remarks
 * specifying remote environment sources or a string referencing an existing
 * environment ID.
 */
declare type CreateAgentInteractionEnvironment = Environment_2 | string;

declare type CreateAgentInteractionParams$ = CreateAgentInteractionParams;

declare type CreateAgentInteractionParams = Omit<CreateInteractionRequest, "body"> & CreateAgentInteraction;

declare type CreateAgentInteractionParamsNonStreaming$ = CreateAgentInteraction;

declare type CreateAgentInteractionParamsNonStreaming$2 = CreateAgentInteractionParamsNonStreaming;

declare type CreateAgentInteractionParamsNonStreaming = CreateAgentInteractionParams & {
    stream?: false | undefined;
};

declare type CreateAgentInteractionParamsStreaming$ = CreateAgentInteraction;

declare type CreateAgentInteractionParamsStreaming$2 = CreateAgentInteractionParamsStreaming;

declare type CreateAgentInteractionParamsStreaming = CreateAgentInteractionParams & {
    stream: true;
};

/**
 * Enforces that the generated response is a JSON object that complies with
 *
 * @remarks
 * the JSON schema specified in this field.
 */
declare type CreateAgentInteractionResponseFormat = ResponseFormat_2 | Array<ResponseFormat_2>;

declare type CreateAgentParams = Omit<CreateAgentRequest, "body"> & CreateAgentRequest["body"];

declare type CreateAgentRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The request body.
     */
    body: agents.Agent;
};

/** Optional parameters. */
export declare interface CreateAuthTokenConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** An optional time after which, when using the resulting token,
     messages in Live API sessions will be rejected. (Gemini may
     preemptively close the session after this time.)

     If not set then this defaults to 30 minutes in the future. If set, this
     value must be less than 20 hours in the future. */
    expireTime?: string;
    /** The time after which new Live API sessions using the token
     resulting from this request will be rejected.

     If not set this defaults to 60 seconds in the future. If set, this value
     must be less than 20 hours in the future. */
    newSessionExpireTime?: string;
    /** The number of times the token can be used. If this value is zero
     then no limit is applied. Default is 1. Resuming a Live API session does
     not count as a use. */
    uses?: number;
    /** Configuration specific to Live API connections created using this token. */
    liveConnectConstraints?: LiveConnectConstraints;
    /** Additional fields to lock in the effective LiveConnectParameters. */
    lockAdditionalFields?: string[];
}

/** Config for auth_tokens.create parameters. */
export declare interface CreateAuthTokenParameters {
    /** Optional parameters for the request. */
    config?: CreateAuthTokenConfig;
}

/** Config for optional parameters. */
export declare interface CreateBatchJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The user-defined name of this BatchJob.
     */
    displayName?: string;
    /** GCS or BigQuery URI prefix for the output predictions. Example:
     "gs://path/to/output/data" or "bq://projectId.bqDatasetId.bqTableId".
     */
    dest?: BatchJobDestinationUnion;
    /** Webhook configuration for receiving notifications when the batch
     operation completes.
     */
    webhookConfig?: WebhookConfig;
}

/** Config for batches.create parameters. */
export declare interface CreateBatchJobParameters {
    /** The name of the model to produces the predictions via the BatchJob.
     */
    model?: string;
    /** GCS URI(-s) or BigQuery URI to your input data to run batch job.
     Example: "gs://path/to/input/data" or "bq://projectId.bqDatasetId.bqTableId".
     */
    src: BatchJobSourceUnion;
    /** Optional parameters for creating a BatchJob.
     */
    config?: CreateBatchJobConfig;
}

/** Optional configuration for cached content creation. */
export declare interface CreateCachedContentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The TTL for this resource. The expiration time is computed: now + TTL. It is a duration string, with up to nine fractional digits, terminated by 's'. Example: "3.5s". */
    ttl?: string;
    /** Timestamp of when this resource is considered expired. Uses RFC 3339 format, Example: 2014-10-02T15:01:23Z. */
    expireTime?: string;
    /** The user-generated meaningful display name of the cached content.
     */
    displayName?: string;
    /** The content to cache.
     */
    contents?: ContentListUnion;
    /** Developer set system instruction.
     */
    systemInstruction?: ContentUnion;
    /** A list of `Tools` the model may use to generate the next response.
     */
    tools?: Tool[];
    /** Configuration for the tools to use. This config is shared for all tools.
     */
    toolConfig?: ToolConfig;
    /** The Cloud KMS resource identifier of the customer managed
     encryption key used to protect a resource.
     The key needs to be in the same region as where the compute resource is
     created. See
     https://cloud.google.com/vertex-ai/docs/general/cmek for more
     details. If this is set, then all created CachedContent objects
     will be encrypted with the provided encryption key.
     Allowed formats: projects/{project}/locations/{location}/keyRings/{key_ring}/cryptoKeys/{crypto_key}
     */
    kmsKeyName?: string;
}

/** Parameters for caches.create method. */
export declare interface CreateCachedContentParameters {
    /** ID of the model to use. Example: gemini-flash-latest */
    model: string;
    /** Configuration that contains optional parameters.
     */
    config?: CreateCachedContentConfig;
}

/** Parameters for initializing a new chat session.

 These parameters are used when creating a chat session with the
 `chats.create()` method. */
export declare interface CreateChatParameters {
    /** The name of the model to use for the chat session.

     For example: 'gemini-flash-latest', 'gemini-flash-lite-latest', etc. See Gemini API
     docs to find the available models.
     */
    model: string;
    /** The initial conversation history for the chat session.

     This allows you to start the chat with a pre-existing history. The history
     must be a list of `Content` alternating between 'user' and 'model' roles.
     It should start with a 'user' message.
     */
    history?: Content[];
    /** Config for the entire chat session.

     This config applies to all requests within the session
     unless overridden by a per-request `config` in `SendMessageParameters`.
     */
    config?: GenerateContentConfig;
}

declare type CreateCredentialGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type CreateCredentialParams = Omit<CreateCredentialRequest, "body"> & CreateCredentialRequest["body"];

declare type CreateCredentialRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The request body.
     */
    body: credentials.CredentialCreateParams;
};

/** Config for optional parameters. */
export declare interface CreateEmbeddingsBatchJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The user-defined name of this BatchJob.
     */
    displayName?: string;
}

/** Config for batches.create parameters. */
export declare interface CreateEmbeddingsBatchJobParameters {
    /** The name of the model to produces the predictions via the BatchJob.
     */
    model?: string;
    /** input data to run batch job".
     */
    src: EmbeddingsBatchJobSource;
    /** Optional parameters for creating a BatchJob.
     */
    config?: CreateEmbeddingsBatchJobConfig;
}

declare type CreateEnvironmentGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type CreateEnvironmentRequest$ = CreateEnvironmentRequest_2;

declare type CreateEnvironmentRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The request body.
     */
    body: environments.CreateEnvironmentRequest;
};

/**
 * Request for `CreateEnvironment`.
 */
declare type CreateEnvironmentRequest_2 = {
    /**
     * Optional. The source environment to copy/fork from.
     *
     * @remarks
     * Format: `environments/{environment_id}` or `{environment_id}`.
     * When specified, `sources` and `env` must be empty.
     */
    from_environment?: string | undefined;
    /**
     * Network configuration for the environment.
     */
    network?: interactions.EnvironmentNetworkEgressAllowlist | CreateEnvironmentRequestNetworkEnum | undefined;
    /**
     * Sources to be mounted into the environment.
     */
    sources?: Array<interactions.Source> | undefined;
};

declare type CreateEnvironmentRequestNetworkEnum = "disabled";

/**
 * Network configuration for the environment.
 */
declare type CreateEnvironmentRequestNetworkUnion = interactions.EnvironmentNetworkEgressAllowlist | CreateEnvironmentRequestNetworkEnum;

/** Used to override the default configuration. */
export declare interface CreateFileConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Generates the parameters for the private _create method. */
export declare interface CreateFileParameters {
    /** The file to be uploaded.
     mime_type: (Required) The MIME type of the file. Must be provided.
     name: (Optional) The name of the file in the destination (e.g.
     'files/sample-image').
     display_name: (Optional) The display name of the file.
     */
    file: File_2;
    /** Used to override the default configuration. */
    config?: CreateFileConfig;
}

/** Response for the create file method. */
export declare class CreateFileResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** Optional parameters for creating a file search store. */
export declare interface CreateFileSearchStoreConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The human-readable display name for the file search store.
     */
    displayName?: string;
    /** The embedding model to use for the FileSearchStore.
     Format: `models/{model}`. If not specified, the default embedding model will be used.
     */
    embeddingModel?: string;
}

/** Config for file_search_stores.create parameters. */
export declare interface CreateFileSearchStoreParameters {
    /** Optional parameters for creating a file search store.
     */
    config?: CreateFileSearchStoreConfig;
}

/**
 * Creates a `FunctionResponsePart` object from a `base64` encoded `string`.
 */
export declare function createFunctionResponsePartFromBase64(data: string, mimeType: string): FunctionResponsePart;

/**
 * Creates a `FunctionResponsePart` object from a `URI` string.
 */
export declare function createFunctionResponsePartFromUri(uri: string, mimeType: string): FunctionResponsePart;

declare type CreateInteractionGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type CreateInteractionParams = Omit<CreateInteractionRequest, "body"> & CreateInteractionRequest["body"];

declare type CreateInteractionParamsNonStreaming = CreateInteractionParams & {
    stream?: false | undefined;
};

declare type CreateInteractionParamsStreaming = CreateInteractionParams & {
    stream: true;
};

declare type CreateInteractionParamsWithOptions = Interactions.InteractionCreateParams & AutomaticContinuationOption;

declare type CreateInteractionRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * The request body.
     */
    body: interactions.CreateAgentInteraction | interactions.CreateModelInteraction;
};

/**
 * The request body.
 */
declare type CreateInteractionRequestBody = interactions.CreateAgentInteraction | interactions.CreateModelInteraction;

declare type CreateInteractionResponse = interactions.Interaction | Stream<interactions.InteractionSSEEvent>;

/**
 * Creates a `Content` object with a model role from a `PartListUnion` object or `string`.
 */
export declare function createModelContent(partOrString: PartListUnion | string): Content;

/**
 * Interaction for generating the completion using models.
 */
declare type CreateModelInteraction = {
    /**
     * Input only. Whether to run the model interaction in the background.
     */
    background?: boolean | undefined;
    /**
     * The name of the cached content used as context to serve the prediction. Note: only used in explicit caching, where users can have control over caching (e.g. what content to cache) and enjoy guaranteed cost savings. Format: cachedContents/{cachedContent}
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    cached_content?: string | undefined;
    /**
     * Opaque token to resume a long decode. Output: set when status is
     *
     * @remarks
     * REQUIRES_CONTINUATION and decoding can be resumed. Input: pass the latest
     * token back unchanged in CreateInteraction to continue decoding.
     */
    continuation_token?: string | undefined;
    /**
     * The environment configuration for the interaction. Can be an object
     *
     * @remarks
     * specifying remote environment sources or a string referencing an existing
     * environment ID.
     */
    environment?: Environment_2 | string | undefined;
    /**
     * Configuration parameters for model interactions.
     */
    generation_config?: GenerationConfig_2 | undefined;
    /**
     * The input for the interaction.
     */
    input?: InteractionsInput | undefined;
    /**
     * The labels with user-defined metadata for the request.
     *
     * @remarks
     *
     * Label keys and values can be no longer than 63 characters
     * (Unicode codepoints) and can only contain lowercase letters, numeric
     * characters, underscores, and dashes. International characters are allowed.
     * Label values are optional. Label keys must start with a letter.
     */
    labels?: {
        [k: string]: string;
    } | undefined;
    /**
     * The model that will complete your prompt.\n\nSee [models](https://ai.google.dev/gemini-api/docs/models) for additional details.
     */
    model: Model_2;
    /**
     * The ID of the previous interaction, if any.
     */
    previous_interaction_id?: string | undefined;
    /**
     * Enforces that the generated response is a JSON object that complies with
     *
     * @remarks
     * the JSON schema specified in this field.
     */
    response_format?: ResponseFormat_2 | Array<ResponseFormat_2> | undefined;
    /**
     * The mime type of the response. This is required if response_format is set.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    response_mime_type?: string | undefined;
    /**
     * The requested modalities of the response (TEXT, IMAGE, AUDIO).
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    response_modalities?: Array<ResponseModality> | undefined;
    /**
     * Safety settings for the interaction.
     */
    safety_settings?: Array<SafetySetting_2> | undefined;
    service_tier?: ServiceTier_2 | undefined;
    /**
     * Input only. Whether to store the response and request for later retrieval.
     */
    store?: boolean | undefined;
    /**
     * Input only. Whether the interaction will be streamed.
     */
    stream?: boolean | undefined;
    /**
     * System instruction for the interaction.
     */
    system_instruction?: string | undefined;
    /**
     * A list of tool declarations the model may call during interaction.
     */
    tools?: Array<Tool_2> | undefined;
    /**
     * Message for configuring webhook events for a request.
     */
    webhook_config?: WebhookConfig_2 | undefined;
};

/**
 * The environment configuration for the interaction. Can be an object
 *
 * @remarks
 * specifying remote environment sources or a string referencing an existing
 * environment ID.
 */
declare type CreateModelInteractionEnvironment = Environment_2 | string;

declare type CreateModelInteractionParams$ = CreateModelInteractionParams;

declare type CreateModelInteractionParams = Omit<CreateInteractionRequest, "body"> & CreateModelInteraction;

declare type CreateModelInteractionParamsNonStreaming$ = CreateModelInteraction;

declare type CreateModelInteractionParamsNonStreaming$2 = CreateModelInteractionParamsNonStreaming;

declare type CreateModelInteractionParamsNonStreaming = CreateModelInteractionParams & {
    stream?: false | undefined;
};

declare type CreateModelInteractionParamsStreaming$ = CreateModelInteraction;

declare type CreateModelInteractionParamsStreaming$2 = CreateModelInteractionParamsStreaming;

declare type CreateModelInteractionParamsStreaming = CreateModelInteractionParams & {
    stream: true;
};

/**
 * Enforces that the generated response is a JSON object that complies with
 *
 * @remarks
 * the JSON schema specified in this field.
 */
declare type CreateModelInteractionResponseFormat = ResponseFormat_2 | Array<ResponseFormat_2>;

/**
 * Creates a `Part` object from a `base64` encoded `string`.
 */
export declare function createPartFromBase64(data: string, mimeType: string, mediaResolution?: PartMediaResolutionLevel): Part;

/**
 * Creates a `Part` object from the `outcome` and `output` of a `CodeExecutionResult` object.
 */
export declare function createPartFromCodeExecutionResult(outcome: Outcome, output: string): Part;

/**
 * Creates a `Part` object from the `code` and `language` of an `ExecutableCode` object.
 */
export declare function createPartFromExecutableCode(code: string, language: Language): Part;

/**
 * Creates a `Part` object from a `FunctionCall` object.
 */
export declare function createPartFromFunctionCall(name: string, args: Record<string, unknown>): Part;

/**
 * Creates a `Part` object from a `FunctionResponse` object.
 */
export declare function createPartFromFunctionResponse(id: string, name: string, response: Record<string, unknown>, parts?: FunctionResponsePart[]): Part;

/**
 * Creates a `Part` object from a `text` string.
 */
export declare function createPartFromText(text: string): Part;

/**
 * Creates a `Part` object from a `URI` string.
 */
export declare function createPartFromUri(uri: string, mimeType: string, mediaResolution?: PartMediaResolutionLevel): Part;

declare type CreateTriggerGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type CreateTriggerParams = Omit<CreateTriggerRequest, "body"> & CreateTriggerRequest["body"];

declare type CreateTriggerRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The trigger configuration to create.
     */
    body: triggers.TriggerCreateParams;
};

/** Fine-tuning job creation request - optional fields. */
export declare interface CreateTuningJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The method to use for tuning (SUPERVISED_FINE_TUNING or PREFERENCE_TUNING or DISTILLATION or REINFORCEMENT_TUNING). If not set, the default method (SFT) will be used. */
    method?: TuningMethod;
    /** Validation dataset for tuning. The dataset must be formatted as a JSONL file. */
    validationDataset?: TuningValidationDataset;
    /** The display name of the tuned Model. The name can be up to 128 characters long and can consist of any UTF-8 characters. */
    tunedModelDisplayName?: string;
    /** The description of the TuningJob */
    description?: string;
    /** Number of complete passes the model makes over the entire training dataset during training. */
    epochCount?: number;
    /** Multiplier for adjusting the default learning rate. 1P models only. Mutually exclusive with learning_rate. */
    learningRateMultiplier?: number;
    /** If set to true, disable intermediate checkpoints and only the last checkpoint will be exported. Otherwise, enable intermediate checkpoints. */
    exportLastCheckpointOnly?: boolean;
    /** The optional checkpoint id of the pre-tuned model to use for tuning, if applicable. */
    preTunedModelCheckpointId?: string;
    /** Adapter size for tuning. */
    adapterSize?: AdapterSize;
    /** Tuning mode for tuning. */
    tuningMode?: TuningMode;
    /** Custom base model for tuning. This is only supported for OSS models in Gemini Enterprise Agent Platform. */
    customBaseModel?: string;
    /** The batch size hyperparameter for tuning. This is only supported for OSS models in Gemini Enterprise Agent Platform. */
    batchSize?: number;
    /** The learning rate for tuning. OSS models only. Mutually exclusive with learning_rate_multiplier. */
    learningRate?: number;
    /** Optional. The labels with user-defined metadata to organize TuningJob and generated resources such as Model and Endpoint. Label keys and values can be no longer than 64 characters (Unicode codepoints), can only contain lowercase letters, numeric characters, underscores and dashes. International characters are allowed. See https://goo.gl/xmQnxf for more information and examples of labels. */
    labels?: Record<string, string>;
    /** Weight for KL Divergence regularization, Preference Optimization tuning only. */
    beta?: number;
    /** The base teacher model that is being distilled. Distillation only. */
    baseTeacherModel?: string;
    /** The resource name of the Tuned teacher model. Distillation only. */
    tunedTeacherModelSource?: string;
    /** Multiplier for adjusting the weight of the SFT loss. Distillation only. */
    sftLossWeightMultiplier?: number;
    /** The Google Cloud Storage location where the tuning job outputs are written. */
    outputUri?: string;
    /** Reward function configuration for reinforcement tuning. Reinforcement tuning only. */
    rewardConfig?: SingleReinforcementTuningRewardConfig;
    /** Composite reward function configuration for reinforcement tuning. Reinforcement tuning only. */
    compositeRewardConfig?: CompositeReinforcementTuningRewardConfig;
    /** Number of different responses to generate per prompt during tuning. Reinforcement tuning only. */
    samplesPerPrompt?: number;
    /** How often at steps to evaluate the tuning job during training. Reinforcement tuning only. */
    evaluateInterval?: number;
    /** How often at steps to save checkpoints during training. Reinforcement tuning only. */
    checkpointInterval?: number;
    /** The maximum number of tokens to generate per prompt. Reinforcement tuning only. */
    maxOutputTokens?: number;
    /** Indicates the maximum thinking depth. Use with earlier models shall result in error. Reinforcement tuning only. */
    thinkingLevel?: ReinforcementTuningThinkingLevel;
    /** Cloud Storage path to file containing validation dataset for tuning. The dataset must be formatted as a JSONL file. If no validation dataset is provided, by default the API splits 25% of the training dataset or 50 examples, whichever is larger, as the validation dataset. Reinforcement tuning only. */
    validationDatasetUri?: string;
    /** The encryption spec of the tuning job. Customer-managed encryption key options for a TuningJob. If this is set, then all resources created by the TuningJob will be encrypted with provided encryption key. */
    encryptionSpec?: EncryptionSpec;
}

/** Fine-tuning job creation parameters - optional fields. */
export declare interface CreateTuningJobParameters {
    /** The base model that is being tuned, e.g., "gemini-flash-latest". */
    baseModel: string;
    /** Cloud Storage path to file containing training dataset for tuning. The dataset must be formatted as a JSONL file. */
    trainingDataset: TuningDataset;
    /** Configuration for the tuning job. */
    config?: CreateTuningJobConfig;
}

/** Fine-tuning job creation parameters - optional fields. */
export declare interface CreateTuningJobParametersPrivate {
    /** The base model that is being tuned, e.g., "gemini-flash-latest". */
    baseModel?: string;
    /** The PreTunedModel that is being tuned. */
    preTunedModel?: PreTunedModel;
    /** Cloud Storage path to file containing training dataset for tuning. The dataset must be formatted as a JSONL file. */
    trainingDataset: TuningDataset;
    /** Configuration for the tuning job. */
    config?: CreateTuningJobConfig;
}

/**
 * Creates a `Content` object with a user role from a `PartListUnion` object or `string`.
 */
export declare function createUserContent(partOrString: PartListUnion | string): Content;

declare type CreateVoiceGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type CreateVoiceRequest$ = CreateVoiceRequest_2;

declare type CreateVoiceRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * The request body.
     */
    body: voices.CreateVoiceRequest;
};

/**
 * Request message for `VoicesService.CreateVoice`.
 */
declare type CreateVoiceRequest_2 = {
    /**
     * Optional. Whether the created voice is persisted and managed by Google.
     *
     * @remarks
     *
     * * When `true`, Google stores the voice and returns `Voice.id` (for example,
     *   `voice_abc123def456`), which can be managed via `GetVoice`, `ListVoices`,
     *   and `DeleteVoice` and referenced by ID in synthesis requests. Stored
     *   voices expire after 1 year of inactivity; using a stored voice in speech
     *   synthesis or as a `base_voice` in `CreateVoice` extends its
     *   `expire_time`. Projects are subject to a maximum active stored voice
     *   quota; exceeding the quota returns `RESOURCE_EXHAUSTED`.
     * * When `false` (default), the voice is not stored by Google and `Voice.key`
     *   (for example, `voicekey_...`) is returned for client-side storage and
     *   synthesis. Optional discovery metadata fields on `voice` are not
     *   persisted or returned when `store` is `false`.
     * * Required to be `true` when `voice.type` is `"prompted"`
     *   (otherwise fails with `INVALID_ARGUMENT`).
     */
    store?: boolean | undefined;
    /**
     * A voice resource representing either a custom voice (created via
     *
     * @remarks
     * `CreateVoice`) or a prebuilt system voice (returned by `ListVoices`).
     */
    voice: VoiceInput;
};

declare type CreateWebhookGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type CreateWebhookParams = Omit<CreateWebhookRequest, "body"> & CreateWebhookRequest["body"];

declare type CreateWebhookRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The request body.
     */
    body: webhooks.WebhookInput;
};

declare type Credential$ = Credential_2;

/**
 * Server-managed credential resource stored in Secret Manager.
 */
declare type Credential_2 = {
    /**
     * Output only. The timestamp when the credential was created.
     */
    create_time?: string | undefined;
    /**
     * Required. Output only. Identifier. Unique identifier for the credential.
     */
    id: string;
    /**
     * Output only. Current status of the credential.
     */
    status?: Status_2 | undefined;
    /**
     * Required. Output only. The type of credential.
     */
    type?: Type_2 | undefined;
    /**
     * Output only. The timestamp when the credential was last updated.
     */
    update_time?: string | undefined;
};

declare type CredentialCreateParams$ = CredentialCreateParams;

/**
 * Represents the fields of a Credential provided on creation.
 */
declare type CredentialCreateParams = EnvironmentVariableConfig | HttpBearerConfig | OAuth2Config;

declare type CredentialDeleteParams$ = DeleteCredentialParams;

declare type CredentialDeleteResponse$ = Empty;

declare type CredentialGetParams$ = GetCredentialParams;

declare type CredentialListParams$ = ListCredentialsParams;

declare type CredentialListResponse$ = CredentialListResponse;

declare type CredentialListResponse = {
    credentials?: Array<Credential_2> | undefined;
    next_page_token?: string | undefined;
};

export declare namespace Credentials {
    export type Credential = Credential$;
    export type CredentialCreateParams = CredentialCreateParams$;
    export type CredentialDeleteParams = CredentialDeleteParams$;
    export type CredentialDeleteResponse = CredentialDeleteResponse$;
    export type CredentialGetParams = CredentialGetParams$;
    export type CredentialListParams = CredentialListParams$;
    export type CredentialListResponse = CredentialListResponse$;
    export type CredentialUpdate = CredentialUpdate$;
    export type EnvironmentVariableConfig = EnvironmentVariableConfig$;
    export type EnvironmentVariableUpdateConfig = EnvironmentVariableUpdateConfig$;
    export type HttpBearerConfig = HttpBearerConfig$;
    export type HttpBearerUpdateConfig = HttpBearerUpdateConfig$;
    export type InjectionLocation = InjectionLocation$;
    export type InjectionLocationEnum = InjectionLocationEnum$;
    export type OAuth2Config = OAuth2Config$;
    export type OAuth2UpdateConfig = OAuth2UpdateConfig$;
}

declare namespace credentials {
    export {
        CredentialCreateParams,
        CredentialListResponse,
        CredentialUpdate,
        Status_2 as Status,
        Type_2 as Type,
        Credential_2 as Credential,
        EnvironmentVariableConfigInjectionLocation,
        EnvironmentVariableConfig,
        EnvironmentVariableUpdateConfigInjectionLocation,
        EnvironmentVariableUpdateConfig,
        HttpBearerConfig,
        HttpBearerUpdateConfig,
        InjectionLocationEnum,
        OAuth2Config,
        OAuth2UpdateConfig
    }
}

declare class Credentials_2 extends ClientSDK {
    /**
     * Lists credentials.
     */
    list(params?: ListCredentialsParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<credentials.CredentialListResponse>;
    /**
     * Creates a new credential.
     */
    create(params: CreateCredentialParams, options?: RequestOptions): APIPromise<credentials.Credential>;
    /**
     * Deletes a credential.
     */
    delete(id: string, params?: DeleteCredentialParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<interactions.Empty>;
    /**
     * Gets a credential by ID.
     */
    get(id: string, params?: GetCredentialParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<credentials.Credential>;
    /**
     * Updates a credential.
     */
    update(id: string, params: UpdateCredentialParams, options?: RequestOptions): APIPromise<credentials.Credential>;
}

declare type CredentialUpdate$ = CredentialUpdate;

/**
 * Represents the fields of a Credential that can be updated.
 */
declare type CredentialUpdate = EnvironmentVariableUpdateConfig | HttpBearerUpdateConfig | OAuth2UpdateConfig;

export declare type CredentialUpdateParams = Credentials.CredentialUpdate & {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Optional. The list of fields to update.
     */
    update_mask?: string | undefined;
};

/** Result for custom code execution metric. This data type is not supported in Gemini API. */
export declare interface CustomCodeExecutionResult {
    /** Output only. Custom code execution score. */
    score?: number;
}

/** Configures the customized avatar to be used in the session. */
export declare interface CustomizedAvatar {
    /** The mime type of the reference image, e.g., "image/jpeg". */
    imageMimeType?: string;
    /** The data of the reference image. The dimensions of the reference
     image should be 9:16 (portrait) with a minimum resolution of 704x1280.
     * @remarks Encoded as base64 string. */
    imageData?: string;
}

/** User provided metadata stored as key-value pairs. This data type is not supported in Vertex AI. */
export declare interface CustomMetadata {
    /** Required. The key of the metadata to store. */
    key?: string;
    /** The numeric value of the metadata to store. */
    numericValue?: number;
    /** The StringList value of the metadata to store. */
    stringListValue?: StringList;
    /** The string value of the metadata to store. */
    stringValue?: string;
}

/** Spec for custom output. This data type is not supported in Gemini API. */
export declare interface CustomOutput {
    /** Output only. List of raw output strings. */
    rawOutputs?: RawOutput;
}

/** Distribution computed over a tuning dataset. This data type is not supported in Gemini API. */
export declare interface DatasetDistribution {
    /** Output only. Defines the histogram bucket. */
    buckets?: DatasetDistributionDistributionBucket[];
    /** Output only. The maximum of the population values. */
    max?: number;
    /** Output only. The arithmetic mean of the values in the population. */
    mean?: number;
    /** Output only. The median of the values in the population. */
    median?: number;
    /** Output only. The minimum of the population values. */
    min?: number;
    /** Output only. The 5th percentile of the values in the population. */
    p5?: number;
    /** Output only. The 95th percentile of the values in the population. */
    p95?: number;
    /** Output only. Sum of a given population of values. */
    sum?: number;
}

/** Dataset bucket used to create a histogram for the distribution given a population of values. This data type is not supported in Gemini API. */
export declare interface DatasetDistributionDistributionBucket {
    /** Output only. Number of values in the bucket. */
    count?: string;
    /** Output only. Left bound of the bucket. */
    left?: number;
    /** Output only. Right bound of the bucket. */
    right?: number;
}

/** Statistics computed over a tuning dataset. This data type is not supported in Gemini API. */
export declare interface DatasetStats {
    /** Output only. Dataset distributions for the number of contents per example. */
    contentsPerExampleDistribution?: DatasetDistribution;
    /** Output only. A partial sample of the indices (starting from 1) of the dropped examples. */
    droppedExampleIndices?: string[];
    /** Output only. For each index in `dropped_example_indices`, the user-facing reason why the example was dropped. */
    droppedExampleReasons?: string[];
    /** Output only. Sample user dataset examples in the training dataset uri for Reinforcement Tuning. */
    reinforcementTuningUserDatasetExamples?: ReinforcementTuningUserDatasetExamples;
    /** Output only. Number of billable characters in the tuning dataset. */
    totalBillableCharacterCount?: string;
    /** Output only. Number of billable tokens in the tuning dataset. */
    totalBillableTokenCount?: string;
    /** Output only. Number of tuning characters in the tuning dataset. */
    totalTuningCharacterCount?: string;
    /** Output only. Number of examples in the tuning dataset. */
    tuningDatasetExampleCount?: string;
    /** Output only. Number of tuning steps for this Tuning Job. */
    tuningStepCount?: string;
    /** Output only. Sample user messages in the training dataset uri. */
    userDatasetExamples?: Content[];
    /** Output only. Dataset distributions for the user input tokens. */
    userInputTokenDistribution?: DatasetDistribution;
    /** Output only. Dataset distributions for the messages per example. */
    userMessagePerExampleDistribution?: DatasetDistribution;
    /** Output only. Dataset distributions for the user output tokens. */
    userOutputTokenDistribution?: DatasetDistribution;
}

declare type DeepResearchAgentConfig$ = DeepResearchAgentConfig;

/**
 * Configuration for the Deep Research agent.
 */
declare type DeepResearchAgentConfig = {
    /**
     * Enables human-in-the-loop planning for the Deep Research agent. If set to
     *
     * @remarks
     * true, the Deep Research agent will provide a research plan in its response.
     * The agent will then proceed only if the user confirms the plan in the next
     * turn.
     */
    collaborative_planning?: boolean | undefined;
    /**
     * Enables bigquery tool for the Deep Research agent.
     */
    enable_bigquery_tool?: boolean | undefined;
    thinking_summaries?: ThinkingSummaries | undefined;
    type: "deep-research";
    /**
     * Whether to include visualizations in the response.
     */
    visualization?: Visualization | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DeleteAgentGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type DeleteAgentParams = Omit<DeleteAgentRequest, "id">;

declare type DeleteAgentRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The name of the agent to delete.
     */
    id: string;
};

/** Optional parameters for models.get method. */
export declare interface DeleteBatchJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Config for batches.delete parameters. */
export declare interface DeleteBatchJobParameters {
    /** A fully-qualified BatchJob resource name or ID.
     Example: "projects/.../locations/.../batchPredictionJobs/456"
     or "456" when project and location are initialized in the client.
     */
    name: string;
    /** Optional parameters for the request. */
    config?: DeleteBatchJobConfig;
}

/** Optional parameters for caches.delete method. */
export declare interface DeleteCachedContentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for caches.delete method. */
export declare interface DeleteCachedContentParameters {
    /** The server-generated resource name of the cached content.
     */
    name: string;
    /** Optional parameters for the request.
     */
    config?: DeleteCachedContentConfig;
}

/** Empty response for caches.delete method. */
export declare class DeleteCachedContentResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DeleteCredentialGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type DeleteCredentialParams = Omit<DeleteCredentialRequest, "id">;

declare type DeleteCredentialRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource ID segment making up resource `name`. It identifies the resource
     *
     * @remarks
     * within its parent collection as described in https://google.aip.dev/122.
     */
    id: string;
};

/** Config for optional parameters. */
export declare interface DeleteDocumentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** If set to true, any `Chunk`s and objects related to this `Document` will
     also be deleted.
     */
    force?: boolean;
}

/** Config for documents.delete parameters. */
export declare interface DeleteDocumentParameters {
    /** The resource name of the Document.
     Example: fileSearchStores/file-search-store-foo/documents/documents-bar */
    name: string;
    /** Optional parameters for the request. */
    config?: DeleteDocumentConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DeleteEnvironmentGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type DeleteEnvironmentParams = Omit<DeleteEnvironmentRequest, "id">;

declare type DeleteEnvironmentRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource ID segment making up resource `name`. It identifies the resource
     *
     * @remarks
     * within its parent collection as described in https://google.aip.dev/122.
     */
    id: string;
};

/** Used to override the default configuration. */
export declare interface DeleteFileConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Generates the parameters for the get method. */
export declare interface DeleteFileParameters {
    /** The name identifier for the file to be deleted. */
    name: string;
    /** Used to override the default configuration. */
    config?: DeleteFileConfig;
}

/** Response for the delete file method. */
export declare class DeleteFileResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** Optional parameters for deleting a FileSearchStore. */
export declare interface DeleteFileSearchStoreConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** If set to true, any Documents and objects related to this FileSearchStore will also be deleted.
     If false (the default), a FAILED_PRECONDITION error will be returned if
     the FileSearchStore contains any Documents.
     */
    force?: boolean;
}

/** Config for file_search_stores.delete parameters. */
export declare interface DeleteFileSearchStoreParameters {
    /** The resource name of the FileSearchStore. Example: `fileSearchStores/my-file-search-store-123` */
    name: string;
    /** Optional parameters for the request. */
    config?: DeleteFileSearchStoreConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DeleteInteractionGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type DeleteInteractionParams = Omit<DeleteInteractionRequest, "id">;

declare type DeleteInteractionRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The name of the interaction to delete.
     */
    id: string;
};

/** Configuration for deleting a tuned model. */
export declare interface DeleteModelConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for deleting a tuned model. */
export declare interface DeleteModelParameters {
    model: string;
    /** Optional parameters for the request. */
    config?: DeleteModelConfig;
}

export declare class DeleteModelResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** The return value of delete operation. */
export declare interface DeleteResourceJob {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    name?: string;
    done?: boolean;
    error?: JobError;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DeleteTriggerGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type DeleteTriggerParams = Omit<DeleteTriggerRequest, "id">;

declare type DeleteTriggerRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource name of the trigger.
     */
    id: string;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DeleteVoiceGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type DeleteVoiceParams = Omit<DeleteVoiceRequest, "id">;

declare type DeleteVoiceRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The resource name of the custom stored voice to delete
     *
     * @remarks
     * (for example, `voices/voice_abc123def456`).
     */
    id: string;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Response message for `VoicesService.DeleteVoice`.
 */
declare type DeleteVoiceResponse = {};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DeleteWebhookGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type DeleteWebhookParams = Omit<DeleteWebhookRequest, "id">;

declare type DeleteWebhookRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The ID of the webhook to delete.
     */
    id: string;
};

/** Delivery mode for the generated content. */
export declare enum Delivery {
    /**
     * Default value. This value is unused.
     */
    DELIVERY_UNSPECIFIED = "DELIVERY_UNSPECIFIED",
    /**
     * Generated bytes are returned inline in the response.
     */
    INLINE = "INLINE",
    /**
     * Generated content is stored and a URI is returned.
     */
    URI = "URI"
}

declare type Disabled = "disabled" | (string & {});

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DisabledSafetyPolicy = "financial_transactions" | "sensitive_data_modification" | "communication_tool" | "account_creation" | "data_modification" | "user_consent_management" | "legal_terms_and_agreements" | (string & {});

/** Statistics for distillation prompt dataset. These statistics do not include the responses sampled from the teacher model. This data type is not supported in Gemini API. */
export declare interface DistillationDataStats {
    /** Output only. Statistics computed for the training dataset. */
    trainingDatasetStats?: DatasetStats;
}

/** Distillation hyperparameters for tuning. */
export declare interface DistillationHyperParameters {
    /** Number of complete passes the model makes over the entire training dataset
     during training. */
    epochCount?: string;
    /** Multiplier for adjusting the default learning rate. */
    learningRateMultiplier?: number;
    /** The size of the adapter. Can be 'small', 'medium', or 'large'. */
    adapterSize?: AdapterSize;
    /** Batch size for tuning. This feature is only available for open
     source models. */
    batchSize?: number;
    /** The learning rate for distillation tuning. */
    learningRate?: number;
    /** Generation config for Distillation teacher model sampling. Only the
     following fields are supported for distillation teacher samplings:
     - temperature
     - top_p
     - top_k
     - candidate_count
     - thinking_config */
    generationConfig?: GenerationConfig;
}

/** Distillation sampling spec for tuning. */
export declare interface DistillationSamplingSpec {
    /** Cloud Storage path to file containing prompt dataset for distillation.
     The dataset must be formatted as a JSONL file. */
    promptDatasetUri?: string;
    /** Cloud Storage path to file containing validation dataset for distillation.
     The dataset must be formatted as a JSONL file. */
    validationDatasetUri?: string;
    /** The base teacher model that is being distilled. See [Supported
     models](https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/tuning#supported_models). */
    baseTeacherModel?: string;
    /** The resource name of the Tuned teacher model. Format:
     `projects/{project}/locations/{location}/models/{model}`. */
    tunedTeacherModelSource?: string;
    /** Hyperparameters for distillation tuning. */
    hyperparameters?: DistillationHyperParameters;
}

/** Distillation tuning spec for tuning. */
export declare interface DistillationSpec {
    /** The base teacher model that is being distilled. See [Supported models](https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/tuning#supported_models). */
    baseTeacherModel?: string;
    /** Optional. Hyperparameters for Distillation. */
    hyperParameters?: DistillationHyperParameters;
    /** Deprecated. A path in a Cloud Storage bucket, which will be treated as the root output directory of the distillation pipeline. It is used by the system to generate the paths of output artifacts. */
    pipelineRootDirectory?: string;
    /** Optional. Cloud Storage path to file containing prompt dataset for distillation. The dataset must be formatted as a JSONL file. */
    promptDatasetUri?: string;
    /** The student model that is being tuned, e.g., "google/gemma-2b-1.1-it". Deprecated. Use base_model instead. */
    studentModel?: string;
    /** Deprecated. Cloud Storage path to file containing training dataset for tuning. The dataset must be formatted as a JSONL file. */
    trainingDatasetUri?: string;
    /** The resource name of the Tuned teacher model. Format: `projects/{project}/locations/{location}/models/{model}`. */
    tunedTeacherModelSource?: string;
    /** Optional. Specifies the tuning mode for distillation (sft part). This feature is only available for open source models. */
    tuningMode?: TuningMode;
    /** Optional. Cloud Storage path to file containing validation dataset for tuning. The dataset must be formatted as a JSONL file. */
    validationDatasetUri?: string;
}

declare type Document$ = DocumentDelta;

/** A Document is a collection of Chunks. */
declare interface Document_2 {
    /** Output only. The Timestamp of when the `Document` was created. */
    createTime?: string;
    /** Optional. User provided custom metadata stored as key-value pairs used for querying. A `Document` can have a maximum of 20 `CustomMetadata`. */
    customMetadata?: CustomMetadata[];
    /** Optional. The human-readable display name for the `Document`. The display name must be no more than 512 characters in length, including spaces. Example: "Semantic Retriever Documentation". */
    displayName?: string;
    /** Output only. The mime type of the Document. */
    mimeType?: string;
    /** Immutable. Identifier. The `Document` resource name. The ID (name excluding the "fileSearchStores/&#42;/documents/" prefix) can contain up to 40 characters that are lowercase alphanumeric or dashes (-). The ID cannot start or end with a dash. If the name is empty on create, a unique name will be derived from `display_name` along with a 12 character random suffix. Example: `fileSearchStores/{file_search_store_id}/documents/my-awesome-doc-123a456b789c` */
    name?: string;
    /** Output only. The size of raw bytes ingested into the Document. */
    sizeBytes?: string;
    /** Output only. Current state of the `Document`. */
    state?: DocumentState;
    /** Output only. The Timestamp of when the `Document` was last updated. */
    updateTime?: string;
}
export { Document_2 as Document }

declare type DocumentContent$ = DocumentContent;

/**
 * A document content block.
 */
declare type DocumentContent = {
    /**
     * The document content.
     */
    data?: string | undefined;
    /**
     * The mime type of the document.
     */
    mime_type?: DocumentContentMimeType | undefined;
    type: "document";
    /**
     * The URI of the document.
     */
    uri?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The mime type of the document.
 */
declare type DocumentContentMimeType = "application/pdf" | "text/csv" | (string & {});

declare type DocumentDelta = {
    data?: string | undefined;
    mime_type?: DocumentDeltaMimeType | undefined;
    type: "document";
    uri?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type DocumentDeltaMimeType = "application/pdf" | "text/csv" | (string & {});

declare class Documents extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    /**
     * Lists documents.
     *
     * @param params - The parameters for the list request.
     * @return - A pager of documents.
     *
     * @example
     * ```ts
     * const documents = await ai.documents.list({parent:'rag_store_name', config: {'pageSize': 2}});
     * for await (const document of documents) {
     *   console.log(document);
     * }
     * ```
     */
    list: (params: types.ListDocumentsParameters) => Promise<Pager<types.Document>>;
    /**
     * Gets a Document.
     *
     * @param params - The parameters for getting a document.
     * @return Document.
     */
    get(params: types.GetDocumentParameters): Promise<types.Document>;
    /**
     * Deletes a Document.
     *
     * @param params - The parameters for deleting a document.
     */
    delete(params: types.DeleteDocumentParameters): Promise<void>;
    private listInternal;
}

/** Output only. Current state of the `Document`. This enum is not supported in Vertex AI. */
export declare enum DocumentState {
    /**
     * The default value. This value is used if the state is omitted.
     */
    STATE_UNSPECIFIED = "STATE_UNSPECIFIED",
    /**
     * Some `Chunks` of the `Document` are being processed (embedding and vector storage).
     */
    STATE_PENDING = "STATE_PENDING",
    /**
     * All `Chunks` of the `Document` is processed and available for querying.
     */
    STATE_ACTIVE = "STATE_ACTIVE",
    /**
     * Some `Chunks` of the `Document` failed processing.
     */
    STATE_FAILED = "STATE_FAILED"
}

export declare type DownloadableFileUnion = string | File_2 | GeneratedVideo | Video;

export declare type DownloadEnvironmentFileParams = {
    environment: string;
    path: string;
    api_version?: string;
};

declare interface Downloader {
    /**
     * Downloads a file to the given location.
     *
     * @param params The parameters for downloading the file.
     * @param apiClient The ApiClient to use for uploading.
     * @return A Promises that resolves when the download is complete.
     */
    download(params: DownloadFileParameters, apiClient: ApiClient): Promise<void>;
}

/** Used to override the default configuration. */
export declare interface DownloadFileConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters used to download a file. */
export declare interface DownloadFileParameters {
    /** The file to download. It can be a file name, a file object or a generated video. */
    file: DownloadableFileUnion;
    /** Location where the file should be downloaded to. */
    downloadPath: string;
    /** Configuration to for the download operation. */
    config?: DownloadFileConfig;
}

/** Used to override the default configuration. */
export declare interface DownloadMediaConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

declare type DynamicAgentConfig$ = DynamicAgentConfig;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for dynamic agents.
 */
declare type DynamicAgentConfig = {
    type: "dynamic";
    [additionalProperties: string]: unknown;
};

/** Describes the options to customize dynamic retrieval. */
export declare interface DynamicRetrievalConfig {
    /** Optional. The threshold to be used in dynamic retrieval. If not set, a system default value is used. */
    dynamicThreshold?: number;
    /** The mode of the predictor to be used in dynamic retrieval. */
    mode?: DynamicRetrievalConfigMode;
}

/** The mode of the predictor to be used in dynamic retrieval. */
export declare enum DynamicRetrievalConfigMode {
    /**
     * Always trigger retrieval.
     */
    MODE_UNSPECIFIED = "MODE_UNSPECIFIED",
    /**
     * Run retrieval only when system decides it is necessary.
     */
    MODE_DYNAMIC = "MODE_DYNAMIC"
}

/** Configuration for editing an image. */
export declare interface EditImageConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** Cloud Storage URI used to store the generated images. */
    outputGcsUri?: string;
    /** Description of what to discourage in the generated images. */
    negativePrompt?: string;
    /** Number of images to generate. */
    numberOfImages?: number;
    /** Aspect ratio of the generated images. Supported values are
     "1:1", "3:4", "4:3", "9:16", and "16:9". */
    aspectRatio?: string;
    /** Controls how much the model adheres to the text prompt. Large
     values increase output and prompt alignment, but may compromise image
     quality. */
    guidanceScale?: number;
    /** Random seed for image generation. This is not available when
     ``add_watermark`` is set to true. */
    seed?: number;
    /** Filter level for safety filtering. */
    safetyFilterLevel?: SafetyFilterLevel;
    /** Allows generation of people by the model. */
    personGeneration?: PersonGeneration;
    /** Whether to report the safety scores of each generated image and
     the positive prompt in the response. */
    includeSafetyAttributes?: boolean;
    /** Whether to include the Responsible AI filter reason if the image
     is filtered out of the response. */
    includeRaiReason?: boolean;
    /** Language of the text in the prompt. */
    language?: ImagePromptLanguage;
    /** MIME type of the generated image. */
    outputMimeType?: string;
    /** Compression quality of the generated image (for ``image/jpeg``
     only). */
    outputCompressionQuality?: number;
    /** Whether to add a watermark to the generated images. */
    addWatermark?: boolean;
    /** User specified labels to track billing usage. */
    labels?: Record<string, string>;
    /** Describes the editing mode for the request. */
    editMode?: EditMode;
    /** The number of sampling steps. A higher value has better image
     quality, while a lower value has better latency. */
    baseSteps?: number;
}

/** Parameters for the request to edit an image. */
export declare interface EditImageParameters {
    /** The model to use. */
    model: string;
    /** A text description of the edit to apply to the image. */
    prompt: string;
    /** The reference images for Imagen 3 editing. */
    referenceImages: ReferenceImage[];
    /** Configuration for editing. */
    config?: EditImageConfig;
}

/** Response for the request to edit an image. */
export declare class EditImageResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** Generated images. */
    generatedImages?: GeneratedImage[];
}

/** Enum representing the editing mode. */
export declare enum EditMode {
    EDIT_MODE_DEFAULT = "EDIT_MODE_DEFAULT",
    EDIT_MODE_INPAINT_REMOVAL = "EDIT_MODE_INPAINT_REMOVAL",
    EDIT_MODE_INPAINT_INSERTION = "EDIT_MODE_INPAINT_INSERTION",
    EDIT_MODE_OUTPAINT = "EDIT_MODE_OUTPAINT",
    EDIT_MODE_CONTROLLED_EDITING = "EDIT_MODE_CONTROLLED_EDITING",
    EDIT_MODE_STYLE = "EDIT_MODE_STYLE",
    EDIT_MODE_BGSWAP = "EDIT_MODE_BGSWAP",
    EDIT_MODE_PRODUCT_IMAGE = "EDIT_MODE_PRODUCT_IMAGE"
}

/** Parameters for the embed_content method. */
export declare interface EmbedContentBatch {
    /** The content to embed. Only the `parts.text` fields will be counted.
     */
    contents?: ContentListUnion;
    /** Configuration that contains optional parameters.
     */
    config?: EmbedContentConfig;
}

/** Optional parameters for the embed_content method. */
export declare interface EmbedContentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** Type of task for which the embedding will be used.
     */
    taskType?: string;
    /** Title for the text. Only applicable when TaskType is
     `RETRIEVAL_DOCUMENT`.
     */
    title?: string;
    /** Reduced dimension for the output embedding. If set,
     excessive values in the output embedding are truncated from the end.
     Supported by newer models since 2024 only. You cannot set this value if
     using the earlier model (`models/embedding-001`).
     */
    outputDimensionality?: number;
    /** Gemini Enterprise Agent Platform only. The MIME type of the input.
     */
    mimeType?: string;
    /** Gemini Enterprise Agent Platform only. Whether to silently truncate inputs longer than
     the max sequence length. If this option is set to false, oversized inputs
     will lead to an INVALID_ARGUMENT error, similar to other text APIs.
     */
    autoTruncate?: boolean;
    /** Gemini Enterprise Agent Platform only. Whether to enable OCR for document content.
     Only applicable to Gemini Embedding 2 models.
     */
    documentOcr?: boolean;
    /** Gemini Enterprise Agent Platform only. Whether to extract audio from video content.
     Only applicable to Gemini Embedding 2 models.
     */
    audioTrackExtraction?: boolean;
}

/** Request-level metadata for the Gemini Enterprise Agent Platform Embed Content API. */
export declare interface EmbedContentMetadata {
    /** Gemini Enterprise Agent Platform only. The total number of billable characters included
     in the request.
     */
    billableCharacterCount?: number;
}

/** Parameters for the embed_content method. */
export declare interface EmbedContentParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** The content to embed. Only the `parts.text` fields will be counted.
     */
    contents: ContentListUnion;
    /** Configuration that contains optional parameters.
     */
    config?: EmbedContentConfig;
}

/** Parameters for the _embed_content method. */
export declare interface EmbedContentParametersPrivate {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** The content to embed. Only the `parts.text` fields will be counted.
     */
    contents?: ContentListUnion;
    /** The single content to embed. Only the `parts.text` fields will be counted.
     */
    content?: ContentUnion;
    /** The Gemini Enterprise Agent Platform embedding API to use.
     */
    embeddingApiType?: EmbeddingApiType;
    /** Configuration that contains optional parameters.
     */
    config?: EmbedContentConfig;
}

/** Response for the embed_content method. */
export declare class EmbedContentResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** The embeddings for each request, in the same order as provided in
     the batch request.
     */
    embeddings?: ContentEmbedding[];
    /** Gemini Enterprise Agent Platform only. Metadata about the request.
     */
    metadata?: EmbedContentMetadata;
}

/** Enum representing the Gemini Enterprise Agent Platform embedding API to use. */
export declare enum EmbeddingApiType {
    /**
     * predict API endpoint (default)
     */
    PREDICT = "PREDICT",
    /**
     * embedContent API Endpoint
     */
    EMBED_CONTENT = "EMBED_CONTENT"
}

export declare interface EmbeddingsBatchJobSource {
    /** The Gemini Developer API's file resource name of the input data
     (e.g. "files/12345").
     */
    fileName?: string;
    /** The Gemini Developer API's inlined input data to run batch job.
     */
    inlinedRequests?: EmbedContentBatch;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A generic empty message that you can re-use to avoid defining duplicated
 *
 * @remarks
 * empty messages in your APIs. A typical example is to use it as the request
 * or the response type of an API method. For instance:
 *
 *     service Foo {
 *       rpc Bar(google.protobuf.Empty) returns (google.protobuf.Empty);
 *     }
 */
declare type Empty = {};

/** Represents a customer-managed encryption key specification that can be applied to a Vertex AI resource. This data type is not supported in Gemini API. */
export declare interface EncryptionSpec {
    /** Required. Resource name of the Cloud KMS key used to protect the resource. The Cloud KMS key must be in the same region as the resource. It must have the format `projects/{project}/locations/{location}/keyRings/{key_ring}/cryptoKeys/{crypto_key}`. */
    kmsKeyName?: string;
}

/** An endpoint where you deploy models. */
export declare interface Endpoint {
    /** Resource name of the endpoint. */
    name?: string;
    /** ID of the model that's deployed to the endpoint. */
    deployedModelId?: string;
}

/** End of speech sensitivity. */
export declare enum EndSensitivity {
    /**
     * The default is END_SENSITIVITY_LOW for Gemini Enterprise Agent Platform and END_SENSITIVITY_HIGH for Gemini Live.
     */
    END_SENSITIVITY_UNSPECIFIED = "END_SENSITIVITY_UNSPECIFIED",
    /**
     * Automatic detection ends speech more often.
     */
    END_SENSITIVITY_HIGH = "END_SENSITIVITY_HIGH",
    /**
     * Automatic detection ends speech less often.
     */
    END_SENSITIVITY_LOW = "END_SENSITIVITY_LOW"
}

/** Tool to search public web data, powered by Vertex AI Search and Sec4 compliance. This data type is not supported in Gemini API. */
export declare interface EnterpriseWebSearch {
    /** Optional. Sites with confidence level chosen & above this value will be blocked from the search results. */
    blockingConfidence?: PhishBlockThreshold;
    /** Optional. List of domains to be excluded from the search results. The default limit is 2000 domains. */
    excludeDomains?: string[];
}

/** An entity representing the segmented area. */
export declare interface EntityLabel {
    /** The label of the segmented entity. */
    label?: string;
    /** The confidence score of the detected label. */
    score?: number;
}

declare type Env = EnvVar | string;

declare type Environment$ = Environment_3;

declare type Environment$2 = Environment_2;

/** The target environment where the computer use tool operates. */
export declare enum Environment {
    /**
     * The environment is unspecified.
     */
    ENVIRONMENT_UNSPECIFIED = "ENVIRONMENT_UNSPECIFIED",
    /**
     * The tool operates in a web browser.
     */
    ENVIRONMENT_BROWSER = "ENVIRONMENT_BROWSER",
    /**
     * The tool operates in a mobile environment.
     */
    ENVIRONMENT_MOBILE = "ENVIRONMENT_MOBILE",
    /**
     * The tool operates in a desktop environment.
     */
    ENVIRONMENT_DESKTOP = "ENVIRONMENT_DESKTOP"
}

/**
 * Configuration for a custom environment.
 */
declare type Environment_2 = {
    /**
     * Environment variables to set in the sandbox environment.
     */
    env?: {
        [k: string]: EnvVar | string;
    } | undefined;
    /**
     * Optional. The environment ID for the interaction. If specified, the request will
     *
     * @remarks
     * update the existing environment instead of creating a new one.
     */
    environment_id?: string | undefined;
    /**
     * Network configuration for the environment.
     */
    network?: EnvironmentNetworkEgressAllowlist | NetworkEnum | undefined;
    sources?: Array<Source> | undefined;
    type: "remote";
};

/**
 * An execution environment for an agent.
 */
declare type Environment_3 = {
    /**
     * Output only. The time at which the environment was created in ISO 8601 format
     *
     * @remarks
     * (YYYY-MM-DDThh:mm:ssZ).
     */
    created?: string | undefined;
    /**
     * Output only. The number of files in the environment, output only.
     */
    file_count?: string | undefined;
    /**
     * Required. Output only. The ID of the environment.
     */
    id: string;
    /**
     * Output only. The time at which the environment was last accessed in ISO 8601 format
     *
     * @remarks
     * (YYYY-MM-DDThh:mm:ssZ).
     */
    last_accessed?: string | undefined;
    /**
     * Network configuration for the environment.
     */
    network?: interactions.EnvironmentNetworkEgressAllowlist | EnvironmentNetworkEnum | undefined;
    /**
     * Output only. The total size of the environment files in bytes, output only.
     */
    size_bytes?: string | undefined;
    /**
     * Sources to be mounted into the environment.
     */
    sources?: Array<interactions.Source> | undefined;
    /**
     * Output only. The status of the environment container.
     */
    status?: Status_3 | undefined;
    /**
     * Output only. The time at which the environment was last updated in ISO 8601 format
     *
     * @remarks
     * (YYYY-MM-DDThh:mm:ssZ).
     */
    updated?: string | undefined;
};

declare type EnvironmentDeleteResponse$ = Empty;

/**
 * The environment being operated.
 */
declare type EnvironmentEnum = "browser" | "mobile" | "desktop" | (string & {});

declare type EnvironmentFile$ = EnvironmentFile;

/**
 * Metadata for a file or directory within an environment.
 */
declare type EnvironmentFile = {
    /**
     * Output only. The creation time of the file/directory.
     */
    created?: string | undefined;
    /**
     * Output only. The MIME type of the file (e.g., "text/python", "image/png").
     *
     * @remarks
     * Empty for directories.
     * NOLINT
     */
    mime_type?: string | undefined;
    /**
     * Output only. The modification time of the file/directory.
     */
    modified?: string | undefined;
    /**
     * Output only. The name of the file or directory (e.g., "main.py" or "src").
     */
    name?: string | undefined;
    /**
     * Output only. The full relative path within the environment
     *
     * @remarks
     * (e.g., "workspace/src/main.py").
     */
    path?: string | undefined;
    /**
     * Output only. The size of the file/directory in bytes.
     *
     * @remarks
     * NOLINT
     */
    size_bytes?: string | undefined;
    /**
     * Output only. The type of the entry.
     */
    type?: Type_3 | undefined;
};

declare type EnvironmentListResponse$ = ListEnvironmentsResponse;

declare type EnvironmentNetworkEgressAllowlist$ = EnvironmentNetworkEgressAllowlist;

/**
 * Network egress configuration for the environment.
 */
declare type EnvironmentNetworkEgressAllowlist = {
    /**
     * List of allowed domains and their configurations. Set to `"disabled"`
     *
     * @remarks
     * to block all network egress.
     */
    allowlist?: Array<AllowlistEntry> | Disabled | undefined;
};

declare type EnvironmentNetworkEnum = "disabled" | (string & {});

/**
 * Network configuration for the environment.
 */
declare type EnvironmentNetworkUnion = interactions.EnvironmentNetworkEgressAllowlist | EnvironmentNetworkEnum;

export declare namespace Environments {
    export type CreateEnvironmentRequest = CreateEnvironmentRequest$;
    export type Environment = Environment$;
    export type EnvironmentDeleteResponse = EnvironmentDeleteResponse$;
    export type EnvironmentFile = EnvironmentFile$;
    export type EnvironmentListResponse = EnvironmentListResponse$;
    export type GetEnvironmentFilesResponse = GetEnvironmentFilesResponse$;
    export type ListEnvironmentsResponse = ListEnvironmentsResponse$;
}

declare namespace environments {
    export {
        CreateEnvironmentRequestNetworkEnum,
        CreateEnvironmentRequestNetworkUnion,
        CreateEnvironmentRequest_2 as CreateEnvironmentRequest,
        Type_3 as Type,
        EnvironmentFile,
        EnvironmentNetworkEnum,
        EnvironmentNetworkUnion,
        Status_3 as Status,
        Environment_3 as Environment,
        GetEnvironmentFilesResponse,
        ListEnvironmentsResponse
    }
}

declare class Environments_2 extends ClientSDK {
    private _internal?;
    get internal(): Internal;
    private _files?;
    get files(): Files_2;
    /**
     * Lists environments.
     */
    listEnvironments(params?: ListEnvironmentsParams_2, options?: Omit<RequestOptions, "extra_body">): APIPromise<environments.ListEnvironmentsResponse>;
    /**
     * Creates an environment.
     */
    createEnvironment(body: environments.CreateEnvironmentRequest, api_version?: string | undefined, options?: RequestOptions): APIPromise<environments.Environment>;
    /**
     * Deletes an environment.
     */
    deleteEnvironment(id: string, params?: DeleteEnvironmentParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<interactions.Empty>;
    /**
     * Gets an environment.
     */
    getEnvironment(id: string, params?: GetEnvironmentParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<environments.Environment>;
}

declare type EnvironmentVariableConfig$ = EnvironmentVariableConfig;

/**
 * Configuration for environment variable credentials.
 */
declare type EnvironmentVariableConfig = {
    id: string;
    /**
     * Required. Locations where the environment variable can be injected in
     *
     * @remarks
     * outgoing HTTP requests. Must contain at least one location.
     * Accepts either a single location (e.g. "header") or an array of locations.
     */
    injection_location: InjectionLocationEnum | Array<InjectionLocationEnum>;
    /**
     * Optional. List of domains allowed to receive this environment variable
     *
     * @remarks
     * value in HTTP requests.
     */
    trusted_domains?: Array<string> | undefined;
    type: "environment_variable";
    /**
     * Required. Input only. Secret value of the environment variable. Write-only; never
     *
     * @remarks
     * returned in responses.
     */
    value: string;
};

/**
 * Required. Locations where the environment variable can be injected in
 *
 * @remarks
 * outgoing HTTP requests. Must contain at least one location.
 * Accepts either a single location (e.g. "header") or an array of locations.
 */
declare type EnvironmentVariableConfigInjectionLocation = InjectionLocationEnum | Array<InjectionLocationEnum>;

declare type EnvironmentVariableConfigParams = Omit<CreateCredentialRequest, "body"> & EnvironmentVariableConfig;

declare type EnvironmentVariableUpdateConfig$ = EnvironmentVariableUpdateConfig;

/**
 * Configuration for updating environment variable credentials.
 */
declare type EnvironmentVariableUpdateConfig = {
    /**
     * Optional. Locations where the environment variable can be injected in
     *
     * @remarks
     * outgoing HTTP requests.
     * Accepts either a single location (e.g. "header") or an array of locations.
     */
    injection_location?: InjectionLocationEnum | Array<InjectionLocationEnum> | undefined;
    /**
     * Optional. List of domains allowed to receive this environment variable
     *
     * @remarks
     * value in HTTP requests.
     */
    trusted_domains?: Array<string> | undefined;
    type: "environment_variable";
    /**
     * Optional. Input only. Secret value of the environment variable. Write-only; never
     *
     * @remarks
     * returned in responses.
     */
    value?: string | undefined;
};

/**
 * Optional. Locations where the environment variable can be injected in
 *
 * @remarks
 * outgoing HTTP requests.
 * Accepts either a single location (e.g. "header") or an array of locations.
 */
declare type EnvironmentVariableUpdateConfigInjectionLocation = InjectionLocationEnum | Array<InjectionLocationEnum>;

declare type EnvironmentVariableUpdateConfigParams = Omit<UpdateCredentialRequest, "id" | "body"> & EnvironmentVariableUpdateConfig;

declare type EnvVar$ = EnvVar;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * An environment variable to set in the execution environment.
 */
declare type EnvVar = {
    /**
     * Optional reference to a server-managed Credential resource by ID.
     */
    credential?: string | undefined;
    /**
     * Direct string value for plain environment variables.
     */
    value?: string | undefined;
};

declare type Error$ = ErrorT;

declare type Error$2 = ErrorT;

declare type ErrorEvent$ = ErrorEvent_2;

declare type ErrorEvent_2 = {
    /**
     * Error message from an interaction.
     */
    error?: ErrorT | undefined;
    /**
     * The event_id token to be used to resume the interaction stream, from
     *
     * @remarks
     * this event.
     */
    event_id?: string | undefined;
    event_type: "error";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Error message from an interaction.
 */
declare type ErrorT = {
    /**
     * A URI that identifies the error type.
     */
    code?: string | undefined;
    /**
     * A human-readable error message.
     */
    message?: string | undefined;
};

/** The results from an evaluation run performed by the EvaluationService. This data type is not supported in Gemini API. */
export declare class EvaluateDatasetResponse {
    /** Output only. Aggregation statistics derived from results of EvaluationService. */
    aggregationOutput?: AggregationOutput;
    /** Output only. Output info for EvaluationService. */
    outputInfo?: OutputInfo;
}

/** Evaluate Dataset Run Result for Tuning Job. This data type is not supported in Gemini API. */
export declare interface EvaluateDatasetRun {
    /** Output only. The checkpoint id used in the evaluation run. Only populated when evaluating checkpoints. */
    checkpointId?: string;
    /** Output only. The error of the evaluation run if any. */
    error?: GoogleRpcStatus;
    /** Output only. Results for EvaluationService. */
    evaluateDatasetResponse?: EvaluateDatasetResponse;
    /** Output only. The resource name of the evaluation run. Format: `projects/{project}/locations/{location}/evaluationRuns/{evaluation_run_id}`. */
    evaluationRun?: string;
    /** Output only. Deprecated: The updated architecture uses evaluation_run instead. */
    operationName?: string;
}

/** The dataset used for evaluation. This data type is not supported in Gemini API. */
export declare interface EvaluationDataset {
    /** BigQuery source holds the dataset. */
    bigquerySource?: BigQuerySource;
    /** Cloud storage source holds the dataset. Currently only one Cloud Storage file path is supported. */
    gcsSource?: GcsSource;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Used to specify configuration for ExaAISearch.
 */
declare type ExaAISearchConfig = {
    /**
     * Required. The API key for ExaAiSearch.
     */
    api_key: string;
    /**
     * Optional. This field can be used to pass any parameter from the Exa.ai Search API.
     */
    custom_config?: {
        [k: string]: any;
    } | undefined;
};

/** Exact match metric value for an instance. This data type is not supported in Gemini API. */
export declare interface ExactMatchMetricValue {
    /** Output only. Exact match score. */
    score?: number;
}

/** Code generated by the model that is meant to be executed, and the result returned to the model. Generated when using the `CodeExecution` tool, in which the code will be automatically executed, and a corresponding CodeExecutionResult will also be generated. */
export declare interface ExecutableCode {
    /** Required. The code to be executed. */
    code?: string;
    /** Required. Programming language of the `code`. */
    language?: Language;
    /** Optional. Unique identifier of the `ExecutableCode` part. The server returns the `CodeExecutionResult` with the matching `id`. */
    id?: string;
}

/** Retrieve from data source powered by external API for grounding. The external API is not owned by Google, but need to follow the pre-defined API spec. This data type is not supported in Gemini API. */
export declare interface ExternalApi {
    /** The authentication config to access the API. Deprecated. Please use auth_config instead. */
    apiAuth?: ApiAuth;
    /** The API spec that the external API implements. */
    apiSpec?: ApiSpec;
    /** The authentication config to access the API. */
    authConfig?: AuthConfig;
    /** Parameters for the elastic search API. */
    elasticSearchParams?: ExternalApiElasticSearchParams;
    /** The endpoint of the external API. The system will call the API at this endpoint to retrieve the data for grounding. Example: https://acme.com:443/search */
    endpoint?: string;
    /** Parameters for the simple search API. */
    simpleSearchParams?: ExternalApiSimpleSearchParams;
}

/** The search parameters to use for the ELASTIC_SEARCH spec. This data type is not supported in Gemini API. */
export declare interface ExternalApiElasticSearchParams {
    /** The ElasticSearch index to use. */
    index?: string;
    /** Optional. Number of hits (chunks) to request. When specified, it is passed to Elasticsearch as the `num_hits` param. */
    numHits?: number;
    /** The ElasticSearch search template to use. */
    searchTemplate?: string;
}

/** The search parameters to use for SIMPLE_SEARCH spec. This data type is not supported in Gemini API. */
export declare interface ExternalApiSimpleSearchParams {
}

/** Options for feature selection preference. */
export declare enum FeatureSelectionPreference {
    FEATURE_SELECTION_PREFERENCE_UNSPECIFIED = "FEATURE_SELECTION_PREFERENCE_UNSPECIFIED",
    PRIORITIZE_QUALITY = "PRIORITIZE_QUALITY",
    BALANCED = "BALANCED",
    PRIORITIZE_COST = "PRIORITIZE_COST"
}

/** A custom fetch function type matching the standard fetch signature. */
export declare type Fetch = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type Fetcher = (input: RequestInfo | URL, init?: RequestInit) => Promise<Response>;

export declare interface FetchPredictOperationConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for the fetchPredictOperation method. */
export declare interface FetchPredictOperationParameters {
    /** The server-assigned name for the operation. */
    operationName: string;
    resourceName: string;
    /** Used to override the default configuration. */
    config?: FetchPredictOperationConfig;
}

/** A file uploaded to the API. */
declare interface File_2 {
    /** The `File` resource name. The ID (name excluding the "files/" prefix) can contain up to 40 characters that are lowercase alphanumeric or dashes (-). The ID cannot start or end with a dash. If the name is empty on create, a unique name will be generated. Example: `files/123-456` */
    name?: string;
    /** Optional. The human-readable display name for the `File`. The display name must be no more than 512 characters in length, including spaces. Example: 'Welcome Image' */
    displayName?: string;
    /** Output only. MIME type of the file. */
    mimeType?: string;
    /** Output only. Size of the file in bytes. */
    sizeBytes?: string;
    /** Output only. The timestamp of when the `File` was created. */
    createTime?: string;
    /** Output only. The timestamp of when the `File` will be deleted. Only set if the `File` is scheduled to expire. */
    expirationTime?: string;
    /** Output only. The timestamp of when the `File` was last updated. */
    updateTime?: string;
    /** Output only. SHA-256 hash of the uploaded bytes. The hash value is encoded in base64 format. */
    sha256Hash?: string;
    /** Output only. The URI of the `File`. */
    uri?: string;
    /** Output only. The URI of the `File`, only set for downloadable (generated) files. */
    downloadUri?: string;
    /** Output only. Processing state of the File. */
    state?: FileState;
    /** Output only. The source of the `File`. */
    source?: FileSource;
    /** Output only. Metadata for a video. */
    videoMetadata?: Record<string, unknown>;
    /** Output only. Error status if File processing failed. */
    error?: FileStatus;
}
export { File_2 as File }

declare type FileCitation$ = FileCitation;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A file citation annotation.
 */
declare type FileCitation = {
    /**
     * User provided metadata about the retrieved context.
     */
    custom_metadata?: {
        [k: string]: any;
    } | undefined;
    /**
     * The URI of the file.
     */
    document_uri?: string | undefined;
    /**
     * End of the attributed segment, exclusive.
     */
    end_index?: number | undefined;
    /**
     * The name of the file.
     */
    file_name?: string | undefined;
    /**
     * Media ID in-case of image citations, if applicable.
     */
    media_id?: string | undefined;
    /**
     * Page number of the cited document, if applicable.
     */
    page_number?: number | undefined;
    /**
     * Source attributed for a portion of the text.
     */
    source?: string | undefined;
    /**
     * Start of segment of the response that is attributed to this source.
     *
     * @remarks
     *
     * Index indicates the start of the segment, measured in bytes.
     */
    start_index?: number | undefined;
    type: "file_citation";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Content of a single file in the codebase.
 */
declare type FileContent = {
    /**
     * The UTF-8 encoded text content of the file.
     */
    content?: string | undefined;
    /**
     * The relative path of the file from the project root.
     */
    path?: string | undefined;
};

/** URI-based data. A FileData message contains a URI pointing to data of a specific media type. It is used to represent images, audio, and video stored in Google Cloud Storage. */
export declare interface FileData {
    /** Optional. The display name of the file. Used to provide a label or filename to distinguish files. This field is only returned in `PromptMessage` for prompt management. It is used in the Gemini calls only when server side tools (`code_execution`, `google_search`, and `url_context`) are enabled. */
    displayName?: string;
    /** Required. The URI of the file in Google Cloud Storage. */
    fileUri?: string;
    /** Required. The IANA standard MIME type of the source data. */
    mimeType?: string;
}

export declare class Files extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    /**
     * Lists files.
     *
     * @param params - The parameters for the list request.
     * @return - A pager of files.
     *
     * @example
     * ```ts
     * const files = await ai.files.list({config: {'pageSize': 2}});
     * for await (const file of files) {
     *   console.log(file);
     * }
     * ```
     */
    list: (params?: types.ListFilesParameters) => Promise<Pager<types.File>>;
    /**
     * Uploads a file asynchronously to the Gemini API.
     * This method is not available in Gemini Enterprise Agent Platform (previously known as Vertex AI).
     * Supported upload sources:
     * - Node.js: File path (string) or Blob object.
     * - Browser: Blob object (e.g., File).
     *
     * @remarks
     * The `mimeType` can be specified in the `config` parameter. If omitted:
     *  - For file path (string) inputs, the `mimeType` will be inferred from the
     *     file extension.
     *  - For Blob object inputs, the `mimeType` will be set to the Blob's `type`
     *     property.
     * Some examples for file extension to mimeType mapping:
     * .txt -> text/plain
     * .json -> application/json
     * .jpg  -> image/jpeg
     * .png -> image/png
     * .mp3 -> audio/mpeg
     * .mp4 -> video/mp4
     *
     * This section can contain multiple paragraphs and code examples.
     *
     * @param params - Optional parameters specified in the
     *        `types.UploadFileParameters` interface.
     *         @see {@link types.UploadFileParameters#config} for the optional
     *         config in the parameters.
     * @return A promise that resolves to a `types.File` object.
     * @throws An error if called on a Gemini Enterprise Agent Platform (previously known as Vertex AI) client.
     * @throws An error if the `mimeType` is not provided and can not be inferred,
     * the `mimeType` can be provided in the `params.config` parameter.
     * @throws An error occurs if a suitable upload location cannot be established.
     *
     * @example
     * The following code uploads a file to Gemini API.
     *
     * ```ts
     * const file = await ai.files.upload({file: 'file.txt', config: {
     *   mimeType: 'text/plain',
     * }});
     * console.log(file.name);
     * ```
     */
    upload(params: types.UploadFileParameters): Promise<types.File>;
    /**
     * Downloads a remotely stored file asynchronously to a location specified in
     * the `params` object. This method only works on Node environment, to
     * download files in the browser, use a browser compliant method like an <a>
     * tag.
     *
     * @param params - The parameters for the download request.
     *
     * @example
     * The following code downloads an example file named "files/mehozpxf877d" as
     * "file.txt".
     *
     * ```ts
     * await ai.files.download({file: file.name, downloadPath: 'file.txt'});
     * ```
     */
    download(params: types.DownloadFileParameters): Promise<void>;
    /**
     * Registers Google Cloud Storage files for use with the API.
     * This method is only available in Node.js environments.
     */
    registerFiles(params: types.RegisterFilesParameters): Promise<types.RegisterFilesResponse>;
    protected _registerFiles(params: types.InternalRegisterFilesParameters): Promise<types.RegisterFilesResponse>;
    private listInternal;
    private createInternal;
    /**
     * Retrieves the file information from the service.
     *
     * @param params - The parameters for the get request
     * @return The Promise that resolves to the types.File object requested.
     *
     * @example
     * ```ts
     * const config: GetFileParameters = {
     *   name: fileName,
     * };
     * file = await ai.files.get(config);
     * console.log(file.name);
     * ```
     */
    get(params: types.GetFileParameters): Promise<types.File>;
    /**
     * Deletes a remotely stored file.
     *
     * @param params - The parameters for the delete request.
     * @return The DeleteFileResponse, the response for the delete method.
     *
     * @example
     * The following code deletes an example file named "files/mehozpxf877d".
     *
     * ```ts
     * await ai.files.delete({name: file.name});
     * ```
     */
    delete(params: types.DeleteFileParameters): Promise<types.DeleteFileResponse>;
    private registerFilesInternal;
}

declare class Files_2 extends ClientSDK {
    /**
     * Retrieves file metadata or directory contents from an environment's snapshot. To download file content, use the download URL returned in the response.
     */
    list(environment: string, path: string, params?: GetEnvironmentFilesParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<environments.GetEnvironmentFilesResponse>;
}

declare type FileSearch$ = FileSearch_2;

/** The FileSearch tool that retrieves knowledge from Semantic Retrieval corpora. Files are imported to Semantic Retrieval corpora using the ImportFile API. This data type is not supported in Vertex AI. */
export declare interface FileSearch {
    /** Required. The names of the file_search_stores to retrieve from. Example: `fileSearchStores/my-file-search-store-123` */
    fileSearchStoreNames?: string[];
    /** Optional. Metadata filter to apply to the semantic retrieval documents and chunks. */
    metadataFilter?: string;
    /** Optional. The number of semantic retrieval chunks to retrieve. */
    topK?: number;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A tool that can be used by the model to search files.
 */
declare type FileSearch_2 = {
    /**
     * The file search store names to search.
     */
    file_search_store_names?: Array<string> | undefined;
    /**
     * Metadata filter to apply to the semantic retrieval documents and chunks.
     */
    metadata_filter?: string | undefined;
    /**
     * The number of semantic retrieval chunks to retrieve.
     */
    top_k?: number | undefined;
    type: "file_search";
};

declare type FileSearchCall$ = FileSearchCallDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type FileSearchCallDelta = {
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "file_search_call";
};

declare type FileSearchCallStep$ = FileSearchCallStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * File Search call step.
 */
declare type FileSearchCallStep = {
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "file_search_call";
};

declare type FileSearchResult$ = FileSearchResultDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The result of the File Search.
 */
declare type FileSearchResult = {};

declare type FileSearchResultDelta = {
    result: Array<FileSearchResult>;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "file_search_result";
};

declare type FileSearchResultStep$ = FileSearchResultStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * File Search result step.
 */
declare type FileSearchResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "file_search_result";
};

/** A collection of Documents. */
export declare interface FileSearchStore {
    /** The embedding model used by the FileSearchStore. */
    embeddingModel?: string;
    /** Output only. The number of documents in the `FileSearchStore` that are active and ready for retrieval. */
    activeDocumentsCount?: string;
    /** Output only. The Timestamp of when the `FileSearchStore` was created. */
    createTime?: string;
    /** Optional. The human-readable display name for the `FileSearchStore`. The display name must be no more than 512 characters in length, including spaces. Example: "Docs on Semantic Retriever". */
    displayName?: string;
    /** Output only. The number of documents in the `FileSearchStore` that have failed processing. */
    failedDocumentsCount?: string;
    /** Output only. Immutable. Identifier. The `FileSearchStore` resource name. It is an ID (name excluding the "fileSearchStores/" prefix) that can contain up to 40 characters that are lowercase alphanumeric or dashes (-). It is output only. The unique name will be derived from `display_name` along with a 12 character random suffix. Example: `fileSearchStores/my-awesome-file-search-store-123a456b789c` If `display_name` is not provided, the name will be randomly generated. */
    name?: string;
    /** Output only. The number of documents in the `FileSearchStore` that are being processed. */
    pendingDocumentsCount?: string;
    /** Output only. The size of raw bytes ingested into the `FileSearchStore`. This is the total size of all the documents in the `FileSearchStore`. */
    sizeBytes?: string;
    /** Output only. The Timestamp of when the `FileSearchStore` was last updated. */
    updateTime?: string;
}

declare class FileSearchStores extends BaseModule {
    private readonly apiClient;
    readonly documents: Documents;
    constructor(apiClient: ApiClient, documents?: Documents);
    /**
     * Lists file search stores.
     *
     * @param params - The parameters for the list request.
     * @return - A pager of file search stores.
     *
     * @example
     * ```ts
     * const fileSearchStores = await ai.fileSearchStores.list({config: {'pageSize': 2}});
     * for await (const fileSearchStore of fileSearchStores) {
     *   console.log(fileSearchStore);
     * }
     * ```
     */
    list: (params?: types.ListFileSearchStoresParameters) => Promise<Pager<types.FileSearchStore>>;
    /**
     * Uploads a file asynchronously to a given File Search Store.
     * This method is not available in Gemini Enterprise Agent Platform (previously known as Vertex AI).
     * Supported upload sources:
     * - Node.js: File path (string) or Blob object.
     * - Browser: Blob object (e.g., File).
     *
     * @remarks
     * The `mimeType` can be specified in the `config` parameter. If omitted:
     *  - For file path (string) inputs, the `mimeType` will be inferred from the
     *     file extension.
     *  - For Blob object inputs, the `mimeType` will be set to the Blob's `type`
     *     property.
     *
     * This section can contain multiple paragraphs and code examples.
     *
     * @param params - Optional parameters specified in the
     *        `types.UploadToFileSearchStoreParameters` interface.
     *         @see {@link types.UploadToFileSearchStoreParameters#config} for the optional
     *         config in the parameters.
     * @return A promise that resolves to a long running operation.
     * @throws An error if called on a Gemini Enterprise Agent Platform (previously known as Vertex AI) client.
     * @throws An error if the `mimeType` is not provided and can not be inferred,
     * the `mimeType` can be provided in the `params.config` parameter.
     * @throws An error occurs if a suitable upload location cannot be established.
     *
     * @example
     * The following code uploads a file to a given file search store.
     *
     * ```ts
     * const operation = await ai.fileSearchStores.upload({fileSearchStoreName: 'fileSearchStores/foo-bar', file: 'file.txt', config: {
     *   mimeType: 'text/plain',
     * }});
     * console.log(operation.name);
     * ```
     */
    uploadToFileSearchStore(params: types.UploadToFileSearchStoreParameters): Promise<types.UploadToFileSearchStoreOperation>;
    /**
     * Downloads media using a Media ID or URI.
     * This method is only supported in the Gemini Developer client.
     *
     * @param uri - The URI or Media ID of the blob.
     * @param config - Optional configuration for the download.
     * @returns A promise that resolves to the blob data as a Uint8Array.
     */
    downloadMedia(uri: string, config?: types.DownloadMediaConfig): Promise<Uint8Array>;
    /**
     * Creates a File Search Store.
     *
     * @param params - The parameters for creating a File Search Store.
     * @return FileSearchStore.
     */
    create(params: types.CreateFileSearchStoreParameters): Promise<types.FileSearchStore>;
    /**
     * Gets a File Search Store.
     *
     * @param params - The parameters for getting a File Search Store.
     * @return FileSearchStore.
     */
    get(params: types.GetFileSearchStoreParameters): Promise<types.FileSearchStore>;
    /**
     * Deletes a File Search Store.
     *
     * @param params - The parameters for deleting a File Search Store.
     */
    delete(params: types.DeleteFileSearchStoreParameters): Promise<void>;
    private listInternal;
    private uploadToFileSearchStoreInternal;
    /**
     * Imports a File from File Service to a FileSearchStore.
     *
     * This is a long-running operation, see aip.dev/151
     *
     * @param params - The parameters for importing a file to a file search store.
     * @return ImportFileOperation.
     */
    importFile(params: types.ImportFileParameters): Promise<types.ImportFileOperation>;
}

/** Source of the File. */
export declare enum FileSource {
    SOURCE_UNSPECIFIED = "SOURCE_UNSPECIFIED",
    UPLOADED = "UPLOADED",
    GENERATED = "GENERATED",
    REGISTERED = "REGISTERED"
}

/**
 * Represents the size and mimeType of a file. The information is used to
 * request the upload URL from the https://generativelanguage.googleapis.com/upload/v1beta/files endpoint.
 * This interface defines the structure for constructing and executing HTTP
 * requests.
 */
declare interface FileStat {
    /**
     * The size of the file in bytes.
     */
    size: number;
    /**
     * The MIME type of the file.
     */
    type: string | undefined;
}

/** State for the lifecycle of a File. */
export declare enum FileState {
    STATE_UNSPECIFIED = "STATE_UNSPECIFIED",
    PROCESSING = "PROCESSING",
    ACTIVE = "ACTIVE",
    FAILED = "FAILED"
}

/** Status of a File that uses a common error model. */
export declare interface FileStatus {
    /** A list of messages that carry the error details. There is a common set of message types for APIs to use. */
    details?: Record<string, unknown>[];
    /** A list of messages that carry the error details. There is a common set of message types for APIs to use. */
    message?: string;
    /** The status code. 0 for OK, 1 for CANCELLED */
    code?: number;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Config for filters.
 */
declare type Filter = {
    /**
     * Optional. String for metadata filtering.
     */
    metadata_filter?: string | undefined;
    /**
     * Optional. Only returns contexts with vector distance smaller than the
     *
     * @remarks
     * threshold.
     */
    vector_distance_threshold?: number | undefined;
    /**
     * Optional. Only returns contexts with vector similarity larger than the
     *
     * @remarks
     * threshold.
     */
    vector_similarity_threshold?: number | undefined;
};

declare type FindRequest$ = FindRequest;

/**
 * Request parameters specific to FIND sessions, used for discovering
 *
 * @remarks
 * vulnerabilities in a codebase.
 */
declare type FindRequest = {
    /**
     * Additional context or custom instructions provided by the user to guide
     *
     * @remarks
     * the vulnerability analysis.
     */
    description?: string | undefined;
    /**
     * The identifier of a specific finding to verify. This is primarily used in
     *
     * @remarks
     * VERIFY mode to focus the agent's execution-based validation on a single
     * vulnerability.
     */
    finding_id?: string | undefined;
    /**
     * The mode of the find session.
     */
    mode?: Mode | undefined;
    /**
     * A list of source files to provide as context for the scan.
     */
    source_files?: Array<FileContent> | undefined;
};

/** Output only. The reason why the model stopped generating tokens.

 If empty, the model has not stopped generating the tokens. */
export declare enum FinishReason {
    /**
     * The finish reason is unspecified.
     */
    FINISH_REASON_UNSPECIFIED = "FINISH_REASON_UNSPECIFIED",
    /**
     * Token generation reached a natural stopping point or a configured stop sequence.
     */
    STOP = "STOP",
    /**
     * Token generation reached the configured maximum output tokens.
     */
    MAX_TOKENS = "MAX_TOKENS",
    /**
     * Token generation stopped because the content potentially contains safety violations. NOTE: When streaming, [content][] is empty if content filters blocks the output.
     */
    SAFETY = "SAFETY",
    /**
     * The token generation stopped because of potential recitation.
     */
    RECITATION = "RECITATION",
    /**
     * The token generation stopped because of using an unsupported language.
     */
    LANGUAGE = "LANGUAGE",
    /**
     * All other reasons that stopped the token generation.
     */
    OTHER = "OTHER",
    /**
     * Token generation stopped because the content contains forbidden terms.
     */
    BLOCKLIST = "BLOCKLIST",
    /**
     * Token generation stopped for potentially containing prohibited content.
     */
    PROHIBITED_CONTENT = "PROHIBITED_CONTENT",
    /**
     * Token generation stopped because the content potentially contains Sensitive Personally Identifiable Information (SPII).
     */
    SPII = "SPII",
    /**
     * The function call generated by the model is invalid.
     */
    MALFORMED_FUNCTION_CALL = "MALFORMED_FUNCTION_CALL",
    /**
     * Token generation stopped because generated images have safety violations.
     */
    IMAGE_SAFETY = "IMAGE_SAFETY",
    /**
     * The tool call generated by the model is invalid.
     */
    UNEXPECTED_TOOL_CALL = "UNEXPECTED_TOOL_CALL",
    /**
     * Model called too many tools consecutively, thus the system exited execution.
     */
    TOO_MANY_TOOL_CALLS = "TOO_MANY_TOOL_CALLS",
    /**
     * Image generation stopped because the generated images have prohibited content.
     */
    IMAGE_PROHIBITED_CONTENT = "IMAGE_PROHIBITED_CONTENT",
    /**
     * The model was expected to generate an image, but none was generated.
     */
    NO_IMAGE = "NO_IMAGE",
    /**
     * Image generation stopped because the generated image may be a recitation from a source.
     */
    IMAGE_RECITATION = "IMAGE_RECITATION",
    /**
     * Image generation stopped for a reason not otherwise specified.
     */
    IMAGE_OTHER = "IMAGE_OTHER",
    /**
     * Token generation stopped because the response reached the per-request token limit, but generation is not yet complete. The response can be continued by passing the returned `continuation_token` in a subsequent request.
     */
    CONTINUATION = "CONTINUATION"
}

declare type FixRequest$ = FixRequest;

/**
 * Request parameters specific to FIX sessions, used for generating and
 *
 * @remarks
 * validating security patches.
 */
declare type FixRequest = {
    /**
     * Additional context or custom instructions provided by the user to guide
     *
     * @remarks
     * the patch generation process.
     */
    description?: string | undefined;
    /**
     * The identifier of the specific security finding to be remediated. This ID
     *
     * @remarks
     * maps to a previously discovered vulnerability.
     */
    finding_id?: string | undefined;
    /**
     * A list of source files providing context for the remediation. These files
     *
     * @remarks
     * are typically the ones containing the identified vulnerability.
     */
    source_files?: Array<FileContent> | undefined;
};

/** Tuning Spec for Full Fine Tuning. This data type is not supported in Gemini API. */
export declare interface FullFineTuningSpec {
    /** Optional. Hyperparameters for Full Fine Tuning. */
    hyperParameters?: SupervisedHyperParameters;
    /** Required. Training dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    trainingDatasetUri?: string;
    /** Optional. Validation dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    validationDatasetUri?: string;
}

declare type Function$ = FunctionT;

/** A predicted FunctionCall returned from the model that contains a string representing the FunctionDeclaration.name and a structured JSON object containing the parameters and their values. */
export declare interface FunctionCall {
    /** Optional. The function parameters and values in JSON object format. See FunctionDeclaration.parameters for parameter details. */
    args?: Record<string, unknown>;
    /** Optional. The unique id of the function call. If populated, the client to execute the `function_call` and return the response with the matching `id`. */
    id?: string;
    /** Optional. The name of the function to call. Matches FunctionDeclaration.name. */
    name?: string;
    /** Optional. The partial argument value of the function call. If provided, represents the arguments/fields that are streamed incrementally. This field is not supported in Gemini API. */
    partialArgs?: PartialArg[];
    /** Optional. Whether this is the last part of the FunctionCall. If true, another partial message for the current FunctionCall is expected to follow. This field is not supported in Gemini API. */
    willContinue?: boolean;
}

/** Function calling config. */
export declare interface FunctionCallingConfig {
    /** Optional. Function names to call. Only set when the Mode is ANY. Function names should match FunctionDeclaration.name. With mode set to ANY, model will predict a function call from the set of function names provided. */
    allowedFunctionNames?: string[];
    /** Optional. Function calling mode. */
    mode?: FunctionCallingConfigMode;
    /** Optional. When set to true, arguments of a single function call will be streamed out in multiple parts/contents/responses. Partial parameter results will be returned in the `FunctionCall.partial_args` field. This field is not supported in Gemini API. */
    streamFunctionCallArguments?: boolean;
}

/** Function calling mode. */
export declare enum FunctionCallingConfigMode {
    /**
     * Unspecified function calling mode. This value should not be used.
     */
    MODE_UNSPECIFIED = "MODE_UNSPECIFIED",
    /**
     * Default model behavior, model decides to predict either function calls or natural language response.
     */
    AUTO = "AUTO",
    /**
     * Model is constrained to always predicting function calls only. If "allowed_function_names" are set, the predicted function calls will be limited to any one of "allowed_function_names", else the predicted function calls will be any one of the provided "function_declarations".
     */
    ANY = "ANY",
    /**
     * Model will not predict any function calls. Model behavior is same as when not passing any function declarations.
     */
    NONE = "NONE",
    /**
     * Model is constrained to predict either function calls or natural language response. If "allowed_function_names" are set, the predicted function calls will be limited to any one of "allowed_function_names", else the predicted function calls will be any one of the provided "function_declarations".
     */
    VALIDATED = "VALIDATED"
}

declare type FunctionCallStep$ = FunctionCallStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A function tool call step.
 */
declare type FunctionCallStep = {
    /**
     * Required. The arguments to pass to the function.
     */
    arguments: {
        [k: string]: any;
    };
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * Required. The name of the tool to call.
     */
    name: string;
    type: "function_call";
};

/** Structured representation of a function declaration as defined by the [OpenAPI 3.0 specification](https://spec.openapis.org/oas/v3.0.3). Included in this declaration are the function name, description, parameters and response type. This FunctionDeclaration is a representation of a block of code that can be used as a `Tool` by the model and executed by the client. */
export declare interface FunctionDeclaration {
    /** Optional. Specifies the function Behavior. If not specified, the system keeps the current function call behavior. This field is currently only supported by the BidiGenerateContent method. */
    behavior?: Behavior;
    /** Optional. Description and purpose of the function. Model uses it to decide how and whether to call the function. */
    description?: string;
    /** Required. The name of the function to call. Must start with a letter or an underscore. Must be a-z, A-Z, 0-9, or contain underscores, dots, colons and dashes, with a maximum length of 128. */
    name?: string;
    /** Optional. Describes the parameters to this function in JSON Schema Object format. Reflects the Open API 3.03 Parameter Object. string Key: the name of the parameter. Parameter names are case sensitive. Schema Value: the Schema defining the type used for the parameter. For function with no parameters, this can be left unset. Parameter names must start with a letter or an underscore and must only contain chars a-z, A-Z, 0-9, or underscores with a maximum length of 64. Example with 1 required and 1 optional parameter: type: OBJECT properties: param1: type: STRING param2: type: INTEGER required: - param1 */
    parameters?: Schema;
    /** Optional. Describes the parameters to the function in JSON Schema format. The schema must describe an object where the properties are the parameters to the function. For example: ``` { "type": "object", "properties": { "name": { "type": "string" }, "age": { "type": "integer" } }, "additionalProperties": false, "required": ["name", "age"], "propertyOrdering": ["name", "age"] } ``` This field is mutually exclusive with `parameters`. */
    parametersJsonSchema?: unknown;
    /** Optional. Describes the output from this function in JSON Schema format. Reflects the Open API 3.03 Response Object. The Schema defines the type used for the response value of the function. */
    response?: Schema;
    /** Optional. Describes the output from this function in JSON Schema format. The value specified by the schema is the response value of the function. This field is mutually exclusive with `response`. */
    responseJsonSchema?: unknown;
}

/** The result output from a FunctionCall that contains a string representing the FunctionDeclaration.name and a structured JSON object containing any output from the function is used as context to the model. This should contain the result of a `FunctionCall` made based on model prediction. */
export declare class FunctionResponse {
    /** Optional. The id of the function call this response is for. Populated by the client to match the corresponding function call `id`. */
    id?: string;
    /** Required. The name of the function to call. Matches FunctionDeclaration.name and FunctionCall.name. */
    name?: string;
    /** Optional. Ordered `Parts` that constitute a function response. Parts may have different IANA MIME types. */
    parts?: FunctionResponsePart[];
    /** Required. The function response in JSON object format. Use "output" key to specify function output and "error" key to specify error details (if any). If "output" and "error" keys are not specified, then whole "response" is treated as function output. */
    response?: Record<string, unknown>;
    /** Optional. Specifies how the response should be scheduled in the conversation. Only applicable to NON_BLOCKING function calls, is ignored otherwise. Defaults to WHEN_IDLE. */
    scheduling?: FunctionResponseScheduling;
    /** Optional. Signals that function call continues, and more responses will be returned, turning the function call into a generator. Is only applicable to NON_BLOCKING function calls, is ignored otherwise. If set to false, future responses will not be considered. It is allowed to return empty `response` with `will_continue=False` to signal that the function call is finished. This may still trigger the model generation. To avoid triggering the generation and finish the function call, additionally set `scheduling` to `SILENT`. This field is not supported in Vertex AI. */
    willContinue?: boolean;
}

/** Raw media bytes for function response. Text should not be sent as raw bytes, use the 'text' field. */
export declare class FunctionResponseBlob {
    /** Required. Raw bytes.
     * @remarks Encoded as base64 string. */
    data?: string;
    /** Optional. Display name of the blob. Used to provide a label or filename to distinguish blobs. This field is only returned in PromptMessage for prompt management. It is currently used in the Gemini GenerateContent calls only when server side tools (code_execution, google_search, and url_context) are enabled. */
    displayName?: string;
    /** Required. The IANA standard MIME type of the source data. */
    mimeType?: string;
}

/** URI based data for function response. */
export declare class FunctionResponseFileData {
    /** Optional. Display name of the file data. Used to provide a label or filename to distinguish file datas. This field is only returned in PromptMessage for prompt management. It is currently used in the Gemini GenerateContent calls only when server side tools (code_execution, google_search, and url_context) are enabled. */
    displayName?: string;
    /** Required. URI. */
    fileUri?: string;
    /** Required. The IANA standard MIME type of the source data. */
    mimeType?: string;
}

/** A datatype containing media that is part of a `FunctionResponse` message. A `FunctionResponsePart` consists of data which has an associated datatype. A `FunctionResponsePart` can only contain one of the accepted types in `FunctionResponsePart.data`. A `FunctionResponsePart` must have a fixed IANA MIME type identifying the type and subtype of the media if the `inline_data` field is filled with raw bytes. */
export declare class FunctionResponsePart {
    /** URI based data. */
    fileData?: FunctionResponseFileData;
    /** Inline media bytes. */
    inlineData?: FunctionResponseBlob;
    /** Optional. How the model processes this part's media for understanding. Only meaningful for video parts (`inline_data` or `file_data` with video mime). Non-video parts ignore this field. This field is not supported in Vertex AI. */
    mediaProcessing?: MediaProcessing;
}

/** Specifies how the response should be scheduled in the conversation. Only applicable to NON_BLOCKING function calls, is ignored otherwise. Defaults to WHEN_IDLE. */
export declare enum FunctionResponseScheduling {
    /**
     * This value is unused.
     */
    SCHEDULING_UNSPECIFIED = "SCHEDULING_UNSPECIFIED",
    /**
     * Only add the result to the conversation context, do not interrupt or trigger generation.
     */
    SILENT = "SILENT",
    /**
     * Add the result to the conversation context, and prompt to generate output without interrupting ongoing generation.
     */
    WHEN_IDLE = "WHEN_IDLE",
    /**
     * Add the result to the conversation context, interrupt ongoing generation and prompt to generate output.
     */
    INTERRUPT = "INTERRUPT"
}

declare type FunctionResult$ = FunctionResultDelta;

declare type FunctionResultDelta = {
    is_error?: boolean | undefined;
    name?: string | undefined;
    result: Array<FunctionResultSubcontent> | FunctionResultDeltaResult | string;
    type: "function_result";
};

declare type FunctionResultDeltaResult = {};

declare type FunctionResultDeltaResultUnion = Array<FunctionResultSubcontent> | FunctionResultDeltaResult | string;

declare type FunctionResultStep$ = FunctionResultStep;

/**
 * Result of a function tool call.
 */
declare type FunctionResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * Whether the tool call resulted in an error.
     */
    is_error?: boolean | undefined;
    /**
     * The name of the tool that was called.
     */
    name?: string | undefined;
    /**
     * Required. The result of the tool call.
     */
    result: Array<FunctionResultSubcontent> | FunctionResultStepResult | string;
    type: "function_result";
};

declare type FunctionResultStepResult = {};

/**
 * Required. The result of the tool call.
 */
declare type FunctionResultStepResultUnion = Array<FunctionResultSubcontent> | FunctionResultStepResult | string;

declare type FunctionResultSubcontent = AudioContent | DocumentContent | ImageContent | TextContent | VideoContent;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A tool that can be used by the model.
 */
declare type FunctionT = {
    /**
     * A description of the function.
     */
    description?: string | undefined;
    /**
     * The name of the function.
     */
    name?: string | undefined;
    /**
     * The JSON Schema for the function's parameters.
     *
     * @remarks
     *
     * Supports a subset of JSON Schema. `minLength`, `maxLength`,
     * `minProperties`, `maxProperties`, `uniqueItems`, `contains`,
     * `minContains`, and `maxContains` are ignored and not enforced.
     */
    parameters?: any | undefined;
    type: "function";
};

/** The Google Cloud Storage location for the input content. This data type is not supported in Gemini API. */
export declare interface GcsSource {
    /** Required. Google Cloud Storage URI(-s) to the input file(s). May contain wildcards. For more information on wildcards, see https://cloud.google.com/storage/docs/wildcards. */
    uris?: string[];
}

declare class GeminiNextGenAgents {
    private readonly parentClient;
    private sdk;
    constructor(parentClient: GoogleGenAIParentClient);
    create(params?: Agents.AgentCreateParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Agents.Agent>;
    list(params?: Agents.AgentListParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Agents.AgentListResponse>;
    get(id: string, params?: Agents.AgentGetParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Agents.Agent>;
    delete(id: string, params?: Agents.AgentDeleteParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Agents.AgentDeleteResponse>;
    private getClient;
}

declare class GeminiNextGenCredentials {
    private readonly parentClient;
    private sdk;
    constructor(parentClient: GoogleGenAIParentClient);
    create(params: Credentials.CredentialCreateParams & {
        api_version?: string;
    }, options?: GoogleGenAIRequestOptions): Promise<Credentials.Credential>;
    list(params?: Credentials.CredentialListParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Credentials.CredentialListResponse>;
    get(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Credentials.Credential>;
    update(id: string, params: CredentialUpdateParams, options?: GoogleGenAIRequestOptions): Promise<Credentials.Credential>;
    delete(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Credentials.CredentialDeleteResponse>;
    private getClient;
}

declare class GeminiNextGenEnvironmentFiles {
    private readonly resolveClient;
    private readonly parentClient?;
    constructor(resolveClient: (apiVersion?: string) => GoogleGenAI_2, parentClient?: GoogleGenAIParentClient | undefined);
    list(params: ListEnvironmentFilesParams, options?: GoogleGenAIRequestOptions): Promise<ListEnvironmentFilesResponse>;
    download(params: DownloadEnvironmentFileParams, options?: GoogleGenAIRequestOptions): Promise<Uint8Array>;
    upload(params: UploadEnvironmentFileParams, options?: GoogleGenAIRequestOptions): Promise<Environments.GetEnvironmentFilesResponse | any>;
}

declare class GeminiNextGenEnvironments {
    private readonly parentClient;
    private sdk;
    readonly files: GeminiNextGenEnvironmentFiles;
    constructor(parentClient: GoogleGenAIParentClient);
    create(params: Environments.CreateEnvironmentRequest & {
        api_version?: string;
    }, options?: GoogleGenAIRequestOptions): Promise<Environments.Environment>;
    list(params?: ListEnvironmentsParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Environments.EnvironmentListResponse>;
    get(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Environments.Environment>;
    delete(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Environments.EnvironmentDeleteResponse>;
    private getClient;
}

declare class GeminiNextGenInteractions {
    private readonly parentClient;
    private sdk;
    constructor(parentClient: GoogleGenAIParentClient, _webSocketFactory?: WebSocketFactory);
    /**
     * Creates a model interaction. Long decodes are continued automatically
     * across hops and merged into one interaction unless
     * `automatic_continuation: false` is passed; see
     * {@link AutomaticContinuationOption}.
     */
    create(params: Interactions.InteractionCreateParams.CreateModelInteractionParamsNonStreaming & AutomaticContinuationOption, options?: GoogleGenAIRequestOptions): Promise<GoogleGenAIInteraction>;
    /**
     * Creates an agent interaction. Agent loops are managed by the server, so
     * `automatic_continuation` has no effect; see
     * {@link AutomaticContinuationOption}.
     */
    create(params: Interactions.InteractionCreateParams.CreateAgentInteractionParamsNonStreaming & AutomaticContinuationOption, options?: GoogleGenAIRequestOptions): Promise<GoogleGenAIInteraction>;
    /**
     * Creates a streaming model interaction. Long decodes are continued
     * automatically: the returned stream yields the events of every hop unless
     * `automatic_continuation: false` is passed; see
     * {@link AutomaticContinuationOption}.
     */
    create(params: Interactions.InteractionCreateParams.CreateModelInteractionParamsStreaming & AutomaticContinuationOption, options?: GoogleGenAIRequestOptions): Promise<Stream<Interactions.InteractionSSEEvent>>;
    /**
     * Creates a streaming agent interaction. Agent loops are managed by the
     * server, so `automatic_continuation` has no effect; see
     * {@link AutomaticContinuationOption}.
     */
    create(params: Interactions.InteractionCreateParams.CreateAgentInteractionParamsStreaming & AutomaticContinuationOption, options?: GoogleGenAIRequestOptions): Promise<Stream<Interactions.InteractionSSEEvent>>;
    /**
     * Creates a streaming interaction; see {@link AutomaticContinuationOption}.
     */
    create(params: Interactions.InteractionCreateParams.InteractionCreateParamsStreaming & AutomaticContinuationOption, options?: GoogleGenAIRequestOptions): Promise<Stream<Interactions.InteractionSSEEvent>>;
    /**
     * Creates an interaction; see {@link AutomaticContinuationOption}.
     */
    create(params: Interactions.InteractionCreateParams.InteractionCreateParamsNonStreaming & AutomaticContinuationOption, options?: GoogleGenAIRequestOptions): Promise<GoogleGenAIInteraction>;
    /**
     * Creates an interaction; see {@link AutomaticContinuationOption}.
     */
    create(params: CreateInteractionParamsWithOptions, options?: GoogleGenAIRequestOptions): Promise<GoogleGenAIInteraction | Stream<Interactions.InteractionSSEEvent>>;
    get(id: string, params?: Interactions.InteractionGetParamsNonStreaming | null, options?: GoogleGenAIRequestOptions): Promise<GoogleGenAIInteraction>;
    get(id: string, params: Interactions.InteractionGetParamsStreaming, options?: GoogleGenAIRequestOptions): Promise<Stream<Interactions.InteractionSSEEvent>>;
    get(id: string, params?: Interactions.InteractionGetParams | null, options?: GoogleGenAIRequestOptions): Promise<GoogleGenAIInteraction | Stream<Interactions.InteractionSSEEvent>>;
    delete(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<unknown>;
    cancel(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<GoogleGenAIInteraction>;
    private getClient;
}

declare class GeminiNextGenTriggers {
    private readonly parentClient;
    private sdk;
    constructor(parentClient: GoogleGenAIParentClient);
    create(params: Triggers.TriggerCreateParams & {
        api_version?: string | undefined;
    }, options?: GoogleGenAIRequestOptions): Promise<Triggers.Trigger>;
    list(params?: Triggers.TriggerListParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Triggers.TriggerListResponse>;
    get(id: string, params?: Triggers.TriggerGetParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Triggers.Trigger>;
    update(id: string, params: Triggers.TriggerUpdateParams, options?: GoogleGenAIRequestOptions): Promise<Triggers.Trigger>;
    delete(id: string, params?: Triggers.TriggerDeleteParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Triggers.TriggerDeleteResponse>;
    run(trigger_id: string, params?: Triggers.TriggerRunParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Triggers.TriggerExecution>;
    listExecutions(trigger_id: string, params?: Triggers.TriggerListExecutionsParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Triggers.TriggerListExecutionsResponse>;
    private getClient;
}

declare class GeminiNextGenVoices {
    private readonly parentClient;
    private sdk;
    constructor(parentClient: GoogleGenAIParentClient);
    create(params: Voices.VoiceCreateParams["body"] & {
        api_version?: string;
    }, options?: GoogleGenAIRequestOptions): Promise<Voices.VoiceListResponse.Voice>;
    list(params?: Voices.VoiceListParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Voices.VoiceListResponse>;
    get(id: string, params?: Voices.VoiceGetParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Voices.VoiceListResponse.Voice>;
    delete(id: string, params?: Voices.VoiceDeleteParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Voices.VoiceDeleteResponse>;
    private getClient;
}

declare class GeminiNextGenWebhooks {
    private readonly parentClient;
    private sdk;
    constructor(parentClient: GoogleGenAIParentClient);
    create(params: Webhooks.WebhookInput & {
        api_version?: string;
    }, options?: GoogleGenAIRequestOptions): Promise<Webhooks.Webhook>;
    list(params?: Webhooks.WebhookListParams | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Webhooks.WebhookListResponse>;
    get(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Webhooks.Webhook>;
    update(id: string, params?: (Webhooks.WebhookUpdate & {
        api_version?: string | undefined;
        update_mask?: string | undefined;
    }) | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Webhooks.Webhook>;
    delete(id: string, params?: {
        api_version?: string;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Webhooks.WebhookDeleteResponse>;
    rotateSigningSecret(id: string, params?: (Webhooks.RotateSigningSecretRequest & {
        api_version?: string;
    }) | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Webhooks.WebhookRotateSigningSecretResponse>;
    ping(id: string, params?: {
        api_version?: string;
        body?: Webhooks.PingWebhookRequest;
    } | null | undefined, options?: GoogleGenAIRequestOptions): Promise<Webhooks.WebhookPingResponse>;
    private getClient;
}

/** Input example for preference optimization. This data type is not supported in Gemini API. */
export declare interface GeminiPreferenceExample {
    /** List of completions for a given prompt. */
    completions?: GeminiPreferenceExampleCompletion[];
    /** Multi-turn contents that represents the Prompt. */
    contents?: Content[];
}

/** Completion and its preference score. This data type is not supported in Gemini API. */
export declare interface GeminiPreferenceExampleCompletion {
    /** Single turn completion for the given prompt. */
    completion?: Content;
    /** The score for the given completion. */
    score?: number;
}

/** Optional model configuration parameters.

 For more information, see `Content generation parameters
 <https://cloud.google.com/vertex-ai/generative-ai/docs/multimodal/content-generation-parameters>`_. */
export declare interface GenerateContentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The service tier to use for the request. For example, ServiceTier.FLEX. */
    serviceTier?: ServiceTier;
    /** Instructions for the model to steer it toward better performance.
     For example, "Answer as concisely as possible" or "Don't use technical
     terms in your response".
     */
    systemInstruction?: ContentUnion;
    /** Value that controls the degree of randomness in token selection.
     Lower temperatures are good for prompts that require a less open-ended or
     creative response, while higher temperatures can lead to more diverse or
     creative results.
     */
    temperature?: number;
    /** Tokens are selected from the most to least probable until the sum
     of their probabilities equals this value. Use a lower value for less
     random responses and a higher value for more random responses.
     */
    topP?: number;
    /** For each token selection step, the ``top_k`` tokens with the
     highest probabilities are sampled. Then tokens are further filtered based
     on ``top_p`` with the final token selected using temperature sampling. Use
     a lower number for less random responses and a higher number for more
     random responses.
     */
    topK?: number;
    /** Number of response variations to return.
     */
    candidateCount?: number;
    /** Maximum number of tokens that can be generated in the response.
     */
    maxOutputTokens?: number;
    /** List of strings that tells the model to stop generating text if one
     of the strings is encountered in the response.
     */
    stopSequences?: string[];
    /** Whether to return the log probabilities of the tokens that were
     chosen by the model at each step.
     */
    responseLogprobs?: boolean;
    /** Number of top candidate tokens to return the log probabilities for
     at each generation step.
     */
    logprobs?: number;
    /** Positive values penalize tokens that already appear in the
     generated text, increasing the probability of generating more diverse
     content.
     */
    presencePenalty?: number;
    /** Positive values penalize tokens that repeatedly appear in the
     generated text, increasing the probability of generating more diverse
     content.
     */
    frequencyPenalty?: number;
    /** When ``seed`` is fixed to a specific number, the model makes a best
     effort to provide the same response for repeated requests. By default, a
     random number is used.
     */
    seed?: number;
    /** Output response mimetype of the generated candidate text.
     Supported mimetype:
     - `text/plain`: (default) Text output.
     - `application/json`: JSON response in the candidates.
     The model needs to be prompted to output the appropriate response type,
     otherwise the behavior is undefined.
     */
    responseMimeType?: string;
    /** The `Schema` object allows the definition of input and output data types.
     These types can be objects, but also primitives and arrays.
     Represents a select subset of an [OpenAPI 3.0 schema
     object](https://spec.openapis.org/oas/v3.0.3#schema).
     If set, a compatible response_mime_type must also be set.
     Compatible mimetypes: `application/json`: Schema for JSON response.

     If `response_schema` doesn't process your schema correctly, try using
     `response_json_schema` instead.
     */
    responseSchema?: SchemaUnion;
    /** Optional. Output schema of the generated response.
     This is an alternative to `response_schema` that accepts [JSON
     Schema](https://json-schema.org/). If set, `response_schema` must be
     omitted, but `response_mime_type` is required. While the full JSON Schema
     may be sent, not all features are supported. Specifically, only the
     following properties are supported: - `$id` - `$defs` - `$ref` - `$anchor`
     - `type` - `format` - `title` - `description` - `enum` (for strings and
     numbers) - `items` - `prefixItems` - `minItems` - `maxItems` - `minimum` -
     `maximum` - `anyOf` - `oneOf` (interpreted the same as `anyOf`) -
     `properties` - `additionalProperties` - `required` The non-standard
     `propertyOrdering` property may also be set. Cyclic references are
     unrolled to a limited degree and, as such, may only be used within
     non-required properties. (Nullable properties are not sufficient.) If
     `$ref` is set on a sub-schema, no other properties, except for than those
     starting as a `$`, may be set. */
    responseJsonSchema?: unknown;
    /** Configuration for model router requests.
     */
    routingConfig?: GenerationConfigRoutingConfig;
    /** Configuration for model selection.
     */
    modelSelectionConfig?: ModelSelectionConfig;
    /** Safety settings in the request to block unsafe content in the
     response.
     */
    safetySettings?: SafetySetting[];
    /** Code that enables the system to interact with external systems to
     perform an action outside of the knowledge and scope of the model.
     */
    tools?: ToolListUnion;
    /** Associates model output to a specific function call.
     */
    toolConfig?: ToolConfig;
    /** Labels with user-defined metadata for the request. */
    labels?: Record<string, string>;
    /** Resource name of a context cache that can be used in subsequent
     requests.
     */
    cachedContent?: string;
    /** The requested modalities of the response. Represents the set of
     modalities that the model can return.
     */
    responseModalities?: string[];
    /** If specified, the media resolution specified will be used.
     */
    mediaResolution?: MediaResolution;
    /** The speech generation configuration.
     */
    speechConfig?: SpeechConfigUnion;
    /** If enabled, audio timestamp will be included in the request to the
     model.
     */
    audioTimestamp?: boolean;
    /** The configuration for automatic function calling.
     */
    automaticFunctionCalling?: AutomaticFunctionCallingConfig;
    /** The thinking features configuration.
     */
    thinkingConfig?: ThinkingConfig;
    /** Optional. Configuration for audio transcription (speech recognition).
     */
    audioTranscriptionConfig?: AudioTranscriptionConfig;
    /** The image generation configuration.
     */
    imageConfig?: ImageConfig;
    /** Enables enhanced civic answers. It may not be available for all
     models. This field is not supported in Gemini Enterprise Agent Platform.
     */
    enableEnhancedCivicAnswers?: boolean;
    /** Settings for prompt and response sanitization using the Model Armor
     service. If supplied, safety_settings must not be supplied.
     */
    modelArmorConfig?: ModelArmorConfig;
    /** An opaque continuation token used to resume generation from a
     previous response that stopped with `finish_reason` set to
     `CONTINUATION`.

     * @remarks Encoded as base64 string. */
    continuationToken?: string;
    /** Defaults to true. When a response ends with finish reason
     `CONTINUATION`, the SDK sends the same request again with the response's
     continuation token until the model finishes. Timeouts, retries and
     billing apply to each request. Set to false to turn this off.
     */
    automaticContinuation?: boolean;
    /** Optional. Configuration for persisting output assets to external
     storage.
     */
    generationOutputConfig?: GenerationOutputConfig;
    /** Configures the logging behavior for a given request. If set, it
     takes precedence over the project-level logging config. This field is not
     supported in Gemini Enterprise Agent Platform.
     */
    store?: boolean;
}

/** Config for models.generate_content parameters. */
export declare interface GenerateContentParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** Content of the request.
     */
    contents: ContentListUnion;
    /** Configuration that contains optional model parameters.
     */
    config?: GenerateContentConfig;
}

/** Response message for PredictionService.GenerateContent. */
export declare class GenerateContentResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** Response variations returned by the model.
     */
    candidates?: Candidate[];
    /** Timestamp when the request is made to the server.
     */
    createTime?: string;
    /** The history of automatic function calling.
     */
    automaticFunctionCallingHistory?: Content[];
    /** Output only. The model version used to generate the response. */
    modelVersion?: string;
    /** Output only. Content filter results for a prompt sent in the request. Note: Sent only in the first stream chunk. Only happens when no candidates were generated due to content violations. */
    promptFeedback?: GenerateContentResponsePromptFeedback;
    /** Output only. response_id is used to identify each response. It is the encoding of the event_id. */
    responseId?: string;
    /** Usage metadata about the response(s). */
    usageMetadata?: GenerateContentResponseUsageMetadata;
    /** Output only. The current model status of this model. This field is not supported in Vertex AI. */
    modelStatus?: ModelStatus;
    /**
     * Returns the concatenation of all text parts from the first candidate in the response.
     *
     * @remarks
     * If there are multiple candidates in the response, the text from the first
     * one will be returned.
     * If there are non-text parts in the response, the concatenation of all text
     * parts will be returned, and a warning will be logged.
     * If there are thought parts in the response, the concatenation of all text
     * parts excluding the thought parts will be returned.
     *
     * @example
     * ```ts
     * const response = await ai.models.generateContent({
     *   model: 'gemini-flash-latest',
     *   contents:
     *     'Why is the sky blue?',
     * });
     *
     * console.debug(response.text);
     * ```
     */
    get text(): string | undefined;
    /**
     * Returns the concatenation of all inline data parts from the first candidate
     * in the response.
     *
     * @remarks
     * If there are multiple candidates in the response, the inline data from the
     * first one will be returned. If there are non-inline data parts in the
     * response, the concatenation of all inline data parts will be returned, and
     * a warning will be logged.
     */
    get data(): string | undefined;
    /**
     * Returns the function calls from the first candidate in the response.
     *
     * @remarks
     * If there are multiple candidates in the response, the function calls from
     * the first one will be returned.
     * If there are no function calls in the response, undefined will be returned.
     *
     * @example
     * ```ts
     * const controlLightFunctionDeclaration: FunctionDeclaration = {
     *   name: 'controlLight',
     *   parameters: {
     *   type: Type.OBJECT,
     *   description: 'Set the brightness and color temperature of a room light.',
     *   properties: {
     *     brightness: {
     *       type: Type.NUMBER,
     *       description:
     *         'Light level from 0 to 100. Zero is off and 100 is full brightness.',
     *     },
     *     colorTemperature: {
     *       type: Type.STRING,
     *       description:
     *         'Color temperature of the light fixture which can be `daylight`, `cool` or `warm`.',
     *     },
     *   },
     *   required: ['brightness', 'colorTemperature'],
     *  };
     *  const response = await ai.models.generateContent({
     *     model: 'gemini-flash-latest',
     *     contents: 'Dim the lights so the room feels cozy and warm.',
     *     config: {
     *       tools: [{functionDeclarations: [controlLightFunctionDeclaration]}],
     *       toolConfig: {
     *         functionCallingConfig: {
     *           mode: FunctionCallingConfigMode.ANY,
     *           allowedFunctionNames: ['controlLight'],
     *         },
     *       },
     *     },
     *   });
     *  console.debug(JSON.stringify(response.functionCalls));
     * ```
     */
    get functionCalls(): FunctionCall[] | undefined;
    /**
     * Returns the first executable code from the first candidate in the response.
     *
     * @remarks
     * If there are multiple candidates in the response, the executable code from
     * the first one will be returned.
     * If there are no executable code in the response, undefined will be
     * returned.
     *
     * @example
     * ```ts
     * const response = await ai.models.generateContent({
     *   model: 'gemini-flash-latest',
     *   contents:
     *     'What is the sum of the first 50 prime numbers? Generate and run code for the calculation, and make sure you get all 50.'
     *   config: {
     *     tools: [{codeExecution: {}}],
     *   },
     * });
     *
     * console.debug(response.executableCode);
     * ```
     */
    get executableCode(): string | undefined;
    /**
     * Returns the first code execution result from the first candidate in the response.
     *
     * @remarks
     * If there are multiple candidates in the response, the code execution result from
     * the first one will be returned.
     * If there are no code execution result in the response, undefined will be returned.
     *
     * @example
     * ```ts
     * const response = await ai.models.generateContent({
     *   model: 'gemini-flash-latest',
     *   contents:
     *     'What is the sum of the first 50 prime numbers? Generate and run code for the calculation, and make sure you get all 50.'
     *   config: {
     *     tools: [{codeExecution: {}}],
     *   },
     * });
     *
     * console.debug(response.codeExecutionResult);
     * ```
     */
    get codeExecutionResult(): string | undefined;
    /**
     * Returns the prompt token count from the initial request prior to any continuation hops.
     */
    get initialPromptTokenCount(): number | undefined;
}

/** Content filter results for a prompt sent in the request. Note: This is sent only in the first stream chunk and only if no candidates were generated due to content violations. */
export declare class GenerateContentResponsePromptFeedback {
    /** Output only. The reason why the prompt was blocked. */
    blockReason?: BlockedReason;
    /** Output only. A readable message that explains the reason why the prompt was blocked. This field is not supported in Gemini API. */
    blockReasonMessage?: string;
    /** Output only. A list of safety ratings for the prompt. There is one rating per category. */
    safetyRatings?: SafetyRating[];
}

/** Usage metadata about the content generation request and response. This message provides a detailed breakdown of token usage and other relevant metrics. This data type is not supported in Gemini API. */
export declare class GenerateContentResponseUsageMetadata {
    /** Output only. A detailed breakdown of the token count for each modality in the cached content. */
    cacheTokensDetails?: ModalityTokenCount[];
    /** Output only. The number of tokens in the cached content that was used for this request. */
    cachedContentTokenCount?: number;
    /** The total number of tokens in the generated candidates. */
    candidatesTokenCount?: number;
    /** Output only. A detailed breakdown of the token count for each modality in the generated candidates. */
    candidatesTokensDetails?: ModalityTokenCount[];
    /** The total number of tokens in the prompt. This includes any text, images, or other media provided in the request. When `cached_content` is set, this also includes the number of tokens in the cached content. */
    promptTokenCount?: number;
    /** Output only. A detailed breakdown of the token count for each modality in the prompt. */
    promptTokensDetails?: ModalityTokenCount[];
    /** Output only. The number of tokens that were part of the model's generated "thoughts" output, if applicable. */
    thoughtsTokenCount?: number;
    /** Output only. The number of tokens in the results from tool executions, which are provided back to the model as input, if applicable. */
    toolUsePromptTokenCount?: number;
    /** Output only. A detailed breakdown by modality of the token counts from the results of tool executions, which are provided back to the model as input. */
    toolUsePromptTokensDetails?: ModalityTokenCount[];
    /** The total number of tokens for the entire request. This is the sum of `prompt_token_count`, `candidates_token_count`, `tool_use_prompt_token_count`, and `thoughts_token_count`. */
    totalTokenCount?: number;
    /** Output only. The traffic type for this request. */
    trafficType?: TrafficType;
    /** Output only. The prompt token count from the initial request prior to any continuation hops. */
    initialPromptTokenCount?: number;
}

/** An output image. */
export declare interface GeneratedImage {
    /** The output image data. */
    image?: Image_2;
    /** Responsible AI filter reason if the image is filtered out of the
     response. */
    raiFilteredReason?: string;
    /** Safety attributes of the image. Lists of RAI categories and their
     scores of each content. */
    safetyAttributes?: SafetyAttributes;
    /** The rewritten prompt used for the image generation if the prompt
     enhancer is enabled. */
    enhancedPrompt?: string;
}

/** A generated image mask. */
export declare interface GeneratedImageMask {
    /** The generated image mask. */
    mask?: Image_2;
    /** The detected entities on the segmented area. */
    labels?: EntityLabel[];
}

/** A generated video. */
export declare interface GeneratedVideo {
    /** The output video */
    video?: Video;
}

/** The config for generating an images. */
export declare interface GenerateImagesConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** Cloud Storage URI used to store the generated images. */
    outputGcsUri?: string;
    /** Description of what to discourage in the generated images. */
    negativePrompt?: string;
    /** Number of images to generate. */
    numberOfImages?: number;
    /** Aspect ratio of the generated images. Supported values are
     "1:1", "3:4", "4:3", "9:16", and "16:9". */
    aspectRatio?: string;
    /** Controls how much the model adheres to the text prompt. Large
     values increase output and prompt alignment, but may compromise image
     quality. */
    guidanceScale?: number;
    /** Random seed for image generation. This is not available when
     ``add_watermark`` is set to true. */
    seed?: number;
    /** Filter level for safety filtering. */
    safetyFilterLevel?: SafetyFilterLevel;
    /** Allows generation of people by the model. */
    personGeneration?: PersonGeneration;
    /** Whether to report the safety scores of each generated image and
     the positive prompt in the response. */
    includeSafetyAttributes?: boolean;
    /** Whether to include the Responsible AI filter reason if the image
     is filtered out of the response. */
    includeRaiReason?: boolean;
    /** Language of the text in the prompt. */
    language?: ImagePromptLanguage;
    /** MIME type of the generated image. */
    outputMimeType?: string;
    /** Compression quality of the generated image (for ``image/jpeg``
     only). */
    outputCompressionQuality?: number;
    /** Whether to add a watermark to the generated images. */
    addWatermark?: boolean;
    /** User specified labels to track billing usage. */
    labels?: Record<string, string>;
    /** The size of the largest dimension of the generated image.
     Supported sizes are 1K and 2K (not supported for Imagen 3 models). */
    imageSize?: string;
    /** Whether to use the prompt rewriting logic. */
    enhancePrompt?: boolean;
}

/** The parameters for generating images. */
export declare interface GenerateImagesParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** Text prompt that typically describes the images to output.
     */
    prompt: string;
    /** Configuration for generating images.
     */
    config?: GenerateImagesConfig;
}

/** The output images response. */
export declare class GenerateImagesResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** List of generated images. */
    generatedImages?: GeneratedImage[];
    /** Safety attributes of the positive prompt. Only populated if
     ``include_safety_attributes`` is set to True. */
    positivePromptSafetyAttributes?: SafetyAttributes;
}

/** Configuration for generating videos. */
export declare interface GenerateVideosConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** Number of output videos. */
    numberOfVideos?: number;
    /** The gcs bucket where to save the generated videos. */
    outputGcsUri?: string;
    /** Frames per second for video generation. */
    fps?: number;
    /** Duration of the clip for video generation in seconds. */
    durationSeconds?: number;
    /** The RNG seed. If RNG seed is exactly same for each request with
     unchanged inputs, the prediction results will be consistent. Otherwise,
     a random RNG seed will be used each time to produce a different
     result. */
    seed?: number;
    /** The aspect ratio for the generated video. 16:9 (landscape) and
     9:16 (portrait) are supported. */
    aspectRatio?: string;
    /** The resolution for the generated video. 720p and 1080p are
     supported. */
    resolution?: string;
    /** Whether allow to generate person videos, and restrict to specific
     ages. Supported values are: dont_allow, allow_adult. */
    personGeneration?: string;
    /** The pubsub topic where to publish the video generation
     progress. */
    pubsubTopic?: string;
    /** Explicitly state what should not be included in the generated
     videos. */
    negativePrompt?: string;
    /** Whether to use the prompt rewriting logic. */
    enhancePrompt?: boolean;
    /** Whether to generate audio along with the video. */
    generateAudio?: boolean;
    /** Image to use as the last frame of generated videos.
     Only supported for image to video use cases. */
    lastFrame?: Image_2;
    /** The images to use as the references to generate the videos.
     If this field is provided, the text prompt field must also be provided.
     The image, video, or last_frame field are not supported. Each image must
     be associated with a type. Veo 2 supports up to 3 asset images *or* 1
     style image. */
    referenceImages?: VideoGenerationReferenceImage[];
    /** The mask to use for generating videos. */
    mask?: VideoGenerationMask;
    /** Compression quality of the generated videos. */
    compressionQuality?: VideoCompressionQuality;
    /** User specified labels to track billing usage. */
    labels?: Record<string, string>;
    /** Webhook configuration for receiving notifications when the
     video generation operation completes. */
    webhookConfig?: WebhookConfig;
    /** Resize mode of the image input for video generation. */
    resizeMode?: ImageResizeMode;
}

/** A video generation operation. */
export declare class GenerateVideosOperation implements Operation<GenerateVideosResponse> {
    /** The server-assigned name, which is only unique within the same service that originally returns it. If you use the default HTTP mapping, the `name` should be a resource name ending with `operations/{unique_id}`. */
    name?: string;
    /** Service-specific metadata associated with the operation. It typically contains progress information and common metadata such as create time. Some services might not provide such metadata.  Any method that returns a long-running operation should document the metadata type, if any. */
    metadata?: Record<string, unknown>;
    /** If the value is `false`, it means the operation is still in progress. If `true`, the operation is completed, and either `error` or `response` is available. */
    done?: boolean;
    /** The error result of the operation in case of failure or cancellation. */
    error?: Record<string, unknown>;
    /** The generated videos. */
    response?: GenerateVideosResponse;
    /**
     * Instantiates an Operation of the same type as the one being called with the fields set from the API response.
     */
    _fromAPIResponse({ apiResponse, _isVertexAI, }: OperationFromAPIResponseParameters): Operation<GenerateVideosResponse>;
    /** The full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** Class that represents the parameters for generating videos. */
export declare interface GenerateVideosParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** The text prompt for generating the videos.
     Optional if image or video is provided. */
    prompt?: string;
    /** The input image for generating the videos.
     Optional if prompt is provided. Not allowed if video is provided. */
    image?: Image_2;
    /** The input video for video extension use cases.
     Optional if prompt is provided. Not allowed if image is provided. */
    video?: Video;
    /** A set of source input(s) for video generation. */
    source?: GenerateVideosSource;
    /** Configuration for generating videos. */
    config?: GenerateVideosConfig;
}

/** Response with generated videos. */
export declare class GenerateVideosResponse {
    /** List of the generated videos */
    generatedVideos?: GeneratedVideo[];
    /** Returns if any videos were filtered due to RAI policies. */
    raiMediaFilteredCount?: number;
    /** Returns rai failure reasons if any. */
    raiMediaFilteredReasons?: string[];
}

/** A set of source input(s) for video generation. */
export declare interface GenerateVideosSource {
    /** The text prompt for generating the videos.
     Optional if image or video is provided. */
    prompt?: string;
    /** The input image for generating the videos.
     Optional if prompt is provided. Not allowed if video is provided. */
    image?: Image_2;
    /** The input video for video extension use cases.
     Optional if prompt is provided. Not allowed if image is provided. */
    video?: Video;
}

declare type GenerationConfig$ = GenerationConfig_2;

/** Generation config. */
export declare interface GenerationConfig {
    /** Optional. Config for model selection. */
    modelSelectionConfig?: ModelSelectionConfig;
    /** Output schema of the generated response. This is an alternative to
     `response_schema` that accepts [JSON Schema](https://json-schema.org/).
     */
    responseJsonSchema?: unknown;
    /** Optional. Configuration for audio transcription (speech recognition).
     */
    audioTranscriptionConfig?: AudioTranscriptionConfig;
    /** Optional. If enabled, audio timestamps will be included in the request to the model. This can be useful for synchronizing audio with other modalities in the response. This field is not supported in Gemini API. */
    audioTimestamp?: boolean;
    /** Optional. The number of candidate responses to generate. A higher `candidate_count` can provide more options to choose from, but it also consumes more resources. This can be useful for generating a variety of responses and selecting the best one. */
    candidateCount?: number;
    /** Optional. If enabled, the model will detect emotions and adapt its responses accordingly. For example, if the model detects that the user is frustrated, it may provide a more empathetic response. */
    enableAffectiveDialog?: boolean;
    /** Optional. Penalizes tokens based on their frequency in the generated text. A positive value helps to reduce the repetition of words and phrases. Valid values can range from [-2.0, 2.0]. */
    frequencyPenalty?: number;
    /** Optional. The number of top log probabilities to return for each token. This can be used to see which other tokens were considered likely candidates for a given position. A higher value will return more options, but it will also increase the size of the response. */
    logprobs?: number;
    /** Optional. The maximum number of tokens to generate in the response. A token is approximately four characters. The default value varies by model. This parameter can be used to control the length of the generated text and prevent overly long responses. */
    maxOutputTokens?: number;
    /** Optional. The token resolution at which input media content is sampled. This is used to control the trade-off between the quality of the response and the number of tokens used to represent the media. A higher resolution allows the model to perceive more detail, which can lead to a more nuanced response, but it will also use more tokens. This does not affect the image dimensions sent to the model. */
    mediaResolution?: MediaResolution;
    /** Optional. Penalizes tokens that have already appeared in the generated text. A positive value encourages the model to generate more diverse and less repetitive text. Valid values can range from [-2.0, 2.0]. */
    presencePenalty?: number;
    /** Optional. New response format field for the model to configure output formatting and delivery. */
    responseFormat?: ResponseFormat[];
    /** Optional. If set to true, the log probabilities of the output tokens are returned. Log probabilities are the logarithm of the probability of a token appearing in the output. A higher log probability means the token is more likely to be generated. This can be useful for analyzing the model's confidence in its own output and for debugging. */
    responseLogprobs?: boolean;
    /** Optional. The IANA standard MIME type of the response. The model will generate output that conforms to this MIME type. Supported values include 'text/plain' (default) and 'application/json'. The model needs to be prompted to output the appropriate response type, otherwise the behavior is undefined. Deprecated: Use `response_format` instead. */
    responseMimeType?: string;
    /** Optional. The modalities of the response. The model will generate a response that includes all the specified modalities. For example, if this is set to `[TEXT, IMAGE]`, the response will include both text and an image. */
    responseModalities?: Modality[];
    /** Optional. Lets you to specify a schema for the model's response, ensuring that the output conforms to a particular structure. This is useful for generating structured data such as JSON. The schema is a subset of the [OpenAPI 3.0 schema object](https://spec.openapis.org/oas/v3.0.3#schema) object. When this field is set, you must also set the `response_mime_type` to `application/json`. Deprecated: Use `response_format` instead. */
    responseSchema?: Schema;
    /** Optional. Routing configuration. This field is not supported in Gemini API. */
    routingConfig?: GenerationConfigRoutingConfig;
    /** Optional. A seed for the random number generator. By setting a seed, you can make the model's output mostly deterministic. For a given prompt and parameters (like temperature, top_p, etc.), the model will produce the same response every time. However, it's not a guaranteed absolute deterministic behavior. This is different from parameters like `temperature`, which control the *level* of randomness. `seed` ensures that the "random" choices the model makes are the same on every run, making it essential for testing and ensuring reproducible results. */
    seed?: number;
    /** Optional. The speech generation config. */
    speechConfig?: SpeechConfig;
    /** Optional. A list of character sequences that will stop the model from generating further tokens. If a stop sequence is generated, the output will end at that point. This is useful for controlling the length and structure of the output. For example, you can use ["\n", "###"] to stop generation at a new line or a specific marker. */
    stopSequences?: string[];
    /** Optional. Controls the randomness of the output. A higher temperature results in more creative and diverse responses, while a lower temperature makes the output more predictable and focused. The valid range is (0.0, 2.0]. */
    temperature?: number;
    /** Optional. Configuration for thinking features. An error will be returned if this field is set for models that don't support thinking. */
    thinkingConfig?: ThinkingConfig;
    /** Optional. Specifies the top-k sampling threshold. The model considers only the top k most probable tokens for the next token. This can be useful for generating more coherent and less random text. For example, a `top_k` of 40 means the model will choose the next word from the 40 most likely words. */
    topK?: number;
    /** Optional. Specifies the nucleus sampling threshold. The model considers only the smallest set of tokens whose cumulative probability is at least `top_p`. This helps generate more diverse and less repetitive responses. For example, a `top_p` of 0.9 means the model considers tokens until the cumulative probability of the tokens to select from reaches 0.9. It's recommended to adjust either temperature or `top_p`, but not both. */
    topP?: number;
    /** Optional. Enables enhanced civic answers. It may not be available for all models. This field is not supported in Vertex AI. */
    enableEnhancedCivicAnswers?: boolean;
    /** Optional. Config for translation. */
    translationConfig?: TranslationConfig;
}

/**
 * Configuration parameters for model interactions.
 */
declare type GenerationConfig_2 = {
    /**
     * The configuration for image interaction.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    image_config?: ImageConfig_2 | undefined;
    /**
     * The maximum number of tokens to include in the response.
     */
    max_output_tokens?: number | undefined;
    /**
     * Seed used in decoding for reproducibility.
     */
    seed?: number | undefined;
    /**
     * Optional. Speech and multi-speaker configuration.
     */
    speech_config?: SpeakerConfig | Array<SpeechConfig_2> | undefined;
    /**
     * A list of character sequences that will stop output interaction.
     */
    stop_sequences?: Array<string> | undefined;
    /**
     * Controls the randomness of the output.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    temperature?: number | undefined;
    thinking_level?: ThinkingLevel_2 | undefined;
    thinking_summaries?: ThinkingSummaries | undefined;
    /**
     * The tool choice configuration.
     */
    tool_choice?: ToolChoiceConfig | ToolChoiceType | undefined;
    /**
     * The maximum cumulative probability of tokens to consider when sampling.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    top_p?: number | undefined;
    /**
     * Configuration for speech recognition (transcription).
     */
    transcription_config?: TranscriptionConfig | undefined;
    /**
     * Configuration options for video generation.
     */
    video_config?: VideoConfig | undefined;
};

/** The configuration for routing the request to a specific model. This can be used to control which model is used for the generation, either automatically or by specifying a model name. This data type is not supported in Gemini API. */
export declare interface GenerationConfigRoutingConfig {
    /** In this mode, the model is selected automatically based on the content of the request. */
    autoMode?: GenerationConfigRoutingConfigAutoRoutingMode;
    /** In this mode, the model is specified manually. */
    manualMode?: GenerationConfigRoutingConfigManualRoutingMode;
}

/** The configuration for automated routing. When automated routing is specified, the routing will be determined by the pretrained routing model and customer provided model routing preference. This data type is not supported in Gemini API. */
export declare interface GenerationConfigRoutingConfigAutoRoutingMode {
    /** The model routing preference. */
    modelRoutingPreference?: 'UNKNOWN' | 'PRIORITIZE_QUALITY' | 'BALANCED' | 'PRIORITIZE_COST';
}

/** The configuration for manual routing. When manual routing is specified, the model will be selected based on the model name provided. This data type is not supported in Gemini API. */
export declare interface GenerationConfigRoutingConfigManualRoutingMode {
    /** The name of the model to use. Only public LLM models are accepted. */
    modelName?: string;
}

/**
 * Config for thinking feature.
 *
 * @deprecated This interface will be deprecated. Please use `ThinkingConfig` instead.
 */
export declare interface GenerationConfigThinkingConfig extends ThinkingConfig {
}

/** Configuration for persisting output assets to external storage. */
export declare interface GenerationOutputConfig {
    /** Optional. The Cloud Storage URI prefix or directory where
     generated media assets should be written (e.g. "gs://my-bucket/prefix/").
     Supported URI schemes: "gs://". When set, media bytes are written directly
     to this location and returned as FileData with a file_uri instead of raw
     inline bytes.
     */
    outputUriPrefix?: string;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GetAgentGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetAgentParams = Omit<GetAgentRequest, "id">;

declare type GetAgentRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The name of the agent to retrieve.
     */
    id: string;
};

/** Optional parameters. */
export declare interface GetBatchJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Config for batches.get parameters. */
export declare interface GetBatchJobParameters {
    /** A fully-qualified BatchJob resource name or ID.
     Example: "projects/.../locations/.../batchPredictionJobs/456"
     or "456" when project and location are initialized in the client.
     */
    name: string;
    /** Optional parameters for the request. */
    config?: GetBatchJobConfig;
}

/** Optional parameters for caches.get method. */
export declare interface GetCachedContentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for caches.get method. */
export declare interface GetCachedContentParameters {
    /** The server-generated resource name of the cached content.
     */
    name: string;
    /** Optional parameters for the request.
     */
    config?: GetCachedContentConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GetCredentialGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetCredentialParams = Omit<GetCredentialRequest, "id">;

declare type GetCredentialRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource ID segment making up resource `name`. It identifies the resource
     *
     * @remarks
     * within its parent collection as described in https://google.aip.dev/122.
     */
    id: string;
};

/** Optional Config. */
export declare interface GetDocumentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for documents.get. */
export declare interface GetDocumentParameters {
    /** The resource name of the Document.
     Example: fileSearchStores/file-search-store-foo/documents/documents-bar */
    name: string;
    /** Optional parameters for the request. */
    config?: GetDocumentConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GetEnvironmentFilesGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetEnvironmentFilesParams = Omit<GetEnvironmentFilesRequest, "environment" | "path">;

declare type GetEnvironmentFilesRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * The ID of the environment whose snapshot to read.
     */
    environment: string;
    /**
     * Path of the file or directory inside the environment workspace, relative to its root (e.g. src).
     */
    path: string;
    /**
     * Optional. Maximum number of entries to return per page (for directory listing).
     */
    page_size?: number | undefined;
    /**
     * Optional. Pagination token for directory listing.
     */
    page_token?: string | undefined;
    /**
     * Optional. If true and the path is a directory, recursively lists all files.
     */
    recursive?: boolean | undefined;
};

declare type GetEnvironmentFilesResponse$ = GetEnvironmentFilesResponse;

/**
 * Response for `GetEnvironmentFiles`.
 */
declare type GetEnvironmentFilesResponse = {
    /**
     * If the requested path is a directory, this contains its contents.
     *
     * @remarks
     * If the requested path is a file, this contains a single entry with the
     * file's metadata.
     * If alt=media was specified, this is empty (content is served via `blob`).
     */
    files?: Array<EnvironmentFile> | undefined;
    /**
     * Pagination token for directory listing.
     *
     * @remarks
     * NOLINT
     */
    next_page_token?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GetEnvironmentGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetEnvironmentParams = Omit<GetEnvironmentRequest, "id">;

declare type GetEnvironmentRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource ID segment making up resource `name`. It identifies the resource
     *
     * @remarks
     * within its parent collection as described in https://google.aip.dev/122.
     */
    id: string;
};

/** Used to override the default configuration. */
export declare interface GetFileConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Generates the parameters for the get method. */
export declare interface GetFileParameters {
    /** The name identifier for the file to retrieve. */
    name: string;
    /** Used to override the default configuration. */
    config?: GetFileConfig;
}

/** Optional parameters for getting a FileSearchStore. */
export declare interface GetFileSearchStoreConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Config for file_search_stores.get parameters. */
export declare interface GetFileSearchStoreParameters {
    /** The resource name of the FileSearchStore. Example: `fileSearchStores/my-file-search-store-123` */
    name: string;
    /** Optional parameters for the request. */
    config?: GetFileSearchStoreConfig;
}

declare type GetInteractionByIdGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetInteractionByIdParams = Omit<GetInteractionByIdRequest, "id">;

declare type GetInteractionByIdParamsNonStreaming = GetInteractionByIdParams & {
    stream?: false | undefined;
};

declare type GetInteractionByIdParamsStreaming = GetInteractionByIdParams & {
    stream: true;
};

declare type GetInteractionByIdRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * If true, includes the input in the response.
     */
    include_input?: boolean | undefined;
    /**
     * Required. The name of the interaction to retrieve.
     */
    id: string;
    /**
     * If set, resumes the interaction stream from the chunk after the event
     *
     * @remarks
     * marked by the event id. Can only be used if `stream` is true.
     */
    last_event_id?: string | undefined;
    /**
     * If true, streams the interaction events as Server-Sent Events.
     */
    stream?: boolean | undefined;
};

declare type GetInteractionByIdResponse = interactions.Interaction | Stream<interactions.InteractionSSEEvent>;

/** Optional parameters for models.get method. */
export declare interface GetModelConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

export declare interface GetModelParameters {
    model: string;
    /** Optional parameters for the request. */
    config?: GetModelConfig;
}

export declare interface GetOperationConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for the GET method. */
export declare interface GetOperationParameters {
    /** The server-assigned name for the operation. */
    operationName: string;
    /** Used to override the default configuration. */
    config?: GetOperationConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GetTriggerGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetTriggerParams = Omit<GetTriggerRequest, "id">;

declare type GetTriggerRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource name of the trigger.
     */
    id: string;
};

/** Optional parameters for tunings.get method. */
export declare interface GetTuningJobConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for the get method. */
export declare interface GetTuningJobParameters {
    name: string;
    /** Optional parameters for the request. */
    config?: GetTuningJobConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GetVoiceGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetVoiceParams = Omit<GetVoiceRequest, "id">;

declare type GetVoiceRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The resource name of the custom stored voice to retrieve
     *
     * @remarks
     * (for example, `voices/voice_abc123def456`).
     */
    id: string;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GetWebhookGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type GetWebhookParams = Omit<GetWebhookRequest, "id">;

declare type GetWebhookRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The ID of the webhook to retrieve.
     */
    id: string;
};

/**
 * The Google GenAI SDK.
 *
 * @remarks
 * Provides access to the GenAI features through either the {@link https://cloud.google.com/vertex-ai/docs/reference/rest | Gemini API}
 * or the {@link https://cloud.google.com/vertex-ai/docs/reference/rest | Vertex AI API}.
 *
 * The {@link GoogleGenAIOptions.vertexai} value determines which of the API services to use.
 *
 * When using the Gemini API, a {@link GoogleGenAIOptions.apiKey} must also be set,
 * when using Vertex AI {@link GoogleGenAIOptions.project} and {@link GoogleGenAIOptions.location} must also be set.
 *
 * @example
 * Initializing the SDK for using the Gemini API:
 * ```ts
 * import {GoogleGenAI} from '@google/genai';
 * const ai = new GoogleGenAI({apiKey: 'GEMINI_API_KEY'});
 * ```
 *
 * @example
 * Initializing the SDK for using the Vertex AI API:
 * ```ts
 * import {GoogleGenAI} from '@google/genai';
 * const ai = new GoogleGenAI({
 *   vertexai: true,
 *   project: 'PROJECT_ID',
 *   location: 'PROJECT_LOCATION'
 * });
 * ```
 *
 */
export declare class GoogleGenAI {
    protected readonly apiClient: ApiClient;
    private readonly apiKey?;
    readonly vertexai: boolean;
    private readonly apiVersion?;
    private readonly httpOptions?;
    readonly models: Models;
    readonly live: Live;
    readonly batches: Batches;
    readonly chats: Chats;
    readonly caches: Caches;
    readonly files: Files;
    readonly operations: Operations;
    readonly authTokens: Tokens;
    readonly tunings: Tunings;
    readonly fileSearchStores: FileSearchStores;
    private _interactions;
    private _webhooks;
    private _agents;
    private _environments;
    private _credentials;
    private _voices;
    private _nextGenClient;
    private _triggers;
    private getNextGenClient;
    get interactions(): GeminiNextGenInteractions;
    get webhooks(): GeminiNextGenWebhooks;
    get agents(): GeminiNextGenAgents;
    get triggers(): GeminiNextGenTriggers;
    get environments(): GeminiNextGenEnvironments;
    get credentials(): GeminiNextGenCredentials;
    get voices(): GeminiNextGenVoices;
    constructor(options?: GoogleGenAIOptions);
}

declare class GoogleGenAI_2 extends ClientSDK {
    private _environments?;
    get environments(): Environments_2;
    private _agents?;
    get agents(): Agents_2;
    private _credentials?;
    get credentials(): Credentials_2;
    private _interactions?;
    get interactions(): Interactions_2;
    private _triggers?;
    get triggers(): Triggers_2;
    private _voices?;
    get voices(): Voices_2;
    private _webhooks?;
    get webhooks(): Webhooks_2;
}

export declare type GoogleGenAIInteraction = GoogleGenAIResponseWithSdkHttpResponse<Omit<Interactions.Interaction, "steps"> & {
    steps: Interactions.Step[];
}>;

/**
 * Google Gen AI SDK's configuration options.
 *
 * See {@link GoogleGenAI} for usage samples.
 */
export declare interface GoogleGenAIOptions {
    /**
     * Optional. Determines whether to use the Vertex AI or the Gemini API.
     *
     * @remarks
     * When true, the {@link https://cloud.google.com/vertex-ai/docs/reference/rest | Gemini Enterprise Agent Platform API} will used.
     * When false, the {@link https://ai.google.dev/api | Gemini API} will be used.
     * When both enterprise and vertexai are set, and they have different values,
     * an Error will be thrown.
     *
     * If unset, default SDK behavior is to use the Gemini API service.
     */
    enterprise?: boolean;
    /**
     * Optional. Determines whether to use the Vertex AI (now Gemini Enterprise Agent Platform) or the Gemini API.
     * The `enterprise` flag is recommended instead.
     *
     * @remarks
     * When true, the {@link https://cloud.google.com/vertex-ai/docs/reference/rest | Vertex AI API} will used.
     * When false, the {@link https://ai.google.dev/api | Gemini API} will be used.
     * When both enterprise and vertexai are set, and they have different values,
     * an Error will be thrown.
     *
     * If unset, default SDK behavior is to use the Gemini API service.
     */
    vertexai?: boolean;
    /**
     * Optional. The Google Cloud project ID for Vertex AI clients.
     *
     * Find your project ID: https://cloud.google.com/resource-manager/docs/creating-managing-projects#identifying_projects
     *
     * @remarks
     * Only supported on Node runtimes, ignored on browser runtimes.
     */
    project?: string;
    /**
     * Optional. The Google Cloud project {@link https://cloud.google.com/vertex-ai/generative-ai/docs/learn/locations | location} for Vertex AI clients.
     *
     * @remarks
     * Only supported on Node runtimes, ignored on browser runtimes.
     *
     */
    location?: string;
    /**
     * The API Key, required for Gemini API clients.
     *
     * @remarks
     * Required on browser runtimes.
     */
    apiKey?: string;
    /**
     * Optional. The API version to use.
     *
     * @remarks
     * If unset, the default API version will be used.
     */
    apiVersion?: string;
    /**
     * Optional. Authentication options defined by the by google-auth-library for Vertex AI clients.
     *
     * @remarks
     * @see {@link https://github.com/googleapis/google-auth-library-nodejs/blob/v9.15.0/src/auth/googleauth.ts | GoogleAuthOptions interface in google-auth-library-nodejs}.
     *
     * Only supported on Node runtimes, ignored on browser runtimes.
     *
     */
    googleAuthOptions?: GoogleAuthOptions;
    /**
     * Optional. A set of customizable configuration for HTTP requests.
     */
    httpOptions?: HttpOptions;
}

declare interface GoogleGenAIParentClient {
    isVertexAI(): boolean;
    getProject(): string | undefined;
    getLocation(): string | undefined;
    getBaseUrl(): string;
    getApiVersion(): string;
    getDefaultHeaders?(): Record<string, string>;
    getHeaders?(): Record<string, string> | undefined;
    getAuthHeaders(url?: string): Headers | Promise<Headers>;
    getFetch?(): Fetcher | undefined;
    getTimeout?(): number | undefined;
}

export declare type GoogleGenAIRequestOptions = {
    /**
     * Sets a timeout, in milliseconds, on HTTP requests made by an SDK method. If
     * `fetchOptions.signal` is set then it will take precedence over this option.
     *
     * For `interactions.create()` with automatic continuation enabled (the
     * default), this bounds the whole call across continuation hops: each hop is
     * sent with the time left, and once it runs out the call stops with a
     * `ContinuationInterruptedError`. See `AutomaticContinuationOption`.
     */
    timeout_ms?: number;
    /**
     * Set or override a retry policy on HTTP calls.
     */
    retries?: RetryConfig;
    /**
     * Specifies the status codes which should be retried using the given retry policy.
     */
    retry_codes?: string[];
    /**
     * Overrides the base server URL that will be used by an operation.
     */
    server_url?: string | URL;
    /**
     * @deprecated `fetchOptions` has been flattened into `GoogleGenAIRequestOptions`.
     *
     * Sets various request options on the `fetch` call made by an SDK method.
     *
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options|Request}
     */
    fetch_options?: Omit<RequestInit, "method" | "body">;
    /**
     * Additional query parameters to set on the request URL. Entries replace
     * any query parameters of the same name produced by the operation. Entries
     * with null or undefined values are skipped, array values are encoded as
     * repeated keys and plain object values are JSON-encoded.
     */
    extra_query?: Record<string, unknown>;
    /**
     * Additional fields to merge into the JSON object request body. Entries
     * replace any fields of the same name produced by the operation. Entries
     * with undefined values are skipped. Setting this option on an operation
     * whose request body is not a JSON object results in an error.
     */
    extra_body?: Record<string, unknown>;
    timeout?: number;
    maxRetries?: number;
    defaultBaseURL?: string;
    fetchOptions?: Omit<RequestInit, "method" | "body">;
    query?: unknown;
    body?: unknown;
} & Omit<RequestInit, "method" | "body">;

export declare type GoogleGenAIResponseWithSdkHttpResponse<T> = T & {
    sdkHttpResponse?: GoogleGenAISdkHttpResponse;
};

export declare type GoogleGenAISdkHttpResponse = {
    headers?: Record<string, string>;
    responseInternal: Response;
    json(): Promise<unknown>;
};

declare type GoogleMaps$ = GoogleMaps_2;

/** Tool to retrieve knowledge from Google Maps. */
export declare interface GoogleMaps {
    /** The authentication config to access the API. Only API key is supported. This field is not supported in Gemini API. */
    authConfig?: AuthConfig;
    /** Deprecated. The Google Maps contextual widget behavior in Grounding with Google Maps is being deprecated; this field is planned for removal and no longer has any effect once removed. Optional. Whether to return a widget context token in the GroundingMetadata of the response. */
    enableWidget?: boolean;
    /** Optional. Specifies the types of Google Maps grounding to enable. Defaults to `places` when unset. This field is not supported in Gemini API. */
    groundingTypes?: GoogleMapsGroundingTypes;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A tool that can be used by the model to call Google Maps.
 */
declare type GoogleMaps_2 = {
    /**
     * Whether to return a widget context token in the tool call result of the
     *
     * @remarks
     * response.
     */
    enable_widget?: boolean | undefined;
    /**
     * The latitude of the user's location.
     */
    latitude?: number | undefined;
    /**
     * The longitude of the user's location.
     */
    longitude?: number | undefined;
    type: "google_maps";
};

declare type GoogleMapsCall$ = GoogleMapsCallDelta;

declare type GoogleMapsCallArguments$ = GoogleMapsCallArguments;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The arguments to pass to the Google Maps tool.
 */
declare type GoogleMapsCallArguments = {
    /**
     * The queries to be executed.
     */
    queries?: Array<string> | undefined;
};

declare type GoogleMapsCallDelta = {
    /**
     * The arguments to pass to the Google Maps tool.
     */
    arguments?: GoogleMapsCallArguments | undefined;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_maps_call";
};

declare type GoogleMapsCallStep$ = GoogleMapsCallStep;

/**
 * Google Maps call step.
 */
declare type GoogleMapsCallStep = {
    /**
     * The arguments to pass to the Google Maps tool.
     */
    arguments?: GoogleMapsCallArguments | undefined;
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_maps_call";
};

/** Defines the types of Google Maps grounding that can be enabled and their configurations. This data type is not supported in Gemini API. */
export declare interface GoogleMapsGroundingTypes {
    /** Optional. Enables grounding with Google Maps Places. This is the default grounding type when no `GroundingTypes` are specified. */
    places?: GoogleMapsPlaces;
    /** Optional. Enables grounding with Google Maps Routing APIs (ComputeRoutes and SearchAlongRoute). */
    routing?: GoogleMapsRouting;
}

/** Grounding with Google Maps Places data (e.g. QueryPlaces). This is the default Google Maps grounding type when no other type is specified. This data type is not supported in Gemini API. */
export declare interface GoogleMapsPlaces {
}

declare type GoogleMapsResult$ = GoogleMapsResult;

declare type GoogleMapsResult$2 = GoogleMapsResultDelta;

/**
 * The result of the Google Maps.
 */
declare type GoogleMapsResult = {
    places?: Array<GoogleMapsResultPlaces> | undefined;
    widget_context_token?: string | undefined;
};

declare type GoogleMapsResultDelta = {
    /**
     * The results of the Google Maps.
     */
    result?: Array<GoogleMapsResult> | undefined;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_maps_result";
};

declare type GoogleMapsResultPlaces = {
    name?: string | undefined;
    place_id?: string | undefined;
    review_snippets?: Array<ReviewSnippet> | undefined;
    url?: string | undefined;
};

declare type GoogleMapsResultStep$ = GoogleMapsResultStep;

/**
 * Google Maps result step.
 */
declare type GoogleMapsResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    result: Array<GoogleMapsResult>;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_maps_result";
};

/** Grounding with Google Maps Routing APIs (ComputeRoutes and SearchAlongRoute). This data type is not supported in Gemini API. */
export declare interface GoogleMapsRouting {
}

/** The `Status` type defines a logical error model that is suitable for different programming environments, including REST APIs and RPC APIs. It is used by [gRPC](https://github.com/grpc). Each `Status` message contains three pieces of data: error code, error message, and error details. You can find out more about this error model and how to work with it in the [API Design Guide](https://cloud.google.com/apis/design/errors). This data type is not supported in Gemini API. */
export declare interface GoogleRpcStatus {
    /** The status code, which should be an enum value of google.rpc.Code. */
    code?: number;
    /** A list of messages that carry the error details. There is a common set of message types for APIs to use. */
    details?: Record<string, unknown>[];
    /** A developer-facing error message, which should be in English. Any user-facing error message should be localized and sent in the google.rpc.Status.details field, or localized by the client. */
    message?: string;
}

declare type GoogleSearch$ = GoogleSearch_2;

/** GoogleSearch tool type. Tool to support Google Search in Model. Powered by Google. */
export declare interface GoogleSearch {
    /** Optional. Sites with confidence level chosen & above this value will be blocked from the search results. This field is not supported in Gemini API. */
    blockingConfidence?: PhishBlockThreshold;
    /** Optional. List of domains to be excluded from the search results. The default limit is 2000 domains. Example: ["amazon.com", "facebook.com"]. This field is not supported in Gemini API. */
    excludeDomains?: string[];
    /** Optional. The set of search types to enable. If not set, web search is enabled by default. */
    searchTypes?: SearchTypes;
    /** Optional. Filter search results to a specific time range. If customers set a start time, they must set an end time (and vice versa). This field is not supported in Vertex AI. */
    timeRangeFilter?: Interval;
}

/**
 * A tool that can be used by the model to search Google.
 */
declare type GoogleSearch_2 = {
    /**
     * The types of search grounding to enable.
     */
    search_types?: Array<GoogleSearchSearchType> | undefined;
    type: "google_search";
};

declare type GoogleSearchCall$ = GoogleSearchCallDelta;

declare type GoogleSearchCallArguments$ = GoogleSearchCallArguments;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The arguments to pass to Google Search.
 */
declare type GoogleSearchCallArguments = {
    /**
     * Web search queries for the following-up web search.
     */
    queries?: Array<string> | undefined;
};

declare type GoogleSearchCallDelta = {
    /**
     * The arguments to pass to Google Search.
     */
    arguments: GoogleSearchCallArguments;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_search_call";
};

declare type GoogleSearchCallStep$ = GoogleSearchCallStep;

/**
 * Google Search call step.
 */
declare type GoogleSearchCallStep = {
    /**
     * The arguments to pass to Google Search.
     */
    arguments: GoogleSearchCallArguments;
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * The type of search grounding enabled.
     */
    search_type?: GoogleSearchCallStepSearchType | undefined;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_search_call";
};

/**
 * The type of search grounding enabled.
 */
declare type GoogleSearchCallStepSearchType = "web_search" | "image_search" | "enterprise_web_search" | (string & {});

declare type GoogleSearchResult$ = GoogleSearchResult;

declare type GoogleSearchResult$2 = GoogleSearchResultDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The result of the Google Search.
 */
declare type GoogleSearchResult = {
    /**
     * Web content snippet that can be embedded in a web page or an app webview.
     */
    search_suggestions?: string | undefined;
};

declare type GoogleSearchResultDelta = {
    is_error?: boolean | undefined;
    result: Array<GoogleSearchResult>;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_search_result";
};

declare type GoogleSearchResultStep$ = GoogleSearchResultStep;

/**
 * Google Search result step.
 */
declare type GoogleSearchResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * Whether the Google Search resulted in an error.
     */
    is_error?: boolean | undefined;
    /**
     * Required. The results of the Google Search.
     */
    result: Array<GoogleSearchResult>;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "google_search_result";
};

/** Tool to retrieve public web data for grounding, powered by Google. */
export declare interface GoogleSearchRetrieval {
    /** Specifies the dynamic retrieval configuration for the given source. */
    dynamicRetrievalConfig?: DynamicRetrievalConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type GoogleSearchSearchType = "web_search" | "image_search" | "enterprise_web_search" | (string & {});

/** Represents a whole or partial calendar date, such as a birthday. The time of day and time zone are either specified elsewhere or are insignificant. The date is relative to the Gregorian Calendar. This can represent one of the following: * A full date, with non-zero year, month, and day values. * A month and day, with a zero year (for example, an anniversary). * A year on its own, with a zero month and a zero day. * A year and month, with a zero day (for example, a credit card expiration date). Related types: * google.type.TimeOfDay * google.type.DateTime * google.protobuf.Timestamp. This data type is not supported in Gemini API. */
export declare interface GoogleTypeDate {
    /** Day of a month. Must be from 1 to 31 and valid for the year and month, or 0 to specify a year by itself or a year and month where the day isn't significant. */
    day?: number;
    /** Month of a year. Must be from 1 to 12, or 0 to specify a year without a month and day. */
    month?: number;
    /** Year of the date. Must be from 1 to 9999, or 0 to specify a date without a year. */
    year?: number;
}

/** A piece of evidence that supports a claim made by the model.

 This is used to show a citation for a claim made by the model. When grounding
 is enabled, the model returns a `GroundingChunk` that contains a reference to
 the source of the information. */
export declare interface GroundingChunk {
    /** A `Maps` chunk is a piece of evidence that comes from Google Maps.

     It contains information about a place, such as its name, address, and
     reviews. This is used to provide the user with rich, location-based
     information. */
    maps?: GroundingChunkMaps;
    /** A grounding chunk from an image search result. See the `Image` message for details. */
    image?: GroundingChunkImage;
    /** A grounding chunk from a data source retrieved by a retrieval tool, such as Vertex AI Search. See the `RetrievedContext` message for details */
    retrievedContext?: GroundingChunkRetrievedContext;
    /** A grounding chunk from a web page, typically from Google Search. See the `Web` message for details. */
    web?: GroundingChunkWeb;
}

/** User provided metadata about the GroundingFact. This data type is not supported in Vertex AI. */
export declare interface GroundingChunkCustomMetadata {
    /** The key of the metadata. */
    key?: string;
    /** Optional. The numeric value of the metadata. The expected range for this value depends on the specific `key` used. */
    numericValue?: number;
    /** Optional. A list of string values for the metadata. */
    stringListValue?: GroundingChunkStringList;
    /** Optional. The string value of the metadata. */
    stringValue?: string;
}

/** An `Image` chunk is a piece of evidence that comes from an image search result. It contains the URI of the image search result and the URI of the image. This is used to provide the user with a link to the source of the information. */
export declare interface GroundingChunkImage {
    /** The domain of the image search result page. */
    domain?: string;
    /** The URI of the image. */
    imageUri?: string;
    /** The URI of the image search result page. */
    sourceUri?: string;
    /** The title of the image search result page. */
    title?: string;
}

/** A `Maps` chunk is a piece of evidence that comes from Google Maps.

 It contains information about a place, such as its name, address, and reviews.
 This is used to provide the user with rich, location-based information. */
export declare interface GroundingChunkMaps {
    /** The sources that were used to generate the place answer.

     This includes review snippets and photos that were used to generate the
     answer, as well as URIs to flag content. */
    placeAnswerSources?: GroundingChunkMapsPlaceAnswerSources;
    /** This Place's resource name, in `places/{place_id}` format.

     This can be used to look up the place in the Google Maps API. */
    placeId?: string;
    /** The text of the place answer. */
    text?: string;
    /** The title of the place. */
    title?: string;
    /** The URI of the place. */
    uri?: string;
    /** Output only. Route information. */
    route?: GroundingChunkMapsRoute;
}

/** The sources that were used to generate the place answer.

 This includes review snippets and photos that were used to generate the
 answer, as well as URIs to flag content. */
export declare interface GroundingChunkMapsPlaceAnswerSources {
    /** Snippets of reviews that were used to generate the answer. */
    reviewSnippet?: GroundingChunkMapsPlaceAnswerSourcesReviewSnippet[];
    /** A link where users can flag a problem with the generated answer. */
    flagContentUri?: string;
    /** Snippets of reviews that were used to generate the answer. */
    reviewSnippets?: GroundingChunkMapsPlaceAnswerSourcesReviewSnippet[];
}

/** Author attribution for a photo or review. */
export declare interface GroundingChunkMapsPlaceAnswerSourcesAuthorAttribution {
    /** Name of the author of the Photo or Review. */
    displayName?: string;
    /** Profile photo URI of the author of the Photo or Review. */
    photoUri?: string;
    /** URI of the author of the Photo or Review. */
    uri?: string;
}

/** Encapsulates a review snippet. */
export declare interface GroundingChunkMapsPlaceAnswerSourcesReviewSnippet {
    /** This review's author. */
    authorAttribution?: GroundingChunkMapsPlaceAnswerSourcesAuthorAttribution;
    /** A link where users can flag a problem with the review. */
    flagContentUri?: string;
    /** A link to show the review on Google Maps. */
    googleMapsUri?: string;
    /** A string of formatted recent time, expressing the review time relative to the current time in a form appropriate for the language and country. */
    relativePublishTimeDescription?: string;
    /** A reference representing this place review which may be used to look up this place review again. */
    review?: string;
    /** Id of the review referencing the place. */
    reviewId?: string;
    /** Title of the review. */
    title?: string;
}

/** Route information from Google Maps. This data type is not supported in Gemini API. */
export declare interface GroundingChunkMapsRoute {
    /** The total distance of the route, in meters. */
    distanceMeters?: number;
    /** The total duration of the route. */
    duration?: string;
    /** An encoded polyline of the route. See https://developers.google.com/maps/documentation/utilities/polylinealgorithm */
    encodedPolyline?: string;
}

/** Context retrieved from a data source to ground the model's response. This is used when a retrieval tool fetches information from a user-provided corpus or a public dataset. */
export declare interface GroundingChunkRetrievedContext {
    /** Output only. The full resource name of the referenced Vertex AI Search document. This is used to identify the specific document that was retrieved. The format is `projects/{project}/locations/{location}/collections/{collection}/dataStores/{data_store}/branches/{branch}/documents/{document}`. This field is not supported in Gemini API. */
    documentName?: string;
    /** Additional context for a Retrieval-Augmented Generation (RAG) retrieval result. This is populated only when the RAG retrieval tool is used. This field is not supported in Gemini API. */
    ragChunk?: RagChunk;
    /** The content of the retrieved data source. */
    text?: string;
    /** The title of the retrieved data source. */
    title?: string;
    /** The URI of the retrieved data source. */
    uri?: string;
    /** Optional. User-provided metadata about the retrieved context. This field is not supported in Vertex AI. */
    customMetadata?: GroundingChunkCustomMetadata[];
    /** Optional. Name of the `FileSearchStore` containing the document. Example: `fileSearchStores/123`. This field is not supported in Vertex AI. */
    fileSearchStore?: string;
    /** Optional. The media blob resource name for multimodal file search results. Format: fileSearchStores/{file_search_store_id}/media/{blob_id}. This field is not supported in Vertex AI. */
    mediaId?: string;
    /** Optional. Page number of the retrieved context, if applicable. This field is not supported in Vertex AI. */
    pageNumber?: number;
}

/** A list of string values. This data type is not supported in Vertex AI. */
export declare interface GroundingChunkStringList {
    /** The string values of the list. */
    values?: string[];
}

/** A `Web` chunk is a piece of evidence that comes from a web page. It contains the URI of the web page, the title of the page, and the domain of the page. This is used to provide the user with a link to the source of the information. */
export declare interface GroundingChunkWeb {
    /** The domain of the web page that contains the evidence. This can be used to filter out low-quality sources. This field is not supported in Gemini API. */
    domain?: string;
    /** The title of the web page that contains the evidence. */
    title?: string;
    /** The URI of the web page that contains the evidence. */
    uri?: string;
}

/** Information for various kinds of grounding. */
export declare interface GroundingMetadata {
    /** A list of supporting references retrieved from the grounding
     source. This field is populated when the grounding source is Google
     Search, Vertex AI Search, or Google Maps.
     */
    groundingChunks?: GroundingChunk[];
    /** List of grounding support. */
    groundingSupports?: GroundingSupport[];
    /** Metadata related to retrieval in the grounding flow. */
    retrievalMetadata?: RetrievalMetadata;
    /** Optional. Google search entry for the following-up web
     searches. */
    searchEntryPoint?: SearchEntryPoint;
    /** Web search queries for the following-up web search. */
    webSearchQueries?: string[];
    /** Optional. Output only. Deprecated: The Google Maps contextual widget behavior in Grounding with Google Maps is being deprecated; this field is planned for removal and will no longer be populated once removed. A token that can be used to render a Google Maps widget with the contextual data. This field is populated only when the grounding source is Google Maps. */
    googleMapsWidgetContextToken?: string;
    /** Optional. The image search queries that were used to generate the content. This field is populated only when the grounding source is Google Search with the Image Search search_type enabled. */
    imageSearchQueries?: string[];
    /** Optional. The queries that were executed by the retrieval tools. This field is populated only when the grounding source is a retrieval tool, such as Vertex AI Search. This field is not supported in Gemini API. */
    retrievalQueries?: string[];
    /** Optional. Output only. A list of URIs that can be used to flag a place or review for inappropriate content. This field is populated only when the grounding source is Google Maps. This field is not supported in Gemini API. */
    sourceFlaggingUris?: GroundingMetadataSourceFlaggingUri[];
}

/** A URI that can be used to flag a place or review for inappropriate content. This is populated only when the grounding source is Google Maps. This data type is not supported in Gemini API. */
export declare interface GroundingMetadataSourceFlaggingUri {
    /** The URI that can be used to flag the content. */
    flagContentUri?: string;
    /** The ID of the place or review. */
    sourceId?: string;
}

/** Grounding support. */
export declare interface GroundingSupport {
    /** Confidence score of the support references.

     Ranges from 0 to 1. 1 is the most confident. This list must have the
     same size as the grounding_chunk_indices. */
    confidenceScores?: number[];
    /** A list of indices (into 'grounding_chunk') specifying the
     citations associated with the claim. For instance [1,3,4] means that
     grounding_chunk[1], grounding_chunk[3], grounding_chunk[4] are the
     retrieved content attributed to the claim. */
    groundingChunkIndices?: number[];
    /** Segment of the content this support belongs to. */
    segment?: Segment;
    /** Indices into the `rendered_parts` field of the `GroundingMetadata` message. These indices specify which rendered parts are associated with this support message. */
    renderedParts?: number[];
}

declare type GroundingToolCount$ = GroundingToolCount;

/**
 * The number of grounding tool counts.
 */
declare type GroundingToolCount = {
    /**
     * The number of grounding tool counts.
     */
    count?: number | undefined;
    /**
     * The grounding tool type associated with the count.
     */
    type?: GroundingToolCountType | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The grounding tool type associated with the count.
 */
declare type GroundingToolCountType = "google_search" | "google_maps" | "retrieval" | (string & {});

/** The method for blocking content. If not specified, the default behavior is to use the probability score. This enum is not supported in Gemini API. */
export declare enum HarmBlockMethod {
    /**
     * The harm block method is unspecified.
     */
    HARM_BLOCK_METHOD_UNSPECIFIED = "HARM_BLOCK_METHOD_UNSPECIFIED",
    /**
     * The harm block method uses both probability and severity scores.
     */
    SEVERITY = "SEVERITY",
    /**
     * The harm block method uses the probability score.
     */
    PROBABILITY = "PROBABILITY"
}

/** The threshold for blocking content. If the harm probability exceeds this threshold, the content will be blocked. */
export declare enum HarmBlockThreshold {
    /**
     * The harm block threshold is unspecified.
     */
    HARM_BLOCK_THRESHOLD_UNSPECIFIED = "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
    /**
     * Block content with a low harm probability or higher.
     */
    BLOCK_LOW_AND_ABOVE = "BLOCK_LOW_AND_ABOVE",
    /**
     * Block content with a medium harm probability or higher.
     */
    BLOCK_MEDIUM_AND_ABOVE = "BLOCK_MEDIUM_AND_ABOVE",
    /**
     * Block content with a high harm probability.
     */
    BLOCK_ONLY_HIGH = "BLOCK_ONLY_HIGH",
    /**
     * Do not block any content, regardless of its harm probability.
     */
    BLOCK_NONE = "BLOCK_NONE",
    /**
     * Turn off the safety filter entirely.
     */
    OFF = "OFF"
}

declare type HarmCategory$ = HarmCategory_2;

/** The harm category to be blocked. */
export declare enum HarmCategory {
    /**
     * Default value. This value is unused.
     */
    HARM_CATEGORY_UNSPECIFIED = "HARM_CATEGORY_UNSPECIFIED",
    /**
     * Abusive, threatening, or content intended to bully, torment, or ridicule.
     */
    HARM_CATEGORY_HARASSMENT = "HARM_CATEGORY_HARASSMENT",
    /**
     * Content that promotes violence or incites hatred against individuals or groups based on certain attributes.
     */
    HARM_CATEGORY_HATE_SPEECH = "HARM_CATEGORY_HATE_SPEECH",
    /**
     * Content that contains sexually explicit material.
     */
    HARM_CATEGORY_SEXUALLY_EXPLICIT = "HARM_CATEGORY_SEXUALLY_EXPLICIT",
    /**
     * Content that promotes, facilitates, or enables dangerous activities.
     */
    HARM_CATEGORY_DANGEROUS_CONTENT = "HARM_CATEGORY_DANGEROUS_CONTENT",
    /**
     * Deprecated: Election filter is not longer supported. The harm category is civic integrity.
     */
    HARM_CATEGORY_CIVIC_INTEGRITY = "HARM_CATEGORY_CIVIC_INTEGRITY",
    /**
     * Prompts designed to bypass safety filters.
     */
    HARM_CATEGORY_JAILBREAK = "HARM_CATEGORY_JAILBREAK",
    /**
     * Images that contain hate speech. This enum value is not supported in Gemini API.
     */
    HARM_CATEGORY_IMAGE_HATE = "HARM_CATEGORY_IMAGE_HATE",
    /**
     * Images that contain dangerous content. This enum value is not supported in Gemini API.
     */
    HARM_CATEGORY_IMAGE_DANGEROUS_CONTENT = "HARM_CATEGORY_IMAGE_DANGEROUS_CONTENT",
    /**
     * Images that contain harassment. This enum value is not supported in Gemini API.
     */
    HARM_CATEGORY_IMAGE_HARASSMENT = "HARM_CATEGORY_IMAGE_HARASSMENT",
    /**
     * Images that contain sexually explicit content. This enum value is not supported in Gemini API.
     */
    HARM_CATEGORY_IMAGE_SEXUALLY_EXPLICIT = "HARM_CATEGORY_IMAGE_SEXUALLY_EXPLICIT"
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type HarmCategory_2 = "hate_speech" | "dangerous_content" | "harassment" | "sexually_explicit" | "civic_integrity" | "image_hate" | "image_dangerous_content" | "image_harassment" | "image_sexually_explicit" | "jailbreak" | (string & {});

/** Output only. The probability of harm for this category. */
export declare enum HarmProbability {
    /**
     * The harm probability is unspecified.
     */
    HARM_PROBABILITY_UNSPECIFIED = "HARM_PROBABILITY_UNSPECIFIED",
    /**
     * The harm probability is negligible.
     */
    NEGLIGIBLE = "NEGLIGIBLE",
    /**
     * The harm probability is low.
     */
    LOW = "LOW",
    /**
     * The harm probability is medium.
     */
    MEDIUM = "MEDIUM",
    /**
     * The harm probability is high.
     */
    HIGH = "HIGH"
}

/** Output only. The severity of harm for this category. This enum is not supported in Gemini API. */
export declare enum HarmSeverity {
    /**
     * The harm severity is unspecified.
     */
    HARM_SEVERITY_UNSPECIFIED = "HARM_SEVERITY_UNSPECIFIED",
    /**
     * The harm severity is negligible.
     */
    HARM_SEVERITY_NEGLIGIBLE = "HARM_SEVERITY_NEGLIGIBLE",
    /**
     * The harm severity is low.
     */
    HARM_SEVERITY_LOW = "HARM_SEVERITY_LOW",
    /**
     * The harm severity is medium.
     */
    HARM_SEVERITY_MEDIUM = "HARM_SEVERITY_MEDIUM",
    /**
     * The harm severity is high.
     */
    HARM_SEVERITY_HIGH = "HARM_SEVERITY_HIGH"
}

/** Configuration for history exchange between client and server. */
export declare interface HistoryConfig {
    /** If true, after sending `setup_complete`, the server will wait
     and at first process `client_content` messages until `turn_complete` is
     `true`. This initial history will not trigger a model call and
     may end with model content. After `turn_complete` is `true`, the client
     can start the realtime conversation via `realtime_input`. */
    initialHistoryInClientContent?: boolean;
}

declare type HookContext = {
    base_url: string | URL;
    operation_id: string;
    o_auth2_scopes: string[] | null;
    security_source?: any | (() => Promise<any>);
    retry_config: RetryConfig;
    resolved_security: SecurityState | null;
    options: SDKOptions;
    timeout_ms?: number;
};

declare interface Hooks {
    /** Registers a hook to be used by the SDK for initialization event. */
    registerSDKInitHook(hook: SDKInitHook): void;
    /** Registers a hook to be used by the SDK for to modify `Request` construction. */
    registerBeforeCreateRequestHook(hook: BeforeCreateRequestHook): void;
    /** Registers a hook to be used by the SDK for the before request event. */
    registerBeforeRequestHook(hook: BeforeRequestHook_2): void;
    /** Registers a hook to be used by the SDK for the after success event. */
    registerAfterSuccessHook(hook: AfterSuccessHook): void;
    /** Registers a hook to be used by the SDK for the after error event. */
    registerAfterErrorHook(hook: AfterErrorHook): void;
}

declare type HttpBearerConfig$ = HttpBearerConfig;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for HTTP Bearer token credentials.
 */
declare type HttpBearerConfig = {
    /**
     * Optional. Header name to inject the token into. Defaults to
     *
     * @remarks
     * 'Authorization'.
     */
    header_name?: string | undefined;
    id: string;
    /**
     * Optional. Prefix to prepend to the token. Defaults to 'Bearer'. Set to ''
     *
     * @remarks
     * for no prefix.
     */
    prefix?: string | undefined;
    /**
     * Required. Input only. The static bearer token. Write-only; never returned in responses.
     */
    token: string;
    type: "bearer_token";
};

declare type HttpBearerConfigParams = Omit<CreateCredentialRequest, "body"> & HttpBearerConfig;

declare type HttpBearerUpdateConfig$ = HttpBearerUpdateConfig;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for updating HTTP Bearer token credentials.
 */
declare type HttpBearerUpdateConfig = {
    /**
     * Optional. Header name to inject the token into. Defaults to
     *
     * @remarks
     * 'Authorization'.
     */
    header_name?: string | undefined;
    /**
     * Optional. Prefix to prepend to the token. Defaults to 'Bearer'. Set to ''
     *
     * @remarks
     * for no prefix.
     */
    prefix?: string | undefined;
    /**
     * Optional. Input only. The static bearer token. Write-only; never returned in responses.
     */
    token?: string | undefined;
    type: "bearer_token";
};

declare type HttpBearerUpdateConfigParams = Omit<UpdateCredentialRequest, "id" | "body"> & HttpBearerUpdateConfig;

declare class HTTPClient {
    private fetcher;
    private requestHooks;
    private requestErrorHooks;
    private responseHooks;
    private options;
    constructor(options?: HTTPClientOptions);
    request(request: Request): Promise<Response>;
    /**
     * Registers a hook that is called before a request is made. The hook function
     * can mutate the request or return a new request. This may be useful to add
     * additional information to request such as request IDs and tracing headers.
     */
    addHook(hook: "beforeRequest", fn: BeforeRequestHook): this;
    /**
     * Registers a hook that is called when a request cannot be made due to a
     * network error.
     */
    addHook(hook: "requestError", fn: RequestErrorHook): this;
    /**
     * Registers a hook that is called when a response has been received from the
     * server.
     */
    addHook(hook: "response", fn: ResponseHook): this;
    /** Removes a hook that was previously registered with `addHook`. */
    removeHook(hook: "beforeRequest", fn: BeforeRequestHook): this;
    /** Removes a hook that was previously registered with `addHook`. */
    removeHook(hook: "requestError", fn: RequestErrorHook): this;
    /** Removes a hook that was previously registered with `addHook`. */
    removeHook(hook: "response", fn: ResponseHook): this;
    clone(): HTTPClient;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Base class for all HTTP errors.
 */
declare class HTTPClientError extends Error {
    /** The underlying cause of the error. */
    readonly cause: unknown;
    name: string;
    constructor(message: string, opts?: {
        cause?: unknown;
    });
}

declare interface HTTPClientOptions {
    fetcher?: Fetcher;
}

/** The location of the API key. This enum is not supported in Gemini API. */
export declare enum HttpElementLocation {
    HTTP_IN_UNSPECIFIED = "HTTP_IN_UNSPECIFIED",
    /**
     * Element is in the HTTP request query.
     */
    HTTP_IN_QUERY = "HTTP_IN_QUERY",
    /**
     * Element is in the HTTP request header.
     */
    HTTP_IN_HEADER = "HTTP_IN_HEADER",
    /**
     * Element is in the HTTP request path.
     */
    HTTP_IN_PATH = "HTTP_IN_PATH",
    /**
     * Element is in the HTTP request body.
     */
    HTTP_IN_BODY = "HTTP_IN_BODY",
    /**
     * Element is in the HTTP request cookie.
     */
    HTTP_IN_COOKIE = "HTTP_IN_COOKIE"
}

/** HTTP options to be used in each of the requests. */
export declare interface HttpOptions {
    /** The base URL for the AI platform service endpoint. */
    baseUrl?: string;
    /** The resource scope used to constructing the resource name when base_url is set */
    baseUrlResourceScope?: ResourceScope;
    /** Specifies the version of the API to use. */
    apiVersion?: string;
    /** Additional HTTP headers to be sent with the request. */
    headers?: Record<string, string>;
    /** Timeout for the request in milliseconds. */
    timeout?: number;
    /** Extra parameters to add to the request body.
     The structure must match the backend API's request structure.
     - Gemini Enterprise Agent Platform backend API docs: https://cloud.google.com/vertex-ai/docs/reference/rest
     - GeminiAPI backend API docs: https://ai.google.dev/api/rest */
    extraBody?: Record<string, unknown>;
    /** HTTP retry options for the request. */
    retryOptions?: HttpRetryOptions;
    /** Custom fetch implementation to use for network requests. */
    fetch?: Fetch;
}

/**
 * Represents the necessary information to send a request to an API endpoint.
 * This interface defines the structure for constructing and executing HTTP
 * requests.
 */
declare interface HttpRequest {
    /**
     * URL path from the modules, this path is appended to the base API URL to
     * form the complete request URL.
     *
     * If you wish to set full URL, use httpOptions.baseUrl instead. Example to
     * set full URL in the request:
     *
     * const request: HttpRequest = {
     *   path: '',
     *   httpOptions: {
     *     baseUrl: 'https://<custom-full-url>',
     *     apiVersion: '',
     *   },
     *   httpMethod: 'GET',
     * };
     *
     * The result URL will be: https://<custom-full-url>
     *
     */
    path: string;
    /**
     * Optional query parameters to be appended to the request URL.
     */
    queryParams?: Record<string, string>;
    /**
     * Optional request body in json string or Blob format, GET request doesn't
     * need a request body.
     */
    body?: string | Blob;
    /**
     * The HTTP method to be used for the request.
     */
    httpMethod: 'GET' | 'POST' | 'PATCH' | 'DELETE';
    /**
     * Optional set of customizable configuration for HTTP requests.
     */
    httpOptions?: types.HttpOptions;
    /**
     * Optional abort signal which can be used to cancel the request.
     */
    abortSignal?: AbortSignal;
}

/** A wrapper class for the http response. */
export declare class HttpResponse {
    /** Used to retain the processed HTTP headers in the response. */
    headers?: Record<string, string>;
    /**
     * The original http response.
     */
    responseInternal: Response;
    constructor(response: Response);
    json(): Promise<unknown>;
}

/** HTTP retry options to be used in each of the requests. */
export declare interface HttpRetryOptions {
    /** Maximum number of attempts, including the original request.
     If 0 or 1, it means no retries. If not specified, default to 5. */
    attempts?: number;
    /** Initial delay before the first retry, in fractions of a second. If not specified, default to 1.0 second. */
    initialDelay?: number;
    /** Maximum delay between retries, in fractions of a second. If not specified, default to 60.0 seconds. */
    maxDelay?: number;
    /** Multiplier by which the delay increases after each attempt. If not specified, default to 2.0. */
    expBase?: number;
    /** Randomness factor for the delay. If not specified, default to 1.0. */
    jitter?: number;
    /** List of HTTP status codes that should trigger a retry.
     If not specified, a default set of retryable codes (408, 429, and 5xx) may be used. */
    httpStatusCodes?: number[];
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Config for Hybrid Search.
 */
declare type HybridSearch = {
    /**
     * Optional. Alpha value controls the weight between dense and sparse vector search
     *
     * @remarks
     * results.
     */
    alpha?: number | undefined;
};

declare type Image$ = ImageDelta;

/** An image. */
declare interface Image_2 {
    /** The Cloud Storage URI of the image. ``Image`` can contain a value
     for this field or the ``image_bytes`` field but not both. */
    gcsUri?: string;
    /** The image bytes data. ``Image`` can contain a value for this field
     or the ``gcs_uri`` field but not both.
     * @remarks Encoded as base64 string. */
    imageBytes?: string;
    /** The MIME type of the image. */
    mimeType?: string;
}
export { Image_2 as Image }

/** The image generation configuration to be used in GenerateContentConfig. */
export declare interface ImageConfig {
    /** Aspect ratio of the generated images. Supported values are
     "1:1", "2:3", "3:2", "3:4", "4:3", "9:16", "16:9", and "21:9". */
    aspectRatio?: string;
    /** Optional. Specifies the size of generated images. Supported
     values are `1K`, `2K`, `4K`. If not specified, the model will use default
     value `1K`. */
    imageSize?: string;
    /** Controls the generation of people. Supported values are:
     ALLOW_ALL, ALLOW_ADULT, ALLOW_NONE. */
    personGeneration?: string;
    /** MIME type of the generated image. This field is not
     supported in Gemini API. */
    outputMimeType?: string;
    /** Compression quality of the generated image (for
     ``image/jpeg`` only). This field is not supported in Gemini API. */
    outputCompressionQuality?: number;
    /** Optional. The image output format for generated images. This field is not supported in Gemini API. */
    imageOutputOptions?: ImageConfigImageOutputOptions;
    /** Optional. Controls whether prominent people (celebrities) generation is allowed. If used with personGeneration, personGeneration enum would take precedence. For instance, if ALLOW_NONE is set, all person generation would be blocked. If this field is unspecified, the default behavior is to allow prominent people. This field is not supported in Gemini API. */
    prominentPeople?: ProminentPeople;
}

/**
 * The configuration for image interaction.
 *
 * @deprecated class: This will be removed in a future release, please migrate away from it as soon as possible.
 */
declare type ImageConfig_2 = {
    /**
     * The aspect ratio of the image to generate. Supported aspect ratios: 1:1,
     *
     * @remarks
     * 2:3, 3:2, 3:4, 4:3, 9:16, 16:9, 21:9.
     *
     * If not specified, the model will choose a default aspect ratio based on any
     * reference images provided.
     */
    aspect_ratio?: ImageConfigAspectRatio | undefined;
    /**
     * Specifies the size of generated images. Supported values are `1K`, `2K`,
     *
     * @remarks
     * `4K`. If not specified, the model will use default value `1K`.
     */
    image_size?: ImageConfigImageSize | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The aspect ratio of the image to generate. Supported aspect ratios: 1:1,
 *
 * @remarks
 * 2:3, 3:2, 3:4, 4:3, 9:16, 16:9, 21:9.
 *
 * If not specified, the model will choose a default aspect ratio based on any
 * reference images provided.
 */
declare type ImageConfigAspectRatio = "1:1" | "2:3" | "3:2" | "3:4" | "4:3" | "4:5" | "5:4" | "9:16" | "16:9" | "21:9" | "1:8" | "8:1" | "1:4" | "4:1" | (string & {});

/** The image output format for generated images. This data type is not supported in Gemini API. */
export declare interface ImageConfigImageOutputOptions {
    /** Optional. The compression quality of the output image. */
    compressionQuality?: number;
    /** Optional. The image format that the output should be saved as. */
    mimeType?: string;
}

/**
 * Specifies the size of generated images. Supported values are `1K`, `2K`,
 *
 * @remarks
 * `4K`. If not specified, the model will use default value `1K`.
 */
declare type ImageConfigImageSize = "1K" | "2K" | "4K" | "512" | (string & {});

declare type ImageContent$ = ImageContent;

/**
 * An image content block.
 */
declare type ImageContent = {
    /**
     * The image content.
     */
    data?: string | undefined;
    /**
     * The mime type of the image.
     */
    mime_type?: ImageContentMimeType | undefined;
    resolution?: MediaResolution_2 | undefined;
    type: "image";
    /**
     * The URI of the image.
     */
    uri?: string | undefined;
};

/**
 * The mime type of the image.
 */
declare type ImageContentMimeType = "image/png" | "image/jpeg" | "image/webp" | "image/heic" | "image/heif" | "image/gif" | "image/bmp" | "image/tiff" | (string & {});

declare type ImageDelta = {
    data?: string | undefined;
    mime_type?: ImageDeltaMimeType | undefined;
    resolution?: MediaResolution_2 | undefined;
    type: "image";
    uri?: string | undefined;
};

declare type ImageDeltaMimeType = "image/png" | "image/jpeg" | "image/webp" | "image/heic" | "image/heif" | "image/gif" | "image/bmp" | "image/tiff" | (string & {});

/** Enum that specifies the language of the text in the prompt. */
export declare enum ImagePromptLanguage {
    /**
     * Auto-detect the language.
     */
    auto = "auto",
    /**
     * English
     */
    en = "en",
    /**
     * Japanese
     */
    ja = "ja",
    /**
     * Korean
     */
    ko = "ko",
    /**
     * Hindi
     */
    hi = "hi",
    /**
     * Chinese
     */
    zh = "zh",
    /**
     * Portuguese
     */
    pt = "pt",
    /**
     * Spanish
     */
    es = "es"
}

/** Resize mode for the image input for video generation. */
export declare enum ImageResizeMode {
    /**
     * Crop the image to fit the correct aspect ratio (so we lose parts
     of the image in the process).
     */
    CROP = "CROP",
    /**
     * Pad the image to fit the correct aspect ratio (so we don't lose
     any parts of the image in the process).
     */
    PAD = "PAD"
}

declare type ImageResponseFormat$ = ImageResponseFormat_2;

/** Configuration for image-specific output formatting. */
export declare class ImageResponseFormat {
    /** Optional. The aspect ratio for the image output. */
    aspectRatio?: AspectRatio;
    /** Optional. Delivery mode for the generated content. */
    delivery?: Delivery;
    /** Optional. The size of the image output. */
    imageSize?: ImageSize;
    /** Optional. The MIME type of the image output. */
    mimeType?: string;
}

/**
 * Configuration for image output format.
 */
declare type ImageResponseFormat_2 = {
    /**
     * The aspect ratio for the image output.
     */
    aspect_ratio?: ImageResponseFormatAspectRatio | undefined;
    /**
     * The delivery mode for the image output.
     */
    delivery?: ImageResponseFormatDelivery | undefined;
    /**
     * The size of the image output.
     */
    image_size?: ImageResponseFormatImageSize | undefined;
    /**
     * The MIME type of the image output.
     */
    mime_type?: ImageResponseFormatMimeType | undefined;
    type: "image";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The aspect ratio for the image output.
 */
declare type ImageResponseFormatAspectRatio = "1:1" | "2:3" | "3:2" | "3:4" | "4:3" | "4:5" | "5:4" | "9:16" | "16:9" | "21:9" | "1:8" | "8:1" | "1:4" | "4:1" | (string & {});

/**
 * The delivery mode for the image output.
 */
declare type ImageResponseFormatDelivery = "inline" | "uri" | (string & {});

/**
 * The size of the image output.
 */
declare type ImageResponseFormatImageSize = "512" | "1K" | "2K" | "4K" | (string & {});

/**
 * The MIME type of the image output.
 */
declare type ImageResponseFormatMimeType = "image/jpeg" | (string & {});

/** Image search for grounding and related configurations. */
export declare interface ImageSearch {
}

/** The size of the image output. */
export declare enum ImageSize {
    /**
     * Default value. This value is unused.
     */
    IMAGE_SIZE_UNSPECIFIED = "IMAGE_SIZE_UNSPECIFIED",
    /**
     * 512px image size.
     */
    IMAGE_SIZE_FIVE_TWELVE = "IMAGE_SIZE_FIVE_TWELVE",
    /**
     * 1K image size.
     */
    IMAGE_SIZE_ONE_K = "IMAGE_SIZE_ONE_K",
    /**
     * 2K image size.
     */
    IMAGE_SIZE_TWO_K = "IMAGE_SIZE_TWO_K",
    /**
     * 4K image size.
     */
    IMAGE_SIZE_FOUR_K = "IMAGE_SIZE_FOUR_K"
}

/** Optional parameters for importing a file. */
export declare interface ImportFileConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** User provided custom metadata stored as key-value pairs used for querying. */
    customMetadata?: CustomMetadata[];
    /** Config for telling the service how to chunk the file. */
    chunkingConfig?: ChunkingConfig;
}

/** Long-running operation for importing a file to a FileSearchStore. */
export declare class ImportFileOperation implements Operation<ImportFileResponse> {
    /** The server-assigned name, which is only unique within the same service that originally returns it. If you use the default HTTP mapping, the `name` should be a resource name ending with `operations/{unique_id}`. */
    name?: string;
    /** Service-specific metadata associated with the operation. It typically contains progress information and common metadata such as create time. Some services might not provide such metadata.  Any method that returns a long-running operation should document the metadata type, if any. */
    metadata?: Record<string, unknown>;
    /** If the value is `false`, it means the operation is still in progress. If `true`, the operation is completed, and either `error` or `response` is available. */
    done?: boolean;
    /** The error result of the operation in case of failure or cancellation. */
    error?: Record<string, unknown>;
    /** The result of the ImportFile operation, available when the operation is done. */
    response?: ImportFileResponse;
    /**
     * Instantiates an Operation of the same type as the one being called with the fields set from the API response.
     */
    _fromAPIResponse({ apiResponse, _isVertexAI, }: OperationFromAPIResponseParameters): Operation<ImportFileResponse>;
    /** The full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** Config for file_search_stores.import_file parameters. */
export declare interface ImportFileParameters {
    /** The resource name of the FileSearchStore. Example: `fileSearchStores/my-file-search-store-123` */
    fileSearchStoreName: string;
    /** The name of the File API File to import. Example: `files/abc-123` */
    fileName: string;
    /** Optional parameters for the request. */
    config?: ImportFileConfig;
}

/** Response for ImportFile to import a File API file with a file search store. */
export declare class ImportFileResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** The name of the FileSearchStore containing Documents. */
    parent?: string;
    /** The identifier for the Document imported. */
    documentName?: string;
}

declare type InjectionLocation$ = InjectionLocationEnum;

declare type InjectionLocationEnum$ = InjectionLocationEnum;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type InjectionLocationEnum = "header" | "query" | "body";

/** Config for `inlined_embedding_responses` parameter. */
export declare class InlinedEmbedContentResponse {
    /** Output only. The response to the request. */
    response?: SingleEmbedContentResponse;
    /** Output only. The error encountered while processing the request. */
    error?: JobError;
    /** Output only. The metadata associated with the request. */
    metadata?: Record<string, unknown>;
}

/** Config for inlined request. */
export declare interface InlinedRequest {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model?: string;
    /** Content of the request.
     */
    contents?: ContentListUnion;
    /** The metadata to be associated with the request. */
    metadata?: Record<string, string>;
    /** Configuration that contains optional model parameters.
     */
    config?: GenerateContentConfig;
}

/** Config for `inlined_responses` parameter. */
export declare class InlinedResponse {
    /** The response to the request.
     */
    response?: GenerateContentResponse;
    /** The metadata to be associated with the request. */
    metadata?: Record<string, string>;
    /** The error encountered while processing the request.
     */
    error?: JobError;
}

declare type InputTokensByModality$ = ModalityTokens;

declare type Interaction$ = Interaction;

/**
 * The Interaction resource.
 */
declare type Interaction = {
    /**
     * The agent to interact with.
     */
    agent?: AgentOption | undefined;
    /**
     * Configuration parameters for the agent interaction.
     */
    agent_config?: AntigravityAgentConfig | CodeMenderAgentConfig | DeepResearchAgentConfig | DynamicAgentConfig | undefined;
    /**
     * The name of the cached content used as context to serve the prediction. Note: only used in explicit caching, where users can have control over caching (e.g. what content to cache) and enjoy guaranteed cost savings. Format: cachedContents/{cachedContent}
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    cached_content?: string | undefined;
    /**
     * The IDs of all server interactions merged into this response when automatic continuation is enabled, in order (ending with the final hop's ID).
     *
     * @remarks
     *
     * Note: this is added by the SDK.
     */
    continuation_ids?: Array<string> | undefined;
    /**
     * Opaque token to resume a long decode. Output: set when status is
     *
     * @remarks
     * REQUIRES_CONTINUATION and decoding can be resumed. Input: pass the latest
     * token back unchanged in CreateInteraction to continue decoding.
     */
    continuation_token?: string | undefined;
    /**
     * Required. Output only. The time at which the response was created in ISO 8601 format
     *
     * @remarks
     * (YYYY-MM-DDThh:mm:ssZ).
     */
    created?: string | undefined;
    /**
     * The environment configuration for the interaction. Can be an object
     *
     * @remarks
     * specifying remote environment sources or a string referencing an existing
     * environment ID.
     */
    environment?: Environment_2 | string | undefined;
    /**
     * Output only. The environment ID for the interaction. Only populated if environment
     *
     * @remarks
     * config is set in the request.
     */
    environment_id?: string | undefined;
    /**
     * Output only. Diagnostic faults / platform errors recorded on the interaction.
     */
    errors?: Array<ErrorT> | undefined;
    /**
     * Configuration parameters for model interactions.
     */
    generation_config?: GenerationConfig_2 | undefined;
    /**
     * Required. Output only. A unique identifier for the interaction completion.
     */
    id: string;
    /**
     * The input for the interaction.
     */
    input?: InteractionsInput | undefined;
    /**
     * The labels with user-defined metadata for the request.
     *
     * @remarks
     *
     * Label keys and values can be no longer than 63 characters
     * (Unicode codepoints) and can only contain lowercase letters, numeric
     * characters, underscores, and dashes. International characters are allowed.
     * Label values are optional. Label keys must start with a letter.
     */
    labels?: {
        [k: string]: string;
    } | undefined;
    /**
     * The model that will complete your prompt.\n\nSee [models](https://ai.google.dev/gemini-api/docs/models) for additional details.
     */
    model?: Model_2 | undefined;
    /**
     * An audio content block.
     */
    output_audio?: AudioContent | undefined;
    /**
     * An image content block.
     */
    output_image?: ImageContent | undefined;
    /**
     * Concatenated text from the last model output in response to the current request.
     *
     * @remarks
     *
     * Note: this is added by the SDK.
     */
    output_text?: string | undefined;
    /**
     * A video content block.
     */
    output_video?: VideoContent | undefined;
    /**
     * The ID of the previous interaction, if any.
     */
    previous_interaction_id?: string | undefined;
    /**
     * Enforces that the generated response is a JSON object that complies with
     *
     * @remarks
     * the JSON schema specified in this field.
     */
    response_format?: ResponseFormat_2 | Array<ResponseFormat_2> | undefined;
    /**
     * The mime type of the response. This is required if response_format is set.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    response_mime_type?: string | undefined;
    /**
     * The requested modalities of the response (TEXT, IMAGE, AUDIO).
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    response_modalities?: Array<ResponseModality> | undefined;
    /**
     * Safety settings for the interaction.
     */
    safety_settings?: Array<SafetySetting_2> | undefined;
    service_tier?: ServiceTier_2 | undefined;
    /**
     * Required. Output only. The status of the interaction.
     */
    status: InteractionStatus_2;
    /**
     * Required. Output only. The steps that make up the interaction, when included in the response.
     */
    steps?: Array<Step> | undefined;
    /**
     * System instruction for the interaction.
     */
    system_instruction?: string | undefined;
    /**
     * A list of tool declarations the model may call during interaction.
     */
    tools?: Array<Tool_2> | undefined;
    /**
     * Required. Output only. The time at which the response was last updated in ISO 8601 format
     *
     * @remarks
     * (YYYY-MM-DDThh:mm:ssZ).
     */
    updated?: string | undefined;
    /**
     * Statistics on the interaction request's token usage.
     */
    usage?: Usage | undefined;
    /**
     * Message for configuring webhook events for a request.
     */
    webhook_config?: WebhookConfig_2 | undefined;
};

/**
 * Configuration parameters for the agent interaction.
 */
declare type InteractionAgentConfig = AntigravityAgentConfig | CodeMenderAgentConfig | DeepResearchAgentConfig | DynamicAgentConfig;

declare type InteractionCancelParams$ = CancelInteractionByIdParams;

declare type InteractionCompletedEvent$ = InteractionCompletedEvent;

/**
 * Signals that the Interaction completed. Sent when the Interaction receives
 *
 * @remarks
 * Complete/Cancel or naturally terminates. No more input can be sent to the
 * Interaction after this.
 */
declare type InteractionCompletedEvent = {
    /**
     * The event_id token to be used to resume the interaction stream, from
     *
     * @remarks
     * this event.
     */
    event_id?: string | undefined;
    event_type: "interaction.completed";
    /**
     * Partial interaction resource emitted by interaction lifecycle SSE events.
     *
     * @remarks
     * Streaming lifecycle payloads may omit fields that are only available on
     * full non-streaming Interaction responses.
     */
    interaction: InteractionSseEventInteraction;
};

declare type InteractionCreatedEvent$ = InteractionCreatedEvent;

/**
 * Server response confirming that a new interaction was created.
 */
declare type InteractionCreatedEvent = {
    /**
     * The event_id token to be used to resume the interaction stream, from
     *
     * @remarks
     * this event.
     */
    event_id?: string | undefined;
    event_type: "interaction.created";
    /**
     * Partial interaction resource emitted by interaction lifecycle SSE events.
     *
     * @remarks
     * Streaming lifecycle payloads may omit fields that are only available on
     * full non-streaming Interaction responses.
     */
    interaction: InteractionSseEventInteraction;
};

declare type InteractionCreateParams$ = CreateInteractionParams;

declare type InteractionCreateParamsNonStreaming$ = CreateInteractionParamsNonStreaming;

declare type InteractionCreateParamsStreaming$ = CreateInteractionParamsStreaming;

declare type InteractionDeleteParams$ = DeleteInteractionParams;

declare type InteractionDeleteResponse$ = Empty;

/**
 * The environment configuration for the interaction. Can be an object
 *
 * @remarks
 * specifying remote environment sources or a string referencing an existing
 * environment ID.
 */
declare type InteractionEnvironment = Environment_2 | string;

declare type InteractionGetParams$ = GetInteractionByIdParams;

declare type InteractionGetParamsNonStreaming$ = GetInteractionByIdParamsNonStreaming;

declare type InteractionGetParamsStreaming$ = GetInteractionByIdParamsStreaming;

/**
 * Enforces that the generated response is a JSON object that complies with
 *
 * @remarks
 * the JSON schema specified in this field.
 */
declare type InteractionResponseFormat = ResponseFormat_2 | Array<ResponseFormat_2>;

export declare namespace Interactions {
    export type AllowedTools = AllowedTools$;
    export type Annotation = Annotation$;
    export type AntigravityAgentConfig = AntigravityAgentConfig$;
    export type AudioContent = AudioContent$;
    export type AudioResponseFormat = AudioResponseFormat$;
    export type CodeExecutionCallArguments = CodeExecutionCallArguments$;
    export interface CodeExecutionCallStep extends CodeExecutionCallStep$ {
    }
    export type CodeExecutionResultStep = CodeExecutionResultStep$;
    export interface CodeMenderAgentConfig extends CodeMenderAgentConfig$ {
    }
    export type Content = Content$;
    export type CreateAgentInteractionParamsNonStreaming = CreateAgentInteractionParamsNonStreaming$;
    export type CreateAgentInteractionParamsStreaming = CreateAgentInteractionParamsStreaming$;
    export type CreateModelInteractionParamsNonStreaming = CreateModelInteractionParamsNonStreaming$;
    export type CreateModelInteractionParamsStreaming = CreateModelInteractionParamsStreaming$;
    export type DeepResearchAgentConfig = DeepResearchAgentConfig$;
    export type DocumentContent = DocumentContent$;
    export type DynamicAgentConfig = DynamicAgentConfig$;
    export interface Environment extends Environment$2 {
    }
    export type Error = Error$;
    export interface ErrorEvent extends ErrorEvent$ {
    }
    export type FileCitation = FileCitation$;
    export type FileSearchCallStep = FileSearchCallStep$;
    export type FileSearchResultStep = FileSearchResultStep$;
    export type Function = Function$;
    export type FunctionCallStep = FunctionCallStep$;
    export type FunctionResultStep = FunctionResultStep$;
    export type GenerationConfig = GenerationConfig$;
    export type GoogleMapsCallArguments = GoogleMapsCallArguments$;
    export interface GoogleMapsCallStep extends GoogleMapsCallStep$ {
    }
    export interface GoogleMapsResult extends GoogleMapsResult$ {
    }
    export interface GoogleMapsResultStep extends GoogleMapsResultStep$ {
    }
    export type GoogleSearchCallArguments = GoogleSearchCallArguments$;
    export interface GoogleSearchCallStep extends GoogleSearchCallStep$ {
    }
    export type GoogleSearchResult = GoogleSearchResult$;
    export interface GoogleSearchResultStep extends GoogleSearchResultStep$ {
    }
    export type HarmCategory = HarmCategory$;
    export type ImageContent = ImageContent$;
    export type ImageResponseFormat = ImageResponseFormat$;
    export type Interaction = Interaction$;
    export type InteractionCancelParams = InteractionCancelParams$;
    export type InteractionCompletedEvent = InteractionCompletedEvent$;
    export type InteractionCreatedEvent = InteractionCreatedEvent$;
    export type InteractionCreateParams = InteractionCreateParams$;
    export type InteractionCreateParamsNonStreaming = InteractionCreateParamsNonStreaming$;
    export type InteractionCreateParamsStreaming = InteractionCreateParamsStreaming$;
    export type InteractionDeleteParams = InteractionDeleteParams$;
    export type InteractionDeleteResponse = InteractionDeleteResponse$;
    export type InteractionGetParams = InteractionGetParams$;
    export type InteractionGetParamsNonStreaming = InteractionGetParamsNonStreaming$;
    export type InteractionGetParamsStreaming = InteractionGetParamsStreaming$;
    export type InteractionSSEEvent = InteractionSSEEvent$;
    export type InteractionStatusUpdate = InteractionStatusUpdate$;
    export type MCPServerToolCallStep = MCPServerToolCallStep$;
    export type MCPServerToolResultStep = MCPServerToolResultStep$;
    export type Model = Model$;
    export type ModelOutputStep = ModelOutputStep$;
    export interface PlaceCitation extends PlaceCitation$ {
    }
    export type ProcessingCallStep = ProcessingCallStep$;
    export type ProcessingResultStep = ProcessingResultStep$;
    export type RetrievalCallArguments = RetrievalCallArguments$;
    export interface RetrievalCallDelta extends RetrievalCallDelta$ {
    }
    export interface RetrievalCallStep extends RetrievalCallStep$ {
    }
    export type RetrievalResultDelta = RetrievalResultDelta$;
    export type RetrievalResultStep = RetrievalResultStep$;
    export type SafetySetting = SafetySetting$;
    export type SpeechConfig = SpeechConfig$;
    export type Step = Step$;
    export interface StepDelta extends StepDelta$ {
    }
    export type StepStart = StepStart$;
    export type StepStop = StepStop$;
    export type TextContent = TextContent$;
    export type TextResponseFormat = TextResponseFormat$;
    export type ThinkingLevel = ThinkingLevel$;
    export type ThoughtStep = ThoughtStep$;
    export type Tool = Tool$;
    export type ToolChoiceConfig = ToolChoiceConfig$;
    export type ToolChoiceType = ToolChoiceType$;
    export type TranscriptionConfig = TranscriptionConfig$;
    export type TranscriptionMode = TranscriptionMode$;
    export type URLCitation = URLCitation$;
    export type URLContextCallArguments = URLContextCallArguments$;
    export interface URLContextCallStep extends URLContextCallStep$ {
    }
    export type URLContextResult = URLContextResult$;
    export interface URLContextResultStep extends URLContextResultStep$ {
    }
    export interface Usage extends Usage$ {
    }
    export type UserInputStep = UserInputStep$;
    export type VideoConfig = VideoConfig$;
    export interface VideoContent extends VideoContent$ {
    }
    export type VideoResponseFormat = VideoResponseFormat$;
    export type WebhookConfig = WebhookConfig$;
    export type WordInfo = WordInfo$;
    export namespace Annotation {
        export type SpeechMetadata = SpeechMetadata$;
    }
    export namespace CodeExecutionCallStep {
        export type Arguments = Arguments$;
    }
    export namespace CodeMenderAgentConfig {
        export interface FindRequest extends FindRequest$ {
        }
        export interface FixRequest extends FixRequest$ {
        }
        export type SessionConfig = SessionConfig$;
        export namespace FindRequest {
            export type SourceFile = SourceFile$;
        }
        export namespace FixRequest {
            export type SourceFile = SourceFile$2;
        }
    }
    export namespace Environment {
        export interface EnvironmentNetworkEgressAllowlist extends EnvironmentNetworkEgressAllowlist$ {
        }
        export type EnvVar = EnvVar$;
        export type Source = Source$;
        export namespace EnvironmentNetworkEgressAllowlist {
            export type AllowlistEntry = AllowlistEntry$;
        }
    }
    export namespace ErrorEvent {
        export type Error = Error$2;
    }
    export namespace GoogleMapsCallStep {
        export type Arguments = Arguments$2;
    }
    export namespace GoogleMapsResult {
        export interface Place extends Place$ {
        }
        export namespace Place {
            export type ReviewSnippet = ReviewSnippet$;
        }
    }
    export namespace GoogleMapsResultStep {
        export interface Result extends Result$ {
        }
        export namespace Result {
            export interface Place extends Place$2 {
            }
            export namespace Place {
                export type ReviewSnippet = ReviewSnippet$2;
            }
        }
    }
    export namespace GoogleSearchCallStep {
        export type Arguments = Arguments$3;
    }
    export namespace GoogleSearchResultStep {
        export type Result = Result$2;
    }
    export namespace InteractionCreateParams {
        export type CreateAgentInteractionParams = CreateAgentInteractionParams$;
        export type CreateAgentInteractionParamsNonStreaming = CreateAgentInteractionParamsNonStreaming$2;
        export type CreateAgentInteractionParamsStreaming = CreateAgentInteractionParamsStreaming$2;
        export type CreateModelInteractionParams = CreateModelInteractionParams$;
        export type CreateModelInteractionParamsNonStreaming = CreateModelInteractionParamsNonStreaming$2;
        export type CreateModelInteractionParamsStreaming = CreateModelInteractionParamsStreaming$2;
        export type InteractionCreateParamsNonStreaming = InteractionCreateParamsNonStreaming$;
        export type InteractionCreateParamsStreaming = InteractionCreateParamsStreaming$;
    }
    export namespace InteractionGetParams {
        export type InteractionGetParamsNonStreaming = InteractionGetParamsNonStreaming$;
        export type InteractionGetParamsStreaming = InteractionGetParamsStreaming$;
    }
    export namespace PlaceCitation {
        export type ReviewSnippet = ReviewSnippet$3;
    }
    export namespace RetrievalCallDelta {
        export type Arguments = Arguments$4;
    }
    export namespace RetrievalCallStep {
        export type Arguments = Arguments$5;
    }
    export namespace StepDelta {
        export type ArgumentsDelta = ArgumentsDelta$;
        export type Audio = Audio$;
        export type CodeExecutionCall = CodeExecutionCall$;
        export type CodeExecutionResult = CodeExecutionResult$;
        export type Document = Document$;
        export type FileSearchCall = FileSearchCall$;
        export type FileSearchResult = FileSearchResult$;
        export type FunctionResult = FunctionResult$;
        export type GoogleMapsCall = GoogleMapsCall$;
        export type GoogleMapsResult = GoogleMapsResult$2;
        export type GoogleSearchCall = GoogleSearchCall$;
        export type GoogleSearchResult = GoogleSearchResult$2;
        export type Image = Image$;
        export type MCPServerToolCall = MCPServerToolCall$;
        export type MCPServerToolResult = MCPServerToolResult$;
        export type Metadata = Metadata$;
        export type ProcessingCall = ProcessingCall$;
        export type ProcessingResult = ProcessingResult$;
        export type Text = Text$;
        export type TextAnnotationDelta = TextAnnotationDelta$;
        export type ThoughtSignature = ThoughtSignature$;
        export type ThoughtSummary = ThoughtSummary$;
        export type URLContextCall = URLContextCall$;
        export type URLContextResult = URLContextResult$2;
        export type Video = Video$;
    }
    export namespace Tool {
        export type CodeExecution = CodeExecution$;
        export type ComputerUse = ComputerUse$;
        export type FileSearch = FileSearch$;
        export type GoogleMaps = GoogleMaps$;
        export type GoogleSearch = GoogleSearch$;
        export type MCPServer = MCPServer$;
        export interface Retrieval extends Retrieval$ {
        }
        export type URLContext = URLContext$;
        export namespace Retrieval {
            export type VertexAISearchConfig = VertexAISearchConfig$;
        }
    }
    export namespace TranscriptionMode {
        export type Smart = Smart$;
        export type Verbatim = Verbatim$;
    }
    export namespace URLContextCallStep {
        export type Arguments = Arguments$6;
    }
    export namespace URLContextResultStep {
        export type Result = Result$3;
    }
    export namespace Usage {
        export type CachedTokensByModality = CachedTokensByModality$;
        export type GroundingToolCount = GroundingToolCount$;
        export type InputTokensByModality = InputTokensByModality$;
        export type OutputTokensByModality = OutputTokensByModality$;
        export type ToolUseTokensByModality = ToolUseTokensByModality$;
    }
    export namespace VideoContent {
        export type Static = Static$;
    }
}

declare namespace interactions {
    export {
        AgentOption,
        AllowedTools,
        Transform,
        AllowlistEntry,
        Annotation,
        AntigravityAgentConfig,
        ArgumentsDelta,
        AudioContentMimeType,
        AudioContent,
        AudioDeltaMimeType,
        AudioDelta,
        AudioResponseFormatDelivery,
        AudioResponseFormatMimeType,
        AudioResponseFormat_2 as AudioResponseFormat,
        Language_2 as Language,
        CodeExecutionCallArguments,
        CodeExecutionCallDelta,
        CodeExecutionCallStep,
        CodeExecutionResultDelta,
        CodeExecutionResultStep,
        CodeExecution,
        CodeMenderAgentConfig,
        DisabledSafetyPolicy,
        EnvironmentEnum,
        ComputerUse_2 as ComputerUse,
        Content_2 as Content,
        CreateAgentInteractionAgentConfig,
        CreateAgentInteractionEnvironment,
        CreateAgentInteractionResponseFormat,
        CreateAgentInteraction,
        CreateModelInteractionEnvironment,
        CreateModelInteractionResponseFormat,
        CreateModelInteraction,
        Visualization,
        DeepResearchAgentConfig,
        DocumentContentMimeType,
        DocumentContent,
        DocumentDeltaMimeType,
        DocumentDelta,
        DynamicAgentConfig,
        Empty,
        EnvVar,
        Disabled,
        Allowlist,
        EnvironmentNetworkEgressAllowlist,
        Env,
        NetworkEnum,
        Network,
        Environment_2 as Environment,
        ErrorEvent_2 as ErrorEvent,
        ErrorT,
        ExaAISearchConfig,
        FileCitation,
        FileContent,
        FileSearchCallDelta,
        FileSearchCallStep,
        FileSearchResultDelta,
        FileSearchResultStep,
        FileSearchResult,
        FileSearch_2 as FileSearch,
        Filter,
        Mode,
        FindRequest,
        FixRequest,
        FunctionCallStep,
        FunctionResultDeltaResult,
        FunctionResultDeltaResultUnion,
        FunctionResultDelta,
        FunctionResultStepResult,
        FunctionResultStepResultUnion,
        FunctionResultStep,
        FunctionResultSubcontent,
        FunctionT,
        SpeechConfigUnion_2 as SpeechConfigUnion,
        ToolChoice,
        GenerationConfig_2 as GenerationConfig,
        GoogleMapsCallArguments,
        GoogleMapsCallDelta,
        GoogleMapsCallStep,
        GoogleMapsResultDelta,
        GoogleMapsResultPlaces,
        GoogleMapsResultStep,
        GoogleMapsResult,
        GoogleMaps_2 as GoogleMaps,
        GoogleSearchCallArguments,
        GoogleSearchCallDelta,
        GoogleSearchCallStepSearchType,
        GoogleSearchCallStep,
        GoogleSearchResultDelta,
        GoogleSearchResultStep,
        GoogleSearchResult,
        GoogleSearchSearchType,
        GoogleSearch_2 as GoogleSearch,
        GroundingToolCountType,
        GroundingToolCount,
        HarmCategory_2 as HarmCategory,
        HybridSearch,
        ImageConfigAspectRatio,
        ImageConfigImageSize,
        ImageConfig_2 as ImageConfig,
        ImageContentMimeType,
        ImageContent,
        ImageDeltaMimeType,
        ImageDelta,
        ImageResponseFormatAspectRatio,
        ImageResponseFormatDelivery,
        ImageResponseFormatImageSize,
        ImageResponseFormatMimeType,
        ImageResponseFormat_2 as ImageResponseFormat,
        InteractionCompletedEvent,
        InteractionCreatedEvent,
        InteractionSseEventInteractionStatus,
        InteractionSseEventInteraction,
        InteractionSSEEvent,
        InteractionSSEStreamEvent,
        InteractionStatusUpdateStatus,
        InteractionStatusUpdate,
        InteractionAgentConfig,
        InteractionEnvironment,
        InteractionResponseFormat,
        InteractionStatus_2 as InteractionStatus,
        Interaction,
        InteractionsInput,
        MCPServerToolCallDelta,
        MCPServerToolCallStep,
        MCPServerToolResultDeltaResult,
        MCPServerToolResultDeltaResultUnion,
        MCPServerToolResultDelta,
        MCPServerToolResultStepResult,
        MCPServerToolResultStepResultUnion,
        MCPServerToolResultStep,
        MCPServer,
        MediaProcessing_2 as MediaProcessing,
        MediaResolution_2 as MediaResolution,
        ModalityTokens,
        ModelOutputStep,
        Model_2 as Model,
        ParallelAISearchConfig,
        PlaceCitation,
        ProcessingCallDelta,
        ProcessingCallStep,
        ProcessingResultDelta,
        ProcessingResultStep,
        RagResource,
        RagRetrievalConfig_2 as RagRetrievalConfig,
        RagStoreConfig,
        RankService,
        Ranking,
        ResponseFormat_2 as ResponseFormat,
        ResponseModality,
        RetrievalCallArguments,
        RetrievalCallDeltaRetrievalType,
        RetrievalCallDelta,
        RetrievalCallStepRetrievalType,
        RetrievalCallStep,
        RetrievalResultDelta,
        RetrievalResultStep,
        RetrievalRetrievalType,
        Retrieval_2 as Retrieval,
        ReviewSnippet,
        Method,
        Threshold,
        SafetySetting_2 as SafetySetting,
        ServiceTier_2 as ServiceTier,
        SessionConfig,
        SmartTranscriptionMode,
        SourceType,
        Source,
        SpeakerConfig,
        SpeechAnnotation,
        SpeechConfig_2 as SpeechConfig,
        StaticMediaProcessing,
        Status,
        StepDeltaData,
        StepDeltaMetadata,
        StepDelta,
        StepStart,
        StepStop,
        Step,
        TextAnnotationDelta,
        TextContent,
        TextDelta,
        TextResponseFormatMimeType,
        TextResponseFormat_2 as TextResponseFormat,
        ThinkingLevel_2 as ThinkingLevel,
        ThinkingSummaries,
        ThoughtSignatureDelta,
        ThoughtStep,
        ThoughtSummaryContent,
        ThoughtSummaryDelta,
        ToolChoiceConfig,
        ToolChoiceType,
        Tool_2 as Tool,
        TranscriptionConfigModeEnum,
        TranscriptionConfigMode,
        TranscriptionConfig,
        TranscriptionMode,
        URLCitation,
        URLContextCallArguments,
        URLContextCallDelta,
        URLContextCallStep,
        URLContextResultDelta,
        URLContextResultStep,
        URLContextResultStatus,
        URLContextResult,
        URLContext,
        Usage,
        UserInputStep,
        VerbatimTranscriptionMode,
        VertexAISearchConfig,
        Task,
        VideoConfig,
        VideoContentMimeType,
        ProcessingEnum,
        Processing,
        VideoContent,
        VideoDeltaMimeType,
        VideoDelta,
        VideoResponseFormatAspectRatio,
        VideoResponseFormatDelivery,
        Resolution,
        VideoResponseFormat_2 as VideoResponseFormat,
        WebhookConfig_2 as WebhookConfig,
        WordInfo_2 as WordInfo
    }
}

declare class Interactions_2 extends ClientSDK {
    /**
     * Creates a new interaction.
     */
    create(params: CreateAgentInteractionParamsNonStreaming, options?: RequestOptions): APIPromise<interactions.Interaction>;
    create(params: CreateModelInteractionParamsNonStreaming, options?: RequestOptions): APIPromise<interactions.Interaction>;
    create(params: CreateAgentInteractionParamsStreaming, options?: RequestOptions): APIPromise<Stream<interactions.InteractionSSEEvent>>;
    create(params: CreateModelInteractionParamsStreaming, options?: RequestOptions): APIPromise<Stream<interactions.InteractionSSEEvent>>;
    create(params: CreateInteractionParamsNonStreaming, options?: RequestOptions): APIPromise<interactions.Interaction>;
    create(params: CreateInteractionParamsStreaming, options?: RequestOptions): APIPromise<Stream<interactions.InteractionSSEEvent>>;
    create(params: CreateInteractionParams, options?: RequestOptions): APIPromise<operations.CreateInteractionResponse>;
    /**
     * Deletes the interaction by id.
     */
    delete(id: string, params?: DeleteInteractionParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<void>;
    /**
     * Retrieves the full details of a single interaction based on its
     * `Interaction.id`.
     */
    get(id: string, params?: GetInteractionByIdParamsNonStreaming, options?: Omit<RequestOptions, "extra_body">): APIPromise<interactions.Interaction>;
    get(id: string, params: GetInteractionByIdParamsStreaming, options?: Omit<RequestOptions, "extra_body">): APIPromise<Stream<interactions.InteractionSSEEvent>>;
    get(id: string, params?: GetInteractionByIdParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<operations.GetInteractionByIdResponse>;
    /**
     * Cancels an interaction by id. This only applies to background interactions
     * that are still running.
     */
    cancel(id: string, params?: CancelInteractionByIdParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<interactions.Interaction>;
}

/**
 * The input for the interaction.
 */
declare type InteractionsInput = Content_2 | Array<Step> | Array<Content_2> | string;

declare type InteractionSSEEvent$ = InteractionSSEEvent;

declare type InteractionSSEEvent = ErrorEvent_2 | InteractionCompletedEvent | InteractionCreatedEvent | InteractionStatusUpdate | StepDelta | StepStart | StepStop;

/**
 * Partial interaction resource emitted by interaction lifecycle SSE events.
 *
 * @remarks
 * Streaming lifecycle payloads may omit fields that are only available on
 * full non-streaming Interaction responses.
 */
declare type InteractionSseEventInteraction = {
    /**
     * The agent to interact with.
     */
    agent?: string | undefined;
    /**
     * Output only. Opaque token to resume a long decode when status is incomplete.
     */
    continuation_token?: string | undefined;
    /**
     * Output only. The time at which the response was created in ISO 8601 format.
     */
    created?: string | undefined;
    /**
     * Required. Output only. A unique identifier for the interaction completion.
     */
    id: string;
    /**
     * The model that will complete your prompt.
     */
    model?: string | undefined;
    /**
     * Output only. The resource type.
     */
    object?: string | undefined;
    service_tier?: ServiceTier_2 | undefined;
    /**
     * Required. Output only. The status of the interaction.
     */
    status: InteractionSseEventInteractionStatus;
    /**
     * Output only. The steps that make up the interaction, if included in this event.
     */
    steps?: Array<Step> | undefined;
    /**
     * Output only. The time at which the response was last updated in ISO 8601 format.
     */
    updated?: string | undefined;
    /**
     * Statistics on the interaction request's token usage.
     */
    usage?: Usage | undefined;
};

/**
 * Required. Output only. The status of the interaction.
 */
declare type InteractionSseEventInteractionStatus = "in_progress" | "requires_action" | "completed" | "failed" | "cancelled" | "incomplete" | "budget_exceeded" | "queued" | "requires_continuation" | (string & {});

declare type InteractionSSEStreamEvent = {
    data: InteractionSSEEvent;
};

/** The different activity states of the live session. */
export declare enum InteractionStatus {
    /**
     * Unspecified interaction status.
     */
    INTERACTION_STATUS_UNSPECIFIED = "INTERACTION_STATUS_UNSPECIFIED",
    /**
     * The server is still actively processing user input or running background reasoning. More model output may follow.
     */
    IN_PROGRESS = "IN_PROGRESS",
    /**
     * Deprecated: Use IDLE instead.
     */
    REQUIRES_ACTION = "REQUIRES_ACTION",
    /**
     * The server has completed all processing and background reasoning.
     */
    IDLE = "IDLE"
}

/**
 * Required. Output only. The status of the interaction.
 */
declare type InteractionStatus_2 = "in_progress" | "requires_action" | "completed" | "failed" | "cancelled" | "incomplete" | "budget_exceeded" | "queued" | "requires_continuation" | (string & {});

declare type InteractionStatusUpdate$ = InteractionStatusUpdate;

declare type InteractionStatusUpdate = {
    /**
     * An optional opaque continuation token used to resume decoding from the
     *
     * @remarks
     * latest checkpoint after a disconnected stream.
     */
    continuation_token?: string | undefined;
    /**
     * The event_id token to be used to resume the interaction stream, from
     *
     * @remarks
     * this event.
     */
    event_id?: string | undefined;
    event_type: "interaction.status_update";
    interaction_id: string;
    status: InteractionStatusUpdateStatus;
    /**
     * Statistics on the interaction request's token usage.
     */
    usage?: Usage | undefined;
};

declare type InteractionStatusUpdateStatus = "in_progress" | "requires_action" | "completed" | "failed" | "cancelled" | "incomplete" | "budget_exceeded" | "queued" | "requires_continuation" | (string & {});

declare class Internal extends ClientSDK {
    /**
     * Start an environment file upload
     *
     * @remarks
     * Starts a resumable upload session for a file in an environment workspace.
     * Upload the file bytes to the URL returned in the `X-Goog-Upload-URL`
     * response header, using the resumable upload protocol.
     */
    startUpload(environment: string, path: string, params: StartEnvironmentFileUploadParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<operations.StartEnvironmentFileUploadResponse | undefined>;
}

/** Parameters for the private _Register method. */
export declare interface InternalRegisterFilesParameters {
    /** The Google Cloud Storage URIs to register. Example: `gs://bucket/object`. */
    uris: string[];
    /** Used to override the default configuration. */
    config?: RegisterFilesConfig;
}

/** Represents a time interval, encoded as a Timestamp start (inclusive) and a Timestamp end (exclusive). The start must be less than or equal to the end. When the start equals the end, the interval is empty (matches no time). When both start and end are unspecified, the interval matches any time. */
export declare interface Interval {
    /** Optional. Exclusive end of the interval. If specified, a Timestamp matching this interval will have to be before the end. */
    endTime?: string;
    /** Optional. Inclusive start of the interval. If specified, a Timestamp matching this interval will have to be the same or after the start. */
    startTime?: string;
}

/**
 * An error that is raised when any inputs used to create a request are invalid.
 */
declare class InvalidRequestError extends HTTPClientError {
    name: string;
}

/** Job error. */
export declare interface JobError {
    /** A list of messages that carry the error details. There is a common set of message types for APIs to use. */
    details?: string[];
    /** The status code. */
    code?: number;
    /** A developer-facing error message, which should be in English. Any user-facing error message should be localized and sent in the `details` field. */
    message?: string;
}

/** Job state. */
export declare enum JobState {
    /**
     * The job state is unspecified.
     */
    JOB_STATE_UNSPECIFIED = "JOB_STATE_UNSPECIFIED",
    /**
     * The job has been just created or resumed and processing has not yet begun.
     */
    JOB_STATE_QUEUED = "JOB_STATE_QUEUED",
    /**
     * The service is preparing to run the job.
     */
    JOB_STATE_PENDING = "JOB_STATE_PENDING",
    /**
     * The job is in progress.
     */
    JOB_STATE_RUNNING = "JOB_STATE_RUNNING",
    /**
     * The job completed successfully.
     */
    JOB_STATE_SUCCEEDED = "JOB_STATE_SUCCEEDED",
    /**
     * The job failed.
     */
    JOB_STATE_FAILED = "JOB_STATE_FAILED",
    /**
     * The job is being cancelled. From this state the job may only go to either `JOB_STATE_SUCCEEDED`, `JOB_STATE_FAILED` or `JOB_STATE_CANCELLED`.
     */
    JOB_STATE_CANCELLING = "JOB_STATE_CANCELLING",
    /**
     * The job has been cancelled.
     */
    JOB_STATE_CANCELLED = "JOB_STATE_CANCELLED",
    /**
     * The job has been stopped, and can be resumed.
     */
    JOB_STATE_PAUSED = "JOB_STATE_PAUSED",
    /**
     * The job has expired.
     */
    JOB_STATE_EXPIRED = "JOB_STATE_EXPIRED",
    /**
     * The job is being updated. Only jobs in the `JOB_STATE_RUNNING` state can be updated. After updating, the job goes back to the `JOB_STATE_RUNNING` state.
     */
    JOB_STATE_UPDATING = "JOB_STATE_UPDATING",
    /**
     * The job is partially succeeded, some results may be missing due to errors.
     */
    JOB_STATE_PARTIALLY_SUCCEEDED = "JOB_STATE_PARTIALLY_SUCCEEDED"
}

/** Programming language of the `code`. */
export declare enum Language {
    /**
     * Unspecified language. This value should not be used.
     */
    LANGUAGE_UNSPECIFIED = "LANGUAGE_UNSPECIFIED",
    /**
     * Python >= 3.10, with numpy and simpy available.
     */
    PYTHON = "PYTHON"
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Programming language of the `code`.
 */
declare type Language_2 = "python" | "bash" | (string & {});

/** Deprecated: Language auto-detection is now the default when language_codes is omitted. */
export declare interface LanguageAuto {
}

/** Deprecated: Use AudioTranscriptionConfig.language_codes instead. */
export declare interface LanguageHints {
    /** Deprecated. BCP-47 language codes. */
    languageCodes?: string[];
}

/** An object that represents a latitude/longitude pair. This is expressed as a pair of doubles to represent degrees latitude and degrees longitude. Unless specified otherwise, this object must conform to the WGS84 standard. Values must be within normalized ranges. */
export declare interface LatLng {
    /** The latitude in degrees. It must be in the range [-90.0, +90.0]. */
    latitude?: number;
    /** The longitude in degrees. It must be in the range [-180.0, +180.0]. */
    longitude?: number;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ListAgentsGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type ListAgentsParams = ListAgentsRequest;

declare type ListAgentsRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    page_size?: number | undefined;
    page_token?: string | undefined;
    /**
     * Required. The parent resource to list agents from.
     *
     * @remarks
     * Format: `projects/{project}/locations/{location}`
     */
    parent?: string | undefined;
};

/** Config for optional parameters. */
export declare interface ListBatchJobsConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    pageSize?: number;
    pageToken?: string;
    filter?: string;
}

/** Config for batches.list parameters. */
export declare interface ListBatchJobsParameters {
    config?: ListBatchJobsConfig;
}

/** Config for batches.list return value. */
export declare class ListBatchJobsResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    nextPageToken?: string;
    batchJobs?: BatchJob[];
}

/** Config for caches.list method. */
export declare interface ListCachedContentsConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    pageSize?: number;
    pageToken?: string;
}

/** Parameters for caches.list method. */
export declare interface ListCachedContentsParameters {
    /** Configuration that contains optional parameters.
     */
    config?: ListCachedContentsConfig;
}

export declare class ListCachedContentsResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    nextPageToken?: string;
    /** List of cached contents.
     */
    cachedContents?: CachedContent[];
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ListCredentialsGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type ListCredentialsParams = ListCredentialsRequest;

declare type ListCredentialsRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Optional. Maximum number of credentials to return.
     */
    page_size?: number | undefined;
    /**
     * Optional. Pagination token.
     */
    page_token?: string | undefined;
};

/** Config for optional parameters. */
export declare interface ListDocumentsConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    pageSize?: number;
    pageToken?: string;
}

/** Config for documents.list parameters. */
export declare interface ListDocumentsParameters {
    /** The resource name of the FileSearchStores. Example: `fileSearchStore/file-search-store-foo` */
    parent: string;
    config?: ListDocumentsConfig;
}

/** Config for documents.list return value. */
export declare class ListDocumentsResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** A token, which can be sent as `page_token` to retrieve the next page. If this field is omitted, there are no more pages. */
    nextPageToken?: string;
    /** The returned `Document`s. */
    documents?: Document_2[];
}

export declare type ListEnvironmentFilesParams = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * The ID of the environment whose snapshot to read.
     */
    environment: string;
    /**
     * Path of the file or directory inside the environment workspace, relative to its root (e.g. src).
     */
    path: string;
    /**
     * Optional. Maximum number of entries to return per page (for directory listing).
     */
    page_size?: number | undefined;
    /**
     * Optional. Pagination token for directory listing.
     */
    page_token?: string | undefined;
    /**
     * Optional. If true and the path is a directory, recursively lists all files.
     */
    recursive?: boolean | undefined;
};

/**
 * Alias for GetEnvironmentFilesResponse when listing files.
 */
export declare type ListEnvironmentFilesResponse = Environments.GetEnvironmentFilesResponse;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ListEnvironmentsGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

export declare type ListEnvironmentsParams = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Optional. Maximum number of environments to return.
     *
     * @remarks
     * If unspecified, defaults to 50. Maximum is 1000.
     */
    page_size?: number | undefined;
    /**
     * Optional. Pagination token.
     */
    page_token?: string | undefined;
};

declare type ListEnvironmentsParams_2 = ListEnvironmentsRequest;

declare type ListEnvironmentsRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Optional. Maximum number of environments to return.
     *
     * @remarks
     * If unspecified, defaults to 50. Maximum is 1000.
     */
    page_size?: number | undefined;
    /**
     * Optional. Pagination token.
     */
    page_token?: string | undefined;
};

declare type ListEnvironmentsResponse$ = ListEnvironmentsResponse;

/**
 * Response for `ListEnvironments`.
 */
declare type ListEnvironmentsResponse = {
    /**
     * Environments belonging to the provided project.
     */
    environments?: Array<Environment_3> | undefined;
    /**
     * Pagination token.
     */
    next_page_token?: string | undefined;
};

export declare interface ListFilesConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    pageSize?: number;
    pageToken?: string;
}

/** Optional parameters for listing FileSearchStore. */
export declare interface ListFileSearchStoresConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    pageSize?: number;
    pageToken?: string;
}

/** Config for file_search_stores.list parameters. */
export declare interface ListFileSearchStoresParameters {
    /** Optional parameters for the list request. */
    config?: ListFileSearchStoresConfig;
}

/** Config for file_search_stores.list return value. */
export declare class ListFileSearchStoresResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** A token, which can be sent as `page_token` to retrieve the next page. If this field is omitted, there are no more pages. */
    nextPageToken?: string;
    /** The returned file search stores. */
    fileSearchStores?: FileSearchStore[];
}

/** Generates the parameters for the list method. */
export declare interface ListFilesParameters {
    /** Used to override the default configuration. */
    config?: ListFilesConfig;
}

/** Response for the list files method. */
export declare class ListFilesResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** A token that can be sent as a `page_token` into a subsequent `ListFiles` call. */
    nextPageToken?: string;
    /** The list of `File`s. */
    files?: File_2[];
}

export declare interface ListModelsConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    pageSize?: number;
    pageToken?: string;
    filter?: string;
    /** Set true to list base models, false to list tuned models. */
    queryBase?: boolean;
}

export declare interface ListModelsParameters {
    config?: ListModelsConfig;
}

export declare class ListModelsResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    nextPageToken?: string;
    models?: Model[];
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ListTriggerExecutionsGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type ListTriggerExecutionsParams = Omit<ListTriggerExecutionsRequest, "trigger_id">;

declare type ListTriggerExecutionsRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * The maximum number of executions to return per page.
     */
    page_size?: number | undefined;
    /**
     * A page token from a previous ListTriggerExecutions call.
     */
    page_token?: string | undefined;
    /**
     * Required. The trigger ID to list executions from.
     */
    trigger_id: string;
};

declare type ListTriggerExecutionsResponse$ = ListTriggerExecutionsResponse;

/**
 * Response message for TriggerService.ListTriggerExecutions.
 */
declare type ListTriggerExecutionsResponse = {
    /**
     * A page token, received from a previous `ListTriggerExecutions` call.
     *
     * @remarks
     * Provide this to retrieve the subsequent page.
     */
    next_page_token?: string | undefined;
    /**
     * The list of trigger executions.
     */
    trigger_executions?: Array<TriggerExecution> | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ListTriggersGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type ListTriggersParams = ListTriggersRequest;

declare type ListTriggersRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Optional. Filter expression (e.g., by state).
     */
    filter?: string | undefined;
    /**
     * Optional. The maximum number of triggers to return per page.
     */
    page_size?: number | undefined;
    /**
     * Optional. A page token from a previous ListTriggers call.
     */
    page_token?: string | undefined;
};

declare type ListTriggersResponse$ = ListTriggersResponse;

/**
 * Response message for TriggerService.ListTriggers.
 */
declare type ListTriggersResponse = {
    /**
     * A page token, received from a previous `ListTriggers` call.
     *
     * @remarks
     * Provide this to retrieve the subsequent page.
     */
    next_page_token?: string | undefined;
    /**
     * The list of triggers.
     */
    triggers?: Array<Trigger> | undefined;
};

/** Configuration for the list tuning jobs method. */
export declare interface ListTuningJobsConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    pageSize?: number;
    pageToken?: string;
    filter?: string;
}

/** Parameters for the list tuning jobs method. */
export declare interface ListTuningJobsParameters {
    config?: ListTuningJobsConfig;
}

/** Response for the list tuning jobs method. */
export declare class ListTuningJobsResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** A token to retrieve the next page of results. Pass this token in a subsequent [GenAiTuningService.ListTuningJobs] call to retrieve the next page of results. */
    nextPageToken?: string;
    /** The tuning jobs that match the request. */
    tuningJobs?: TuningJob[];
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ListVoicesGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type ListVoicesParams = ListVoicesRequest;

declare type ListVoicesRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Optional. Filter by accent description (e.g. "American", "British").
     *
     * @remarks
     * Case-insensitive exact match. If multiple values are specified, matches
     * voices with any of the specified accents (OR).
     */
    accent?: Array<string> | undefined;
    /**
     * Optional. Filter by intended context or domain (e.g. "News, Commercial").
     *
     * @remarks
     * Case-insensitive exact match. If multiple values are specified, matches
     * voices with any of the specified contexts (OR).
     */
    contexts?: Array<string> | undefined;
    /**
     * Optional. Filter by gender presentation (e.g. "female", "male", "neutral").
     *
     * @remarks
     * Case-insensitive exact match. If multiple values are specified, matches
     * voices with any of the specified genders (OR).
     */
    gender?: Array<string> | undefined;
    /**
     * Optional. Filter by BCP-47 language code (e.g. "en-US").
     *
     * @remarks
     * Case-insensitive exact match. If multiple values are specified, matches
     * voices with any of the specified language codes (OR).
     */
    language_code?: Array<string> | undefined;
    /**
     * Optional. The maximum number of voices to return per page. The service may
     *
     * @remarks
     * return fewer than this value. If unspecified, at most 50 voices are
     * returned. The maximum value is 1000; values above 1000 are coerced to
     * 1000.
     */
    page_size?: number | undefined;
    /**
     * Optional. A page token received from a previous `ListVoices` call. Provide
     *
     * @remarks
     * this to retrieve the subsequent page.
     *
     * When paginating, all filter query parameters (`language_code`,
     * `region_code`, `accent`, `persona`, `context`, `gender`, `pitch`, `type`,
     * and `search`) must match the call that returned this token; otherwise the
     * request fails with `INVALID_ARGUMENT`. `page_size` may change between
     * pages.
     */
    page_token?: string | undefined;
    /**
     * Optional. Filter by vocal persona (e.g. "Warm, Friendly").
     *
     * @remarks
     * Case-insensitive exact match. If multiple values are specified, matches
     * voices with any of the specified personas (OR).
     */
    persona?: Array<string> | undefined;
    /**
     * Optional. Filter by vocal pitch. Accepts `"low"`, `"medium"`, `"high"`
     *
     * @remarks
     * (case-insensitive). If multiple values are specified, matches voices with
     * any of the specified pitches (OR).
     */
    pitch?: Array<string> | undefined;
    /**
     * Optional. Filter by ISO 3166-1 alpha-2 or UN M.49 region code (e.g. "US",
     *
     * @remarks
     * "001").
     * Case-insensitive exact match. If multiple values are specified, matches
     * voices with any of the specified region codes (OR).
     */
    region_code?: Array<string> | undefined;
    /**
     * Optional. Free-text substring search query matched case-insensitively
     *
     * @remarks
     * against both `display_name` and `description`. Maximum 2048 bytes.
     */
    search?: string | undefined;
    /**
     * Optional. Filter by voice type. Accepts `"prebuilt"`, `"replicated"`,
     *
     * @remarks
     * `"prompted"` (case-insensitive). If multiple values are specified, matches
     * voices with any of the specified types (OR).
     */
    type?: Array<string> | undefined;
};

/**
 * Response message for `VoicesService.ListVoices`.
 */
declare type ListVoicesResponse = {
    /**
     * A token that can be sent as `page_token` to retrieve the next page.
     *
     * @remarks
     * If empty, there are no subsequent pages.
     */
    next_page_token?: string | undefined;
    /**
     * The voices from the specified collection.
     */
    voices?: Array<VoiceOutput> | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ListWebhooksGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type ListWebhooksParams = ListWebhooksRequest;

declare type ListWebhooksRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Optional. The maximum number of webhooks to return. The service may return
     *
     * @remarks
     * fewer than this value. If unspecified, at most 50 webhooks will be
     * returned. The maximum value is 1000.
     */
    page_size?: number | undefined;
    /**
     * Optional. A page token, received from a previous `ListWebhooks` call.
     *
     * @remarks
     * Provide this to retrieve the subsequent page.
     */
    page_token?: string | undefined;
};

/**
 Live class encapsulates the configuration for live interaction with the
 Generative Language API. It embeds ApiClient for general API settings.

 @experimental
 */
export declare class Live {
    private readonly apiClient;
    private readonly auth;
    private readonly webSocketFactory;
    readonly music: LiveMusic;
    constructor(apiClient: ApiClient, auth: Auth, webSocketFactory: WebSocketFactory);
    /**
     Establishes a connection to the specified model with the given
     configuration and returns a Session object representing that connection.

     @experimental Built-in MCP support is an experimental feature, may change in
     future versions.

     @remarks

     @param params - The parameters for establishing a connection to the model.
     @return A live session.

     @example
     ```ts
     let model: string;
     if (GOOGLE_GENAI_USE_VERTEXAI) {
     model = 'gemini-2.0-flash-live-preview-04-09';
     } else {
     model = 'gemini-live-2.5-flash-preview';
     }
     const session = await ai.live.connect({
     model: model,
     config: {
     responseModalities: [Modality.AUDIO],
     },
     callbacks: {
     onopen: () => {
     console.log('Connected to the socket.');
     },
     onmessage: (e: MessageEvent) => {
     console.log('Received message from the server: %s\n', debug(e.data));
     },
     onerror: (e: ErrorEvent) => {
     console.log('Error occurred: %s\n', debug(e.error));
     },
     onclose: (e: CloseEvent) => {
     console.log('Connection closed.');
     },
     },
     });
     ```
     */
    connect(params: types.LiveConnectParameters): Promise<Session>;
    private isCallableTool;
}

/** Callbacks for the live API. */
export declare interface LiveCallbacks {
    /**
     * Called when the websocket connection is established.
     */
    onopen?: (() => void) | null;
    /**
     * Called when a message is received from the server.
     */
    onmessage: (e: LiveServerMessage) => void;
    /**
     * Called when an error occurs.
     */
    onerror?: ((e: ErrorEvent) => void) | null;
    /**
     * Called when the websocket connection is closed.
     */
    onclose?: ((e: CloseEvent) => void) | null;
}

/** Incremental update of the current conversation delivered from the client.

 All the content here will unconditionally be appended to the conversation
 history and used as part of the prompt to the model to generate content.

 A message here will interrupt any current model generation. */
export declare interface LiveClientContent {
    /** The content appended to the current conversation with the model.

     For single-turn queries, this is a single instance. For multi-turn
     queries, this is a repeated field that contains conversation history and
     latest request.
     */
    turns?: Content[];
    /** If true, indicates that the server content generation should start with
     the currently accumulated prompt. Otherwise, the server will await
     additional messages before starting generation. */
    turnComplete?: boolean;
}

/** Updates to the context of the current session.

 Only fields that are set will be updated. Updates are guaranteed to be
 processed *in order* with the rest of the inputs. */
export declare interface LiveClientContextUpdate {
    /** Updated system instruction for the model. If set, overrides `BidiGenerateContentSetup.system_instruction`. The system instructions are part of the model preamble, so updating them invalidates the prefix cache. Clients should only update this field when strictly necessary as it might have a performance impact on the model generation. */
    systemInstruction?: ContentUnion;
    /** An updated list of tools the model may use to generate the subsequent responses. If set, this list replaces the previously provided tools. The tools are part of the model preamble, so updating them invalidates the prefix cache. Clients should only update this field when strictly necessary as it might have a performance impact on the model generation. */
    tools?: LiveClientContextUpdateTools;
}

/** A wrapper around the list of tools.

 This wrapper exists because a bare `repeated Tool` field cannot tell apart
 "not sending a tools update" from "clearing all tools": an unset repeated
 field and an empty repeated field look identical on the wire. Wrapping the
 list in a message adds a presence bit, so the two cases become: - `tools`
 field unset: no update; keep the previously provided tools. - `tools` field
 set (even with an empty list): replace the current tools with the provided
 list, which may be empty to clear all tools. */
export declare interface LiveClientContextUpdateTools {
    /** The list of tools the model may use to generate the next response. */
    tools?: ToolListUnion;
}

/** Messages sent by the client in the API call. */
export declare interface LiveClientMessage {
    /** Message to be sent by the system when connecting to the API. SDK users should not send this message. */
    setup?: LiveClientSetup;
    /** Incremental update of the current conversation delivered from the client. */
    clientContent?: LiveClientContent;
    /** User input that is sent in real time. */
    realtimeInput?: LiveClientRealtimeInput;
    /** Response to a `ToolCallMessage` received from the server. */
    toolResponse?: LiveClientToolResponse;
    /** Updates to the context of the current session. */
    contextUpdate?: LiveClientContextUpdate;
}

/** User input that is sent in real time.

 This is different from `LiveClientContent` in a few ways:

 - Can be sent continuously without interruption to model generation.
 - If there is a need to mix data interleaved across the
 `LiveClientContent` and the `LiveClientRealtimeInput`, server attempts to
 optimize for best response, but there are no guarantees.
 - End of turn is not explicitly specified, but is rather derived from user
 activity (for example, end of speech).
 - Even before the end of turn, the data is processed incrementally
 to optimize for a fast start of the response from the model.
 - Is always assumed to be the user's input (cannot be used to populate
 conversation history). */
export declare interface LiveClientRealtimeInput {
    /** Inlined bytes data for media input. */
    mediaChunks?: Blob_2[];
    /** The realtime audio input stream. */
    audio?: Blob_2;
    /**
     Indicates that the audio stream has ended, e.g. because the microphone was
     turned off.

     This should only be sent when automatic activity detection is enabled
     (which is the default).

     The client can reopen the stream by sending an audio message.
     */
    audioStreamEnd?: boolean;
    /** The realtime video input stream. */
    video?: Blob_2;
    /** The realtime text input stream. */
    text?: string;
    /** Marks the start of user activity. */
    activityStart?: ActivityStart;
    /** Marks the end of user activity. */
    activityEnd?: ActivityEnd;
}

/** Message contains configuration that will apply for the duration of the streaming session. */
export declare interface LiveClientSetup {
    /**
     The fully qualified name of the publisher model or tuned model endpoint to
     use.
     */
    model?: string;
    /** The generation configuration for the session.
     Note: only a subset of fields are supported.
     */
    generationConfig?: GenerationConfig;
    /** The user provided system instructions for the model.
     Note: only text should be used in parts and content in each part will be
     in a separate paragraph. */
    systemInstruction?: ContentUnion;
    /**  A list of `Tools` the model may use to generate the next response.

     A `Tool` is a piece of code that enables the system to interact with
     external systems to perform an action, or set of actions, outside of
     knowledge and scope of the model. */
    tools?: ToolListUnion;
    /** Configures the realtime input behavior in BidiGenerateContent. */
    realtimeInputConfig?: RealtimeInputConfig;
    /** Configures session resumption mechanism.

     If included server will send SessionResumptionUpdate messages. */
    sessionResumption?: SessionResumptionConfig;
    /** Configures context window compression mechanism.

     If included, server will compress context window to fit into given length. */
    contextWindowCompression?: ContextWindowCompressionConfig;
    /** The transcription of the input aligns with the input audio language.
     */
    inputAudioTranscription?: AudioTranscriptionConfig;
    /** The transcription of the output aligns with the language code
     specified for the output audio.
     */
    outputAudioTranscription?: AudioTranscriptionConfig;
    /** Configures the proactivity of the model. This allows the model to respond proactively to
     the input and to ignore irrelevant input. */
    proactivity?: ProactivityConfig;
    /** Configures the exchange of history between the client and the server. */
    historyConfig?: HistoryConfig;
    /** Configures the explicit VAD signal. If enabled, the client will send
     vad_signal to indicate the start and end of speech. This allows the server
     to process the audio more efficiently. */
    explicitVadSignal?: boolean;
    /** Configures the avatar model behavior. */
    avatarConfig?: AvatarConfig;
    /** Safety settings in the request to block unsafe content in the
     response.
     */
    safetySettings?: SafetySetting[];
    /** Optional. Labels with user-defined metadata for the request. Optional. Labels must follow standard unified Cloud label requirements: - Label keys must start with a letter. - Label keys and values can be no longer than 63 characters (Unicode codepoints) and can only contain lowercase letters, numeric characters, underscores, and dashes. - International characters are allowed. Usage: - Safety identifiers from aggregators: Use the key `safety_identifier` (e.g. `{"safety_identifier": "user_session_123"}`) */
    labels?: Record<string, string>;
}

/** Client generated response to a `ToolCall` received from the server.

 Individual `FunctionResponse` objects are matched to the respective
 `FunctionCall` objects by the `id` field.

 Note that in the unary and server-streaming GenerateContent APIs function
 calling happens by exchanging the `Content` parts, while in the bidi
 GenerateContent APIs function calling happens over this dedicated set of
 messages. */
export declare class LiveClientToolResponse {
    /** The response to the function calls. */
    functionResponses?: FunctionResponse[];
}

/** Session config for the API connection. */
export declare interface LiveConnectConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The generation configuration for the session. */
    generationConfig?: GenerationConfig;
    /** The requested modalities of the response. Represents the set of
     modalities that the model can return. Defaults to AUDIO if not specified.
     */
    responseModalities?: Modality[];
    /** Value that controls the degree of randomness in token selection.
     Lower temperatures are good for prompts that require a less open-ended or
     creative response, while higher temperatures can lead to more diverse or
     creative results.
     */
    temperature?: number;
    /** Tokens are selected from the most to least probable until the sum
     of their probabilities equals this value. Use a lower value for less
     random responses and a higher value for more random responses.
     */
    topP?: number;
    /** For each token selection step, the ``top_k`` tokens with the
     highest probabilities are sampled. Then tokens are further filtered based
     on ``top_p`` with the final token selected using temperature sampling. Use
     a lower number for less random responses and a higher number for more
     random responses.
     */
    topK?: number;
    /** Maximum number of tokens that can be generated in the response.
     */
    maxOutputTokens?: number;
    /** If specified, the media resolution specified will be used.
     */
    mediaResolution?: MediaResolution;
    /** When ``seed`` is fixed to a specific number, the model makes a best
     effort to provide the same response for repeated requests. By default, a
     random number is used.
     */
    seed?: number;
    /** The speech generation configuration.
     */
    speechConfig?: SpeechConfig;
    /** Config for thinking features.
     An error will be returned if this field is set for models that don't
     support thinking.
     */
    thinkingConfig?: ThinkingConfig;
    /** If enabled, the model will detect emotions and adapt its responses accordingly. */
    enableAffectiveDialog?: boolean;
    /** The user provided system instructions for the model.
     Note: only text should be used in parts and content in each part will be
     in a separate paragraph. */
    systemInstruction?: ContentUnion;
    /** A list of `Tools` the model may use to generate the next response.

     A `Tool` is a piece of code that enables the system to interact with
     external systems to perform an action, or set of actions, outside of
     knowledge and scope of the model. */
    tools?: ToolListUnion;
    /** Configures session resumption mechanism.

     If included the server will send SessionResumptionUpdate messages. */
    sessionResumption?: SessionResumptionConfig;
    /** The transcription of the input aligns with the input audio language.
     */
    inputAudioTranscription?: AudioTranscriptionConfig;
    /** The transcription of the output aligns with the language code
     specified for the output audio.
     */
    outputAudioTranscription?: AudioTranscriptionConfig;
    /** Configures the realtime input behavior in BidiGenerateContent. */
    realtimeInputConfig?: RealtimeInputConfig;
    /** Configures context window compression mechanism.

     If included, server will compress context window to fit into given length. */
    contextWindowCompression?: ContextWindowCompressionConfig;
    /** Configures the proactivity of the model. This allows the model to respond proactively to
     the input and to ignore irrelevant input. */
    proactivity?: ProactivityConfig;
    /** Configures the explicit VAD signal. If enabled, the client will send
     vad_signal to indicate the start and end of speech. This allows the server
     to process the audio more efficiently. */
    explicitVadSignal?: boolean;
    /** Configures the avatar model behavior. */
    avatarConfig?: AvatarConfig;
    /** Safety settings in the request to block unsafe content in the
     response.
     */
    safetySettings?: SafetySetting[];
    /** Config for translation. */
    translationConfig?: TranslationConfig;
    /** Labels with user-defined metadata for the session. In Gemini
     Enterprise Agent Platform, they are used for billing and reporting. */
    labels?: Record<string, string>;
}

/** Config for LiveConnectConstraints for Auth Token creation. */
export declare interface LiveConnectConstraints {
    /** ID of the model to configure in the ephemeral token for Live API.
     For a list of models, see `Gemini models
     <https://ai.google.dev/gemini-api/docs/models>`. */
    model?: string;
    /** Configuration specific to Live API connections created using this token. */
    config?: LiveConnectConfig;
}

/** Parameters for connecting to the live API. */
export declare interface LiveConnectParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** callbacks */
    callbacks: LiveCallbacks;
    /** Optional configuration parameters for the request.
     */
    config?: LiveConnectConfig;
}

/**
 LiveMusic class encapsulates the configuration for live music
 generation via Lyria Live models.

 @experimental
 */
declare class LiveMusic {
    private readonly apiClient;
    private readonly auth;
    private readonly webSocketFactory;
    constructor(apiClient: ApiClient, auth: Auth, webSocketFactory: WebSocketFactory);
    /**
     Establishes a connection to the specified model and returns a
     LiveMusicSession object representing that connection.

     @experimental

     @remarks

     @param params - The parameters for establishing a connection to the model.
     @return A live session.

     @example
     ```ts
     let model = 'models/lyria-realtime-exp';
     const session = await ai.live.music.connect({
     model: model,
     callbacks: {
     onmessage: (e: MessageEvent) => {
     console.log('Received message from the server: %s\n', debug(e.data));
     },
     onerror: (e: ErrorEvent) => {
     console.log('Error occurred: %s\n', debug(e.error));
     },
     onclose: (e: CloseEvent) => {
     console.log('Connection closed.');
     },
     },
     });
     ```
     */
    connect(params: types.LiveMusicConnectParameters): Promise<LiveMusicSession>;
}

/** Callbacks for the realtime music API. */
export declare interface LiveMusicCallbacks {
    /**
     * Called when a message is received from the server.
     */
    onmessage: (e: LiveMusicServerMessage) => void;
    /**
     * Called when an error occurs.
     */
    onerror?: ((e: ErrorEvent) => void) | null;
    /**
     * Called when the websocket connection is closed.
     */
    onclose?: ((e: CloseEvent) => void) | null;
}

/** User input to start or steer the music. */
export declare interface LiveMusicClientContent {
    /** Weighted prompts as the model input. */
    weightedPrompts?: WeightedPrompt[];
}

/** Messages sent by the client in the LiveMusicClientMessage call. */
export declare interface LiveMusicClientMessage {
    /** Message to be sent in the first (and only in the first) `LiveMusicClientMessage`.
     Clients should wait for a `LiveMusicSetupComplete` message before
     sending any additional messages. */
    setup?: LiveMusicClientSetup;
    /** User input to influence music generation. */
    clientContent?: LiveMusicClientContent;
    /** Configuration for music generation. */
    musicGenerationConfig?: LiveMusicGenerationConfig;
    /** Playback control signal for the music generation. */
    playbackControl?: LiveMusicPlaybackControl;
}

/** Message to be sent by the system when connecting to the API. */
export declare interface LiveMusicClientSetup {
    /** The model's resource name. Format: `models/{model}`. */
    model?: string;
}

/** Parameters for connecting to the live API. */
export declare interface LiveMusicConnectParameters {
    /** The model's resource name. */
    model: string;
    /** Callbacks invoked on server events. */
    callbacks: LiveMusicCallbacks;
}

/** A prompt that was filtered with the reason. */
export declare interface LiveMusicFilteredPrompt {
    /** The text prompt that was filtered. */
    text?: string;
    /** The reason the prompt was filtered. */
    filteredReason?: string;
}

/** Configuration for music generation. */
export declare interface LiveMusicGenerationConfig {
    /** Controls the variance in audio generation. Higher values produce
     higher variance. Range is [0.0, 3.0]. */
    temperature?: number;
    /** Controls how the model selects tokens for output. Samples the topK
     tokens with the highest probabilities. Range is [1, 1000]. */
    topK?: number;
    /** Seeds audio generation. If not set, the request uses a randomly
     generated seed. */
    seed?: number;
    /** Controls how closely the model follows prompts.
     Higher guidance follows more closely, but will make transitions more
     abrupt. Range is [0.0, 6.0]. */
    guidance?: number;
    /** Beats per minute. Range is [60, 200]. */
    bpm?: number;
    /** Density of sounds. Range is [0.0, 1.0]. */
    density?: number;
    /** Brightness of the music. Range is [0.0, 1.0]. */
    brightness?: number;
    /** Scale of the generated music. */
    scale?: Scale;
    /** Whether the audio output should contain bass. */
    muteBass?: boolean;
    /** Whether the audio output should contain drums. */
    muteDrums?: boolean;
    /** Whether the audio output should contain only bass and drums. */
    onlyBassAndDrums?: boolean;
    /** The mode of music generation. Default mode is QUALITY. */
    musicGenerationMode?: MusicGenerationMode;
}

/** The playback control signal to apply to the music generation. */
export declare enum LiveMusicPlaybackControl {
    /**
     * This value is unused.
     */
    PLAYBACK_CONTROL_UNSPECIFIED = "PLAYBACK_CONTROL_UNSPECIFIED",
    /**
     * Start generating the music.
     */
    PLAY = "PLAY",
    /**
     * Hold the music generation. Use PLAY to resume from the current position.
     */
    PAUSE = "PAUSE",
    /**
     * Stop the music generation and reset the context (prompts retained).
     Use PLAY to restart the music generation.
     */
    STOP = "STOP",
    /**
     * Reset the context of the music generation without stopping it.
     Retains the current prompts and config.
     */
    RESET_CONTEXT = "RESET_CONTEXT"
}

/** Server update generated by the model in response to client messages.

 Content is generated as quickly as possible, and not in real time.
 Clients may choose to buffer and play it out in real time. */
export declare interface LiveMusicServerContent {
    /** The audio chunks that the model has generated. */
    audioChunks?: AudioChunk[];
}

/** Response message for the LiveMusicClientMessage call. */
export declare class LiveMusicServerMessage {
    /** Message sent in response to a `LiveMusicClientSetup` message from the client.
     Clients should wait for this message before sending any additional messages. */
    setupComplete?: LiveMusicServerSetupComplete;
    /** Content generated by the model in response to client messages. */
    serverContent?: LiveMusicServerContent;
    /** A prompt that was filtered with the reason. */
    filteredPrompt?: LiveMusicFilteredPrompt;
    /**
     * Returns the first audio chunk from the server content, if present.
     *
     * @remarks
     * If there are no audio chunks in the response, undefined will be returned.
     */
    get audioChunk(): AudioChunk | undefined;
}

/** Sent in response to a `LiveMusicClientSetup` message from the client. */
export declare interface LiveMusicServerSetupComplete {
}

/**
 Represents a connection to the API.

 @experimental
 */
export declare class LiveMusicSession {
    readonly conn: WebSocket_2;
    private readonly apiClient;
    constructor(conn: WebSocket_2, apiClient: ApiClient);
    /**
     Sets inputs to steer music generation. Updates the session's current
     weighted prompts.

     @param params - Contains one property, `weightedPrompts`.

     - `weightedPrompts` to send to the model; weights are normalized to
     sum to 1.0.

     @experimental
     */
    setWeightedPrompts(params: types.LiveMusicSetWeightedPromptsParameters): Promise<void>;
    /**
     Sets a configuration to the model. Updates the session's current
     music generation config.

     @param params - Contains one property, `musicGenerationConfig`.

     - `musicGenerationConfig` to set in the model. Passing an empty or
     undefined config to the model will reset the config to defaults.

     @experimental
     */
    setMusicGenerationConfig(params: types.LiveMusicSetConfigParameters): Promise<void>;
    private sendPlaybackControl;
    /**
     * Start the music stream.
     *
     * @experimental
     */
    play(): void;
    /**
     * Temporarily halt the music stream. Use `play` to resume from the current
     * position.
     *
     * @experimental
     */
    pause(): void;
    /**
     * Stop the music stream and reset the state. Retains the current prompts
     * and config.
     *
     * @experimental
     */
    stop(): void;
    /**
     * Resets the context of the music generation without stopping it.
     * Retains the current prompts and config.
     *
     * @experimental
     */
    resetContext(): void;
    /**
     Terminates the WebSocket connection.

     @experimental
     */
    close(): void;
}

/** Parameters for setting config for the live music API. */
export declare interface LiveMusicSetConfigParameters {
    /** Configuration for music generation. */
    musicGenerationConfig: LiveMusicGenerationConfig;
}

/** Parameters for setting weighted prompts for the live music API. */
export declare interface LiveMusicSetWeightedPromptsParameters {
    /** A map of text prompts to weights to use for the generation request. */
    weightedPrompts: WeightedPrompt[];
}

/** Prompts and config used for generating this audio chunk. */
export declare interface LiveMusicSourceMetadata {
    /** Weighted prompts for generating this audio chunk. */
    clientContent?: LiveMusicClientContent;
    /** Music generation config for generating this audio chunk. */
    musicGenerationConfig?: LiveMusicGenerationConfig;
}

/** Parameters for sending client content to the live API. */
export declare interface LiveSendClientContentParameters {
    /** Client content to send to the session. */
    turns?: ContentListUnion;
    /** If true, indicates that the server content generation should start with
     the currently accumulated prompt. Otherwise, the server will await
     additional messages before starting generation. */
    turnComplete?: boolean;
}

/** Parameters for sending realtime input to the live API. */
export declare interface LiveSendRealtimeInputParameters {
    /** Realtime input to send to the session. */
    media?: BlobImageUnion;
    /** The realtime audio input stream. */
    audio?: Blob_2;
    /**
     Indicates that the audio stream has ended, e.g. because the microphone was
     turned off.

     This should only be sent when automatic activity detection is enabled
     (which is the default).

     The client can reopen the stream by sending an audio message.
     */
    audioStreamEnd?: boolean;
    /** The realtime video input stream. */
    video?: BlobImageUnion;
    /** The realtime text input stream. */
    text?: string;
    /** Marks the start of user activity. */
    activityStart?: ActivityStart;
    /** Marks the end of user activity. */
    activityEnd?: ActivityEnd;
}

/** Parameters for sending tool responses to the live API. */
export declare class LiveSendToolResponseParameters {
    /** Tool responses to send to the session. */
    functionResponses: FunctionResponse[] | FunctionResponse;
}

/** Incremental server update generated by the model in response to client messages.

 Content is generated as quickly as possible, and not in real time. Clients
 may choose to buffer and play it out in real time. */
export declare interface LiveServerContent {
    /** The content that the model has generated as part of the current conversation with the user. */
    modelTurn?: Content;
    /** If true, indicates that the model is done generating. Generation will only start in response to additional client messages. Can be set alongside `content`, indicating that the `content` is the last in the turn. */
    turnComplete?: boolean;
    /** If true, indicates that a client message has interrupted current model generation. If the client is playing out the content in realtime, this is a good signal to stop and empty the current queue. */
    interrupted?: boolean;
    /** Metadata returned to client when grounding is enabled. */
    groundingMetadata?: GroundingMetadata;
    /** If true, indicates that the model is done generating. When model is
     interrupted while generating there will be no generation_complete message
     in interrupted turn, it will go through interrupted > turn_complete.
     When model assumes realtime playback there will be delay between
     generation_complete and turn_complete that is caused by model
     waiting for playback to finish. If true, indicates that the model
     has finished generating all content. This is a signal to the client
     that it can stop sending messages. */
    generationComplete?: boolean;
    /** Input transcription. The transcription is independent to the model
     turn which means it doesn’t imply any ordering between transcription and
     model turn. */
    inputTranscription?: Transcription;
    /** Low latency transcription updated while the user is speaking. */
    interimInputTranscription?: Transcription;
    /** Output transcription. The transcription is independent to the model
     turn which means it doesn’t imply any ordering between transcription and
     model turn.
     */
    outputTranscription?: Transcription;
    /** Metadata related to url context retrieval tool. */
    urlContextMetadata?: UrlContextMetadata;
    /** Reason for the turn is complete. */
    turnCompleteReason?: TurnCompleteReason;
    /** If true, indicates that the model is not generating content because
     it is waiting for more input from the user, e.g. because it expects the
     user to continue talking. */
    waitingForInput?: boolean;
    /** The current activity status of the live session. Always sent alongside `turn_complete`. */
    interactionStatus?: InteractionStatus;
}

/** Server will not be able to service client soon. */
export declare interface LiveServerGoAway {
    /** The remaining time before the connection will be terminated as ABORTED. The minimal time returned here is specified differently together with the rate limits for a given model. */
    timeLeft?: string;
}

/** Response message for API call. */
export declare class LiveServerMessage {
    /** Sent in response to a `LiveClientSetup` message from the client. */
    setupComplete?: LiveServerSetupComplete;
    /** Content generated by the model in response to client messages. */
    serverContent?: LiveServerContent;
    /** Request for the client to execute the `function_calls` and return the responses with the matching `id`s. */
    toolCall?: LiveServerToolCall;
    /** Notification for the client that a previously issued `ToolCallMessage` with the specified `id`s should have been not executed and should be cancelled. */
    toolCallCancellation?: LiveServerToolCallCancellation;
    /** Usage metadata about model response(s). */
    usageMetadata?: UsageMetadata;
    /** Server will disconnect soon. */
    goAway?: LiveServerGoAway;
    /** Update of the session resumption state. */
    sessionResumptionUpdate?: LiveServerSessionResumptionUpdate;
    /** Voice activity detection signal. Allowlisted only. */
    voiceActivityDetectionSignal?: VoiceActivityDetectionSignal;
    /** Voice activity signal. */
    voiceActivity?: VoiceActivity;
    /**
     * Returns the concatenation of all text parts from the server content if present.
     *
     * @remarks
     * If there are non-text parts in the response, the concatenation of all text
     * parts will be returned, and a warning will be logged.
     */
    get text(): string | undefined;
    /**
     * Returns the concatenation of all inline data parts from the server content if present.
     *
     * @remarks
     * If there are non-inline data parts in the
     * response, the concatenation of all inline data parts will be returned, and
     * a warning will be logged.
     */
    get data(): string | undefined;
}

/** Update of the session resumption state.

 Only sent if `session_resumption` was set in the connection config. */
export declare interface LiveServerSessionResumptionUpdate {
    /** New handle that represents state that can be resumed. Empty if `resumable`=false. */
    newHandle?: string;
    /** True if session can be resumed at this point. It might be not possible to resume session at some points. In that case we send update empty new_handle and resumable=false. Example of such case could be model executing function calls or just generating. Resuming session (using previous session token) in such state will result in some data loss. */
    resumable?: boolean;
    /** Index of last message sent by client that is included in state represented by this SessionResumptionToken. Only sent when `SessionResumptionConfig.transparent` is set.

     Presence of this index allows users to transparently reconnect and avoid issue of losing some part of realtime audio input/video. If client wishes to temporarily disconnect (for example as result of receiving GoAway) they can do it without losing state by buffering messages sent since last `SessionResumptionTokenUpdate`. This field will enable them to limit buffering (avoid keeping all requests in RAM).

     Note: This should not be used for when resuming a session at some time later -- in those cases partial audio and video frames are likely not needed. */
    lastConsumedClientMessageIndex?: string;
}

/** Sent in response to a `LiveGenerateContentSetup` message from the client. */
export declare interface LiveServerSetupComplete {
    /** The session id of the live session. */
    sessionId?: string;
    /** Signature of the verified consent audio. This is populated when the
     request has a ReplicatedVoiceConfig with consent_audio set, if the consent
     verification was successful. This may be used in a subsequent request
     instead of the consent_audio to verify the same consent. */
    voiceConsentSignature?: VoiceConsentSignature;
}

/** Request for the client to execute the `function_calls` and return the responses with the matching `id`s. */
export declare interface LiveServerToolCall {
    /** The function call to be executed. */
    functionCalls?: FunctionCall[];
}

/** Notification for the client that a previously issued `ToolCallMessage` with the specified `id`s should have been not executed and should be cancelled.

 If there were side-effects to those tool calls, clients may attempt to undo
 the tool calls. This message occurs only in cases where the clients interrupt
 server turns. */
export declare interface LiveServerToolCallCancellation {
    /** The ids of the tool calls to be cancelled. */
    ids?: string[];
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare interface Logger {
    group(label?: string): void;
    groupEnd(): void;
    log(message: any, ...args: any[]): void;
}

/** The log probabilities of the tokens generated by the model. This is useful for understanding the model's confidence in its predictions and for debugging. For example, you can use log probabilities to identify when the model is making a less confident prediction or to explore alternative responses that the model considered. A low log probability can also indicate that the model is "hallucinating" or generating factually incorrect information. */
export declare interface LogprobsResult {
    /** A list of the chosen candidate tokens at each decoding step. The length of this list is equal to the total number of decoding steps. Note that the chosen candidate might not be in `top_candidates`. */
    chosenCandidates?: LogprobsResultCandidate[];
    /** A list of the top candidate tokens at each decoding step. The length of this list is equal to the total number of decoding steps. */
    topCandidates?: LogprobsResultTopCandidates[];
    /** Sum of log probabilities for all tokens. This field is not supported in Vertex AI. */
    logProbabilitySum?: number;
}

/** A single token and its associated log probability. */
export declare interface LogprobsResultCandidate {
    /** The log probability of this token. A higher value indicates that the model was more confident in this token. The log probability can be used to assess the relative likelihood of different tokens and to identify when the model is uncertain. */
    logProbability?: number;
    /** The token's string representation. */
    token?: string;
    /** The token's numerical ID. While the `token` field provides the string representation of the token, the `token_id` is the numerical representation that the model uses internally. This can be useful for developers who want to build custom logic based on the model's vocabulary. */
    tokenId?: number;
}

/** A list of the top candidate tokens and their log probabilities at each decoding step. This can be used to see what other tokens the model considered. */
export declare interface LogprobsResultTopCandidates {
    /** The list of candidate tokens, sorted by log probability in descending order. */
    candidates?: LogprobsResultCandidate[];
}

/** Configuration for a Mask reference image. */
export declare interface MaskReferenceConfig {
    /** Prompts the model to generate a mask instead of you needing to
     provide one (unless MASK_MODE_USER_PROVIDED is used). */
    maskMode?: MaskReferenceMode;
    /** A list of up to 5 class ids to use for semantic segmentation.
     Automatically creates an image mask based on specific objects. */
    segmentationClasses?: number[];
    /** Dilation percentage of the mask provided.
     Float between 0 and 1. */
    maskDilation?: number;
}

/** A mask reference image.

 This encapsulates either a mask image provided by the user and configs for
 the user provided mask, or only config parameters for the model to generate
 a mask.

 A mask image is an image whose non-zero values indicate where to edit the base
 image. If the user provides a mask image, the mask must be in the same
 dimensions as the raw image. */
export declare class MaskReferenceImage {
    /** The reference image for the editing operation. */
    referenceImage?: Image_2;
    /** The id of the reference image. */
    referenceId?: number;
    /** The type of the reference image. Only set by the SDK. */
    referenceType?: string;
    /** Configuration for the mask reference image. */
    config?: MaskReferenceConfig;
    /** Internal method to convert to ReferenceImageAPIInternal. */
    toReferenceImageAPI(): ReferenceImageAPIInternal;
}

/** Enum representing the mask mode of a mask reference image. */
export declare enum MaskReferenceMode {
    MASK_MODE_DEFAULT = "MASK_MODE_DEFAULT",
    MASK_MODE_USER_PROVIDED = "MASK_MODE_USER_PROVIDED",
    MASK_MODE_BACKGROUND = "MASK_MODE_BACKGROUND",
    MASK_MODE_FOREGROUND = "MASK_MODE_FOREGROUND",
    MASK_MODE_SEMANTIC = "MASK_MODE_SEMANTIC"
}

/** Match operation to use for evaluating rewards. This enum is not supported in Gemini API. */
export declare enum MatchOperation {
    /**
     * Default value. A user error will be returned if not set.
     */
    MATCH_OPERATION_UNSPECIFIED = "MATCH_OPERATION_UNSPECIFIED",
    /**
     * Equivalent to [GoogleSQL](https://cloud.google.com/bigquery/docs/reference/standard-sql/string_functions#regexp_contains) `REGEX_CONTAINS(target, expression)`.
     */
    REGEX_CONTAINS = "REGEX_CONTAINS",
    /**
     * The match operation returns `true` if expression is a substring of the target.
     */
    PARTIAL_MATCH = "PARTIAL_MATCH",
    /**
     * The match operation returns `true` expression is an exact match of the target.
     */
    EXACT_MATCH = "EXACT_MATCH"
}

declare type MCPServer$ = MCPServer;

/**
 * A MCPServer is a server that can be called by the model to perform actions.
 */
declare type MCPServer = {
    /**
     * The allowed tools.
     */
    allowed_tools?: Array<AllowedTools> | undefined;
    /**
     * Optional: Fields for authentication headers, timeouts, etc., if needed.
     */
    headers?: {
        [k: string]: string;
    } | undefined;
    /**
     * The name of the MCPServer.
     */
    name?: string | undefined;
    type: "mcp_server";
    /**
     * The full URL for the MCPServer endpoint.
     *
     * @remarks
     * Example: "https://api.example.com/mcp"
     */
    url?: string | undefined;
};

/** A MCPServer is a server that can be called by the model to perform actions. It is a server that implements the MCP protocol. This data type is not supported in Vertex AI. */
export declare interface McpServer {
    /** The name of the MCPServer. */
    name?: string;
    /** A transport that can stream HTTP requests and responses. */
    streamableHttpTransport?: StreamableHttpTransport;
}

declare type MCPServerToolCall$ = MCPServerToolCallDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type MCPServerToolCallDelta = {
    arguments: {
        [k: string]: any;
    };
    name: string;
    server_name: string;
    type: "mcp_server_tool_call";
};

declare type MCPServerToolCallStep$ = MCPServerToolCallStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * MCPServer tool call step.
 */
declare type MCPServerToolCallStep = {
    /**
     * Required. The JSON object of arguments for the function.
     */
    arguments: {
        [k: string]: any;
    };
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * Required. The name of the tool which was called.
     */
    name: string;
    /**
     * Required. The name of the used MCP server.
     */
    server_name: string;
    type: "mcp_server_tool_call";
};

declare type MCPServerToolResult$ = MCPServerToolResultDelta;

declare type MCPServerToolResultDelta = {
    name?: string | undefined;
    result: Array<FunctionResultSubcontent> | MCPServerToolResultDeltaResult | string;
    server_name?: string | undefined;
    type: "mcp_server_tool_result";
};

declare type MCPServerToolResultDeltaResult = {};

declare type MCPServerToolResultDeltaResultUnion = Array<FunctionResultSubcontent> | MCPServerToolResultDeltaResult | string;

declare type MCPServerToolResultStep$ = MCPServerToolResultStep;

/**
 * MCPServer tool result step.
 */
declare type MCPServerToolResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * Name of the tool which is called for this specific tool call.
     */
    name?: string | undefined;
    /**
     * Required. The output from the MCP server call. Can be simple text or rich content.
     */
    result: Array<FunctionResultSubcontent> | MCPServerToolResultStepResult | string;
    /**
     * The name of the used MCP server.
     */
    server_name?: string | undefined;
    type: "mcp_server_tool_result";
};

declare type MCPServerToolResultStepResult = {};

/**
 * Required. The output from the MCP server call. Can be simple text or rich content.
 */
declare type MCPServerToolResultStepResultUnion = Array<FunctionResultSubcontent> | MCPServerToolResultStepResult | string;

/**
 * Creates a McpCallableTool from MCP clients and an optional config.
 *
 * The callable tool can invoke the MCP clients with given function call
 * arguments. (often for automatic function calling).
 * Use the config to modify tool parameters such as behavior.
 *
 * @experimental Built-in MCP support is an experimental feature, may change in future
 * versions.
 */
export declare function mcpToTool(...args: [...Client[], CallableToolConfig | Client]): CallableTool;

/** The modality that this token count applies to. */
export declare enum MediaModality {
    /**
     * When a modality is not specified, it is treated as `TEXT`.
     */
    MODALITY_UNSPECIFIED = "MODALITY_UNSPECIFIED",
    /**
     * The `Part` contains plain text.
     */
    TEXT = "TEXT",
    /**
     * The `Part` contains an image.
     */
    IMAGE = "IMAGE",
    /**
     * The `Part` contains a video.
     */
    VIDEO = "VIDEO",
    /**
     * The `Part` contains audio.
     */
    AUDIO = "AUDIO",
    /**
     * The `Part` contains a document, such as a PDF.
     */
    DOCUMENT = "DOCUMENT"
}

/** How the model processes input media for understanding. */
export declare enum MediaProcessing {
    /**
     * Default. Uses model-specific processing
     */
    MEDIA_PROCESSING_UNSPECIFIED = "MEDIA_PROCESSING_UNSPECIFIED",
    /**
     * Fixed-rate frame extraction. All frames placed in context.
     */
    STATIC = "STATIC",
    /**
     * Model-driven dynamic navigation. Recommended for most use cases.
     */
    AGENTIC = "AGENTIC"
}

declare type MediaProcessing_2 = StaticMediaProcessing;

/** The media resolution to use. */
export declare enum MediaResolution {
    /**
     * Media resolution has not been set
     */
    MEDIA_RESOLUTION_UNSPECIFIED = "MEDIA_RESOLUTION_UNSPECIFIED",
    /**
     * Media resolution set to low (64 tokens).
     */
    MEDIA_RESOLUTION_LOW = "MEDIA_RESOLUTION_LOW",
    /**
     * Media resolution set to medium (256 tokens).
     */
    MEDIA_RESOLUTION_MEDIUM = "MEDIA_RESOLUTION_MEDIUM",
    /**
     * Media resolution set to high (zoomed reframing with 256 tokens).
     */
    MEDIA_RESOLUTION_HIGH = "MEDIA_RESOLUTION_HIGH"
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type MediaResolution_2 = "low" | "medium" | "high" | "ultra_high" | (string & {});

declare type Metadata$ = StepDeltaMetadata;

/**
 * Optional. The method for blocking content. If not specified, the default
 *
 * @remarks
 * behavior is to use the probability score.
 */
declare type Method = "severity" | "probability" | (string & {});

/** Server content modalities. */
export declare enum Modality {
    /**
     * The modality is unspecified.
     */
    MODALITY_UNSPECIFIED = "MODALITY_UNSPECIFIED",
    /**
     * Indicates the model should return text
     */
    TEXT = "TEXT",
    /**
     * Indicates the model should return images.
     */
    IMAGE = "IMAGE",
    /**
     * Indicates the model should return audio.
     */
    AUDIO = "AUDIO",
    /**
     * Indicates the model should return video.
     */
    VIDEO = "VIDEO"
}

/** Represents a breakdown of token usage by modality. This message is used in CountTokensResponse and GenerateContentResponse.UsageMetadata to provide a detailed view of how many tokens are used by each modality (e.g., text, image, video) in a request. This is particularly useful for multimodal models, allowing you to track and manage token consumption for billing and quota purposes. */
export declare interface ModalityTokenCount {
    /** The modality that this token count applies to. */
    modality?: MediaModality;
    /** The number of tokens counted for this modality. */
    tokenCount?: number;
}

/**
 * The token count for a single response modality.
 */
declare type ModalityTokens = {
    modality?: ResponseModality | undefined;
    /**
     * Number of tokens for the modality.
     */
    tokens?: number | undefined;
};

/**
 * The mode of the find session.
 */
declare type Mode = "scan" | "verify" | (string & {});

declare type Model$ = Model_2;

/** A trained machine learning model. */
export declare interface Model {
    /** Resource name of the model. */
    name?: string;
    /** Display name of the model. */
    displayName?: string;
    /** Description of the model. */
    description?: string;
    /** Version ID of the model. A new version is committed when a new
     model version is uploaded or trained under an existing model ID. The
     version ID is an auto-incrementing decimal number in string
     representation. */
    version?: string;
    /** List of deployed models created from this base model. Note that a
     model could have been deployed to endpoints in different locations. */
    endpoints?: Endpoint[];
    /** Labels with user-defined metadata to organize your models. */
    labels?: Record<string, string>;
    /** Information about the tuned model from the base model. */
    tunedModelInfo?: TunedModelInfo;
    /** The maximum number of input tokens that the model can handle. */
    inputTokenLimit?: number;
    /** The maximum number of output tokens that the model can generate. */
    outputTokenLimit?: number;
    /** List of actions that are supported by the model. */
    supportedActions?: string[];
    /** The default checkpoint id of a model version.
     */
    defaultCheckpointId?: string;
    /** The checkpoints of the model. */
    checkpoints?: Checkpoint[];
    /** Temperature value used for sampling set when the dataset was saved.
     This value is used to tune the degree of randomness. */
    temperature?: number;
    /** The maximum temperature value used for sampling set when the
     dataset was saved. This value is used to tune the degree of randomness. */
    maxTemperature?: number;
    /** Optional. Specifies the nucleus sampling threshold. The model
     considers only the smallest set of tokens whose cumulative probability is
     at least `top_p`. This helps generate more diverse and less repetitive
     responses. For example, a `top_p` of 0.9 means the model considers tokens
     until the cumulative probability of the tokens to select from reaches 0.9.
     It's recommended to adjust either temperature or `top_p`, but not both. */
    topP?: number;
    /** Optional. Specifies the top-k sampling threshold. The model
     considers only the top k most probable tokens for the next token. This can
     be useful for generating more coherent and less random text. For example,
     a `top_k` of 40 means the model will choose the next word from the 40 most
     likely words. */
    topK?: number;
    /** Whether the model supports thinking features. If true, thoughts are
     returned only if the model supports thought and thoughts are available. */
    thinking?: boolean;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The model that will complete your prompt.\n\nSee [models](https://ai.google.dev/gemini-api/docs/models) for additional details.
 */
declare type Model_2 = "gemma-4-26b-a4b-it" | "gemma-4-31b-it" | "gemini-flash-latest" | "gemini-flash-lite-latest" | "gemini-pro-latest" | "gemini-2.5-flash" | "gemini-2.5-pro" | "gemini-2.5-flash-lite" | "gemini-3.5-flash-lite" | "gemini-2.5-flash-image" | "gemini-3-flash-preview" | "gemini-3.1-pro-preview" | "gemini-3.1-pro-preview-customtools" | "gemini-3.1-flash-lite" | "gemini-3.1-flash-lite-image" | "gemini-3-pro-image" | "nano-banana-pro-preview" | "gemini-3.1-flash-image" | "gemini-nano-banana-2.1" | "gemini-3.1-flash-tts-preview" | "gemini-3.5-flash" | "gemini-3.6-flash" | "gemini-3.7-flash" | "gemini-3.8-flash" | "gemini-4-argon" | "gemini-3.8-flash-tts" | "gemini-3.8-flash-lite-tts" | "lyria-3-clip-preview" | "lyria-3-pro-preview" | "gemini-robotics-er-1.6-preview" | "gemini-robotics-er-2-preview" | "lyria-3.5" | "gemini-omni-1.1-flash" | "gemini-omni-flash-preview" | (string & {});

/** Configuration for Model Armor. Model Armor is a Google Cloud service that provides safety and security filtering for prompts and responses. It helps protect your AI applications from risks such as harmful content, sensitive data leakage, and prompt injection attacks. This data type is not supported in Gemini API. */
export declare interface ModelArmorConfig {
    /** Optional. The resource name of the Model Armor template to use for prompt screening. A Model Armor template is a set of customized filters and thresholds that define how Model Armor screens content. If specified, Model Armor will use this template to check the user's prompt for safety and security risks before it is sent to the model. The name must be in the format `projects/{project}/locations/{location}/templates/{template}`. */
    promptTemplateName?: string;
    /** Optional. The resource name of the Model Armor template to use for response screening. A Model Armor template is a set of customized filters and thresholds that define how Model Armor screens content. If specified, Model Armor will use this template to check the model's response for safety and security risks before it is returned to the user. The name must be in the format `projects/{project}/locations/{location}/templates/{template}`. */
    responseTemplateName?: string;
}

declare type ModelOutputStep$ = ModelOutputStep;

/**
 * Output generated by the model.
 */
declare type ModelOutputStep = {
    content?: Array<Content_2> | undefined;
    /**
     * The `Status` type defines a logical error model that is suitable for
     *
     * @remarks
     * different programming environments, including REST APIs and RPC APIs. It is
     * used by [gRPC](https://github.com/grpc). Each `Status` message contains
     * three pieces of data: error code, error message, and error details.
     *
     * You can find out more about this error model and how to work with it in the
     * [API Design Guide](https://cloud.google.com/apis/design/errors).
     */
    error?: Status | undefined;
    type: "model_output";
};

export declare class Models extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    private static loggedGenerateImagesWarning;
    private static loggedEditImageWarning;
    private static loggedGenerateVideosWarning;
    /**
     * Calculates embeddings for the given contents.
     *
     * @param params - The parameters for embedding contents.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.embedContent({
     *  model: 'text-embedding-004',
     *  contents: [
     *    'What is your name?',
     *    'What is your favorite color?',
     *  ],
     *  config: {
     *    outputDimensionality: 64,
     *  },
     * });
     * console.log(response);
     * ```
     */
    embedContent: (params: types.EmbedContentParameters) => Promise<types.EmbedContentResponse>;
    private generateContentWithContinuation;
    private generateContentStreamWithContinuation;
    /**
     * Makes an API request to generate content with a given model.
     *
     * For the `model` parameter, supported formats for Gemini Enterprise Agent Platform API include:
     * - The Gemini model ID, for example: 'gemini-flash-latest'
     * - The full resource name starts with 'projects/', for example:
     *  'projects/my-project-id/locations/us-central1/publishers/google/models/gemini-flash-latest'
     * - The partial resource name with 'publishers/', for example:
     *  'publishers/google/models/gemini-flash-latest' or
     *  'publishers/meta/models/llama-3.1-405b-instruct-maas'
     * - `/` separated publisher and model name, for example:
     * 'google/gemini-flash-latest' or 'meta/llama-3.1-405b-instruct-maas'
     *
     * For the `model` parameter, supported formats for Gemini API include:
     * - The Gemini model ID, for example: 'gemini-flash-latest'
     * - The model name starts with 'models/', for example:
     *  'models/gemini-flash-latest'
     * - For tuned models, the model name starts with 'tunedModels/',
     * for example:
     * 'tunedModels/1234567890123456789'
     *
     * Some models support multimodal input and output. Automatic continuation
     * (`config.automaticContinuation`) is enabled by default (`true`); set
     * `config.automaticContinuation = false` to disable it.
     *
     * @param params - The parameters for generating content.
     * @return The response from generating content.
     *
     * @example
     * ```ts
     * const response = await ai.models.generateContent({
     *   model: 'gemini-flash-latest',
     *   contents: 'why is the sky blue?',
     *   config: {
     *     candidateCount: 2,
     *   }
     * });
     * console.log(response);
     * ```
     */
    generateContent: (params: types.GenerateContentParameters) => Promise<types.GenerateContentResponse>;
    /**
     * This logic is needed for GenerateContentConfig only.
     * Previously we made GenerateContentConfig.responseSchema field to accept
     * unknown. Since v1.9.0, we switch to use backend JSON schema support.
     * To maintain backward compatibility, we move the data that was treated as
     * JSON schema from the responseSchema field to the responseJsonSchema field.
     */
    private maybeMoveToResponseJsonSchema;
    /**
     * Makes an API request to generate content with a given model and yields the
     * response in chunks.
     *
     * For the `model` parameter, supported formats for Gemini Enterprise Agent Platform API include:
     * - The Gemini model ID, for example: 'gemini-flash-latest'
     * - The full resource name starts with 'projects/', for example:
     *  'projects/my-project-id/locations/us-central1/publishers/google/models/gemini-flash-latest'
     * - The partial resource name with 'publishers/', for example:
     *  'publishers/google/models/gemini-flash-latest' or
     *  'publishers/meta/models/llama-3.1-405b-instruct-maas'
     * - `/` separated publisher and model name, for example:
     * 'google/gemini-flash-latest' or 'meta/llama-3.1-405b-instruct-maas'
     *
     * For the `model` parameter, supported formats for Gemini API include:
     * - The Gemini model ID, for example: 'gemini-flash-latest'
     * - The model name starts with 'models/', for example:
     *  'models/gemini-flash-latest'
     * - For tuned models, the model name starts with 'tunedModels/',
     * for example:
     *  'tunedModels/1234567890123456789'
     *
     * Some models support multimodal input and output. Automatic continuation
     * (`config.automaticContinuation`) is enabled by default (`true`); set
     * `config.automaticContinuation = false` to disable it.
     *
     * @param params - The parameters for generating content with streaming response.
     * @return The response from generating content.
     *
     * @example
     * ```ts
     * const response = await ai.models.generateContentStream({
     *   model: 'gemini-flash-latest',
     *   contents: 'why is the sky blue?',
     *   config: {
     *     maxOutputTokens: 200,
     *   }
     * });
     * for await (const chunk of response) {
     *   console.log(chunk);
     * }
     * ```
     */
    generateContentStream: (params: types.GenerateContentParameters) => Promise<AsyncGenerator<types.GenerateContentResponse>>;
    /**
     * Transforms the CallableTools in the parameters to be simply Tools, it
     * copies the params into a new object and replaces the tools, it does not
     * modify the original params. Also sets the MCP usage header if there are
     * MCP tools in the parameters.
     */
    private processParamsMaybeAddMcpUsage;
    private initAfcToolsMap;
    private processAfcStream;
    /**
     * Generates an image based on a text description and configuration.
     *
     * @param params - The parameters for generating images.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await client.models.generateImages({
     *  model: 'imagen-4.0-generate-001',
     *  prompt: 'Robot holding a red skateboard',
     *  config: {
     *    numberOfImages: 1,
     *    includeRaiReason: true,
     *  },
     * });
     * console.log(response?.generatedImages?.[0]?.image?.imageBytes);
     * ```
     */
    generateImages: (params: types.GenerateImagesParameters) => Promise<types.GenerateImagesResponse>;
    list: (params?: types.ListModelsParameters) => Promise<Pager<types.Model>>;
    /**
     * Edits an image based on a prompt, list of reference images, and configuration.
     *
     * @param params - The parameters for editing an image.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await client.models.editImage({
     *  model: 'imagen-3.0-capability-001',
     *  prompt: 'Generate an image containing a mug with the product logo [1] visible on the side of the mug.',
     *  referenceImages: [subjectReferenceImage]
     *  config: {
     *    numberOfImages: 1,
     *    includeRaiReason: true,
     *  },
     * });
     * console.log(response?.generatedImages?.[0]?.image?.imageBytes);
     * ```
     */
    editImage: (params: types.EditImageParameters) => Promise<types.EditImageResponse>;
    /**
     * Upscales an image based on an image, upscale factor, and configuration.
     * Only supported in Gemini Enterprise Agent Platform currently.
     *
     * @param params - The parameters for upscaling an image.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await client.models.upscaleImage({
     *  model: 'imagen-4.0-upscale-preview',
     *  image: image,
     *  upscaleFactor: 'x2',
     *  config: {
     *    includeRaiReason: true,
     *  },
     * });
     * console.log(response?.generatedImages?.[0]?.image?.imageBytes);
     * ```
     */
    upscaleImage: (params: types.UpscaleImageParameters) => Promise<types.UpscaleImageResponse>;
    /**
     *  Generates videos based on a text description and configuration.
     *
     * @param params - The parameters for generating videos.
     * @return A Promise<GenerateVideosOperation> which allows you to track the progress and eventually retrieve the generated videos using the operations.get method.
     *
     * @example
     * ```ts
     * const operation = await ai.models.generateVideos({
     *  model: 'veo-2.0-generate-001',
     *  source: {
     *    prompt: 'A neon hologram of a cat driving at top speed',
     *  },
     *  config: {
     *    numberOfVideos: 1
     * });
     *
     * while (!operation.done) {
     *   await new Promise(resolve => setTimeout(resolve, 10000));
     *   operation = await ai.operations.getVideosOperation({operation: operation});
     * }
     *
     * console.log(operation.response?.generatedVideos?.[0]?.video?.uri);
     * ```
     */
    generateVideos: (params: types.GenerateVideosParameters) => Promise<types.GenerateVideosOperation>;
    private generateContentInternal;
    private generateContentStreamInternal;
    /**
     * Calculates embeddings for the given contents. Only text is supported.
     *
     * @param params - The parameters for embedding contents.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.embedContent({
     *  model: 'text-embedding-004',
     *  contents: [
     *    'What is your name?',
     *    'What is your favorite color?',
     *  ],
     *  config: {
     *    outputDimensionality: 64,
     *  },
     * });
     * console.log(response);
     * ```
     */
    private embedContentInternal;
    /**
     * Private method for generating images.
     */
    private generateImagesInternal;
    /**
     * Private method for editing an image.
     */
    private editImageInternal;
    /**
     * Private method for upscaling an image.
     */
    private upscaleImageInternal;
    /**
     * Recontextualizes an image.
     *
     * There is one type of recontextualization currently supported:
     * 1) Virtual Try-On: Generate images of persons modeling fashion products.
     *
     * @param params - The parameters for recontextualizing an image.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.recontextImage({
     *  model: 'virtual-try-on-001',
     *  source: {
     *    personImage: personImage,
     *    productImages: [productImage],
     *  },
     *  config: {
     *    numberOfImages: 1,
     *  },
     * });
     * console.log(response?.generatedImages?.[0]?.image?.imageBytes);
     * ```
     */
    recontextImage(params: types.RecontextImageParameters): Promise<types.RecontextImageResponse>;
    /**
     * Segments an image, creating a mask of a specified area.
     *
     * @param params - The parameters for segmenting an image.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.segmentImage({
     *  model: 'image-segmentation-001',
     *  source: {
     *    image: image,
     *  },
     *  config: {
     *    mode: 'foreground',
     *  },
     * });
     * console.log(response?.generatedMasks?.[0]?.mask?.imageBytes);
     * ```
     */
    segmentImage(params: types.SegmentImageParameters): Promise<types.SegmentImageResponse>;
    /**
     * Fetches information about a model by name.
     *
     * @example
     * ```ts
     * const modelInfo = await ai.models.get({model: 'gemini-flash-latest'});
     * ```
     */
    get(params: types.GetModelParameters): Promise<types.Model>;
    private listInternal;
    /**
     * Updates a tuned model by its name.
     *
     * @param params - The parameters for updating the model.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.update({
     *   model: 'tuned-model-name',
     *   config: {
     *     displayName: 'New display name',
     *     description: 'New description',
     *   },
     * });
     * ```
     */
    update(params: types.UpdateModelParameters): Promise<types.Model>;
    /**
     * Deletes a tuned model by its name.
     *
     * @param params - The parameters for deleting the model.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.delete({model: 'tuned-model-name'});
     * ```
     */
    delete(params: types.DeleteModelParameters): Promise<types.DeleteModelResponse>;
    /**
     * Counts the number of tokens in the given contents. Multimodal input is
     * supported for Gemini models.
     *
     * @param params - The parameters for counting tokens.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.countTokens({
     *  model: 'gemini-flash-latest',
     *  contents: 'The quick brown fox jumps over the lazy dog.'
     * });
     * console.log(response);
     * ```
     */
    countTokens(params: types.CountTokensParameters): Promise<types.CountTokensResponse>;
    /**
     * Given a list of contents, returns a corresponding TokensInfo containing
     * the list of tokens and list of token ids.
     *
     * This method is not supported by the Gemini Developer API.
     *
     * @param params - The parameters for computing tokens.
     * @return The response from the API.
     *
     * @example
     * ```ts
     * const response = await ai.models.computeTokens({
     *  model: 'gemini-flash-latest',
     *  contents: 'What is your name?'
     * });
     * console.log(response);
     * ```
     */
    computeTokens(params: types.ComputeTokensParameters): Promise<types.ComputeTokensResponse>;
    /**
     * Private method for generating videos.
     */
    private generateVideosInternal;
}

declare namespace models {
    export {
        Security
    }
}

/** Config for model selection. */
export declare interface ModelSelectionConfig {
    /** Options for feature selection preference. */
    featureSelectionPreference?: FeatureSelectionPreference;
}

/** The stage of the underlying model. This enum is not supported in Vertex AI. */
export declare enum ModelStage {
    /**
     * Unspecified model stage.
     */
    MODEL_STAGE_UNSPECIFIED = "MODEL_STAGE_UNSPECIFIED",
    /**
     * The underlying model is subject to lots of tunings.
     */
    UNSTABLE_EXPERIMENTAL = "UNSTABLE_EXPERIMENTAL",
    /**
     * Models in this stage are for experimental purposes only.
     */
    EXPERIMENTAL = "EXPERIMENTAL",
    /**
     * Models in this stage are more mature than experimental models.
     */
    PREVIEW = "PREVIEW",
    /**
     * Models in this stage are considered stable and ready for production use.
     */
    STABLE = "STABLE",
    /**
     * If the model is on this stage, it means that this model is on the path to deprecation in near future. Only existing customers can use this model.
     */
    LEGACY = "LEGACY",
    /**
     * Models in this stage are deprecated. These models cannot be used.
     */
    DEPRECATED = "DEPRECATED",
    /**
     * Models in this stage are retired. These models cannot be used.
     */
    RETIRED = "RETIRED"
}

/** The status of the underlying model. This is used to indicate the stage of the underlying model and the retirement time if applicable. This data type is not supported in Vertex AI. */
export declare interface ModelStatus {
    /** A message explaining the model status. */
    message?: string;
    /** The stage of the underlying model. */
    modelStage?: ModelStage;
    /** The time at which the model will be retired. */
    retirementTime?: string;
}

/** Configuration for a multi-speaker text-to-speech request. */
export declare interface MultiSpeakerVoiceConfig {
    /** Required. A list of configurations for the voices of the speakers. Exactly two speaker voice configurations must be provided. */
    speakerVoiceConfigs?: SpeakerVoiceConfig[];
}

/** The mode of music generation. */
export declare enum MusicGenerationMode {
    /**
     * Rely on the server default generation mode.
     */
    MUSIC_GENERATION_MODE_UNSPECIFIED = "MUSIC_GENERATION_MODE_UNSPECIFIED",
    /**
     * Steer text prompts to regions of latent space with higher quality
     music.
     */
    QUALITY = "QUALITY",
    /**
     * Steer text prompts to regions of latent space with a larger
     diversity of music.
     */
    DIVERSITY = "DIVERSITY",
    /**
     * Steer text prompts to regions of latent space more likely to
     generate music with vocals.
     */
    VOCALIZATION = "VOCALIZATION"
}

/**
 * Network configuration for the environment.
 */
declare type Network = EnvironmentNetworkEgressAllowlist | NetworkEnum;

declare type NetworkEnum = "disabled" | (string & {});

declare type OAuth2Config$ = OAuth2Config;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for OAuth2 credentials with automatic token refresh.
 */
declare type OAuth2Config = {
    /**
     * Required. OAuth2 client ID.
     */
    client_id: string;
    /**
     * Required. Input only. OAuth2 client secret. Write-only; never returned in responses.
     */
    client_secret: string;
    id: string;
    /**
     * Required. Input only. OAuth2 refresh token. Write-only; never returned in responses.
     */
    refresh_token: string;
    /**
     * Optional. List of OAuth2 scopes.
     */
    scopes?: Array<string> | undefined;
    /**
     * Required. OAuth2 token endpoint URL for refreshing access tokens.
     */
    token_url: string;
    type: "oauth2";
};

declare type OAuth2ConfigParams = Omit<CreateCredentialRequest, "body"> & OAuth2Config;

declare type OAuth2PasswordFlow = {
    username: string;
    password: string;
    client_id?: string | undefined;
    client_secret?: string | undefined;
    token_url: string;
};

declare type OAuth2UpdateConfig$ = OAuth2UpdateConfig;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for updating OAuth2 credentials.
 */
declare type OAuth2UpdateConfig = {
    /**
     * Optional. OAuth2 client ID.
     */
    client_id?: string | undefined;
    /**
     * Optional. Input only. OAuth2 client secret. Write-only; never returned in responses.
     */
    client_secret?: string | undefined;
    /**
     * Optional. Input only. OAuth2 refresh token. Write-only; never returned in responses.
     */
    refresh_token?: string | undefined;
    /**
     * Optional. List of OAuth2 scopes.
     */
    scopes?: Array<string> | undefined;
    /**
     * Optional. OAuth2 token endpoint URL for refreshing access tokens.
     */
    token_url?: string | undefined;
    type: "oauth2";
};

declare type OAuth2UpdateConfigParams = Omit<UpdateCredentialRequest, "id" | "body"> & OAuth2UpdateConfig;

/** A long-running operation. */
export declare interface Operation<T> {
    /** The server-assigned name, which is only unique within the same service that originally returns it. If you use the default HTTP mapping, the `name` should be a resource name ending with `operations/{unique_id}`. */
    name?: string;
    /** Service-specific metadata associated with the operation. It typically contains progress information and common metadata such as create time. Some services might not provide such metadata.  Any method that returns a long-running operation should document the metadata type, if any. */
    metadata?: Record<string, unknown>;
    /** If the value is `false`, it means the operation is still in progress. If `true`, the operation is completed, and either `error` or `response` is available. */
    done?: boolean;
    /** The error result of the operation in case of failure or cancellation. */
    error?: Record<string, unknown>;
    /** The response if the operation is successful. */
    response?: T;
    /**
     * Instantiates an Operation of the same type as the one being called with the fields set from the API response.
     */
    _fromAPIResponse({ apiResponse, _isVertexAI, }: OperationFromAPIResponseParameters): Operation<T>;
}

/** Parameters of the fromAPIResponse method of the Operation class. */
export declare interface OperationFromAPIResponseParameters {
    /** The API response to be converted to an Operation. */
    apiResponse: Record<string, unknown>;
    /** Whether the API response is from Vertex AI. */
    _isVertexAI: boolean;
}

/** Parameters for the get method of the operations module. */
export declare interface OperationGetParameters<T, U extends Operation<T>> {
    /** Used to override the default configuration. */
    config?: GetOperationConfig;
    /** The operation to be retrieved. */
    operation: U;
}

export declare class Operations extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    /**
     * Gets the status of a long-running operation.
     *
     * @param parameters The parameters for the get operation request.
     * @return The updated Operation object, with the latest status or result.
     */
    getVideosOperation(parameters: types.OperationGetParameters<types.GenerateVideosResponse, types.GenerateVideosOperation>): Promise<types.GenerateVideosOperation>;
    /**
     * Gets the status of a long-running operation.
     *
     * @param parameters The parameters for the get operation request.
     * @return The updated Operation object, with the latest status or result.
     */
    get<T, U extends types.Operation<T>>(parameters: types.OperationGetParameters<T, U>): Promise<types.Operation<T>>;
    private getVideosOperationInternal;
    private fetchPredictVideosOperationInternal;
}

declare namespace operations {
    export {
        CancelInteractionByIdGlobals,
        CancelInteractionByIdRequest,
        CreateAgentGlobals,
        CreateAgentRequest,
        CreateCredentialGlobals,
        CreateCredentialRequest,
        CreateEnvironmentGlobals,
        CreateEnvironmentRequest,
        CreateInteractionGlobals,
        CreateInteractionRequestBody,
        CreateInteractionRequest,
        CreateInteractionResponse,
        CreateTriggerGlobals,
        CreateTriggerRequest,
        CreateVoiceGlobals,
        CreateVoiceRequest,
        CreateWebhookGlobals,
        CreateWebhookRequest,
        DeleteAgentGlobals,
        DeleteAgentRequest,
        DeleteCredentialGlobals,
        DeleteCredentialRequest,
        DeleteEnvironmentGlobals,
        DeleteEnvironmentRequest,
        DeleteInteractionGlobals,
        DeleteInteractionRequest,
        DeleteTriggerGlobals,
        DeleteTriggerRequest,
        DeleteVoiceGlobals,
        DeleteVoiceRequest,
        DeleteWebhookGlobals,
        DeleteWebhookRequest,
        GetAgentGlobals,
        GetAgentRequest,
        GetCredentialGlobals,
        GetCredentialRequest,
        GetEnvironmentFilesGlobals,
        GetEnvironmentFilesRequest,
        GetEnvironmentGlobals,
        GetEnvironmentRequest,
        GetInteractionByIdGlobals,
        GetInteractionByIdRequest,
        GetInteractionByIdResponse,
        GetTriggerGlobals,
        GetTriggerRequest,
        GetVoiceGlobals,
        GetVoiceRequest,
        GetWebhookGlobals,
        GetWebhookRequest,
        ListAgentsGlobals,
        ListAgentsRequest,
        ListCredentialsGlobals,
        ListCredentialsRequest,
        ListEnvironmentsGlobals,
        ListEnvironmentsRequest,
        ListTriggerExecutionsGlobals,
        ListTriggerExecutionsRequest,
        ListTriggersGlobals,
        ListTriggersRequest,
        ListVoicesGlobals,
        ListVoicesRequest,
        ListWebhooksGlobals,
        ListWebhooksRequest,
        CancelInteractionByIdParams,
        CreateAgentParams,
        CreateCredentialParams,
        EnvironmentVariableConfigParams,
        HttpBearerConfigParams,
        OAuth2ConfigParams,
        CreateInteractionParams,
        CreateInteractionParamsNonStreaming,
        CreateInteractionParamsStreaming,
        CreateAgentInteractionParams,
        CreateAgentInteractionParamsNonStreaming,
        CreateAgentInteractionParamsStreaming,
        CreateModelInteractionParams,
        CreateModelInteractionParamsNonStreaming,
        CreateModelInteractionParamsStreaming,
        CreateTriggerParams,
        CreateWebhookParams,
        DeleteAgentParams,
        DeleteCredentialParams,
        DeleteEnvironmentParams,
        DeleteInteractionParams,
        DeleteTriggerParams,
        DeleteVoiceParams,
        DeleteWebhookParams,
        GetAgentParams,
        GetCredentialParams,
        GetEnvironmentFilesParams,
        GetEnvironmentParams,
        GetInteractionByIdParams,
        GetInteractionByIdParamsNonStreaming,
        GetInteractionByIdParamsStreaming,
        GetTriggerParams,
        GetVoiceParams,
        GetWebhookParams,
        ListAgentsParams,
        ListCredentialsParams,
        ListEnvironmentsParams_2 as ListEnvironmentsParams,
        ListTriggerExecutionsParams,
        ListTriggersParams,
        ListVoicesParams,
        ListWebhooksParams,
        RunTriggerParams,
        StartEnvironmentFileUploadParams,
        UpdateCredentialParams,
        EnvironmentVariableUpdateConfigParams,
        HttpBearerUpdateConfigParams,
        OAuth2UpdateConfigParams,
        UpdateTriggerParams,
        UpdateWebhookParams,
        PingWebhookGlobals,
        PingWebhookRequest_2 as PingWebhookRequest,
        RotateSigningSecretGlobals,
        RotateSigningSecretRequest_2 as RotateSigningSecretRequest,
        RunTriggerGlobals,
        RunTriggerRequest,
        StartEnvironmentFileUploadGlobals,
        StartEnvironmentFileUploadRequest,
        StartEnvironmentFileUploadResponse,
        UpdateCredentialGlobals,
        UpdateCredentialRequest,
        UpdateTriggerGlobals,
        UpdateTriggerRequest,
        UpdateWebhookGlobals,
        UpdateWebhookRequest
    }
}

/** Outcome of the code execution. */
export declare enum Outcome {
    /**
     * Unspecified status. This value should not be used.
     */
    OUTCOME_UNSPECIFIED = "OUTCOME_UNSPECIFIED",
    /**
     * Code execution completed successfully. `output` contains the stdout, if any.
     */
    OUTCOME_OK = "OUTCOME_OK",
    /**
     * Code execution failed. `output` contains the stderr and stdout, if any.
     */
    OUTCOME_FAILED = "OUTCOME_FAILED",
    /**
     * Code execution ran for too long, and was cancelled. There may or may not be a partial `output` present.
     */
    OUTCOME_DEADLINE_EXCEEDED = "OUTCOME_DEADLINE_EXCEEDED"
}

/** Describes the info for output of EvaluationService. This data type is not supported in Gemini API. */
export declare interface OutputInfo {
    /** Output only. The full path of the Cloud Storage directory created, into which the evaluation results and aggregation results are written. */
    gcsOutputDirectory?: string;
}

declare type OutputTokensByModality$ = ModalityTokens;

export declare enum PagedItem {
    PAGED_ITEM_BATCH_JOBS = "batchJobs",
    PAGED_ITEM_MODELS = "models",
    PAGED_ITEM_TUNING_JOBS = "tuningJobs",
    PAGED_ITEM_FILES = "files",
    PAGED_ITEM_CACHED_CONTENTS = "cachedContents",
    PAGED_ITEM_FILE_SEARCH_STORES = "fileSearchStores",
    PAGED_ITEM_DOCUMENTS = "documents",
    PAGED_ITEM_SKILLS = "skills"
}

declare interface PagedItemConfig {
    parent?: string;
    config?: {
        pageToken?: string;
        pageSize?: number;
    };
}

declare interface PagedItemResponse<T> {
    nextPageToken?: string;
    sdkHttpResponse?: types.HttpResponse;
    batchJobs?: T[];
    models?: T[];
    tuningJobs?: T[];
    files?: T[];
    cachedContents?: T[];
    fileSearchStores?: T[];
    documents?: T[];
    skills?: T[];
}

/**
 * Pager class for iterating through paginated results.
 */
export declare class Pager<T> implements AsyncIterable<T> {
    private nameInternal;
    private pageInternal;
    private paramsInternal;
    private pageInternalSize;
    private sdkHttpResponseInternal?;
    protected requestInternal: (params: PagedItemConfig) => Promise<PagedItemResponse<T>>;
    protected idxInternal: number;
    constructor(name: PagedItem, request: (params: PagedItemConfig) => Promise<PagedItemResponse<T>>, response: PagedItemResponse<T>, params: PagedItemConfig);
    private init;
    private initNextPage;
    /**
     * Returns the current page, which is a list of items.
     *
     * @remarks
     * The first page is retrieved when the pager is created. The returned list of
     * items could be a subset of the entire list.
     */
    get page(): T[];
    /**
     * Returns the type of paged item (for example, ``batch_jobs``).
     */
    get name(): PagedItem;
    /**
     * Returns the length of the page fetched each time by this pager.
     *
     * @remarks
     * The number of items in the page is less than or equal to the page length.
     */
    get pageSize(): number;
    /**
     * Returns the headers of the API response.
     */
    get sdkHttpResponse(): types.HttpResponse | undefined;
    /**
     * Returns the parameters when making the API request for the next page.
     *
     * @remarks
     * Parameters contain a set of optional configs that can be
     * used to customize the API request. For example, the `pageToken` parameter
     * contains the token to request the next page.
     */
    get params(): PagedItemConfig;
    /**
     * Returns the total number of items in the current page.
     */
    get pageLength(): number;
    /**
     * Returns the item at the given index.
     */
    getItem(index: number): T;
    /**
     * Returns an async iterator that support iterating through all items
     * retrieved from the API.
     *
     * @remarks
     * The iterator will automatically fetch the next page if there are more items
     * to fetch from the API.
     *
     * @example
     *
     * ```ts
     * const pager = await ai.files.list({config: {pageSize: 10}});
     * for await (const file of pager) {
     *   console.log(file.name);
     * }
     * ```
     */
    [Symbol.asyncIterator](): AsyncIterator<T>;
    /**
     * Fetches the next page of items. This makes a new API request.
     *
     * @throws {Error} If there are no more pages to fetch.
     *
     * @example
     *
     * ```ts
     * const pager = await ai.files.list({config: {pageSize: 10}});
     * let page = pager.page;
     * while (true) {
     *   for (const file of page) {
     *     console.log(file.name);
     *   }
     *   if (!pager.hasNextPage()) {
     *     break;
     *   }
     *   page = await pager.nextPage();
     * }
     * ```
     */
    nextPage(): Promise<T[]>;
    /**
     * Returns true if there are more pages to fetch from the API.
     */
    hasNextPage(): boolean;
}

/** Output only. Pairwise metric choice. This enum is not supported in Gemini API. */
export declare enum PairwiseChoice {
    /**
     * Unspecified prediction choice.
     */
    PAIRWISE_CHOICE_UNSPECIFIED = "PAIRWISE_CHOICE_UNSPECIFIED",
    /**
     * Baseline prediction wins
     */
    BASELINE = "BASELINE",
    /**
     * Candidate prediction wins
     */
    CANDIDATE = "CANDIDATE",
    /**
     * Winner cannot be determined
     */
    TIE = "TIE"
}

/** Spec for pairwise metric result. This data type is not supported in Gemini API. */
export declare interface PairwiseMetricResult {
    /** Output only. Spec for custom output. */
    customOutput?: CustomOutput;
    /** Output only. Explanation for pairwise metric score. */
    explanation?: string;
    /** Output only. Pairwise metric choice. */
    pairwiseChoice?: PairwiseChoice;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Used to specify configuration for ParallelAISearch.
 */
declare type ParallelAISearchConfig = {
    /**
     * Optional. The API key for ParallelAiSearch.
     */
    api_key?: string | undefined;
    /**
     * Optional. Custom configs for ParallelAiSearch.
     */
    custom_config?: {
        [k: string]: any;
    } | undefined;
};

/** A datatype containing media content.

 Exactly one field within a Part should be set, representing the specific type
 of content being conveyed. Using multiple fields within the same `Part`
 instance is considered invalid. */
export declare interface Part {
    /** Media resolution for the input media.
     */
    mediaResolution?: PartMediaResolution;
    /** Server-side tool call. This field is populated when the model predicts a tool invocation that should be executed on the server. The client is expected to echo this message back to the API. */
    toolCall?: ToolCall;
    /** The output from a server-side ToolCall execution. This field is populated by the client with the results of executing the corresponding ToolCall. */
    toolResponse?: ToolResponse;
    /** Output only. The transcription of the audio part. */
    audioTranscription?: Transcription;
    /** Optional. The result of executing the ExecutableCode. */
    codeExecutionResult?: CodeExecutionResult;
    /** Optional. Code generated by the model that is intended to be executed. */
    executableCode?: ExecutableCode;
    /** Optional. The URI-based data of the part. This can be used to include files from Google Cloud Storage. */
    fileData?: FileData;
    /** Optional. A predicted function call returned from the model. This contains the name of the function to call and the arguments to pass to the function. */
    functionCall?: FunctionCall;
    /** Optional. The result of a function call. This is used to provide the model with the result of a function call that it predicted. */
    functionResponse?: FunctionResponse;
    /** Optional. The inline data content of the part. This can be used to include images, audio, or video in a request. */
    inlineData?: Blob_2;
    /** Optional. The text content of the part. When sent from the VSCode Gemini Code Assist extension, references to @mentioned items will be converted to markdown boldface text. For example `@my-repo` will be converted to and sent as `**my-repo**` by the IDE agent. */
    text?: string;
    /** Optional. Indicates whether the `part` represents the model's thought process or reasoning. */
    thought?: boolean;
    /** Optional. An opaque signature for the thought so it can be reused in subsequent requests.
     * @remarks Encoded as base64 string. */
    thoughtSignature?: string;
    /** Optional. Video metadata. The metadata should only be specified while the video data is presented in inline_data or file_data. */
    videoMetadata?: VideoMetadata;
    /** Custom metadata associated with the Part. Agents using genai.Part as content representation may need to keep track of the additional information. For example it can be name of a file/source from which the Part originates or a way to multiplex multiple Part streams. This field is not supported in Vertex AI. */
    partMetadata?: Record<string, unknown>;
    /** How the model processes this part's media for understanding. */
    mediaProcessing?: MediaProcessing;
    /** Extra metadata associated with the part for speech synthesis, such
     as speaker and style. Only valid when `Part.data` is set to `text`. */
    speechMetadata?: SpeechMetadata;
}

/** Partial argument value of the function call. This data type is not supported in Gemini API. */
export declare interface PartialArg {
    /** Optional. Represents a boolean value. */
    boolValue?: boolean;
    /** Required. A JSON Path (RFC 9535) to the argument being streamed. https://datatracker.ietf.org/doc/html/rfc9535. e.g. "$.foo.bar[0].data". */
    jsonPath?: string;
    /** Optional. Represents a null value. */
    nullValue?: 'NULL_VALUE';
    /** Optional. Represents a double value. */
    numberValue?: number;
    /** Optional. Represents a string value. */
    stringValue?: string;
    /** Optional. Whether this is not the last part of the same json_path. If true, another PartialArg message for the current json_path is expected to follow. */
    willContinue?: boolean;
}

export declare type PartListUnion = PartUnion[] | PartUnion;

/** Media resolution for the input media. */
export declare interface PartMediaResolution {
    /** The tokenization quality used for given media.
     */
    level?: PartMediaResolutionLevel;
    /** Specifies the required sequence length for media tokenization.
     */
    numTokens?: number;
}

/** The tokenization quality used for given media. */
export declare enum PartMediaResolutionLevel {
    /**
     * Media resolution has not been set.
     */
    MEDIA_RESOLUTION_UNSPECIFIED = "MEDIA_RESOLUTION_UNSPECIFIED",
    /**
     * Media resolution set to low.
     */
    MEDIA_RESOLUTION_LOW = "MEDIA_RESOLUTION_LOW",
    /**
     * Media resolution set to medium.
     */
    MEDIA_RESOLUTION_MEDIUM = "MEDIA_RESOLUTION_MEDIUM",
    /**
     * Media resolution set to high.
     */
    MEDIA_RESOLUTION_HIGH = "MEDIA_RESOLUTION_HIGH",
    /**
     * Media resolution set to ultra high.
     */
    MEDIA_RESOLUTION_ULTRA_HIGH = "MEDIA_RESOLUTION_ULTRA_HIGH"
}

/** Tuning spec for Partner models. This data type is not supported in Gemini API. */
export declare interface PartnerModelTuningSpec {
    /** Hyperparameters for tuning. The accepted hyper_parameters and their valid range of values will differ depending on the base model. */
    hyperParameters?: Record<string, unknown>;
    /** Required. Cloud Storage path to file containing training dataset for tuning. The dataset must be formatted as a JSONL file. */
    trainingDatasetUri?: string;
    /** Optional. Cloud Storage path to file containing validation dataset for tuning. The dataset must be formatted as a JSONL file. */
    validationDatasetUri?: string;
}

export declare type PartUnion = Part | string;

/** Enum that controls the generation of people. */
export declare enum PersonGeneration {
    /**
     * Block generation of images of people.
     */
    DONT_ALLOW = "DONT_ALLOW",
    /**
     * Generate images of adults, but not children.
     */
    ALLOW_ADULT = "ALLOW_ADULT",
    /**
     * Generate images that include adults and children.
     */
    ALLOW_ALL = "ALLOW_ALL"
}

/** Sites with confidence level chosen & above this value will be blocked from the search results. This enum is not supported in Gemini API. */
export declare enum PhishBlockThreshold {
    /**
     * Defaults to unspecified.
     */
    PHISH_BLOCK_THRESHOLD_UNSPECIFIED = "PHISH_BLOCK_THRESHOLD_UNSPECIFIED",
    /**
     * Blocks Low and above confidence URL that is risky.
     */
    BLOCK_LOW_AND_ABOVE = "BLOCK_LOW_AND_ABOVE",
    /**
     * Blocks Medium and above confidence URL that is risky.
     */
    BLOCK_MEDIUM_AND_ABOVE = "BLOCK_MEDIUM_AND_ABOVE",
    /**
     * Blocks High and above confidence URL that is risky.
     */
    BLOCK_HIGH_AND_ABOVE = "BLOCK_HIGH_AND_ABOVE",
    /**
     * Blocks Higher and above confidence URL that is risky.
     */
    BLOCK_HIGHER_AND_ABOVE = "BLOCK_HIGHER_AND_ABOVE",
    /**
     * Blocks Very high and above confidence URL that is risky.
     */
    BLOCK_VERY_HIGH_AND_ABOVE = "BLOCK_VERY_HIGH_AND_ABOVE",
    /**
     * Blocks Extremely high confidence URL that is risky.
     */
    BLOCK_ONLY_EXTREMELY_HIGH = "BLOCK_ONLY_EXTREMELY_HIGH"
}

declare type PingWebhookGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type PingWebhookRequest$ = PingWebhookRequest;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Request message for WebhookService.PingWebhook.
 */
declare type PingWebhookRequest = {};

declare type PingWebhookRequest_2 = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The ID of the webhook to ping.
     */
    id: string;
    /**
     * The request body.
     */
    body?: webhooks.PingWebhookRequest | undefined;
};

declare type Pitch$ = Pitch;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type Pitch = "low" | "medium" | "high" | (string & {});

declare type Place$ = GoogleMapsResultPlaces;

declare type Place$2 = GoogleMapsResultPlaces;

declare type PlaceCitation$ = PlaceCitation;

/**
 * A place citation annotation.
 */
declare type PlaceCitation = {
    /**
     * End of the attributed segment, exclusive.
     */
    end_index?: number | undefined;
    /**
     * Title of the place.
     */
    name?: string | undefined;
    /**
     * The ID of the place, in `places/{place_id}` format.
     */
    place_id?: string | undefined;
    /**
     * Snippets of reviews that are used to generate answers about the
     *
     * @remarks
     * features of a given place in Google Maps.
     */
    review_snippets?: Array<ReviewSnippet> | undefined;
    /**
     * Start of segment of the response that is attributed to this source.
     *
     * @remarks
     *
     * Index indicates the start of the segment, measured in bytes.
     */
    start_index?: number | undefined;
    type: "place_citation";
    /**
     * URI reference of the place.
     */
    url?: string | undefined;
};

/** Spec for pointwise metric result. This data type is not supported in Gemini API. */
export declare interface PointwiseMetricResult {
    /** Output only. Spec for custom output. */
    customOutput?: CustomOutput;
    /** Output only. Explanation for pointwise metric score. */
    explanation?: string;
    /** Output only. Pointwise metric score. */
    score?: number;
}

/** Configuration for a prebuilt voice. */
export declare interface PrebuiltVoiceConfig {
    /** The name of the prebuilt voice to use. */
    voiceName?: string;
}

/** Statistics computed for datasets used for preference optimization. This data type is not supported in Gemini API. */
export declare interface PreferenceOptimizationDataStats {
    /** Output only. A partial sample of the indices (starting from 1) of the dropped examples. */
    droppedExampleIndices?: string[];
    /** Output only. For each index in `dropped_example_indices`, the user-facing reason why the example was dropped. */
    droppedExampleReasons?: string[];
    /** Output only. Dataset distributions for scores variance per example. */
    scoreVariancePerExampleDistribution?: DatasetDistribution;
    /** Output only. Dataset distributions for scores. */
    scoresDistribution?: DatasetDistribution;
    /** Output only. Number of billable tokens in the tuning dataset. */
    totalBillableTokenCount?: string;
    /** Output only. Number of examples in the tuning dataset. */
    tuningDatasetExampleCount?: string;
    /** Output only. Number of tuning steps for this Tuning Job. */
    tuningStepCount?: string;
    /** Output only. Sample user examples in the training dataset. */
    userDatasetExamples?: GeminiPreferenceExample[];
    /** Output only. Dataset distributions for the user input tokens. */
    userInputTokenDistribution?: DatasetDistribution;
    /** Output only. Dataset distributions for the user output tokens. */
    userOutputTokenDistribution?: DatasetDistribution;
}

/** Hyperparameters for Preference Optimization. This data type is not supported in Gemini API. */
export declare interface PreferenceOptimizationHyperParameters {
    /** Optional. Adapter size for preference optimization. */
    adapterSize?: AdapterSize;
    /** Optional. Weight for KL Divergence regularization. */
    beta?: number;
    /** Optional. Number of complete passes the model makes over the entire training dataset during training. */
    epochCount?: string;
    /** Optional. Multiplier for adjusting the default learning rate. */
    learningRateMultiplier?: number;
}

/** Preference optimization tuning spec for tuning. */
export declare interface PreferenceOptimizationSpec {
    /** Optional. If set to true, disable intermediate checkpoints for Preference Optimization and only the last checkpoint will be exported. Otherwise, enable intermediate checkpoints for Preference Optimization. Default is false. */
    exportLastCheckpointOnly?: boolean;
    /** Optional. Hyperparameters for Preference Optimization. */
    hyperParameters?: PreferenceOptimizationHyperParameters;
    /** Required. Cloud Storage path to file containing training dataset for preference optimization tuning. The dataset must be formatted as a JSONL file. */
    trainingDatasetUri?: string;
    /** Optional. Cloud Storage path to file containing validation dataset for preference optimization tuning. The dataset must be formatted as a JSONL file. */
    validationDatasetUri?: string;
}

/** A pre-tuned model for continuous tuning. This data type is not supported in Gemini API. */
export declare interface PreTunedModel {
    /** Output only. The name of the base model this PreTunedModel was tuned from. */
    baseModel?: string;
    /** Optional. The source checkpoint id. If not specified, the default checkpoint will be used. */
    checkpointId?: string;
    /** The resource name of the Model. E.g., a model resource name with a specified version id or alias: `projects/{project}/locations/{location}/models/{model}@{version_id}` `projects/{project}/locations/{location}/models/{model}@{alias}` Or, omit the version id to use the default version: `projects/{project}/locations/{location}/models/{model}` */
    tunedModelName?: string;
}

/** Config for proactivity features. */
export declare interface ProactivityConfig {
    /** If enabled, the model can reject responding to the last prompt. For
     example, this allows the model to ignore out of context speech or to stay
     silent if the user did not make a request, yet. */
    proactiveAudio?: boolean;
}

/**
 * How the model processes this video for understanding.
 */
declare type Processing = MediaProcessing_2 | ProcessingEnum;

declare type ProcessingCall$ = ProcessingCallDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Streaming delta for a server-initiated media processing step.
 */
declare type ProcessingCallDelta = {
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "processing_call";
};

declare type ProcessingCallStep$ = ProcessingCallStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A server-initiated processing step for media analysis (e.g. video
 *
 * @remarks
 * understanding).
 */
declare type ProcessingCallStep = {
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "processing_call";
};

declare type ProcessingEnum = "static" | "agentic" | (string & {});

declare type ProcessingResult$ = ProcessingResultDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Streaming delta for the result of a server-initiated media processing step.
 */
declare type ProcessingResultDelta = {
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "processing_result";
};

declare type ProcessingResultStep$ = ProcessingResultStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The result of a server-initiated media processing step.
 */
declare type ProcessingResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "processing_result";
};

/** An image of the product. */
export declare interface ProductImage {
    /** An image of the product to be recontextualized. */
    productImage?: Image_2;
}

/** Controls whether prominent people (celebrities) generation is allowed. If used with personGeneration, personGeneration enum would take precedence. For instance, if ALLOW_NONE is set, all person generation would be blocked. If this field is unspecified, the default behavior is to allow prominent people. This enum is not supported in Gemini API. */
export declare enum ProminentPeople {
    /**
     * Unspecified value. The model will proceed with the default behavior, which is to allow generation of prominent people.
     */
    PROMINENT_PEOPLE_UNSPECIFIED = "PROMINENT_PEOPLE_UNSPECIFIED",
    /**
     * Allows the model to generate images of prominent people.
     */
    ALLOW_PROMINENT_PEOPLE = "ALLOW_PROMINENT_PEOPLE",
    /**
     * Prevents the model from generating images of prominent people.
     */
    BLOCK_PROMINENT_PEOPLE = "BLOCK_PROMINENT_PEOPLE"
}

declare type PromptedVoice$ = PromptedVoice;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Parameters for prompted voice generation.
 *
 * @remarks
 * Required in `CreateVoice` when `type` is `"prompted"`. Returned in
 * `CreateVoice`, `GetVoice`, and `ListVoices` responses for prompted voices.
 */
declare type PromptedVoice = {
    /**
     * Optional. The name or ID of an existing base voice to edit or remix.
     *
     * @remarks
     * Use the voice name for prebuilt voices (e.g., `Puck`) or the voice ID for
     * previously created voices (e.g., `voice_abc123`). This can be any
     * prompted or replicated voice that the user has access to.
     * When present, `input` describes relative alterations to make to the base
     * voice.
     */
    base_voice?: string | undefined;
    /**
     * Required. The natural-language prompt describing the desired voice, e.g.
     *
     * @remarks
     * "A deep, booming male voice of a massive evil ogre in his middle years."
     */
    input: string;
};

/** A RagChunk includes the content of a chunk of a RagFile, and associated metadata. This data type is not supported in Gemini API. */
export declare interface RagChunk {
    /** The ID of the chunk. */
    chunkId?: string;
    /** The ID of the file that the chunk belongs to. */
    fileId?: string;
    /** If populated, represents where the chunk starts and ends in the document. */
    pageSpan?: RagChunkPageSpan;
    /** The content of the chunk. */
    text?: string;
}

/** Represents where the chunk starts and ends in the document. This data type is not supported in Gemini API. */
export declare interface RagChunkPageSpan {
    /** Page where chunk starts in the document. Inclusive. 1-indexed. */
    firstPage?: number;
    /** Page where chunk ends in the document. Inclusive. 1-indexed. */
    lastPage?: number;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The definition of the Rag resource.
 */
declare type RagResource = {
    /**
     * Optional. RagCorpora resource name.
     */
    rag_corpus?: string | undefined;
    /**
     * Optional. rag_file_id. The files should be in the same rag_corpus set in
     *
     * @remarks
     * rag_corpus field.
     */
    rag_file_ids?: Array<string> | undefined;
};

/** Specifies the context retrieval config. This data type is not supported in Gemini API. */
export declare interface RagRetrievalConfig {
    /** Optional. Config for filters. */
    filter?: RagRetrievalConfigFilter;
    /** Optional. Config for Hybrid Search. */
    hybridSearch?: RagRetrievalConfigHybridSearch;
    /** Optional. Config for ranking and reranking. */
    ranking?: RagRetrievalConfigRanking;
    /** Optional. The number of contexts to retrieve. */
    topK?: number;
}

/**
 * Specifies the context retrieval config.
 */
declare type RagRetrievalConfig_2 = {
    /**
     * Config for filters.
     */
    filter?: Filter | undefined;
    /**
     * Config for Hybrid Search.
     */
    hybrid_search?: HybridSearch | undefined;
    /**
     * Config for ranking and reranking.
     */
    ranking?: Ranking | undefined;
    /**
     * Optional. The number of contexts to retrieve.
     */
    top_k?: number | undefined;
};

/** Config for filters. This data type is not supported in Gemini API. */
export declare interface RagRetrievalConfigFilter {
    /** Optional. String for metadata filtering. */
    metadataFilter?: string;
    /** Optional. Only returns contexts with vector distance smaller than the threshold. */
    vectorDistanceThreshold?: number;
    /** Optional. Only returns contexts with vector similarity larger than the threshold. */
    vectorSimilarityThreshold?: number;
}

/** Config for Hybrid Search. This data type is not supported in Gemini API. */
export declare interface RagRetrievalConfigHybridSearch {
    /** Optional. Alpha value controls the weight between dense and sparse vector search results. The range is [0, 1], while 0 means sparse vector search only and 1 means dense vector search only. The default value is 0.5 which balances sparse and dense vector search equally. */
    alpha?: number;
}

/** Config for ranking and reranking. This data type is not supported in Gemini API. */
export declare interface RagRetrievalConfigRanking {
    /** Optional. Config for LlmRanker. */
    llmRanker?: RagRetrievalConfigRankingLlmRanker;
    /** Optional. Config for Rank Service. */
    rankService?: RagRetrievalConfigRankingRankService;
}

/** Config for LlmRanker. This data type is not supported in Gemini API. */
export declare interface RagRetrievalConfigRankingLlmRanker {
    /** Optional. The model name used for ranking. See [Supported models](https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/inference#supported-models). */
    modelName?: string;
}

/** Config for Rank Service. This data type is not supported in Gemini API. */
export declare interface RagRetrievalConfigRankingRankService {
    /** Optional. The model name of the rank service. Format: `semantic-ranker-512@latest` */
    modelName?: string;
}

/**
 * Use to specify configuration for RAG Store.
 */
declare type RagStoreConfig = {
    /**
     * Optional. The representation of the rag source.
     */
    rag_resources?: Array<RagResource> | undefined;
    /**
     * Specifies the context retrieval config.
     */
    rag_retrieval_config?: RagRetrievalConfig_2 | undefined;
    /**
     * Optional. Number of top k results to return from the selected corpora.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    similarity_top_k?: number | undefined;
    /**
     * Optional. Only return results with vector distance smaller than the threshold.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    vector_distance_threshold?: number | undefined;
};

/**
 * Config for ranking and reranking.
 */
declare type Ranking = {
    /**
     * Optional. The model name of the rank service.
     */
    model_name?: string | undefined;
    /**
     * Config for Rank Service.
     */
    rank_service?: RankService | undefined;
    ranking_config: "rank_service";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Config for Rank Service.
 */
declare type RankService = {
    /**
     * Optional. The model name of the rank service.
     */
    model_name?: string | undefined;
};

/** Raw output. This data type is not supported in Gemini API. */
export declare interface RawOutput {
    /** Output only. Raw output string. */
    rawOutput?: string[];
}

/** A raw reference image.

 A raw reference image represents the base image to edit, provided by the user.
 It can optionally be provided in addition to a mask reference image or
 a style reference image. */
export declare class RawReferenceImage {
    /** The reference image for the editing operation. */
    referenceImage?: Image_2;
    /** The id of the reference image. */
    referenceId?: number;
    /** The type of the reference image. Only set by the SDK. */
    referenceType?: string;
    /** Internal method to convert to ReferenceImageAPIInternal. */
    toReferenceImageAPI(): ReferenceImageAPIInternal;
}

declare const ReadableStreamBase: typeof ReadableStream;

/** Marks the end of user activity.

 This can only be sent if automatic (i.e. server-side) activity detection is
 disabled. */
export declare interface RealtimeInputConfig {
    /** If not set, automatic activity detection is enabled by default. If automatic voice detection is disabled, the client must send activity signals. */
    automaticActivityDetection?: AutomaticActivityDetection;
    /** Defines what effect activity has. */
    activityHandling?: ActivityHandling;
    /** Defines which input is included in the user's turn. */
    turnCoverage?: TurnCoverage;
    /** If true, enables interim transcript timestamps. */
    interimTranscriptTimestampEnabled?: boolean;
}

/** Configuration for recontextualizing an image. */
export declare interface RecontextImageConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** Number of images to generate. */
    numberOfImages?: number;
    /** The number of sampling steps. A higher value has better image
     quality, while a lower value has better latency. */
    baseSteps?: number;
    /** Cloud Storage URI used to store the generated images. */
    outputGcsUri?: string;
    /** Random seed for image generation. */
    seed?: number;
    /** Filter level for safety filtering. */
    safetyFilterLevel?: SafetyFilterLevel;
    /** Whether allow to generate person images, and restrict to specific
     ages. */
    personGeneration?: PersonGeneration;
    /** Whether to add a SynthID watermark to the generated images. */
    addWatermark?: boolean;
    /** MIME type of the generated image. */
    outputMimeType?: string;
    /** Compression quality of the generated image (for ``image/jpeg``
     only). */
    outputCompressionQuality?: number;
    /** Whether to use the prompt rewriting logic. */
    enhancePrompt?: boolean;
    /** User specified labels to track billing usage. */
    labels?: Record<string, string>;
}

/** The parameters for recontextualizing an image. */
export declare interface RecontextImageParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** A set of source input(s) for image recontextualization. */
    source: RecontextImageSource;
    /** Configuration for image recontextualization. */
    config?: RecontextImageConfig;
}

/** The output images response. */
export declare class RecontextImageResponse {
    /** List of generated images. */
    generatedImages?: GeneratedImage[];
}

/** A set of source input(s) for image recontextualization. */
export declare interface RecontextImageSource {
    /** A text prompt for guiding the model during image
     recontextualization. Not supported for Virtual Try-On. */
    prompt?: string;
    /** Image of the person or subject who will be wearing the
     product(s). */
    personImage?: Image_2;
    /** A list of product images. */
    productImages?: ProductImage[];
}

export declare type ReferenceImage = RawReferenceImage | MaskReferenceImage | ControlReferenceImage | StyleReferenceImage | SubjectReferenceImage | ContentReferenceImage;

/** Private class that represents a Reference image that is sent to API. */
declare interface ReferenceImageAPIInternal {
    /** The reference image for the editing operation. */
    referenceImage?: types.Image;
    /** The id of the reference image. */
    referenceId?: number;
    /** The type of the reference image. Only set by the SDK. */
    referenceType?: string;
    /** Configuration for the mask reference image. */
    maskImageConfig?: types.MaskReferenceConfig;
    /** Configuration for the control reference image. */
    controlImageConfig?: types.ControlReferenceConfig;
    /** Configuration for the style reference image. */
    styleImageConfig?: types.StyleReferenceConfig;
    /** Configuration for the subject reference image. */
    subjectImageConfig?: types.SubjectReferenceConfig;
}

/** Used to override the default configuration. */
export declare interface RegisterFilesConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Generates the parameters for the private registerFiles method. */
export declare interface RegisterFilesParameters {
    /**
     * The authentication object.
     */
    auth?: any;
    /**
     * The Google Cloud Storage URIs to register. Example: `gs://bucket/object`.
     */
    uris: string[];
    /** Used to override the default configuration. */
    config?: RegisterFilesConfig;
}

/** Response for the _register file method. */
export declare class RegisterFilesResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** The registered files. */
    files?: File_2[];
}

/** Reinforcement tuning autorater scorer. */
export declare interface ReinforcementTuningAutoraterScorer {
    /** Autorater config for evaluation. */
    autoraterConfig?: AutoraterConfig;
    /** The prompt for an autorater to scorer the parsed sample response. This field supports the following placeholders that will be replaced before scoring: - {{prompt}} - {{response}} - {{system_instruction}} - {{references.key}}  */
    autoraterPrompt?: string;
    /** Parses autorater returned response for scoring. For example, if the autorater response has reward stored in the `2.0` block, defining a parsing response config using regex `".*(.*?)"` will return a score `"2.0"`. */
    autoraterResponseParseConfig?: ReinforcementTuningParseResponseConfig;
    /** Scores autorater responses by using string match reward scorer. */
    exactMatchScorer?: ReinforcementTuningAutoraterScorerExactMatchScorer;
    /** Scores autorater responses by directly converting parsed autorater response to a float reward. Note: Reward is clipped to be within `[-1, 1]`, i.e., `reward = max(min(reward, 1.0), -1.0)`. */
    parsedResponseConversionScorer?: ReinforcementTuningAutoraterScorerParsedResponseConversionScorer;
}

/** Scores autorater responses by using exact string match reward scorer. This data type is not supported in Gemini API. */
export declare interface ReinforcementTuningAutoraterScorerExactMatchScorer {
    /** Assigns this reward score if the parsed response string equals the expression. */
    correctAnswerReward?: number;
    /** The string expression to match against for scoring. This field supports placeholders in the format of {{references.key}} that will be replaced before matching. Regex is not supported for this expression. For example, users can define an ExactMatchScorer as follows: { "correctAnswerReward": 1.0, "wrongAnswerReward": -1.0, "expression": "{{references.concise_answer}}" } When evaluating the reward for each parsed autorater response, if the prompt references in the training/validation dataset has the following fields: ``` { "example": ..., "references": { "concise_ansser": "Yes", "verbose_answer": "The answer is Yes" } } ``` The above ExactMatchScorer will be replaced as follows for scoring: ``` { "correctAnswerReward": 1.0, "wrongAnswerReward": -1.0, "expression": "Yes" } ``` If the *parsed* autorater response is equal to the string `"Yes"`, then the reward is `1.0`, otherwise the reward is `-1.0`. */
    expression?: string;
    /** Assigns this reward score if the parsed reward value does not equal the expression. */
    wrongAnswerReward?: number;
}

/** Scores responses by directly converting the parsed autorater response to a float reward. Note: Reward is clipped to be within `[-1, 1]`, i.e., `reward = max(min(reward, 1.0), -1.0)`. This data type is not supported in Gemini API. */
export declare class ReinforcementTuningAutoraterScorerParsedResponseConversionScorer {
}

/** ReinforcementTuningCloudRunRewardScorer allows users to implement a reward function through GCP Cloud Run. Comparing with ReinforcementTuningCodeExecutionRewardScorer that runs in a Sandbox and has no internet access, Cloud Run reward scorer is fully controlled by users. The Cloud Run service should implement the following HTTP API: HTTP method: `POST` HTTP request body: ``` { "example": ReinforcementTuningExample, "response": Content, "metadata": { "step": int "tuning_job_id": int64 } } ``` * `example` is a ReinforcementTuningExample in ProtoJSON format, (i.e., the format is the same as as one line in the training/validation dataset except that the keys must be in camel case). System instructions (i.e., `example.get("systemInstruction")`) and references (i.e., `example.get("references")`) are also included in the `example` provided that they are set in the training/validation dataset. * `response` is a Content in ProtoJSON format (i.e., keys must be in camel case), which is the same as the Online Prediction response for Gemini models. HTTP response body: { "reward": float, "user_requested_aux_info": str // Optional } where the field "user_requested_aux_info" is any (optional) string provided by users for assisting debugging. It's in snake case. This field is mostly useful when calling the GenAiTuningService.ValidateReinforcementTuningReward API, where the proto field (not Cloud Run HTTP response body) userRequestedAuxInfo will be populated if the Cloud Run reward function sets this field in the HTTP response. The following are examples for the HTTP request and response body. Example HTTP request body: ``` { "example": { "contents": [ { "role": "user", "parts": [ { "text": "What is the capital of France?" } ] } ], "references": { "answer": "Paris" } }, "response": { "parts": [ { "text": "London" } ] }, "metadata": { "step": 1, "tuning_job_id": 123456789 } } ``` Example HTTP response body: ``` { "reward": -1.0 } ``` Note: Reward output by Cloud Run reward function is clipped to be within `[-1, 1]`, i.e., `reward = max(min(reward, 1.0), -1.0)`. This data type is not supported in Gemini API. */
export declare interface ReinforcementTuningCloudRunRewardScorer {
    /** URI of the Cloud Run service that will be used to compute the reward. The [Vertex AI Secure Fine Tuning Service Agent](https://docs.cloud.google.com/iam/docs/service-agents#vertex-ai-secure-fine-tuning-service-agent) (`service-@gcp-sa-vertex-tune.iam.gserviceaccount.com`) must be granted the permission (e.g. by granting `roles/run.invoker` in IAM) to invoke the Cloud Run service. */
    cloudRunUri?: string;
}

/** ReinforcementTuningCodeExecutionRewardScorer allows users to implement a function to evaluate rewards for the sample response. The function signature is as follows: ``` def evaluate(example: dict[str, Any], response: dict[str, Any]) -> float: ... ``` `example` is a ReinforcementTuningExample in ProtoJSON format, (i.e., the format is the same as as one line in the training/validation dataset except that the keys must be in camel case). System instructions (i.e., `example.get("systemInstruction")`) and references (i.e., `example.get("references")`) are also included in the `example` provided that they are set in the training/validation dataset. `response` is a Content in ProtoJSON format (i.e., keys must be in camel case), which is the same as the Online Prediction response for Gemini models. Note: Reward output by the `evaluate` function is clipped to be within `[-1, 1]`, i.e., `reward = max(min(reward, 1.0), -1.0)`. This data type is not supported in Gemini API. */
export declare interface ReinforcementTuningCodeExecutionRewardScorer {
    /** The python code snippet as a string for evaluating rewards. The following is an example python code snippet that returns a reward `1.0` for a parsed response matching the user-provided reference answer in per prompt references map. ``` def evaluate(example, response) -> float: response_str = response.get("parts", [])0 references = example.get("references", {}) if response_str == references.get("concise_answer"): return 1.0 return -1.0 ``` Note: Reward output by the evaluate function is clipped to be within `[-1, 1]`, i.e., `reward = max(min(reward, 1.0), -1.0)`. */
    pythonCodeSnippet?: string;
}

/** User-facing format for Gemini Reinforcement Tuning examples on Vertex. */
export declare interface ReinforcementTuningExample {
    /** References for the given prompt. The key is the name of the reference, and the value is the reference itself. */
    references?: Record<string, string>;
    /** Multi-turn contents that represents the Prompt. */
    contents?: Content[];
    /** Corresponds to system_instruction in user-facing GenerateContentRequest. */
    systemInstruction?: Content;
    /** Optional. Corresponds to tools in user-facing GenerateContentRequest. */
    tools?: Tool[];
}

/** Hyperparameters for Reinforcement Tuning. */
export declare interface ReinforcementTuningHyperParameters {
    /** Learning rate multiplier for Reinforcement Learning. */
    learningRateMultiplier?: number;
    /** Optional. Adapter size for Reinforcement Tuning. */
    adapterSize?: AdapterSize;
    /** Optional. Batch size for the tuning job. How many prompts to process at a train step. If not set, the batch size will be determined automatically. */
    batchSize?: number;
    /** Optional. How often at steps to save checkpoints during training. If not set, one checkpoint per epoch will be set. ```total_steps = epoch_count * samples_per_prompt / total_prompts_in_dataset``` */
    checkpointInterval?: number;
    /** Optional. Number of training epoches for the tuning job. */
    epochCount?: string;
    /** Optional. How often at steps to evaluate the tuning job during training. If not set, evel will be run per epoch. `total_steps = epoch_count * samples_per_prompt / total_prompts_in_dataset` */
    evaluateInterval?: number;
    /** Optional. The maximum number of tokens to generate per prompt. Default to 32768. */
    maxOutputTokens?: number;
    /** Optional. Number of different responses to generate per prompt during tuning. */
    samplesPerPrompt?: number;
    /** Optional. The thinking budget for the tuning job to optimize for (Gemini 2.5 only). * -1 means dynamic thinking * 0 means no thinking * > 0 means thinking budget in tokens If not set, default to -1 (dynamic thinking). */
    thinkingBudget?: number;
    /** Indicates the maximum thinking depth during tuning. Starting from Gemini 3.5 models, the old thinking_budget will no longer be supported and will result in a user error if set. Instead, users should use the thinking_level parameter to control the maximum thinking depth. */
    thinkingLevel?: ReinforcementTuningThinkingLevel;
    /** Optional. Number of steps for the tuning job (mutually exclusive with epoch_count). */
    stepCount?: string;
}

/** Defines how to parse sample response config for reinforcement tuning. The parsed response (i.e., substring) will be passed to the reward functions. For example, the input prompt might be: > "Perform step-by-step thoughts first to problem A, finally output answer in the <ans> </ans> block." The sample response from the model under tuning might look like: > "<ans>Yes</ans>" Here, users can define the following parse config: ``` { "parseType": "REGEX_EXTRACT", "regexExtractExpression": ".*(.*?)" } ``` The resulting parsed response would be `"Yes"` and will be passed to the reward functions for evaluating rewards. This data type is not supported in Gemini API. */
export declare class ReinforcementTuningParseResponseConfig {
    /** Defines the type for parsing sample response. */
    parseType?: ResponseParseType;
    /** Defines the regex for extracting the important part of sample response. This field is only used when parse_type is ResponseParseType.REGEX_EXTRACT. */
    regexExtractExpression?: string;
}

/** The reward info for a reward function. */
export declare interface ReinforcementTuningRewardInfo {
    /** Output only. The calculated reward for the reward function. */
    reward?: number;
    /** Output only. The user-requested auxiliary info for the reward function. This field is set only if the Cloud Run reward function configured by user returns a "user_requested_aux_info". Refer to ReinforcementTuningCloudRunRewardScorer for more details. */
    userRequestedAuxInfo?: string;
    /** Output only. In case of an error for this reward, this field will be populated with a detailed error status. */
    errorStatus?: GoogleRpcStatus;
}

/** Reinforcement tuning spec for tuning. */
export declare interface ReinforcementTuningSpec {
    /** Composite reward function configuration for reinforcement tuning. */
    compositeRewardConfig?: CompositeReinforcementTuningRewardConfig;
    /** Single reward function configuration for reinforcement tuning. */
    singleRewardConfig?: SingleReinforcementTuningRewardConfig;
    /** Additional hyper-parameters to use during tuning. */
    hyperParameters?: ReinforcementTuningHyperParameters;
    /** Cloud Storage path to the file containing training dataset for tuning. The dataset must be formatted as a JSONL file. */
    trainingDatasetUri?: string;
    /** Cloud Storage path to the file containing validation dataset for tuning. The dataset must be formatted as a JSONL file. */
    validationDatasetUri?: string;
}

/** ReinforcementTuningStringMatchRewardScorer is used to score parsed responses for string matching use cases. For example, for math problems, users can use string match scorer to check if the correct exact answer is generated. Note: Reward returned by the string match reward function is clipped to be within `[-1, 1]` if wrongAnswerReward or correctAnswerReward are beyond the range, i.e., `reward = max(min(reward, 1.0), -1.0)`. This data type is not supported in Gemini API. */
export declare interface ReinforcementTuningStringMatchRewardScorer {
    /** Correct answer rewawrd is returned if the parsed response is evaluated as `true`. All correct answers get the same reward. */
    correctAnswerReward?: number;
    /** Uses json match expression to evaluate parsed response. */
    jsonMatchExpression?: ReinforcementTuningStringMatchRewardScorerJsonMatchExpression;
    /** Uses string match expression to evaluate parsed response. */
    stringMatchExpression?: ReinforcementTuningStringMatchRewardScorerStringMatchExpression;
    /** Wrong answer reward is returned if the parsed response is evaluated as `false`. All wrong answers get the same reward. */
    wrongAnswerReward?: number;
}

/** JsonMatchExpression supports converting the parsed responses to JSON format, finding the value in the JSON response that matches the key_name in the first level, and performing StringMatchExpression operation on the matched JSON value. This data type is not supported in Gemini API. */
export declare interface ReinforcementTuningStringMatchRewardScorerJsonMatchExpression {
    /** The key name to find the value in the parsed response that's in JSON format. Only first-level key matching is supported. */
    keyName?: string;
    /** String match expression to match against the extracted value from the JSON representation of the parsed response. */
    valueStringMatchExpression?: ReinforcementTuningStringMatchRewardScorerStringMatchExpression;
}

/** Evaluates parsed response using match type against the expression. Returns `true` if `MatchOperation(target, expression)` evaluates to `true`, and `false` otherwise. This data type is not supported in Gemini API. */
export declare interface ReinforcementTuningStringMatchRewardScorerStringMatchExpression {
    /** A string or a regular expression to match against for evaluating rewards. Users can also provide a references map of `{key: value}` whose `value` will be used to replace the placeholder {{references.key}} in the expression. For example, if the following `references` are defined in the training / validation dataset: ``` { "systemInstruction": ..., "contents": ..., "references": { "concise_answer": "Yes", "verbose_answer": "The answer is Yes" } } ``` and if users define the following StringMatchExpression: { "matchOperation": "REGEX_CONTAINS", "expression": ".*{{references.concise_answer}}.*" } On evaluating the reward for each sample response, this StringMatchExpression will be substituted as: ``` { "matchOperation": "REGEX_CONTAINS", "expression": ".*Yes.*" } ``` */
    expression?: string;
    /** Match operation to use for evaluating rewards. */
    matchOperation?: MatchOperation;
}

/** Represents how much to think for the tuning job. */
export declare enum ReinforcementTuningThinkingLevel {
    /**
     * Unspecified thinking level.
     */
    REINFORCEMENT_TUNING_THINKING_LEVEL_UNSPECIFIED = "REINFORCEMENT_TUNING_THINKING_LEVEL_UNSPECIFIED",
    /**
     * Little to no thinking.
     */
    MINIMAL = "MINIMAL",
    /**
     * High thinking level.
     */
    HIGH = "HIGH"
}

/** Sample reinforcement tuning user data in the training dataset. The contents are truncated for better UI showing. This data type is not supported in Gemini API. */
export declare interface ReinforcementTuningUserDatasetExamples {
    /** List of user datasset examples showing to user. */
    userDatasetExamples?: ReinforcementTuningExample[];
}

/** Represents a recorded session. */
export declare interface ReplayFile {
    replayId?: string;
    interactions?: ReplayInteraction[];
}

/** Represents a single interaction, request and response in a replay. */
export declare interface ReplayInteraction {
    request?: ReplayRequest;
    response?: ReplayResponse;
}

/** Represents a single request in a replay. */
export declare interface ReplayRequest {
    method?: string;
    url?: string;
    headers?: Record<string, string>;
    bodySegments?: Record<string, unknown>[];
}

/** Represents a single response in a replay. */
export declare class ReplayResponse {
    statusCode?: number;
    headers?: Record<string, string>;
    bodySegments?: Record<string, unknown>[];
    sdkResponseSegments?: Record<string, unknown>[];
}

declare type ReplicatedVoice$ = ReplicatedVoice;

/**
 * Input only. Parameters for replicated voice generation.
 *
 * @remarks
 * Required on input when `type` is `"replicated"`. Not returned in
 * responses.
 */
declare type ReplicatedVoice = {
    /**
     * Audio payload used for voice creation.
     */
    consent_audio: AudioData_2;
    /**
     * Audio payload used for voice creation.
     */
    source_audio: AudioData_2;
};

/** The configuration for the replicated voice to use. */
export declare interface ReplicatedVoiceConfig {
    /** The mimetype of the voice sample. The only currently supported
     value is `audio/wav`. This represents 16-bit signed little-endian wav
     data, with a 24kHz sampling rate.
     */
    mimeType?: string;
    /** The sample of the custom voice.

     * @remarks Encoded as base64 string. */
    voiceSampleAudio?: string;
    /** Recorded consent verifying ownership of the voice. This
     represents 16-bit signed little-endian wav data, with a 24kHz sampling
     rate.
     * @remarks Encoded as base64 string. */
    consentAudio?: string;
    /** Signature of a previously verified consent audio. This should be
     populated with a signature generated by the server for a previous
     request containing the consent_audio field. When provided, the
     signature is verified instead of the consent_audio field to reduce
     latency. Requests will fail if the signature is invalid or expired. */
    voiceConsentSignature?: VoiceConsentSignature;
}

/**
 * An error that is raised when a HTTP request was aborted by the client error.
 */
declare class RequestAbortedError extends HTTPClientError {
    readonly name = "RequestAbortedError";
}

declare type RequestConfig = {
    method: string;
    path: string;
    baseURL?: string | URL | undefined;
    query?: string;
    body?: RequestInit["body"];
    headers?: HeadersInit;
    security?: SecurityState | null;
    uaHeader?: string;
    userAgent?: string | undefined;
    timeout_ms?: number;
};

declare type RequestErrorHook = (err: unknown, req: Request) => Awaitable<void>;

declare type RequestInput = {
    /**
     * The URL the request will use.
     */
    url: URL;
    /**
     * Options used to create a [`Request`](https://developer.mozilla.org/en-US/docs/Web/API/Request/Request).
     */
    options?: RequestInit | undefined;
};

declare type RequestOptions = {
    /**
     * Sets a timeout, in milliseconds, on HTTP requests made by an SDK method. If
     * `fetchOptions.signal` is set then it will take precedence over this option.
     */
    timeout_ms?: number;
    /**
     * Set or override a retry policy on HTTP calls.
     */
    retries?: RetryConfig;
    /**
     * Specifies the status codes which should be retried using the given retry policy.
     */
    retry_codes?: string[];
    /**
     * Overrides the base server URL that will be used by an operation.
     */
    server_url?: string | URL;
    /**
     * @deprecated `fetchOptions` has been flattened into `RequestOptions`.
     *
     * Sets various request options on the `fetch` call made by an SDK method.
     *
     * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/Request/Request#options|Request}
     */
    fetch_options?: Omit<RequestInit, "method" | "body">;
    /**
     * Additional query parameters to set on the request URL. Entries replace
     * any query parameters of the same name produced by the operation. Entries
     * with null or undefined values are skipped, array values are encoded as
     * repeated keys and plain object values are JSON-encoded.
     */
    extra_query?: Record<string, unknown>;
    /**
     * Additional fields to merge into the JSON object request body. Entries
     * replace any fields of the same name produced by the operation. Entries
     * with undefined values are skipped. Setting this option on an operation
     * whose request body is not a JSON object results in an error.
     */
    extra_body?: Record<string, unknown>;
} & Omit<RequestInit, "method" | "body">;

/**
 * An error that is raised when a HTTP request timed out due to an AbortSignal
 * signal timeout.
 */
declare class RequestTimeoutError extends HTTPClientError {
    readonly name = "RequestTimeoutError";
}

/**
 * The video output resolution. Defaults to 720p.
 */
declare type Resolution = "360p" | "720p" | "1080p" | "4k" | (string & {});

/** Resource scope. */
export declare enum ResourceScope {
    /**
     * When setting base_url, this value configures resource scope to be the collection.
     The resource name will not include api version, project, or location.
     For example, if base_url is set to "https://aiplatform.googleapis.com",
     then the resource name for a Model would be
     "https://aiplatform.googleapis.com/publishers/google/models/gemini-3-pro-preview
     */
    COLLECTION = "COLLECTION"
}

/** Configuration for the model to configure output formatting and delivery. This data type is not supported in Gemini API. */
export declare class ResponseFormat {
    /** Audio output format. */
    audio?: AudioResponseFormat;
    /** Image output format. */
    image?: ImageResponseFormat;
    /** Text output format. */
    text?: TextResponseFormat;
    /** Video output format. */
    video?: VideoResponseFormat;
}

declare type ResponseFormat_2 = AudioResponseFormat_2 | ImageResponseFormat_2 | TextResponseFormat_2 | VideoResponseFormat_2 | {
    [k: string]: any;
};

declare type ResponseHook = (res: Response, req: Request) => Awaitable<void>;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ResponseModality = "text" | "image" | "audio" | "video" | "document" | (string & {});

/** Defines the type for parsing sample response. This enum is not supported in Gemini API. */
export declare enum ResponseParseType {
    /**
     * Default value. Fallback to IDENTITY
     */
    RESPONSE_PARSE_TYPE_UNSPECIFIED = "RESPONSE_PARSE_TYPE_UNSPECIFIED",
    /**
     * Returns the sample response as is.
     */
    IDENTITY = "IDENTITY",
    /**
     * Uses regex to extract the important part of sample response. Similar to [GoogleSQL](https://cloud.google.com/bigquery/docs/reference/standard-sql/string_functions#regexp_extract) `REGEX_EXTRACT(response, regex_extract_expression)`, but different in that if there are multiple matches, the last match will be returned.
     */
    REGEX_EXTRACT = "REGEX_EXTRACT"
}

declare type Result$ = GoogleMapsResult;

declare type Result$2 = GoogleSearchResult;

declare type Result$3 = URLContextResult;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A monad that captures the result of a function call or an error if it was not
 * successful. Railway programming, enabled by this type, can be a nicer
 * alternative to traditional exception throwing because it allows functions to
 * declare all _known_ errors with static types and then check for them
 * exhaustively in application code. Thrown exception have a type of `unknown`
 * and break out of regular control flow of programs making them harder to
 * inspect and more verbose work with due to try-catch blocks.
 */
declare type Result<T, E = unknown> = {
    ok: true;
    value: T;
    error?: never;
} | {
    ok: false;
    value?: never;
    error: E;
};

declare type Retrieval$ = Retrieval_2;

/** Defines a retrieval tool that model can call to access external knowledge. This data type is not supported in Gemini API. */
export declare interface Retrieval {
    /** Optional. Deprecated. This option is no longer supported. */
    disableAttribution?: boolean;
    /** Use data source powered by external API for grounding. */
    externalApi?: ExternalApi;
    /** Set to use data source powered by Vertex AI Search. */
    vertexAiSearch?: VertexAISearch;
    /** Set to use data source powered by Vertex RAG store. User data is uploaded via the VertexRagDataService. */
    vertexRagStore?: VertexRagStore;
}

/**
 * A tool that can be used by the model to retrieve files.
 */
declare type Retrieval_2 = {
    /**
     * Used to specify configuration for ExaAISearch.
     */
    exa_ai_search_config?: ExaAISearchConfig | undefined;
    /**
     * Used to specify configuration for ParallelAISearch.
     */
    parallel_ai_search_config?: ParallelAISearchConfig | undefined;
    /**
     * Use to specify configuration for RAG Store.
     */
    rag_store_config?: RagStoreConfig | undefined;
    /**
     * The types of file retrieval to enable.
     */
    retrieval_types?: Array<RetrievalRetrievalType> | undefined;
    type: "retrieval";
    /**
     * Used to specify configuration for VertexAISearch.
     */
    vertex_ai_search_config?: VertexAISearchConfig | undefined;
};

declare type RetrievalCallArguments$ = RetrievalCallArguments;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The arguments to pass to Retrieval tools.
 */
declare type RetrievalCallArguments = {
    /**
     * Queries for Retrieval information.
     */
    queries?: Array<string> | undefined;
};

declare type RetrievalCallDelta$ = RetrievalCallDelta;

/**
 * Used by Vertex Retrieval tools such as Parallel AI, Exa AI, Vertex AI Search,
 *
 * @remarks
 * etc. RetrievalType decides which tool is used.
 */
declare type RetrievalCallDelta = {
    /**
     * The arguments to pass to Retrieval tools.
     */
    arguments: RetrievalCallArguments;
    /**
     * The type of retrieval tools.
     */
    retrieval_type?: RetrievalCallDeltaRetrievalType | undefined;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "retrieval_call";
};

/**
 * The type of retrieval tools.
 */
declare type RetrievalCallDeltaRetrievalType = "vertex_ai_search" | "rag_store" | "exa_ai_search" | "parallel_ai_search" | (string & {});

declare type RetrievalCallStep$ = RetrievalCallStep;

/**
 * Retrieval call step.
 *
 * @remarks
 * Used by Vertex Retrieval tools such as Parallel AI, Exa AI, Vertex AI Search,
 * etc. RetrievalType decides which tool is used.
 */
declare type RetrievalCallStep = {
    /**
     * The arguments to pass to Retrieval tools.
     */
    arguments: RetrievalCallArguments;
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * The type of retrieval tools.
     */
    retrieval_type?: RetrievalCallStepRetrievalType | undefined;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "retrieval_call";
};

/**
 * The type of retrieval tools.
 */
declare type RetrievalCallStepRetrievalType = "vertex_ai_search" | "rag_store" | "exa_ai_search" | "parallel_ai_search" | (string & {});

/** Retrieval config. */
export declare interface RetrievalConfig {
    /** The language code of the user. */
    languageCode?: string;
    /** The location of the user. */
    latLng?: LatLng;
}

/** Metadata returned to client when grounding is enabled. */
export declare interface RetrievalMetadata {
    /** Optional. Score indicating how likely information from google
     search could help answer the prompt. The score is in the range [0, 1],
     where 0 is the least likely and 1 is the most likely. This score is only
     populated when google search grounding and dynamic retrieval is enabled.
     It will be compared to the threshold to determine whether to trigger
     Google search. */
    googleSearchDynamicRetrievalScore?: number;
}

declare type RetrievalResultDelta$ = RetrievalResultDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Used by Vertex Retrieval tools such as Parallel AI, Exa AI, Vertex AI Search,
 *
 * @remarks
 * etc.
 * ToolResultDelta.type
 */
declare type RetrievalResultDelta = {
    /**
     * Whether the retrieval resulted in an error.
     */
    is_error?: boolean | undefined;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "retrieval_result";
};

declare type RetrievalResultStep$ = RetrievalResultStep;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Vertex Retrieval result step.
 *
 * @remarks
 * Used by Vertex Retrieval tools such as Parallel AI, Exa AI, Vertex AI Search,
 * etc.
 */
declare type RetrievalResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * Whether the retrieval resulted in an error.
     */
    is_error?: boolean | undefined;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "retrieval_result";
};

declare type RetrievalRetrievalType = "vertex_ai_search" | "rag_store" | "exa_ai_search" | "parallel_ai_search" | (string & {});

export declare type RetryConfig = {
    strategy: "none";
} | {
    strategy: "backoff";
    backoff?: BackoffStrategy;
    retryConnectionErrors?: boolean;
} | {
    strategy: "attempt-count-backoff";
    maxRetries: number;
    backoff?: Partial<BackoffStrategy>;
    retryConnectionErrors?: boolean;
};

declare type ReviewSnippet$ = ReviewSnippet;

declare type ReviewSnippet$2 = ReviewSnippet;

declare type ReviewSnippet$3 = ReviewSnippet;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Encapsulates a snippet of a user review that answers a question about
 *
 * @remarks
 * the features of a specific place in Google Maps.
 */
declare type ReviewSnippet = {
    /**
     * The ID of the review snippet.
     */
    review_id?: string | undefined;
    /**
     * Title of the review.
     */
    title?: string | undefined;
    /**
     * A link that corresponds to the user review on Google Maps.
     */
    url?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Optional. The revocation behavior for previous signing secrets.
 */
declare type RevocationBehavior = "revoke_previous_secrets_after_h24" | "revoke_previous_secrets_immediately";

declare type RotateSigningSecretGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type RotateSigningSecretRequest$ = RotateSigningSecretRequest;

/**
 * Request message for WebhookService.RotateSigningSecret.
 */
declare type RotateSigningSecretRequest = {
    /**
     * Optional. The revocation behavior for previous signing secrets.
     */
    revocation_behavior?: RevocationBehavior | undefined;
};

declare type RotateSigningSecretRequest_2 = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The ID of the webhook for which to generate a signing secret.
     */
    id: string;
    /**
     * Required. The request body.
     */
    body: webhooks.RotateSigningSecretRequest;
};

/** Rouge metric value for an instance. This data type is not supported in Gemini API. */
export declare interface RougeMetricValue {
    /** Output only. Rouge score. */
    score?: number;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type RunTriggerGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type RunTriggerParams = Omit<RunTriggerRequest, "trigger_id">;

declare type RunTriggerRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource name of the trigger.
     */
    trigger_id: string;
};

/** Safety attributes of a GeneratedImage or the user-provided prompt. */
export declare interface SafetyAttributes {
    /** List of RAI categories. */
    categories?: string[];
    /** List of scores of each categories. */
    scores?: number[];
    /** Internal use only. */
    contentType?: string;
}

/** Enum that controls the safety filter level for objectionable content. */
export declare enum SafetyFilterLevel {
    BLOCK_LOW_AND_ABOVE = "BLOCK_LOW_AND_ABOVE",
    BLOCK_MEDIUM_AND_ABOVE = "BLOCK_MEDIUM_AND_ABOVE",
    BLOCK_ONLY_HIGH = "BLOCK_ONLY_HIGH",
    BLOCK_NONE = "BLOCK_NONE"
}

/** SafetyPolicy */
export declare enum SafetyPolicy {
    /**
     * The safety policy is unspecified.
     */
    SAFETY_POLICY_UNSPECIFIED = "SAFETY_POLICY_UNSPECIFIED",
    /**
     * Policy that restricts financial transactions.
     */
    FINANCIAL_TRANSACTIONS = "FINANCIAL_TRANSACTIONS",
    /**
     * Policy that restricts modification of sensitive data.
     */
    SENSITIVE_DATA_MODIFICATION = "SENSITIVE_DATA_MODIFICATION",
    /**
     * Policy that restricts the use of communication tools.
     */
    COMMUNICATION_TOOL = "COMMUNICATION_TOOL",
    /**
     * Policy that restricts the creation of accounts.
     */
    ACCOUNT_CREATION = "ACCOUNT_CREATION",
    /**
     * Policy that restricts general data modification.
     */
    DATA_MODIFICATION = "DATA_MODIFICATION",
    /**
     * Policy that restricts user consent management.
     */
    USER_CONSENT_MANAGEMENT = "USER_CONSENT_MANAGEMENT",
    /**
     * Policy that restricts interaction with legal terms and agreements.
     */
    LEGAL_TERMS_AND_AGREEMENTS = "LEGAL_TERMS_AND_AGREEMENTS"
}

/** A safety rating for a piece of content. The safety rating contains the harm category and the harm probability level. */
export declare interface SafetyRating {
    /** Output only. Indicates whether the content was blocked because of this rating. */
    blocked?: boolean;
    /** Output only. The harm category of this rating. */
    category?: HarmCategory;
    /** Output only. The overwritten threshold for the safety category of Gemini 2.0 image out. If minors are detected in the output image, the threshold of each safety category will be overwritten if user sets a lower threshold. This field is not supported in Gemini API. */
    overwrittenThreshold?: HarmBlockThreshold;
    /** Output only. The probability of harm for this category. */
    probability?: HarmProbability;
    /** Output only. The probability score of harm for this category. This field is not supported in Gemini API. */
    probabilityScore?: number;
    /** Output only. The severity of harm for this category. This field is not supported in Gemini API. */
    severity?: HarmSeverity;
    /** Output only. The severity score of harm for this category. This field is not supported in Gemini API. */
    severityScore?: number;
}

declare type SafetySetting$ = SafetySetting_2;

/** A safety setting that affects the safety-blocking behavior. A SafetySetting consists of a harm category and a threshold for that category. */
export declare interface SafetySetting {
    /** Required. The harm category to be blocked. */
    category?: HarmCategory;
    /** Optional. The method for blocking content. If not specified, the default behavior is to use the probability score. This field is not supported in Gemini API. */
    method?: HarmBlockMethod;
    /** Required. The threshold for blocking content. If the harm probability exceeds this threshold, the content will be blocked. */
    threshold?: HarmBlockThreshold;
}

/**
 * A safety setting that affects the safety-blocking behavior.
 *
 * @remarks
 *
 * A SafetySetting consists of a
 * harm category and a
 * threshold for that
 * category.
 */
declare type SafetySetting_2 = {
    /**
     * Optional. The method for blocking content. If not specified, the default
     *
     * @remarks
     * behavior is to use the probability score.
     */
    method?: Method | undefined;
    /**
     * Required. The threshold for blocking content. If the harm probability
     *
     * @remarks
     * exceeds this threshold, the content will be blocked.
     */
    threshold: Threshold;
    type: HarmCategory_2;
};

/** Scale of the generated music. */
export declare enum Scale {
    /**
     * Default value. This value is unused.
     */
    SCALE_UNSPECIFIED = "SCALE_UNSPECIFIED",
    /**
     * C major or A minor.
     */
    C_MAJOR_A_MINOR = "C_MAJOR_A_MINOR",
    /**
     * Db major or Bb minor.
     */
    D_FLAT_MAJOR_B_FLAT_MINOR = "D_FLAT_MAJOR_B_FLAT_MINOR",
    /**
     * D major or B minor.
     */
    D_MAJOR_B_MINOR = "D_MAJOR_B_MINOR",
    /**
     * Eb major or C minor
     */
    E_FLAT_MAJOR_C_MINOR = "E_FLAT_MAJOR_C_MINOR",
    /**
     * E major or Db minor.
     */
    E_MAJOR_D_FLAT_MINOR = "E_MAJOR_D_FLAT_MINOR",
    /**
     * F major or D minor.
     */
    F_MAJOR_D_MINOR = "F_MAJOR_D_MINOR",
    /**
     * Gb major or Eb minor.
     */
    G_FLAT_MAJOR_E_FLAT_MINOR = "G_FLAT_MAJOR_E_FLAT_MINOR",
    /**
     * G major or E minor.
     */
    G_MAJOR_E_MINOR = "G_MAJOR_E_MINOR",
    /**
     * Ab major or F minor.
     */
    A_FLAT_MAJOR_F_MINOR = "A_FLAT_MAJOR_F_MINOR",
    /**
     * A major or Gb minor.
     */
    A_MAJOR_G_FLAT_MINOR = "A_MAJOR_G_FLAT_MINOR",
    /**
     * Bb major or G minor.
     */
    B_FLAT_MAJOR_G_MINOR = "B_FLAT_MAJOR_G_MINOR",
    /**
     * B major or Ab minor.
     */
    B_MAJOR_A_FLAT_MINOR = "B_MAJOR_A_FLAT_MINOR"
}

/** Schema is used to define the format of input/output data.

 Represents a select subset of an [OpenAPI 3.0 schema
 object](https://spec.openapis.org/oas/v3.0.3#schema-object). More fields may
 be added in the future as needed. */
export declare interface Schema {
    /** Optional. The instance must be valid against any (one or more) of the subschemas listed in `any_of`. */
    anyOf?: Schema[];
    /** Optional. Default value to use if the field is not specified. */
    default?: unknown;
    /** Optional. Describes the data. The model uses this field to understand the purpose of the schema and how to use it. It is a best practice to provide a clear and descriptive explanation for the schema and its properties here, rather than in the prompt. */
    description?: string;
    /** Optional. Possible values of the field. This field can be used to restrict a value to a fixed set of values. To mark a field as an enum, set `format` to `enum` and provide the list of possible values in `enum`. For example: 1. To define directions: `{type:STRING, format:enum, enum:["EAST", "NORTH", "SOUTH", "WEST"]}` 2. To define apartment numbers: `{type:INTEGER, format:enum, enum:["101", "201", "301"]}` */
    enum?: string[];
    /** Optional. Example of an instance of this schema. */
    example?: unknown;
    /** Optional. The format of the data. For `NUMBER` type, format can be `float` or `double`. For `INTEGER` type, format can be `int32` or `int64`. For `STRING` type, format can be `email`, `byte`, `date`, `date-time`, `password`, and other formats to further refine the data type. */
    format?: string;
    /** Optional. If type is `ARRAY`, `items` specifies the schema of elements in the array. */
    items?: Schema;
    /** Optional. If type is `ARRAY`, `max_items` specifies the maximum number of items in an array. */
    maxItems?: string;
    /** Optional. If type is `STRING`, `max_length` specifies the maximum length of the string. */
    maxLength?: string;
    /** Optional. If type is `OBJECT`, `max_properties` specifies the maximum number of properties that can be provided. */
    maxProperties?: string;
    /** Optional. If type is `INTEGER` or `NUMBER`, `maximum` specifies the maximum allowed value. */
    maximum?: number;
    /** Optional. If type is `ARRAY`, `min_items` specifies the minimum number of items in an array. */
    minItems?: string;
    /** Optional. If type is `STRING`, `min_length` specifies the minimum length of the string. */
    minLength?: string;
    /** Optional. If type is `OBJECT`, `min_properties` specifies the minimum number of properties that can be provided. */
    minProperties?: string;
    /** Optional. If type is `INTEGER` or `NUMBER`, `minimum` specifies the minimum allowed value. */
    minimum?: number;
    /** Optional. Indicates if the value of this field can be null. */
    nullable?: boolean;
    /** Optional. If type is `STRING`, `pattern` specifies a regular expression that the string must match. */
    pattern?: string;
    /** Optional. If type is `OBJECT`, `properties` is a map of property names to schema definitions for each property of the object. */
    properties?: Record<string, Schema>;
    /** Optional. Order of properties displayed or used where order matters. This is not a standard field in OpenAPI specification, but can be used to control the order of properties. */
    propertyOrdering?: string[];
    /** Optional. If type is `OBJECT`, `required` lists the names of properties that must be present. */
    required?: string[];
    /** Optional. Title for the schema. */
    title?: string;
    /** Optional. Data type of the schema field. */
    type?: Type;
}

export declare type SchemaUnion = Schema | unknown;

/** An image mask representing a brush scribble. */
export declare interface ScribbleImage {
    /** The brush scribble to guide segmentation. Valid for the interactive mode. */
    image?: Image_2;
}

declare class SDKHooks implements Hooks {
    sdkInitHooks: SDKInitHook[];
    beforeCreateRequestHooks: BeforeCreateRequestHook[];
    beforeRequestHooks: BeforeRequestHook_2[];
    afterSuccessHooks: AfterSuccessHook[];
    afterErrorHooks: AfterErrorHook[];
    constructor();
    registerSDKInitHook(hook: SDKInitHook): void;
    registerBeforeCreateRequestHook(hook: BeforeCreateRequestHook): void;
    registerBeforeRequestHook(hook: BeforeRequestHook_2): void;
    registerAfterSuccessHook(hook: AfterSuccessHook): void;
    registerAfterErrorHook(hook: AfterErrorHook): void;
    sdkInit(opts: SDKOptions): SDKOptions;
    beforeCreateRequest(hookCtx: BeforeCreateRequestContext, input: RequestInput): RequestInput;
    beforeRequest(hookCtx: BeforeRequestContext, request: Request): Promise<Request>;
    afterSuccess(hookCtx: AfterSuccessContext, response: Response): Promise<Response>;
    afterError(hookCtx: AfterErrorContext, response: Response | null, error: unknown): Promise<{
        response: Response | null;
        error: unknown;
    }>;
}

/**
 * SDKInitHook is called when the SDK is initializing. The
 * hook can return a new baseURL and HTTP client to be used by the SDK.
 */
declare interface SDKInitHook {
    sdkInit: (opts: SDKOptions) => SDKOptions;
}

declare type SDKOptions = {
    /**
     * The security details required to authenticate the SDK
     */
    security?: models.Security | (() => Promise<models.Security>) | undefined;
    /**
     * Allows setting the api_version parameter for all supported operations
     */
    api_version?: string | undefined;
    /**
     * Allows setting the user_project parameter for all supported operations
     */
    user_project?: string | undefined;
    http_client?: HTTPClient;
    /**
     * Allows overriding the default server used by the SDK
     */
    server_idx?: number | undefined;
    /**
     * Allows overriding the default server URL used by the SDK
     */
    server_url?: string | undefined;
    /**
     * Allows overriding the default user agent used by the SDK
     */
    user_agent?: string | undefined;
    /**
     * Allows overriding the default retry config used by the SDK
     */
    retry_config?: RetryConfig;
    timeout_ms?: number;
    debug_logger?: Logger;
};

/** The entry point used to search for grounding sources. */
export declare interface SearchEntryPoint {
    /** Optional. Web content snippet that can be embedded in a web page
     or an app webview. */
    renderedContent?: string;
    /** Optional. JSON representing array of tuples.
     * @remarks Encoded as base64 string. */
    sdkBlob?: string;
}

/** Different types of search that can be enabled on the GoogleSearch tool. */
export declare interface SearchTypes {
    /** Optional. Setting this field enables image search. Image bytes are returned. */
    imageSearch?: ImageSearch;
    /** Optional. Setting this field enables web search. Only text results are returned. */
    webSearch?: WebSearch;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type Security = {
    /**
     * OAuth access token sent as a bearer Authorization header.
     */
    access_token?: string | undefined;
    /**
     * Gemini API key sent as x-goog-api-key.
     */
    api_key?: string | undefined;
    /**
     * Additional default headers to apply before request-specific headers and auth.
     */
    default_headers?: {
        [k: string]: string;
    } | undefined;
};

declare type SecurityState = {
    basic: {
        username?: string | undefined;
        password?: string | undefined;
    };
    headers: Record<string, string>;
    queryParams: Record<string, string>;
    cookies: Record<string, string>;
    oauth2: ({
        type: "password";
    } & OAuth2PasswordFlow) | {
        type: "none";
    };
};

/** Segment of the content this support belongs to. */
export declare interface Segment {
    /** Output only. Start index in the given Part, measured in bytes.

     Offset from the start of the Part, inclusive, starting at zero. */
    startIndex?: number;
    /** Output only. End index in the given Part, measured in bytes.

     Offset from the start of the Part, exclusive, starting at zero. */
    endIndex?: number;
    /** Output only. The index of a Part object within its parent
     Content object. */
    partIndex?: number;
    /** Output only. The text corresponding to the segment from the
     response. */
    text?: string;
}

/** Configuration for segmenting an image. */
export declare interface SegmentImageConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The segmentation mode to use. */
    mode?: SegmentMode;
    /** The maximum number of predictions to return up to, by top
     confidence score. */
    maxPredictions?: number;
    /** The confidence score threshold for the detections as a decimal
     value. Only predictions with a confidence score higher than this
     threshold will be returned. */
    confidenceThreshold?: number;
    /** A decimal value representing how much dilation to apply to the
     masks. 0 for no dilation. 1.0 means the masked area covers the whole
     image. */
    maskDilation?: number;
    /** The binary color threshold to apply to the masks. The threshold
     can be set to a decimal value between 0 and 255 non-inclusive.
     Set to -1 for no binary color thresholding. */
    binaryColorThreshold?: number;
    /** User specified labels to track billing usage. */
    labels?: Record<string, string>;
}

/** The parameters for segmenting an image. */
export declare interface SegmentImageParameters {
    /** ID of the model to use. For a list of models, see `Google models
     <https://cloud.google.com/vertex-ai/generative-ai/docs/learn/models>`_. */
    model: string;
    /** A set of source input(s) for image segmentation. */
    source: SegmentImageSource;
    /** Configuration for image segmentation. */
    config?: SegmentImageConfig;
}

/** The output images response. */
export declare class SegmentImageResponse {
    /** List of generated image masks.
     */
    generatedMasks?: GeneratedImageMask[];
}

/** A set of source input(s) for image segmentation. */
export declare interface SegmentImageSource {
    /** A text prompt for guiding the model during image segmentation.
     Required for prompt mode and semantic mode, disallowed for other modes. */
    prompt?: string;
    /** The image to be segmented. */
    image?: Image_2;
    /** The brush scribble to guide segmentation.
     Required for the interactive mode, disallowed for other modes. */
    scribbleImage?: ScribbleImage;
}

/** Enum that represents the segmentation mode. */
export declare enum SegmentMode {
    FOREGROUND = "FOREGROUND",
    BACKGROUND = "BACKGROUND",
    PROMPT = "PROMPT",
    SEMANTIC = "SEMANTIC",
    INTERACTIVE = "INTERACTIVE"
}

/** Parameters for sending a message within a chat session.

 These parameters are used with the `chat.sendMessage()` method. */
export declare interface SendMessageParameters {
    /** The message to send to the model.

     The SDK will combine all parts into a single 'user' content to send to
     the model.
     */
    message: PartListUnion;
    /**  Config for this specific request.

     Please note that the per-request config does not change the chat level
     config, nor inherit from it. If you intend to use some values from the
     chat's default config, you must explicitly copy them into this per-request
     config.
     */
    config?: GenerateContentConfig;
}

/** Pricing and performance service tier. */
export declare enum ServiceTier {
    /**
     * Default service tier, which is standard.
     */
    UNSPECIFIED = "unspecified",
    /**
     * Flex service tier.
     */
    FLEX = "flex",
    /**
     * Standard service tier.
     */
    STANDARD = "standard",
    /**
     * Priority service tier.
     */
    PRIORITY = "priority"
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ServiceTier_2 = "flex" | "standard" | "priority" | "deferred" | (string & {});

/**
 Represents a connection to the API.

 @experimental
 */
export declare class Session {
    readonly conn: WebSocket_2;
    private readonly apiClient;
    setupComplete?: types.LiveServerSetupComplete;
    constructor(conn: WebSocket_2, apiClient: ApiClient);
    private tLiveClientContent;
    private tLiveClienttToolResponse;
    /**
     Send a message over the established connection.

     @param params - Contains two **optional** properties, `turns` and
     `turnComplete`.

     - `turns` will be converted to a `Content[]`
     - `turnComplete: true` [default] indicates that you are done sending
     content and expect a response. If `turnComplete: false`, the server
     will wait for additional messages before starting generation.

     @experimental

     @remarks
     There are two ways to send messages to the live API:
     `sendClientContent` and `sendRealtimeInput`.

     `sendClientContent` messages are added to the model context **in order**.
     Having a conversation using `sendClientContent` messages is roughly
     equivalent to using the `Chat.sendMessageStream`, except that the state of
     the `chat` history is stored on the API server instead of locally.

     Because of `sendClientContent`'s order guarantee, the model cannot respons
     as quickly to `sendClientContent` messages as to `sendRealtimeInput`
     messages. This makes the biggest difference when sending objects that have
     significant preprocessing time (typically images).

     The `sendClientContent` message sends a `Content[]`
     which has more options than the `Blob` sent by `sendRealtimeInput`.

     So the main use-cases for `sendClientContent` over `sendRealtimeInput` are:

     - Sending anything that can't be represented as a `Blob` (text,
     `sendClientContent({turns="Hello?"}`)).
     - Managing turns when not using audio input and voice activity detection.
     (`sendClientContent({turnComplete:true})` or the short form
     `sendClientContent()`)
     - Prefilling a conversation context
     ```
     sendClientContent({
     turns: [
     Content({role:user, parts:...}),
     Content({role:user, parts:...}),
     ...
     ]
     })
     ```
     @experimental
     */
    sendClientContent(params: types.LiveSendClientContentParameters): void;
    /**
     Send a realtime message over the established connection.

     @param params - Contains one property, `media`.

     - `media` will be converted to a `Blob`

     @experimental

     @remarks
     Use `sendRealtimeInput` for realtime audio chunks and video frames (images).

     With `sendRealtimeInput` the api will respond to audio automatically
     based on voice activity detection (VAD).

     `sendRealtimeInput` is optimized for responsivness at the expense of
     deterministic ordering guarantees. Audio and video tokens are to the
     context when they become available.

     Note: The Call signature expects a `Blob` object, but only a subset
     of audio and image mimetypes are allowed.
     */
    sendRealtimeInput(params: types.LiveSendRealtimeInputParameters): void;
    /**
     Send a function response message over the established connection.

     @param params - Contains property `functionResponses`.

     - `functionResponses` will be converted to a `functionResponses[]`

     @remarks
     Use `sendFunctionResponse` to reply to `LiveServerToolCall` from the server.

     Use {@link types.LiveConnectConfig#tools} to configure the callable functions.

     @experimental
     */
    sendToolResponse(params: types.LiveSendToolResponseParameters): void;
    /**
     Send a context update message over the established connection.

     @param params - Contains properties `systemInstruction` and/or `tools`.

     @remarks
     Updates to the context of the current session. Only fields that are set will
     be updated. Updates are guaranteed to be processed in order with the rest of
     the inputs.

     @experimental
     */
    sendContextUpdate(params: types.LiveClientContextUpdate): void;
    /**
     Terminates the WebSocket connection.

     @experimental

     @example
     ```ts
     let model: string;
     if (GOOGLE_GENAI_USE_VERTEXAI) {
     model = 'gemini-2.0-flash-live-preview-04-09';
     } else {
     model = 'gemini-live-2.5-flash-preview';
     }
     const session = await ai.live.connect({
     model: model,
     config: {
     responseModalities: [Modality.AUDIO],
     }
     });

     session.close();
     ```
     */
    close(): void;
}

declare type SessionConfig$ = SessionConfig;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The configuration of CodeMender sessions.
 */
declare type SessionConfig = {
    /**
     * The maximum number of interaction rounds the agent is allowed to perform
     *
     * @remarks
     * before reaching a timeout.
     */
    max_rounds?: number | undefined;
};

/** Configuration of session resumption mechanism.

 Included in `LiveConnectConfig.session_resumption`. If included server
 will send `LiveServerSessionResumptionUpdate` messages. */
export declare interface SessionResumptionConfig {
    /** Session resumption handle of previous session (session to restore).

     If not present new session will be started. */
    handle?: string;
    /** If set the server will send `last_consumed_client_message_index` in the `session_resumption_update` messages to allow for transparent reconnections. */
    transparent?: boolean;
}

/**
 * Overrides the base URLs for the Gemini API and Vertex AI API.
 *
 * @remarks This function should be called before initializing the SDK. If the
 * base URLs are set after initializing the SDK, the base URLs will not be
 * updated. Base URLs provided in the HttpOptions will also take precedence over
 * URLs set here.
 *
 * @example
 * ```ts
 * import {GoogleGenAI, setDefaultBaseUrls} from '@google/genai';
 * // Override the base URL for the Gemini API.
 * setDefaultBaseUrls({geminiUrl:'https://gemini.google.com'});
 *
 * // Override the base URL for the Vertex AI API.
 * setDefaultBaseUrls({vertexUrl: 'https://vertexai.googleapis.com'});
 *
 * const ai = new GoogleGenAI({apiKey: 'GEMINI_API_KEY'});
 * ```
 */
export declare function setDefaultBaseUrls(baseUrlParams: BaseUrlParameters): void;

declare type SigningSecret$ = SigningSecret;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Represents a signing secret used to verify webhook payloads.
 */
declare type SigningSecret = {
    /**
     * Output only. The expiration date of the signing secret.
     */
    expire_time?: string | undefined;
    /**
     * Output only. The truncated version of the signing secret.
     */
    truncated_secret?: string | undefined;
};

/** Config for `response` parameter. */
export declare class SingleEmbedContentResponse {
    /** The response to the request.
     */
    embedding?: ContentEmbedding;
    /** The error encountered while processing the request.
     */
    tokenCount?: string;
}

/** Single reinforcement tuning reward config. */
export declare interface SingleReinforcementTuningRewardConfig {
    /** Scores parsed responses for autorater use cases by using a model to compute the reward. */
    autoraterScorer?: ReinforcementTuningAutoraterScorer;
    /** ReinforcementTuningCloudRunRewardScorer is used to score parsed responses by calling a Cloud Run service. */
    cloudRunRewardScorer?: ReinforcementTuningCloudRunRewardScorer;
    /** ReinforcementTuningCodeExecutionRewardScorer is used to score parsed responses for code execution use cases. */
    codeExecutionRewardScorer?: ReinforcementTuningCodeExecutionRewardScorer;
    /** Defines how to parse sample response. For example, given a sample response for evaluating the reward, users might want to extract the text only between `` and `` in the sample response, and keeps only the last one in case there are multiple such tags. To achieve such a purpose, they can define a regex `".*(.*?)"` using the ReinforcementTuningParseResponseConfig.ResponseParseType.REGEX_EXTRACT parse type. */
    parseResponseConfig?: ReinforcementTuningParseResponseConfig;
    /** A unique reward name for identifying each single reinforcement tuning reward. */
    rewardName?: string;
    /** ReinforcementTuningStringMatchRewardScorer is used to score parsed responses for simple string matching use cases against reference answers. */
    stringMatchRewardScorer?: ReinforcementTuningStringMatchRewardScorer;
}

/** Context window will be truncated by keeping only suffix of it.

 Context window will always be cut at start of USER role turn. System
 instructions and `BidiGenerateContentSetup.prefix_turns` will not be
 subject to the sliding window mechanism, they will always stay at the
 beginning of context window. */
export declare interface SlidingWindow {
    /** Session reduction target -- how many tokens we should keep. Window shortening operation has some latency costs, so we should avoid running it on every turn. Should be < trigger_tokens. If not set, trigger_tokens/2 is assumed. */
    targetTokens?: string;
}

declare type Smart$ = SmartTranscriptionMode;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for smart transcription mode.
 */
declare type SmartTranscriptionMode = {
    type: "smart";
};

declare type Source$ = Source;

/**
 * A source to be mounted into the environment.
 */
declare type Source = {
    /**
     * The inline content if `type` is `INLINE`.
     */
    content?: string | undefined;
    /**
     * Optional encoding for inline content (e.g. `base64`).
     */
    encoding?: string | undefined;
    /**
     * The source of the environment.
     *
     * @remarks
     * For Cloud Storage, this is the Cloud Storage path.
     * For GitHub, this is the GitHub path.
     */
    source?: string | undefined;
    /**
     * Where the source should appear in the environment.
     */
    target?: string | undefined;
    type?: SourceType | undefined;
};

declare type SourceFile$ = FileContent;

declare type SourceFile$2 = FileContent;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type SourceType = "gcs" | "inline" | "repository" | "skill_registry" | (string & {});

/**
 * Configuration for multi-speaker and speech generation.
 */
declare type SpeakerConfig = {
    /**
     * Individual speaker configurations.
     */
    speakers?: Array<SpeechConfig_2> | undefined;
};

/** Configuration for a single speaker in a multi-speaker setup. */
export declare interface SpeakerVoiceConfig {
    /** Required. The name of the speaker. This should be the same as the speaker name used in the prompt. */
    speaker?: string;
    /** Required. The configuration for the voice of this speaker. */
    voiceConfig?: VoiceConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Speech annotation for text content.
 */
declare type SpeechAnnotation = {
    /**
     * End of the attributed segment, exclusive.
     */
    end_index?: number | undefined;
    /**
     * The speaker to associate with this turn.
     */
    speaker?: string | undefined;
    /**
     * Start of segment of the response that is attributed to this source.
     *
     * @remarks
     *
     * Index indicates the start of the segment, measured in bytes.
     */
    start_index?: number | undefined;
    /**
     * Style instruction for the speech synthesis.
     */
    style?: string | undefined;
    type: "speech_metadata";
};

declare type SpeechConfig$ = SpeechConfig_2;

/** Config for speech generation and transcription. */
export declare interface SpeechConfig {
    /** The configuration in case of single-voice output. */
    voiceConfig?: VoiceConfig;
    /** Optional. The language code (ISO 639-1) for the speech synthesis. */
    languageCode?: string;
    /** The configuration for a multi-speaker text-to-speech request. This field is mutually exclusive with `voice_config`. */
    multiSpeakerVoiceConfig?: MultiSpeakerVoiceConfig;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The configuration for speech interaction.
 */
declare type SpeechConfig_2 = {
    /**
     * The language of the speech.
     */
    language?: string | undefined;
    /**
     * The speaker's name, it should match the speaker name given in the prompt.
     */
    speaker?: string | undefined;
    /**
     * The voice of the speaker.
     */
    voice?: string | undefined;
};

export declare type SpeechConfigUnion = SpeechConfig | string;

/**
 * Optional. Speech and multi-speaker configuration.
 */
declare type SpeechConfigUnion_2 = SpeakerConfig | Array<SpeechConfig_2>;

declare type SpeechMetadata$ = SpeechAnnotation;

/** Extra metadata associated with the part for speech synthesis. */
export declare interface SpeechMetadata {
    /** The speaker for this part, which must match a `speaker` name in
     `MultiSpeakerVoiceConfig.speaker_voice_configs`. */
    speaker?: string;
    /** The style instruction for how the voice should be synthesized
     (e.g. "excited, fast-paced"). */
    style?: string;
}

export declare type SseMessage<T> = {
    data?: T | undefined;
    event?: string | null | undefined;
    id?: string | null | undefined;
    retry?: number | null | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type StartEnvironmentFileUploadGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type StartEnvironmentFileUploadParams = Omit<StartEnvironmentFileUploadRequest, "environment" | "path">;

declare type StartEnvironmentFileUploadRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * The ID of the environment that owns the destination file.
     */
    environment: string;
    /**
     * The relative destination path inside the environment workspace.
     */
    path: string;
    /**
     * Optional. If true, treats the uploaded file as a tar/tar.gz archive and unpacks it into `path`.
     */
    extract?: boolean | undefined;
    /**
     * Optional. Whether to overwrite the destination file if it already exists.
     */
    overwrite?: boolean | undefined;
    /**
     * Command that starts the resumable upload session.
     */
    "X-Goog-Upload-Command"?: "start" | undefined;
    /**
     * Total number of file bytes that will be uploaded to the session URL.
     */
    "X-Goog-Upload-Header-Content-Length": number;
    /**
     * MIME type of the file that will be uploaded to the session URL.
     */
    "X-Goog-Upload-Header-Content-Type": string;
    /**
     * Resumable upload protocol selector.
     */
    "X-Goog-Upload-Protocol"?: "resumable" | undefined;
};

declare type StartEnvironmentFileUploadResponse = {
    Headers: {
        [k: string]: Array<string>;
    };
};

/** Start of speech sensitivity. */
export declare enum StartSensitivity {
    /**
     * The default is START_SENSITIVITY_LOW for Gemini Enterprise Agent Platform and START_SENSITIVITY_HIGH for Gemini Live.
     */
    START_SENSITIVITY_UNSPECIFIED = "START_SENSITIVITY_UNSPECIFIED",
    /**
     * Automatic detection will detect the start of speech more often.
     */
    START_SENSITIVITY_HIGH = "START_SENSITIVITY_HIGH",
    /**
     * Automatic detection will detect the start of speech less often.
     */
    START_SENSITIVITY_LOW = "START_SENSITIVITY_LOW"
}

declare type Static$ = StaticMediaProcessing;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type StaticMediaProcessing = {
    /**
     * Optional. Segment end time. Specified as a decimal number of seconds followed
     *
     * @remarks
     * by an 's' suffix, e.g., "30s". Must be non-negative and greater than
     * `start_offset` if `start_offset` is set.
     */
    end_offset?: string | undefined;
    /**
     * Optional. Video frame-rate sampling density.
     */
    fps?: number | undefined;
    /**
     * Optional. Segment start time. Specified as a decimal number of seconds followed
     *
     * @remarks
     * by an 's' suffix, e.g., "10.5s". Must be non-negative.
     */
    start_offset?: string | undefined;
    type: "static";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The `Status` type defines a logical error model that is suitable for
 *
 * @remarks
 * different programming environments, including REST APIs and RPC APIs. It is
 * used by [gRPC](https://github.com/grpc). Each `Status` message contains
 * three pieces of data: error code, error message, and error details.
 *
 * You can find out more about this error model and how to work with it in the
 * [API Design Guide](https://cloud.google.com/apis/design/errors).
 */
declare type Status = {
    /**
     * The status code, which should be an enum value of google.rpc.Code.
     */
    code?: number | undefined;
    /**
     * A list of messages that carry the error details.  There is a common set of
     *
     * @remarks
     * message types for APIs to use.
     */
    details?: Array<{
        [k: string]: any;
    }> | undefined;
    /**
     * A developer-facing error message, which should be in English. Any
     *
     * @remarks
     * user-facing error message should be localized and sent in the
     * google.rpc.Status.details field, or localized by the client.
     */
    message?: string | undefined;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Output only. Current status of the credential.
 */
declare type Status_2 = "active" | "revoked" | (string & {});

/**
 * Output only. The status of the environment container.
 */
declare type Status_3 = "active" | "expired" | (string & {});

declare type Step$ = Step;

/**
 * A step in the interaction.
 */
declare type Step = CodeExecutionCallStep | CodeExecutionResultStep | FileSearchCallStep | FileSearchResultStep | FunctionCallStep | FunctionResultStep | GoogleMapsCallStep | GoogleMapsResultStep | GoogleSearchCallStep | GoogleSearchResultStep | MCPServerToolCallStep | MCPServerToolResultStep | ModelOutputStep | ProcessingCallStep | ProcessingResultStep | RetrievalCallStep | RetrievalResultStep | ThoughtStep | URLContextCallStep | URLContextResultStep | UserInputStep;

declare type StepDelta$ = StepDelta;

declare type StepDelta = {
    delta: StepDeltaData;
    /**
     * The event_id token to be used to resume the interaction stream, from
     *
     * @remarks
     * this event.
     */
    event_id?: string | undefined;
    event_type: "step.delta";
    index: number;
    /**
     * Optional metadata accompanying ANY streamed event.
     */
    metadata?: StepDeltaMetadata | undefined;
};

declare type StepDeltaData = ArgumentsDelta | AudioDelta | CodeExecutionCallDelta | CodeExecutionResultDelta | DocumentDelta | FileSearchCallDelta | FileSearchResultDelta | FunctionResultDelta | GoogleMapsCallDelta | GoogleMapsResultDelta | GoogleSearchCallDelta | GoogleSearchResultDelta | ImageDelta | MCPServerToolCallDelta | MCPServerToolResultDelta | ProcessingCallDelta | ProcessingResultDelta | RetrievalCallDelta | RetrievalResultDelta | TextAnnotationDelta | TextDelta | ThoughtSignatureDelta | ThoughtSummaryDelta | URLContextCallDelta | URLContextResultDelta | VideoDelta;

/**
 * Optional metadata accompanying ANY streamed event.
 */
declare type StepDeltaMetadata = {
    /**
     * Statistics on the interaction request's token usage.
     */
    total_usage?: Usage | undefined;
};

declare type StepStart$ = StepStart;

declare type StepStart = {
    /**
     * The event_id token to be used to resume the interaction stream, from
     *
     * @remarks
     * this event.
     */
    event_id?: string | undefined;
    event_type: "step.start";
    index: number;
    /**
     * A step in the interaction.
     */
    step: Step;
};

declare type StepStop$ = StepStop;

declare type StepStop = {
    /**
     * The event_id token to be used to resume the interaction stream, from
     *
     * @remarks
     * this event.
     */
    event_id?: string | undefined;
    event_type: "step.stop";
    index: number;
    /**
     * Statistics on the interaction request's token usage.
     */
    step_usage?: Usage | undefined;
    /**
     * Statistics on the interaction request's token usage.
     */
    usage?: Usage | undefined;
};

export declare class Stream<T> extends ReadableStreamBase<T> {
    constructor(responseBody: ReadableStream<Uint8Array>, parse: (x: SseMessage<string>) => IteratorResult<T, undefined>, opts?: {
        dataRequired?: boolean;
    });
    [Symbol.asyncIterator](options?: unknown): StreamAsyncIterator<T>;
    values(options?: unknown): StreamAsyncIterator<T>;
}

/** A transport that can stream HTTP requests and responses. This data type is not supported in Vertex AI. */
export declare interface StreamableHttpTransport {
    /** Optional: Fields for authentication headers, timeouts, etc., if needed. */
    headers?: Record<string, string>;
    /** Timeout for SSE read operations. */
    sseReadTimeout?: string;
    /** Whether to close the client session when the transport closes. */
    terminateOnClose?: boolean;
    /** HTTP timeout for regular operations. */
    timeout?: string;
    /** The full URL for the MCPServer endpoint. Example: "https://api.example.com/mcp". */
    url?: string;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type StreamAsyncIterator<T> = {
    next(): Promise<IteratorResult<T, undefined>>;
    throw?(e?: unknown): Promise<IteratorResult<T, undefined>>;
    return?(): Promise<IteratorResult<T, undefined>>;
    [Symbol.asyncIterator](): StreamAsyncIterator<T>;
} & {
    [K in typeof Symbol extends {
        readonly asyncDispose: infer SymbolType extends symbol;
    } ? SymbolType : never]: () => PromiseLike<void>;
};

/** User provided string values assigned to a single metadata key. This data type is not supported in Vertex AI. */
export declare interface StringList {
    /** The string values of the metadata to store. */
    values?: string[];
}

/** Configuration for a Style reference image. */
export declare interface StyleReferenceConfig {
    /** A text description of the style to use for the generated image. */
    styleDescription?: string;
}

/** A style reference image.

 This encapsulates a style reference image provided by the user, and
 additionally optional config parameters for the style reference image.

 A raw reference image can also be provided as a destination for the style to
 be applied to. */
export declare class StyleReferenceImage {
    /** The reference image for the editing operation. */
    referenceImage?: Image_2;
    /** The id of the reference image. */
    referenceId?: number;
    /** The type of the reference image. Only set by the SDK. */
    referenceType?: string;
    /** Configuration for the style reference image. */
    config?: StyleReferenceConfig;
    /** Internal method to convert to ReferenceImageAPIInternal. */
    toReferenceImageAPI(): ReferenceImageAPIInternal;
}

/** Configuration for a Subject reference image. */
export declare interface SubjectReferenceConfig {
    /** The subject type of a subject reference image. */
    subjectType?: SubjectReferenceType;
    /** Subject description for the image. */
    subjectDescription?: string;
}

/** A subject reference image.

 This encapsulates a subject reference image provided by the user, and
 additionally optional config parameters for the subject reference image.

 A raw reference image can also be provided as a destination for the subject to
 be applied to. */
export declare class SubjectReferenceImage {
    /** The reference image for the editing operation. */
    referenceImage?: Image_2;
    /** The id of the reference image. */
    referenceId?: number;
    /** The type of the reference image. Only set by the SDK. */
    referenceType?: string;
    /** Configuration for the subject reference image. */
    config?: SubjectReferenceConfig;
    toReferenceImageAPI(): ReferenceImageAPIInternal;
}

/** Enum representing the subject type of a subject reference image. */
export declare enum SubjectReferenceType {
    SUBJECT_TYPE_DEFAULT = "SUBJECT_TYPE_DEFAULT",
    SUBJECT_TYPE_PERSON = "SUBJECT_TYPE_PERSON",
    SUBJECT_TYPE_ANIMAL = "SUBJECT_TYPE_ANIMAL",
    SUBJECT_TYPE_PRODUCT = "SUBJECT_TYPE_PRODUCT"
}

/** Hyperparameters for SFT. This data type is not supported in Gemini API. */
export declare interface SupervisedHyperParameters {
    /** Optional. Adapter size for tuning. */
    adapterSize?: AdapterSize;
    /** Optional. Batch size for tuning. This feature is only available for open source models. */
    batchSize?: string;
    /** Optional. Number of complete passes the model makes over the entire training dataset during training. */
    epochCount?: string;
    /** Optional. Learning rate for tuning. Mutually exclusive with `learning_rate_multiplier`. This feature is only available for open source models. */
    learningRate?: number;
    /** Optional. Multiplier for adjusting the default learning rate. Mutually exclusive with `learning_rate`. This feature is only available for 1P models. */
    learningRateMultiplier?: number;
}

/** Dataset distribution for Supervised Tuning. This data type is not supported in Gemini API. */
export declare interface SupervisedTuningDatasetDistribution {
    /** Output only. Sum of a given population of values that are billable. */
    billableSum?: string;
    /** Output only. Defines the histogram bucket. */
    buckets?: SupervisedTuningDatasetDistributionDatasetBucket[];
    /** Output only. The maximum of the population values. */
    max?: number;
    /** Output only. The arithmetic mean of the values in the population. */
    mean?: number;
    /** Output only. The median of the values in the population. */
    median?: number;
    /** Output only. The minimum of the population values. */
    min?: number;
    /** Output only. The 5th percentile of the values in the population. */
    p5?: number;
    /** Output only. The 95th percentile of the values in the population. */
    p95?: number;
    /** Output only. Sum of a given population of values. */
    sum?: string;
}

/** Dataset bucket used to create a histogram for the distribution given a population of values. This data type is not supported in Gemini API. */
export declare interface SupervisedTuningDatasetDistributionDatasetBucket {
    /** Output only. Number of values in the bucket. */
    count?: number;
    /** Output only. Left bound of the bucket. */
    left?: number;
    /** Output only. Right bound of the bucket. */
    right?: number;
}

/** Tuning data statistics for Supervised Tuning. This data type is not supported in Gemini API. */
export declare interface SupervisedTuningDataStats {
    /** Output only. For each index in `truncated_example_indices`, the user-facing reason why the example was dropped. */
    droppedExampleReasons?: string[];
    /** Output only. Number of billable characters in the tuning dataset. */
    totalBillableCharacterCount?: string;
    /** Output only. Number of billable tokens in the tuning dataset. */
    totalBillableTokenCount?: string;
    /** Output only. The number of examples in the dataset that have been dropped. An example can be dropped for reasons including: too many tokens, contains an invalid image, contains too many images, etc. */
    totalTruncatedExampleCount?: string;
    /** Output only. Number of tuning characters in the tuning dataset. */
    totalTuningCharacterCount?: string;
    /** Output only. A partial sample of the indices (starting from 1) of the dropped examples. */
    truncatedExampleIndices?: string[];
    /** Output only. Number of examples in the tuning dataset. */
    tuningDatasetExampleCount?: string;
    /** Output only. Number of tuning steps for this Tuning Job. */
    tuningStepCount?: string;
    /** Output only. Sample user messages in the training dataset uri. */
    userDatasetExamples?: Content[];
    /** Output only. Dataset distributions for the user input tokens. */
    userInputTokenDistribution?: SupervisedTuningDatasetDistribution;
    /** Output only. Dataset distributions for the messages per example. */
    userMessagePerExampleDistribution?: SupervisedTuningDatasetDistribution;
    /** Output only. Dataset distributions for the user output tokens. */
    userOutputTokenDistribution?: SupervisedTuningDatasetDistribution;
}

/** Supervised tuning spec for tuning. */
export declare interface SupervisedTuningSpec {
    /** Optional. If set to true, disable intermediate checkpoints for SFT and only the last checkpoint will be exported. Otherwise, enable intermediate checkpoints for SFT. Default is false. */
    exportLastCheckpointOnly?: boolean;
    /** Optional. Hyperparameters for SFT. */
    hyperParameters?: SupervisedHyperParameters;
    /** Required. Training dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    trainingDatasetUri?: string;
    /** Tuning mode. */
    tuningMode?: TuningMode;
    /** Optional. Validation dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    validationDatasetUri?: string;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Optional task mode for video generation. If not specified, the model
 *
 * @remarks
 * automatically determines the appropriate mode based on the provided text
 * prompt and input media.
 */
declare type Task = "text_to_video" | "image_to_video" | "reference_to_video" | "edit" | "extend" | "upscale" | (string & {});

export declare interface TestTableFile {
    comment?: string;
    testMethod?: string;
    parameterNames?: string[];
    testTable?: TestTableItem[];
}

export declare interface TestTableItem {
    /** The name of the test. This is used to derive the replay id. */
    name?: string;
    /** The parameters to the test. Use pydantic models. */
    parameters?: Record<string, unknown>;
    /** Expects an exception for MLDev matching the string. */
    exceptionIfMldev?: string;
    /** Expects an exception for Vertex matching the string. */
    exceptionIfVertex?: string;
    /** Use if you don't want to use the default replay id which is derived from the test name. */
    overrideReplayId?: string;
    /** True if the parameters contain an unsupported union type. This test  will be skipped for languages that do not support the union type. */
    hasUnion?: boolean;
    /** When set to a reason string, this test will be skipped in the API mode. Use this flag for tests that can not be reproduced with the real API. E.g. a test that deletes a resource. */
    skipInApiMode?: string;
    /** Keys to ignore when comparing the request and response. This is useful for tests that are not deterministic. */
    ignoreKeys?: string[];
}

declare type Text$ = TextDelta;

declare type TextAnnotationDelta$ = TextAnnotationDelta;

declare type TextAnnotationDelta = {
    /**
     * Citation information for model-generated content.
     */
    annotations?: Array<Annotation> | undefined;
    type: "text_annotation_delta";
};

declare type TextContent$ = TextContent;

/**
 * A text content block.
 */
declare type TextContent = {
    /**
     * Citation information for model-generated content.
     */
    annotations?: Array<Annotation> | undefined;
    /**
     * Required. The text content.
     */
    text: string;
    type: "text";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type TextDelta = {
    text: string;
    type: "text";
};

declare type TextResponseFormat$ = TextResponseFormat_2;

/** Configuration for text-specific output formatting. */
export declare class TextResponseFormat {
    /** Optional. The IANA standard MIME type of the response. */
    mimeType?: string;
    /** Optional. The JSON schema that the output should conform to. Only applicable when mime_type is APPLICATION_JSON. */
    schema?: unknown;
}

/**
 * Configuration for text output format.
 */
declare type TextResponseFormat_2 = {
    /**
     * The MIME type of the text output.
     */
    mime_type?: TextResponseFormatMimeType | undefined;
    /**
     * The JSON schema that the output should conform to. Only applicable when
     *
     * @remarks
     * mime_type is application/json.
     *
     * Supports a subset of JSON Schema. `minLength`, `maxLength`,
     * `minProperties`, `maxProperties`, `uniqueItems`, `contains`,
     * `minContains`, and `maxContains` are ignored and not enforced; validate
     * these in your application. `minItems` and `maxItems` are enforced. Schemas
     * that are too complex to enforce (for example, large `maxItems` on nested
     * arrays) return a 400 INVALID_ARGUMENT error.
     */
    schema?: {
        [k: string]: any;
    } | undefined;
    type: "text";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The MIME type of the text output.
 */
declare type TextResponseFormatMimeType = "application/json" | "text/plain" | (string & {});

/** The thinking features configuration. */
export declare interface ThinkingConfig {
    /** Indicates whether to include thoughts in the response. If true, thoughts are returned only if the model supports thought and thoughts are available.
     */
    includeThoughts?: boolean;
    /** Indicates the thinking budget in tokens. 0 is DISABLED. -1 is AUTOMATIC. The default values and allowed ranges are model dependent.
     */
    thinkingBudget?: number;
    /** Optional. The number of thoughts tokens that the model should generate. */
    thinkingLevel?: ThinkingLevel;
}

declare type ThinkingLevel$ = ThinkingLevel_2;

/** The number of thoughts tokens that the model should generate. */
export declare enum ThinkingLevel {
    /**
     * Unspecified thinking level.
     */
    THINKING_LEVEL_UNSPECIFIED = "THINKING_LEVEL_UNSPECIFIED",
    /**
     * MINIMAL thinking level.
     */
    MINIMAL = "MINIMAL",
    /**
     * Low thinking level.
     */
    LOW = "LOW",
    /**
     * Medium thinking level.
     */
    MEDIUM = "MEDIUM",
    /**
     * High thinking level.
     */
    HIGH = "HIGH"
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ThinkingLevel_2 = "minimal" | "low" | "medium" | "high" | (string & {});

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ThinkingSummaries = "auto" | "none" | (string & {});

declare type ThoughtSignature$ = ThoughtSignatureDelta;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ThoughtSignatureDelta = {
    /**
     * Signature to match the backend source to be part of the generation.
     */
    signature?: string | undefined;
    type: "thought_signature";
};

declare type ThoughtStep$ = ThoughtStep;

/**
 * A thought step.
 */
declare type ThoughtStep = {
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    /**
     * A summary of the thought.
     */
    summary?: Array<ThoughtSummaryContent> | undefined;
    type: "thought";
};

declare type ThoughtSummary$ = ThoughtSummaryDelta;

declare type ThoughtSummaryContent = ImageContent | TextContent;

declare type ThoughtSummaryDelta = {
    /**
     * The content of the response.
     */
    content?: Content_2 | undefined;
    type: "thought_summary";
};

/**
 * Required. The threshold for blocking content. If the harm probability
 *
 * @remarks
 * exceeds this threshold, the content will be blocked.
 */
declare type Threshold = "block_low_and_above" | "block_medium_and_above" | "block_only_high" | "block_none" | "off" | (string & {});

export declare class Tokens extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    /**
     * Creates an ephemeral auth token resource.
     *
     * @experimental
     *
     * @remarks
     * Ephemeral auth tokens is only supported in the Gemini Developer API.
     * It can be used for the session connection to the Live constrained API.
     * Support in v1alpha only.
     *
     * @param params - The parameters for the create request.
     * @return The created auth token.
     *
     * @example
     * ```ts
     * const ai = new GoogleGenAI({
     *     apiKey: token.name,
     *     httpOptions: { apiVersion: 'v1alpha' }  // Support in v1alpha only.
     * });
     *
     * // Case 1: If LiveEphemeralParameters is unset, unlock LiveConnectConfig
     * // when using the token in Live API sessions. Each session connection can
     * // use a different configuration.
     * const config: CreateAuthTokenConfig = {
     *     uses: 3,
     *     expireTime: '2025-05-01T00:00:00Z',
     * }
     * const token = await ai.tokens.create(config);
     *
     * // Case 2: If LiveEphemeralParameters is set, lock all fields in
     * // LiveConnectConfig when using the token in Live API sessions. For
     * // example, changing `outputAudioTranscription` in the Live API
     * // connection will be ignored by the API.
     * const config: CreateAuthTokenConfig =
     *     uses: 3,
     *     expireTime: '2025-05-01T00:00:00Z',
     *     LiveEphemeralParameters: {
     *        model: 'gemini-2.0-flash-001',
     *        config: {
     *           'responseModalities': ['AUDIO'],
     *           'systemInstruction': 'Always answer in English.',
     *        }
     *     }
     * }
     * const token = await ai.tokens.create(config);
     *
     * // Case 3: If LiveEphemeralParameters is set and lockAdditionalFields is
     * // set, lock LiveConnectConfig with set and additional fields (e.g.
     * // responseModalities, systemInstruction, temperature in this example) when
     * // using the token in Live API sessions.
     * const config: CreateAuthTokenConfig =
     *     uses: 3,
     *     expireTime: '2025-05-01T00:00:00Z',
     *     LiveEphemeralParameters: {
     *        model: 'gemini-2.0-flash-001',
     *        config: {
     *           'responseModalities': ['AUDIO'],
     *           'systemInstruction': 'Always answer in English.',
     *        }
     *     },
     *     lockAdditionalFields: ['temperature'],
     * }
     * const token = await ai.tokens.create(config);
     *
     * // Case 4: If LiveEphemeralParameters is set and lockAdditionalFields is
     * // empty array, lock LiveConnectConfig with set fields (e.g.
     * // responseModalities, systemInstruction in this example) when using the
     * // token in Live API sessions.
     * const config: CreateAuthTokenConfig =
     *     uses: 3,
     *     expireTime: '2025-05-01T00:00:00Z',
     *     LiveEphemeralParameters: {
     *        model: 'gemini-2.0-flash-001',
     *        config: {
     *           'responseModalities': ['AUDIO'],
     *           'systemInstruction': 'Always answer in English.',
     *        }
     *     },
     *     lockAdditionalFields: [],
     * }
     * const token = await ai.tokens.create(config);
     * ```
     */
    create(params: types.CreateAuthTokenParameters): Promise<types.AuthToken>;
}

/** Tokens info with a list of tokens and the corresponding list of token ids. */
export declare interface TokensInfo {
    /** Optional fields for the role from the corresponding Content. */
    role?: string;
    /** A list of token ids from the input. */
    tokenIds?: string[];
    /** A list of tokens from the input.
     * @remarks Encoded as base64 string. */
    tokens?: string[];
}

declare type Tool$ = Tool_2;

/** Tool details of a tool that the model may use to generate a response. */
export declare interface Tool {
    /** Optional. Retrieval tool type. System will always execute the provided retrieval tool(s) to get external knowledge to answer the prompt. Retrieval results are presented to the model for generation. This field is not supported in Gemini API. */
    retrieval?: Retrieval;
    /** Optional. Tool that allows grounding the model's response with
     geospatial context related to the user's query. */
    googleMaps?: GoogleMaps;
    /** Optional. MCP Servers to connect to. This field is not supported in Vertex AI. */
    mcpServers?: McpServer[];
    /** Optional. CodeExecution tool type. Enables the model to execute code as part of generation. */
    codeExecution?: ToolCodeExecution;
    /** Optional. Tool to support the model interacting directly with the computer. If enabled, it automatically populates computer-use specific Function Declarations. */
    computerUse?: ComputerUse;
    /** Optional. Tool to support searching public web data, powered by Vertex AI Search and Sec4 compliance. This field is not supported in Gemini API. */
    enterpriseWebSearch?: EnterpriseWebSearch;
    /** Optional. Uses Exa.ai to search for information to answer user queries. The search results will be grounded on Exa.ai and presented to the model for response generation. This field is not supported in Gemini API. */
    exaAiSearch?: ToolExaAiSearch;
    /** Optional. Function tool type. One or more function declarations to be passed to the model along with the current user query. Model may decide to call a subset of these functions by populating FunctionCall in the response. User should provide a FunctionResponse for each function call in the next turn. Based on the function responses, Model will generate the final response back to the user. Maximum 512 function declarations can be provided. */
    functionDeclarations?: FunctionDeclaration[];
    /** Optional. GoogleSearch tool type. Tool to support Google Search in Model. Powered by Google. */
    googleSearch?: GoogleSearch;
    /** Optional. Specialized retrieval tool that is powered by Google Search. */
    googleSearchRetrieval?: GoogleSearchRetrieval;
    /** Optional. If specified, Vertex AI will use Parallel.ai to search for information to answer user queries. The search results will be grounded on Parallel.ai and presented to the model for response generation. This field is not supported in Gemini API. */
    parallelAiSearch?: ToolParallelAiSearch;
    /** Optional. Tool to support URL context retrieval. */
    urlContext?: UrlContext;
    /** Optional. FileSearch tool type. Tool to retrieve knowledge from Semantic Retrieval corpora. This field is not supported in Vertex AI. */
    fileSearch?: FileSearch;
}

/**
 * A tool that can be used by the model.
 */
declare type Tool_2 = CodeExecution | ComputerUse_2 | FileSearch_2 | FunctionT | GoogleMaps_2 | GoogleSearch_2 | MCPServer | Retrieval_2 | URLContext;

/** A predicted server-side `ToolCall` returned from the model.

 This message contains information about a tool that the model wants to invoke.
 The client is NOT expected to execute this `ToolCall`. Instead, the
 client should pass this `ToolCall` back to the API in a subsequent turn
 within a `Content` message, along with the corresponding `ToolResponse`. */
export declare interface ToolCall {
    /** Unique identifier of the tool call. The server returns the tool response with the matching `id`. */
    id?: string;
    /** The type of tool that was called. */
    toolType?: ToolType;
    /** The tool call arguments. Example: {"arg1": "value1", "arg2": "value2"}. */
    args?: Record<string, unknown>;
}

/**
 * The tool choice configuration.
 */
declare type ToolChoice = ToolChoiceConfig | ToolChoiceType;

declare type ToolChoiceConfig$ = ToolChoiceConfig;

/**
 * The tool choice configuration containing allowed tools.
 */
declare type ToolChoiceConfig = {
    /**
     * The configuration for allowed tools.
     */
    allowed_tools?: AllowedTools | undefined;
};

declare type ToolChoiceType$ = ToolChoiceType;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type ToolChoiceType = "auto" | "any" | "none" | "validated" | (string & {});

/** Tool that executes code generated by the model, and automatically returns the result to the model. See also ExecutableCode and CodeExecutionResult, which are input and output to this tool. This data type is not supported in Gemini API. */
export declare interface ToolCodeExecution {
}

/** Tool config. This config is shared for all tools provided in the request. */
export declare interface ToolConfig {
    /** Optional. Function calling config. */
    functionCallingConfig?: FunctionCallingConfig;
    /** Optional. Retrieval config. */
    retrievalConfig?: RetrievalConfig;
    /** Optional. If true, the API response will include the server-side tool calls and responses within the `Content` message. This allows clients to observe the server's tool interactions. This field is not supported in Vertex AI. */
    includeServerSideToolInvocations?: boolean;
}

/** ExaAiSearch tool type. A tool that uses the Exa.ai search engine for grounding. This data type is not supported in Gemini API. */
export declare interface ToolExaAiSearch {
    /** Required. The API key for ExaAiSearch. */
    apiKey?: string;
    /** Optional. This field can be used to pass any parameter from the Exa.ai Search API. */
    customConfigs?: Record<string, unknown>;
}

export declare type ToolListUnion = ToolUnion[];

/** ParallelAiSearch tool type. A tool that uses the Parallel.ai search engine for grounding. This data type is not supported in Gemini API. */
export declare interface ToolParallelAiSearch {
    /** Optional. The API key for ParallelAiSearch. If an API key is not provided, the system will attempt to verify access by checking for an active Parallel.ai subscription through the Google Cloud Marketplace. See https://docs.parallel.ai/search/search-quickstart for more details. */
    apiKey?: string;
    /** Optional. Custom configs for ParallelAiSearch. This field can be used to pass any parameter from the Parallel.ai Search API. See the Parallel.ai documentation for the full list of available parameters and their usage: https://docs.parallel.ai/api-reference/search-beta/search Currently only `source_policy`, `excerpts`, `max_results`, `mode`, `fetch_policy` can be set via this field. For example: { "source_policy": { "include_domains": ["google.com", "wikipedia.org"], "exclude_domains": ["example.com"] }, "fetch_policy": { "max_age_seconds": 3600 } } */
    customConfigs?: Record<string, unknown>;
    /** Optional. Deprecated: Use `enable_zero_data_retention` instead. Instructs Vertex Grounding to use Parallel's Zero Data Retention Marketplace product. If this value is "false" or omitted, the Parallel Web Search for Grounding standard subscription will be used. If this value is "true", the Parallel Web Search for Grounding - ZDR subscription will be used. */
    enableDataRetention?: boolean;
    /** Optional. Instructs Vertex Grounding to use Parallel's Zero Data Retention Marketplace product. If this value is "false" or omitted, the Parallel Web Search for Grounding standard subscription will be used. If this value is "true", the Parallel Web Search for Grounding - ZDR subscription will be used. */
    enableZeroDataRetention?: boolean;
}

/** The output from a server-side `ToolCall` execution.

 This message contains the results of a tool invocation that was initiated by a
 `ToolCall` from the model. The client should pass this `ToolResponse` back to
 the API in a subsequent turn within a `Content` message, along with the
 corresponding `ToolCall`. */
export declare class ToolResponse {
    /** The identifier of the tool call this response is for. */
    id?: string;
    /** The type of tool that was called, matching the tool_type in the corresponding ToolCall. */
    toolType?: ToolType;
    /** The tool response. */
    response?: Record<string, unknown>;
}

/** The type of tool in the function call. */
export declare enum ToolType {
    /**
     * Unspecified tool type.
     */
    TOOL_TYPE_UNSPECIFIED = "TOOL_TYPE_UNSPECIFIED",
    /**
     * Google search tool, maps to Tool.google_search.search_types.web_search.
     */
    GOOGLE_SEARCH_WEB = "GOOGLE_SEARCH_WEB",
    /**
     * Image search tool, maps to Tool.google_search.search_types.image_search.
     */
    GOOGLE_SEARCH_IMAGE = "GOOGLE_SEARCH_IMAGE",
    /**
     * URL context tool, maps to Tool.url_context.
     */
    URL_CONTEXT = "URL_CONTEXT",
    /**
     * Google maps tool, maps to Tool.google_maps.
     */
    GOOGLE_MAPS = "GOOGLE_MAPS",
    /**
     * File search tool, maps to Tool.file_search.
     */
    FILE_SEARCH = "FILE_SEARCH",
    /**
     * Media processing tool.
     */
    MEDIA_PROCESSING = "MEDIA_PROCESSING"
}

export declare type ToolUnion = Tool | CallableTool;

declare type ToolUseTokensByModality$ = ModalityTokens;

/** Output only. The traffic type for this request. This enum is not supported in Gemini API. */
export declare enum TrafficType {
    /**
     * Unspecified request traffic type.
     */
    TRAFFIC_TYPE_UNSPECIFIED = "TRAFFIC_TYPE_UNSPECIFIED",
    /**
     * The request was processed using Pay-As-You-Go quota.
     */
    ON_DEMAND = "ON_DEMAND",
    /**
     * Type for Priority Pay-As-You-Go traffic.
     */
    ON_DEMAND_PRIORITY = "ON_DEMAND_PRIORITY",
    /**
     * Type for Flex traffic.
     */
    ON_DEMAND_FLEX = "ON_DEMAND_FLEX",
    /**
     * Type for Off-Peak Pay-As-You-Go traffic.
     */
    ON_DEMAND_OFFPEAK = "ON_DEMAND_OFFPEAK",
    /**
     * Type for Provisioned Throughput traffic.
     */
    PROVISIONED_THROUGHPUT = "PROVISIONED_THROUGHPUT"
}

/** Audio transcription in Server Content. */
export declare interface Transcription {
    /** Optional. Transcription text. */
    text?: string;
    /** Optional. The bool indicates the end of the transcription. */
    finished?: boolean;
    /** The BCP-47 language code of the transcription. */
    languageCode?: string;
    /** A label identifying the speaker of this audio segment (e.g. "spk_1", "spk_2").
     */
    speakerLabel?: string;
    /** Detailed word-level transcriptions and timing details.
     */
    words?: WordInfo[];
    /** Start offset in time of the transcription relative to the start of the audio.
     */
    startOffset?: string;
    /** End offset in time of the transcription relative to the start of the audio.
     */
    endOffset?: string;
}

declare type TranscriptionConfig$ = TranscriptionConfig;

/**
 * Configuration for speech recognition (transcription).
 */
declare type TranscriptionConfig = {
    /**
     * Optional. A list of phrases to bias the ASR model towards.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    adaptation_phrases?: Array<string> | undefined;
    /**
     * Optional. A list of custom vocabulary phrases to bias the speech recognition model
     *
     * @remarks
     * toward recognizing specific terms.
     */
    custom_vocabulary?: Array<string> | undefined;
    /**
     * Optional. Configures speaker diarization. Supported values: "speaker".
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    diarization_mode?: string | undefined;
    /**
     * Optional. BCP-47 language codes providing hints about the languages present in the
     *
     * @remarks
     * audio. If omitted or empty, defaults to automatic language detection.
     */
    language_codes?: Array<string> | undefined;
    /**
     * Deprecated: use language_codes. BCP-47 language codes providing hints about the languages present in the audio.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    language_hints?: Array<string> | undefined;
    /**
     * Discriminated transcription mode options or enum.
     */
    mode?: TranscriptionMode | TranscriptionConfigModeEnum | undefined;
    /**
     * Optional. The granularity of timestamps to include in the transcription output.
     *
     * @remarks
     * Supported values: "word". If empty, no timestamps are generated.
     *
     * @deprecated field: This will be removed in a future release, please migrate away from it as soon as possible.
     */
    timestamp_granularities?: Array<string> | undefined;
};

/**
 * Discriminated transcription mode options or enum.
 */
declare type TranscriptionConfigMode = TranscriptionMode | TranscriptionConfigModeEnum;

declare type TranscriptionConfigModeEnum = "verbatim" | "smart" | (string & {});

declare type TranscriptionMode$ = TranscriptionMode;

/**
 * Configuration for transcription mode.
 */
declare type TranscriptionMode = SmartTranscriptionMode | VerbatimTranscriptionMode;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Headers to inject on all outbound requests matching this domain. Accepts a single dict or a list of dicts. The egress proxy injects these automatically.
 */
declare type Transform = Array<{
    [k: string]: string;
}> | {
    [k: string]: string;
};

/** Config for stream translation. */
export declare interface TranslationConfig {
    /** If true, the model will generate audio when the target language is spoken, essentially it will parrot the input. If false, we will not produce audio for the target language. */
    echoTargetLanguage?: boolean;
    /** The target language for translation. Supported values are BCP-47 language codes (e.g. "en", "es", "fr"). */
    targetLanguageCode?: string;
}

declare type Trigger$ = Trigger;

/**
 * A trigger configuration that is scheduled to run an agent.
 */
declare type Trigger = {
    /**
     * Output only. The number of consecutive failures that have occurred
     *
     * @remarks
     * since the last successful execution.
     */
    consecutive_failure_count?: number | undefined;
    /**
     * Output only. The time when the trigger was created.
     */
    create_time?: string | undefined;
    /**
     * Optional. The display name of the trigger.
     */
    display_name?: string | undefined;
    /**
     * Optional. The environment ID for the trigger execution.
     */
    environment_id?: string | undefined;
    /**
     * Optional. The execution timeout for the triggered interaction.
     */
    execution_timeout_seconds?: number | undefined;
    /**
     * Required. Output only. Identifier. The ID of the trigger.
     */
    id: string;
    /**
     * Interaction for generating the completion using agents.
     */
    interaction: interactions.CreateAgentInteraction;
    /**
     * Output only. The time when the trigger was last paused.
     */
    last_pause_time?: string | undefined;
    /**
     * Output only. The time when the trigger was last resumed.
     */
    last_resume_time?: string | undefined;
    /**
     * Output only. The time when the trigger was last run.
     */
    last_run_time?: string | undefined;
    /**
     * Optional. The maximum number of consecutive failures allowed before
     *
     * @remarks
     * the trigger is automatically paused (status becomes ERROR).
     */
    max_consecutive_failures?: number | undefined;
    /**
     * Output only. The time when the trigger is scheduled to run next.
     */
    next_run_time?: string | undefined;
    /**
     * Output only. The ID of the last interaction created by this trigger.
     */
    previous_interaction_id?: string | undefined;
    /**
     * Required. The cron schedule on which the trigger should run.
     *
     * @remarks
     * Standard cron format.
     */
    schedule: string;
    /**
     * Output only. The current status of the trigger.
     */
    status?: TriggerStatus | undefined;
    /**
     * Required. Time zone in which the schedule should be interpreted.
     */
    time_zone: string;
    /**
     * Output only. The time when the trigger was last updated.
     */
    update_time?: string | undefined;
};

declare type TriggerCreateParams$ = TriggerCreateParams;

/**
 * Parameters for creating a trigger.
 */
declare type TriggerCreateParams = {
    /**
     * Optional. The display name of the trigger.
     */
    display_name?: string | undefined;
    /**
     * Optional. The environment ID for the trigger execution.
     */
    environment_id?: string | undefined;
    /**
     * Optional. The execution timeout for the triggered interaction.
     */
    execution_timeout_seconds?: number | undefined;
    /**
     * Interaction for generating the completion using agents.
     */
    interaction: interactions.CreateAgentInteraction;
    /**
     * Optional. The maximum number of consecutive failures allowed before
     *
     * @remarks
     * the trigger is automatically paused (status becomes ERROR).
     */
    max_consecutive_failures?: number | undefined;
    /**
     * Required. The cron schedule on which the trigger should run.
     *
     * @remarks
     * Standard cron format.
     */
    schedule: string;
    /**
     * Required. Time zone in which the schedule should be interpreted.
     */
    time_zone: string;
};

declare type TriggerDeleteParams$ = DeleteTriggerParams;

declare type TriggerDeleteResponse$ = Empty;

declare type TriggerExecution$ = TriggerExecution;

/**
 * An execution instance of a trigger.
 */
declare type TriggerExecution = {
    /**
     * Output only. The time when the execution finished.
     */
    end_time?: string | undefined;
    /**
     * Output only. The environment ID used for the execution.
     */
    environment_id?: string | undefined;
    /**
     * Output only. The error message if the execution failed.
     */
    error?: string | undefined;
    /**
     * Required. Output only. Identifier. The ID of the trigger execution.
     */
    id: string;
    /**
     * Output only. The ID of the interaction created by this execution, if any.
     */
    interaction_id?: string | undefined;
    /**
     * Output only. The time when the execution was scheduled to run.
     */
    scheduled_time?: string | undefined;
    /**
     * Output only. The time when the execution started.
     */
    start_time?: string | undefined;
    /**
     * Output only. The status of the execution.
     */
    status?: TriggerExecutionStatus | undefined;
    /**
     * Required. Output only. Identifier. The ID of the trigger that created this execution.
     */
    trigger_id: string;
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Output only. The status of the execution.
 */
declare type TriggerExecutionStatus = "in_progress" | "completed" | "failed" | "skipped" | "timed_out" | (string & {});

declare type TriggerGetParams$ = GetTriggerParams;

declare type TriggerListExecutionsParams$ = ListTriggerExecutionsParams;

declare type TriggerListExecutionsResponse$ = ListTriggerExecutionsResponse;

declare type TriggerListParams$ = ListTriggersParams;

declare type TriggerListResponse$ = ListTriggersResponse;

declare type TriggerRunParams$ = RunTriggerParams;

export declare namespace Triggers {
    export type ListTriggerExecutionsResponse = ListTriggerExecutionsResponse$;
    export type ListTriggersResponse = ListTriggersResponse$;
    export type Trigger = Trigger$;
    export type TriggerCreateParams = TriggerCreateParams$;
    export type TriggerDeleteParams = TriggerDeleteParams$;
    export type TriggerDeleteResponse = TriggerDeleteResponse$;
    export type TriggerExecution = TriggerExecution$;
    export type TriggerGetParams = TriggerGetParams$;
    export type TriggerListExecutionsParams = TriggerListExecutionsParams$;
    export type TriggerListExecutionsResponse = TriggerListExecutionsResponse$;
    export type TriggerListParams = TriggerListParams$;
    export type TriggerListResponse = TriggerListResponse$;
    export type TriggerRunParams = TriggerRunParams$;
    export type TriggerUpdate = TriggerUpdate$;
    export type TriggerUpdateParams = TriggerUpdateParams$;
}

declare namespace triggers {
    export {
        ListTriggerExecutionsResponse,
        ListTriggersResponse,
        TriggerCreateParams,
        TriggerExecutionStatus,
        TriggerExecution,
        TriggerUpdateStatus,
        TriggerUpdate,
        TriggerStatus,
        Trigger
    }
}

declare class Triggers_2 extends ClientSDK {
    /**
     * Lists triggers for a project.
     */
    list(params?: ListTriggersParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<triggers.ListTriggersResponse>;
    /**
     * Creates a new trigger that will invoke the specified agent on the given
     * cron schedule.
     */
    create(params: CreateTriggerParams, options?: RequestOptions): APIPromise<triggers.Trigger>;
    /**
     * Deletes a trigger.
     */
    delete(id: string, params?: DeleteTriggerParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<interactions.Empty>;
    /**
     * Gets details of a single trigger.
     */
    get(id: string, params?: GetTriggerParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<triggers.Trigger>;
    /**
     * Updates a trigger.
     */
    update(id: string, params: UpdateTriggerParams, options?: RequestOptions): APIPromise<triggers.Trigger>;
    /**
     * Lists executions for a trigger.
     */
    listExecutions(trigger_id: string, params?: ListTriggerExecutionsParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<triggers.ListTriggerExecutionsResponse>;
    /**
     * Runs a trigger immediately.
     */
    run(trigger_id: string, params?: RunTriggerParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<triggers.TriggerExecution>;
}

/**
 * Output only. The current status of the trigger.
 */
declare type TriggerStatus = "active" | "paused" | "error" | (string & {});

declare type TriggerUpdate$ = TriggerUpdate;

/**
 * Represents the fields of a Trigger that can be updated.
 */
declare type TriggerUpdate = {
    /**
     * Optional. The display name of the trigger.
     */
    display_name?: string | undefined;
    /**
     * Optional. The status of the trigger.
     */
    status?: TriggerUpdateStatus | undefined;
};

declare type TriggerUpdateParams$ = UpdateTriggerParams;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Optional. The status of the trigger.
 */
declare type TriggerUpdateStatus = "active" | "paused" | "error";

/** TunedModel for the Tuned Model of a Tuning Job. */
export declare interface TunedModel {
    /** Output only. The resource name of the TunedModel.
     Format: `projects/{project}/locations/{location}/models/{model}@{version_id}`
     When tuning from a base model, the version_id will be 1.
     For continuous tuning, the version id will be incremented by 1 from the
     last version id in the parent model. E.g., `projects/{project}/locations/{location}/models/{model}@{last_version_id + 1}`
     */
    model?: string;
    /** Output only. A resource name of an Endpoint.
     Format: `projects/{project}/locations/{location}/endpoints/{endpoint}`.
     */
    endpoint?: string;
    /** The checkpoints associated with this TunedModel.
     This field is only populated for tuning jobs that enable intermediate
     checkpoints. */
    checkpoints?: TunedModelCheckpoint[];
}

/** TunedModelCheckpoint for the Tuned Model of a Tuning Job. */
export declare interface TunedModelCheckpoint {
    /** The ID of the checkpoint.
     */
    checkpointId?: string;
    /** The epoch of the checkpoint.
     */
    epoch?: string;
    /** The step of the checkpoint.
     */
    step?: string;
    /** The Endpoint resource name that the checkpoint is deployed to.
     Format: `projects/{project}/locations/{location}/endpoints/{endpoint}`.
     */
    endpoint?: string;
}

/** A tuned machine learning model. */
export declare interface TunedModelInfo {
    /** ID of the base model that you want to tune. */
    baseModel?: string;
    /** Date and time when the base model was created. */
    createTime?: string;
    /** Date and time when the base model was last updated. */
    updateTime?: string;
}

/** Supervised fine-tuning training dataset. */
export declare interface TuningDataset {
    /** GCS URI of the file containing training dataset in JSONL format. */
    gcsUri?: string;
    /** The resource name of the Gemini Enterprise Agent Platform (previously known as Vertex AI) Multimodal Dataset that is used as training dataset. Example: 'projects/my-project-id-or-number/locations/my-location/datasets/my-dataset-id'. */
    vertexDatasetResource?: string;
    /** Inline examples with simple input/output text. */
    examples?: TuningExample[];
}

/** The tuning data statistic values for TuningJob. This data type is not supported in Gemini API. */
export declare interface TuningDataStats {
    /** Output only. Statistics for distillation prompt dataset. These statistics do not include the responses sampled from the teacher model. */
    distillationDataStats?: DistillationDataStats;
    /** Output only. Statistics for preference optimization. */
    preferenceOptimizationDataStats?: PreferenceOptimizationDataStats;
    /** Output only. Statistics for reinforcement tuning. */
    reinforcementTuningDataStats?: DatasetStats;
    /** The SFT Tuning data stats. */
    supervisedTuningDataStats?: SupervisedTuningDataStats;
}

/** A single example for tuning. This data type is not supported in Vertex AI. */
export declare interface TuningExample {
    /** Required. The expected model output. */
    output?: string;
    /** Optional. Text model input. */
    textInput?: string;
}

/** A tuning job. */
export declare interface TuningJob {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** Output only. Identifier. Resource name of a TuningJob. Format: `projects/{project}/locations/{location}/tuningJobs/{tuning_job}` */
    name?: string;
    /** Output only. The detailed state of the job. */
    state?: JobState;
    /** Output only. Time when the TuningJob was created. */
    createTime?: string;
    /** Output only. Time when the TuningJob for the first time entered the `JOB_STATE_RUNNING` state. */
    startTime?: string;
    /** Output only. Time when the TuningJob entered any of the following JobStates: `JOB_STATE_SUCCEEDED`, `JOB_STATE_FAILED`, `JOB_STATE_CANCELLED`, `JOB_STATE_EXPIRED`. */
    endTime?: string;
    /** Output only. Time when the TuningJob was most recently updated. */
    updateTime?: string;
    /** Output only. Only populated when job's state is `JOB_STATE_FAILED` or `JOB_STATE_CANCELLED`. */
    error?: GoogleRpcStatus;
    /** Optional. The description of the TuningJob. */
    description?: string;
    /** The base model that is being tuned. See [Supported models](https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/tuning#supported_models). */
    baseModel?: string;
    /** Output only. The tuned model resources associated with this TuningJob. */
    tunedModel?: TunedModel;
    /** The pre-tuned model for continuous tuning. */
    preTunedModel?: PreTunedModel;
    /** Tuning Spec for Supervised Fine Tuning. */
    supervisedTuningSpec?: SupervisedTuningSpec;
    /** Tuning Spec for Preference Optimization. */
    preferenceOptimizationSpec?: PreferenceOptimizationSpec;
    distillationSamplingSpec?: DistillationSamplingSpec;
    /** Tuning Spec for Distillation. */
    distillationSpec?: DistillationSpec;
    /** Tuning Spec for Reinforcement Tuning. */
    reinforcementTuningSpec?: ReinforcementTuningSpec;
    /** Output only. The tuning data statistics associated with this TuningJob. */
    tuningDataStats?: TuningDataStats;
    /** Customer-managed encryption key options for a TuningJob. If this is set, then all resources created by the TuningJob will be encrypted with the provided encryption key. */
    encryptionSpec?: EncryptionSpec;
    /** Tuning Spec for open sourced and third party Partner models. */
    partnerModelTuningSpec?: PartnerModelTuningSpec;
    /** Optional. The user-provided path to custom model weights. Set this field to tune a custom model. The path must be a Cloud Storage directory that contains the model weights in .safetensors format along with associated model metadata files. If this field is set, the base_model field must still be set to indicate which base model the custom model is derived from. This feature is only available for open source models. */
    customBaseModel?: string;
    /** Output only. Evaluation runs for the Tuning Job. */
    evaluateDatasetRuns?: EvaluateDatasetRun[];
    /** Output only. The Experiment associated with this TuningJob. */
    experiment?: string;
    /** Tuning Spec for Full Fine Tuning. */
    fullFineTuningSpec?: FullFineTuningSpec;
    /** Optional. The labels with user-defined metadata to organize TuningJob and generated resources such as Model and Endpoint. Label keys and values can be no longer than 64 characters (Unicode codepoints), can only contain lowercase letters, numeric characters, underscores and dashes. International characters are allowed. See https://goo.gl/xmQnxf for more information and examples of labels. */
    labels?: Record<string, string>;
    /** Optional. Cloud Storage path to the directory where tuning job outputs are written to. This field is only available and required for open source models. */
    outputUri?: string;
    /** Output only. The resource name of the PipelineJob associated with the TuningJob. Format: `projects/{project}/locations/{location}/pipelineJobs/{pipeline_job}`. */
    pipelineJob?: string;
    /** The service account that the tuningJob workload runs as. If not specified, the Vertex AI Secure Fine-Tuned Service Agent in the project will be used. See https://cloud.google.com/iam/docs/service-agents#vertex-ai-secure-fine-tuning-service-agent Users starting the pipeline must have the `iam.serviceAccounts.actAs` permission on this service account. */
    serviceAccount?: string;
    /** Optional. The display name of the TunedModel. The name can be up to 128 characters long and can consist of any UTF-8 characters. For continuous tuning, tuned_model_display_name will by default use the same display name as the pre-tuned model. If a new display name is provided, the tuning job will create a new model instead of a new version. */
    tunedModelDisplayName?: string;
    /** Output only. Tuning Job metadata. */
    tuningJobMetadata?: TuningJobMetadata;
    /** Output only. The detail state of the tuning job (while the overall `JobState` is running). */
    tuningJobState?: TuningJobState;
    /** Tuning Spec for Veo LoRA Tuning. */
    veoLoraTuningSpec?: VeoLoraTuningSpec;
    /** Tuning Spec for Veo Tuning. */
    veoTuningSpec?: VeoTuningSpec;
    /** Output only. The Cloud Storage metrics URI associated with this TuningJob. */
    gcsMetricsUri?: string;
}

/** Tuning job metadata. This data type is not supported in Gemini API. */
export declare interface TuningJobMetadata {
    /** Output only. The number of epochs that have been completed. */
    completedEpochCount?: string;
    /** Output only. The number of steps that have been completed. Set for Multi-Step RL. */
    completedStepCount?: string;
}

/** Output only. The detail state of the tuning job (while the overall `JobState` is running). This enum is not supported in Gemini API. */
export declare enum TuningJobState {
    /**
     * Default tuning job state.
     */
    TUNING_JOB_STATE_UNSPECIFIED = "TUNING_JOB_STATE_UNSPECIFIED",
    /**
     * Tuning job is waiting for job quota.
     */
    TUNING_JOB_STATE_WAITING_FOR_QUOTA = "TUNING_JOB_STATE_WAITING_FOR_QUOTA",
    /**
     * Tuning job is validating the dataset.
     */
    TUNING_JOB_STATE_PROCESSING_DATASET = "TUNING_JOB_STATE_PROCESSING_DATASET",
    /**
     * Tuning job is waiting for hardware capacity.
     */
    TUNING_JOB_STATE_WAITING_FOR_CAPACITY = "TUNING_JOB_STATE_WAITING_FOR_CAPACITY",
    /**
     * Tuning job is running.
     */
    TUNING_JOB_STATE_TUNING = "TUNING_JOB_STATE_TUNING",
    /**
     * Tuning job is doing some post processing steps.
     */
    TUNING_JOB_STATE_POST_PROCESSING = "TUNING_JOB_STATE_POST_PROCESSING"
}

/** Enum representing the tuning method. */
export declare enum TuningMethod {
    /**
     * Supervised fine tuning.
     */
    SUPERVISED_FINE_TUNING = "SUPERVISED_FINE_TUNING",
    /**
     * Preference optimization tuning.
     */
    PREFERENCE_TUNING = "PREFERENCE_TUNING",
    /**
     * Distillation tuning.
     */
    DISTILLATION = "DISTILLATION",
    /**
     * Reinforcement tuning.
     */
    REINFORCEMENT_TUNING = "REINFORCEMENT_TUNING"
}

/** Tuning mode. This enum is not supported in Gemini API. */
export declare enum TuningMode {
    /**
     * Tuning mode is unspecified.
     */
    TUNING_MODE_UNSPECIFIED = "TUNING_MODE_UNSPECIFIED",
    /**
     * Full fine-tuning mode.
     */
    TUNING_MODE_FULL = "TUNING_MODE_FULL",
    /**
     * PEFT adapter tuning mode.
     */
    TUNING_MODE_PEFT_ADAPTER = "TUNING_MODE_PEFT_ADAPTER"
}

/** A long-running operation. */
export declare interface TuningOperation {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** The server-assigned name, which is only unique within the same service that originally returns it. If you use the default HTTP mapping, the `name` should be a resource name ending with `operations/{unique_id}`. */
    name?: string;
    /** Service-specific metadata associated with the operation. It typically contains progress information and common metadata such as create time. Some services might not provide such metadata.  Any method that returns a long-running operation should document the metadata type, if any. */
    metadata?: Record<string, unknown>;
    /** If the value is `false`, it means the operation is still in progress. If `true`, the operation is completed, and either `error` or `response` is available. */
    done?: boolean;
    /** The error result of the operation in case of failure or cancellation. */
    error?: Record<string, unknown>;
}

declare class Tunings extends BaseModule {
    private readonly apiClient;
    constructor(apiClient: ApiClient);
    /**
     * Lists tuning jobs.
     *
     * @param params - The parameters for the list request.
     * @return - A pager of tuning jobs.
     *
     * @example
     * ```ts
     * const tuningJobs = await ai.tunings.list({config: {'pageSize': 2}});
     * for await (const tuningJob of tuningJobs) {
     *   console.log(tuningJob);
     * }
     * ```
     */
    list: (params?: types.ListTuningJobsParameters) => Promise<Pager<types.TuningJob>>;
    /**
     * Gets a TuningJob.
     *
     * @param name - The resource name of the tuning job.
     * @return - A TuningJob object.
     *
     * @experimental - The SDK's tuning implementation is experimental, and may
     * change in future versions.
     */
    get: (params: types.GetTuningJobParameters) => Promise<types.TuningJob>;
    /**
     * Creates a supervised fine-tuning job.
     *
     * @param params - The parameters for the tuning job.
     * @return - A TuningJob operation.
     *
     * @experimental - The SDK's tuning implementation is experimental, and may
     * change in future versions.
     */
    tune: (params: types.CreateTuningJobParameters) => Promise<types.TuningJob>;
    private getInternal;
    private listInternal;
    /**
     * Cancels a tuning job.
     *
     * @param params - The parameters for the cancel request.
     * @return The empty response returned by the API.
     *
     * @example
     * ```ts
     * await ai.tunings.cancel({name: '...'}); // The server-generated resource name.
     * ```
     */
    cancel(params: types.CancelTuningJobParameters): Promise<types.CancelTuningJobResponse>;
    private tuneInternal;
    private tuneMldevInternal;
    validateReward(params: types.ValidateRewardParameters): Promise<types.ValidateRewardResponse>;
}

/** The speed of the tuning job. Only supported for Veo 3.0 models. This enum is not supported in Gemini API. */
export declare enum TuningSpeed {
    /**
     * The default / unset value. For Veo 3.0 models, this defaults to FAST.
     */
    TUNING_SPEED_UNSPECIFIED = "TUNING_SPEED_UNSPECIFIED",
    /**
     * Regular tuning speed.
     */
    REGULAR = "REGULAR",
    /**
     * Fast tuning speed.
     */
    FAST = "FAST"
}

/** The tuning task for Veo. This enum is not supported in Gemini API. */
export declare enum TuningTask {
    /**
     * Default value. This value is unused.
     */
    TUNING_TASK_UNSPECIFIED = "TUNING_TASK_UNSPECIFIED",
    /**
     * Tuning task for image to video.
     */
    TUNING_TASK_I2V = "TUNING_TASK_I2V",
    /**
     * Tuning task for text to video.
     */
    TUNING_TASK_T2V = "TUNING_TASK_T2V",
    /**
     * Tuning task for reference to video.
     */
    TUNING_TASK_R2V = "TUNING_TASK_R2V"
}

export declare interface TuningValidationDataset {
    /** GCS URI of the file containing validation dataset in JSONL format. */
    gcsUri?: string;
    /** The resource name of the Gemini Enterprise Agent Platform (previously known as Vertex AI) Multimodal Dataset that is used as validation dataset. Example: 'projects/my-project-id-or-number/locations/my-location/datasets/my-dataset-id'. */
    vertexDatasetResource?: string;
}

/** The reason why the turn is complete. */
export declare enum TurnCompleteReason {
    /**
     * Default value. Reason is unspecified.
     */
    TURN_COMPLETE_REASON_UNSPECIFIED = "TURN_COMPLETE_REASON_UNSPECIFIED",
    /**
     * The function call generated by the model is invalid.
     */
    MALFORMED_FUNCTION_CALL = "MALFORMED_FUNCTION_CALL",
    /**
     * The response is rejected by the model.
     */
    RESPONSE_REJECTED = "RESPONSE_REJECTED",
    /**
     * Needs more input from the user.
     */
    NEED_MORE_INPUT = "NEED_MORE_INPUT",
    /**
     * Input content is prohibited.
     */
    PROHIBITED_INPUT_CONTENT = "PROHIBITED_INPUT_CONTENT",
    /**
     * Input image contains prohibited content.
     */
    IMAGE_PROHIBITED_INPUT_CONTENT = "IMAGE_PROHIBITED_INPUT_CONTENT",
    /**
     * Input text contains prominent person reference.
     */
    INPUT_TEXT_CONTAIN_PROMINENT_PERSON_PROHIBITED = "INPUT_TEXT_CONTAIN_PROMINENT_PERSON_PROHIBITED",
    /**
     * Input image contains celebrity.
     */
    INPUT_IMAGE_CELEBRITY = "INPUT_IMAGE_CELEBRITY",
    /**
     * Input image contains photo realistic child.
     */
    INPUT_IMAGE_PHOTO_REALISTIC_CHILD_PROHIBITED = "INPUT_IMAGE_PHOTO_REALISTIC_CHILD_PROHIBITED",
    /**
     * Input text contains NCII content.
     */
    INPUT_TEXT_NCII_PROHIBITED = "INPUT_TEXT_NCII_PROHIBITED",
    /**
     * Other input safety issue.
     */
    INPUT_OTHER = "INPUT_OTHER",
    /**
     * Input contains IP violation.
     */
    INPUT_IP_PROHIBITED = "INPUT_IP_PROHIBITED",
    /**
     * Input matched blocklist.
     */
    BLOCKLIST = "BLOCKLIST",
    /**
     * Input is unsafe for image generation.
     */
    UNSAFE_PROMPT_FOR_IMAGE_GENERATION = "UNSAFE_PROMPT_FOR_IMAGE_GENERATION",
    /**
     * Generated image failed safety check.
     */
    GENERATED_IMAGE_SAFETY = "GENERATED_IMAGE_SAFETY",
    /**
     * Generated content failed safety check.
     */
    GENERATED_CONTENT_SAFETY = "GENERATED_CONTENT_SAFETY",
    /**
     * Generated audio failed safety check.
     */
    GENERATED_AUDIO_SAFETY = "GENERATED_AUDIO_SAFETY",
    /**
     * Generated video failed safety check.
     */
    GENERATED_VIDEO_SAFETY = "GENERATED_VIDEO_SAFETY",
    /**
     * Generated content is prohibited.
     */
    GENERATED_CONTENT_PROHIBITED = "GENERATED_CONTENT_PROHIBITED",
    /**
     * Generated content matched blocklist.
     */
    GENERATED_CONTENT_BLOCKLIST = "GENERATED_CONTENT_BLOCKLIST",
    /**
     * Generated image is prohibited.
     */
    GENERATED_IMAGE_PROHIBITED = "GENERATED_IMAGE_PROHIBITED",
    /**
     * Generated image contains celebrity.
     */
    GENERATED_IMAGE_CELEBRITY = "GENERATED_IMAGE_CELEBRITY",
    /**
     * Generated image contains prominent people detected by rewriter.
     */
    GENERATED_IMAGE_PROMINENT_PEOPLE_DETECTED_BY_REWRITER = "GENERATED_IMAGE_PROMINENT_PEOPLE_DETECTED_BY_REWRITER",
    /**
     * Generated image contains identifiable people.
     */
    GENERATED_IMAGE_IDENTIFIABLE_PEOPLE = "GENERATED_IMAGE_IDENTIFIABLE_PEOPLE",
    /**
     * Generated image contains minors.
     */
    GENERATED_IMAGE_MINORS = "GENERATED_IMAGE_MINORS",
    /**
     * Generated image contains IP violation.
     */
    OUTPUT_IMAGE_IP_PROHIBITED = "OUTPUT_IMAGE_IP_PROHIBITED",
    /**
     * Other generated content issue.
     */
    GENERATED_OTHER = "GENERATED_OTHER",
    /**
     * Max regeneration attempts reached.
     */
    MAX_REGENERATION_REACHED = "MAX_REGENERATION_REACHED"
}

/** Options about which input is included in the user's turn. */
export declare enum TurnCoverage {
    /**
     * If unspecified, the default behavior is `TURN_INCLUDES_ONLY_ACTIVITY`.
     */
    TURN_COVERAGE_UNSPECIFIED = "TURN_COVERAGE_UNSPECIFIED",
    /**
     * The users turn only includes activity since the last turn, excluding inactivity (e.g. silence on the audio stream). This is the default behavior.
     */
    TURN_INCLUDES_ONLY_ACTIVITY = "TURN_INCLUDES_ONLY_ACTIVITY",
    /**
     * The users turn includes all realtime input since the last turn, including inactivity (e.g. silence on the audio stream).
     */
    TURN_INCLUDES_ALL_INPUT = "TURN_INCLUDES_ALL_INPUT",
    /**
     * Includes audio activity and all video since the last turn. With automatic activity detection, audio activity means speech and excludes silence.
     */
    TURN_INCLUDES_AUDIO_ACTIVITY_AND_ALL_VIDEO = "TURN_INCLUDES_AUDIO_ACTIVITY_AND_ALL_VIDEO"
}

/** Data type of the schema field. */
export declare enum Type {
    /**
     * Not specified, should not be used.
     */
    TYPE_UNSPECIFIED = "TYPE_UNSPECIFIED",
    /**
     * OpenAPI string type
     */
    STRING = "STRING",
    /**
     * OpenAPI number type
     */
    NUMBER = "NUMBER",
    /**
     * OpenAPI integer type
     */
    INTEGER = "INTEGER",
    /**
     * OpenAPI boolean type
     */
    BOOLEAN = "BOOLEAN",
    /**
     * OpenAPI array type
     */
    ARRAY = "ARRAY",
    /**
     * OpenAPI object type
     */
    OBJECT = "OBJECT",
    /**
     * Null type
     */
    NULL = "NULL"
}

/**
 * Required. Output only. The type of credential.
 */
declare type Type_2 = "bearer_token" | "oauth2" | "environment_variable" | (string & {});

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Output only. The type of the entry.
 */
declare type Type_3 = "file" | "directory" | (string & {});

declare namespace types {
    export {
        createFunctionResponsePartFromBase64,
        createFunctionResponsePartFromUri,
        createPartFromUri,
        createPartFromText,
        createPartFromFunctionCall,
        createPartFromFunctionResponse,
        createPartFromBase64,
        createPartFromCodeExecutionResult,
        createPartFromExecutableCode,
        createUserContent,
        createModelContent,
        MediaProcessing,
        Outcome,
        Language,
        FunctionResponseScheduling,
        Type,
        AuthType,
        HttpElementLocation,
        ApiSpec,
        SafetyPolicy,
        Environment,
        PhishBlockThreshold,
        Behavior,
        DynamicRetrievalConfigMode,
        ThinkingLevel,
        PersonGeneration,
        ProminentPeople,
        HarmCategory,
        HarmBlockMethod,
        HarmBlockThreshold,
        FunctionCallingConfigMode,
        AudioTranscriptionConfigMode,
        FinishReason,
        HarmProbability,
        HarmSeverity,
        UrlRetrievalStatus,
        BlockedReason,
        TrafficType,
        MediaModality,
        ModelStage,
        MediaResolution,
        Modality,
        Delivery,
        AspectRatio,
        ImageSize,
        TuningMode,
        AdapterSize,
        ResponseParseType,
        MatchOperation,
        ReinforcementTuningThinkingLevel,
        JobState,
        TuningJobState,
        AggregationMetric,
        PairwiseChoice,
        VideoOrientation,
        TuningSpeed,
        TuningTask,
        DocumentState,
        ServiceTier,
        PartMediaResolutionLevel,
        ToolType,
        ResourceScope,
        FeatureSelectionPreference,
        EmbeddingApiType,
        SafetyFilterLevel,
        ImagePromptLanguage,
        MaskReferenceMode,
        ControlReferenceType,
        SubjectReferenceType,
        EditMode,
        SegmentMode,
        VideoGenerationReferenceType,
        VideoGenerationMaskMode,
        VideoCompressionQuality,
        ImageResizeMode,
        TuningMethod,
        FileState,
        FileSource,
        TurnCompleteReason,
        InteractionStatus,
        VadSignalType,
        VoiceActivityType,
        StartSensitivity,
        EndSensitivity,
        ActivityHandling,
        TurnCoverage,
        Scale,
        MusicGenerationMode,
        LiveMusicPlaybackControl,
        PartMediaResolution,
        ToolCall,
        ToolResponse,
        SpeechMetadata,
        WordInfo,
        Transcription,
        CodeExecutionResult,
        ExecutableCode,
        FileData,
        PartialArg,
        FunctionCall,
        FunctionResponseFileData,
        FunctionResponseBlob,
        FunctionResponsePart,
        FunctionResponse,
        Blob_2 as Blob,
        VideoMetadata,
        Part,
        Content,
        HttpRetryOptions,
        HttpOptions,
        Schema,
        ModelSelectionConfig,
        ApiKeyConfig,
        AuthConfigGoogleServiceAccountConfig,
        AuthConfigHttpBasicAuthConfig,
        AuthConfigOauthConfig,
        AuthConfigOidcConfig,
        AuthConfig,
        GoogleMapsPlaces,
        GoogleMapsRouting,
        GoogleMapsGroundingTypes,
        GoogleMaps,
        ApiAuthApiKeyConfig,
        ApiAuth,
        ExternalApiElasticSearchParams,
        ExternalApiSimpleSearchParams,
        ExternalApi,
        VertexAISearchDataStoreSpec,
        VertexAISearch,
        VertexRagStoreRagResource,
        RagRetrievalConfigFilter,
        RagRetrievalConfigHybridSearch,
        RagRetrievalConfigRankingLlmRanker,
        RagRetrievalConfigRankingRankService,
        RagRetrievalConfigRanking,
        RagRetrievalConfig,
        VertexRagStore,
        Retrieval,
        StreamableHttpTransport,
        McpServer,
        ToolCodeExecution,
        ComputerUse,
        EnterpriseWebSearch,
        ToolExaAiSearch,
        FunctionDeclaration,
        ImageSearch,
        WebSearch,
        SearchTypes,
        Interval,
        GoogleSearch,
        DynamicRetrievalConfig,
        GoogleSearchRetrieval,
        ToolParallelAiSearch,
        UrlContext,
        FileSearch,
        Tool,
        VoiceConsentSignature,
        ReplicatedVoiceConfig,
        PrebuiltVoiceConfig,
        VoiceConfig,
        SpeakerVoiceConfig,
        MultiSpeakerVoiceConfig,
        SpeechConfig,
        AutomaticFunctionCallingConfig,
        ThinkingConfig,
        ImageConfigImageOutputOptions,
        ImageConfig,
        GenerationOutputConfig,
        GenerationConfigRoutingConfigAutoRoutingMode,
        GenerationConfigRoutingConfigManualRoutingMode,
        GenerationConfigRoutingConfig,
        SafetySetting,
        FunctionCallingConfig,
        LatLng,
        RetrievalConfig,
        ToolConfig,
        LanguageAuto,
        LanguageHints,
        AudioTranscriptionConfig,
        ModelArmorConfig,
        GenerateContentConfig,
        GenerateContentParameters,
        HttpResponse,
        LiveCallbacks,
        GoogleTypeDate,
        Citation,
        CitationMetadata,
        GroundingChunkMapsPlaceAnswerSourcesAuthorAttribution,
        GroundingChunkMapsPlaceAnswerSourcesReviewSnippet,
        GroundingChunkMapsPlaceAnswerSources,
        GroundingChunkMapsRoute,
        GroundingChunkMaps,
        GroundingChunkImage,
        RagChunkPageSpan,
        RagChunk,
        GroundingChunkStringList,
        GroundingChunkCustomMetadata,
        GroundingChunkRetrievedContext,
        GroundingChunkWeb,
        GroundingChunk,
        Segment,
        GroundingSupport,
        RetrievalMetadata,
        SearchEntryPoint,
        GroundingMetadataSourceFlaggingUri,
        GroundingMetadata,
        LogprobsResultCandidate,
        LogprobsResultTopCandidates,
        LogprobsResult,
        SafetyRating,
        UrlMetadata,
        UrlContextMetadata,
        Candidate,
        GenerateContentResponsePromptFeedback,
        ModalityTokenCount,
        GenerateContentResponseUsageMetadata,
        ModelStatus,
        GenerateContentResponse,
        ReferenceImage,
        EditImageParameters,
        EmbedContentConfig,
        EmbedContentParametersPrivate,
        ContentEmbeddingStatistics,
        ContentEmbedding,
        EmbedContentMetadata,
        EmbedContentResponse,
        GenerateImagesConfig,
        GenerateImagesParameters,
        Image_2 as Image,
        SafetyAttributes,
        GeneratedImage,
        GenerateImagesResponse,
        MaskReferenceConfig,
        ControlReferenceConfig,
        StyleReferenceConfig,
        SubjectReferenceConfig,
        EditImageConfig,
        EditImageResponse,
        UpscaleImageResponse,
        ProductImage,
        RecontextImageSource,
        RecontextImageConfig,
        RecontextImageParameters,
        RecontextImageResponse,
        ScribbleImage,
        SegmentImageSource,
        SegmentImageConfig,
        SegmentImageParameters,
        EntityLabel,
        GeneratedImageMask,
        SegmentImageResponse,
        GetModelConfig,
        GetModelParameters,
        Endpoint,
        TunedModelInfo,
        Checkpoint,
        Model,
        ListModelsConfig,
        ListModelsParameters,
        ListModelsResponse,
        UpdateModelConfig,
        UpdateModelParameters,
        DeleteModelConfig,
        DeleteModelParameters,
        DeleteModelResponse,
        AudioResponseFormat,
        ImageResponseFormat,
        TextResponseFormat,
        VideoResponseFormat,
        ResponseFormat,
        TranslationConfig,
        GenerationConfig,
        CountTokensConfig,
        CountTokensParameters,
        CountTokensResponse,
        ComputeTokensConfig,
        ComputeTokensParameters,
        TokensInfo,
        ComputeTokensResponse,
        Video,
        GenerateVideosSource,
        VideoGenerationReferenceImage,
        VideoGenerationMask,
        WebhookConfig,
        GenerateVideosConfig,
        GenerateVideosParameters,
        GeneratedVideo,
        GenerateVideosResponse,
        Operation,
        GenerateVideosOperation,
        GetTuningJobConfig,
        GetTuningJobParameters,
        TunedModelCheckpoint,
        TunedModel,
        SupervisedHyperParameters,
        SupervisedTuningSpec,
        PreferenceOptimizationHyperParameters,
        PreferenceOptimizationSpec,
        DistillationHyperParameters,
        DistillationSamplingSpec,
        DistillationSpec,
        AutoraterConfig,
        ReinforcementTuningParseResponseConfig,
        ReinforcementTuningAutoraterScorerExactMatchScorer,
        ReinforcementTuningAutoraterScorerParsedResponseConversionScorer,
        ReinforcementTuningAutoraterScorer,
        ReinforcementTuningCloudRunRewardScorer,
        ReinforcementTuningCodeExecutionRewardScorer,
        ReinforcementTuningStringMatchRewardScorerStringMatchExpression,
        ReinforcementTuningStringMatchRewardScorerJsonMatchExpression,
        ReinforcementTuningStringMatchRewardScorer,
        SingleReinforcementTuningRewardConfig,
        CompositeReinforcementTuningRewardConfigWeightedRewardConfig,
        CompositeReinforcementTuningRewardConfig,
        ReinforcementTuningHyperParameters,
        ReinforcementTuningSpec,
        GoogleRpcStatus,
        PreTunedModel,
        DatasetDistributionDistributionBucket,
        DatasetDistribution,
        ReinforcementTuningExample,
        ReinforcementTuningUserDatasetExamples,
        DatasetStats,
        DistillationDataStats,
        GeminiPreferenceExampleCompletion,
        GeminiPreferenceExample,
        PreferenceOptimizationDataStats,
        SupervisedTuningDatasetDistributionDatasetBucket,
        SupervisedTuningDatasetDistribution,
        SupervisedTuningDataStats,
        TuningDataStats,
        EncryptionSpec,
        PartnerModelTuningSpec,
        BleuMetricValue,
        CustomCodeExecutionResult,
        ExactMatchMetricValue,
        RawOutput,
        CustomOutput,
        PairwiseMetricResult,
        PointwiseMetricResult,
        RougeMetricValue,
        AggregationResult,
        BigQuerySource,
        GcsSource,
        EvaluationDataset,
        AggregationOutput,
        OutputInfo,
        EvaluateDatasetResponse,
        EvaluateDatasetRun,
        FullFineTuningSpec,
        TuningJobMetadata,
        VeoHyperParameters,
        VeoLoraTuningSpec,
        VeoTuningSpec,
        TuningJob,
        ListTuningJobsConfig,
        ListTuningJobsParameters,
        ListTuningJobsResponse,
        CancelTuningJobConfig,
        CancelTuningJobParameters,
        CancelTuningJobResponse,
        TuningExample,
        TuningDataset,
        TuningValidationDataset,
        CreateTuningJobConfig,
        CreateTuningJobParametersPrivate,
        TuningOperation,
        ValidateRewardConfig,
        ValidateRewardParameters,
        ReinforcementTuningRewardInfo,
        ValidateRewardResponse,
        CreateCachedContentConfig,
        CreateCachedContentParameters,
        CachedContentUsageMetadata,
        CachedContent,
        GetCachedContentConfig,
        GetCachedContentParameters,
        DeleteCachedContentConfig,
        DeleteCachedContentParameters,
        DeleteCachedContentResponse,
        UpdateCachedContentConfig,
        UpdateCachedContentParameters,
        ListCachedContentsConfig,
        ListCachedContentsParameters,
        ListCachedContentsResponse,
        GetDocumentConfig,
        GetDocumentParameters,
        StringList,
        CustomMetadata,
        Document_2 as Document,
        DeleteDocumentConfig,
        DeleteDocumentParameters,
        ListDocumentsConfig,
        ListDocumentsParameters,
        ListDocumentsResponse,
        CreateFileSearchStoreConfig,
        CreateFileSearchStoreParameters,
        FileSearchStore,
        GetFileSearchStoreConfig,
        GetFileSearchStoreParameters,
        DeleteFileSearchStoreConfig,
        DeleteFileSearchStoreParameters,
        ListFileSearchStoresConfig,
        ListFileSearchStoresParameters,
        ListFileSearchStoresResponse,
        WhiteSpaceConfig,
        ChunkingConfig,
        UploadToFileSearchStoreConfig,
        UploadToFileSearchStoreParameters,
        UploadToFileSearchStoreResumableResponse,
        ImportFileConfig,
        ImportFileParameters,
        ImportFileResponse,
        ImportFileOperation,
        ListFilesConfig,
        ListFilesParameters,
        FileStatus,
        File_2 as File,
        ListFilesResponse,
        CreateFileConfig,
        CreateFileParameters,
        CreateFileResponse,
        GetFileConfig,
        GetFileParameters,
        DeleteFileConfig,
        DeleteFileParameters,
        DeleteFileResponse,
        RegisterFilesConfig,
        InternalRegisterFilesParameters,
        RegisterFilesResponse,
        InlinedRequest,
        BatchJobSource,
        VertexMultimodalDatasetDestination,
        JobError,
        InlinedResponse,
        SingleEmbedContentResponse,
        InlinedEmbedContentResponse,
        BatchJobDestination,
        CreateBatchJobConfig,
        CreateBatchJobParameters,
        BatchJobOutputInfo,
        CompletionStats,
        BatchJob,
        EmbedContentBatch,
        EmbeddingsBatchJobSource,
        CreateEmbeddingsBatchJobConfig,
        CreateEmbeddingsBatchJobParameters,
        GetBatchJobConfig,
        GetBatchJobParameters,
        CancelBatchJobConfig,
        CancelBatchJobParameters,
        ListBatchJobsConfig,
        ListBatchJobsParameters,
        ListBatchJobsResponse,
        DeleteBatchJobConfig,
        DeleteBatchJobParameters,
        DeleteResourceJob,
        GetOperationConfig,
        GetOperationParameters,
        FetchPredictOperationConfig,
        FetchPredictOperationParameters,
        TestTableItem,
        TestTableFile,
        ReplayRequest,
        ReplayResponse,
        ReplayInteraction,
        ReplayFile,
        UploadFileConfig,
        DownloadFileConfig,
        DownloadFileParameters,
        UpscaleImageConfig,
        UpscaleImageParameters,
        RawReferenceImage,
        MaskReferenceImage,
        ControlReferenceImage,
        StyleReferenceImage,
        SubjectReferenceImage,
        ContentReferenceImage,
        LiveServerSetupComplete,
        LiveServerContent,
        LiveServerToolCall,
        LiveServerToolCallCancellation,
        UsageMetadata,
        LiveServerGoAway,
        LiveServerSessionResumptionUpdate,
        VoiceActivityDetectionSignal,
        VoiceActivity,
        LiveServerMessage,
        OperationFromAPIResponseParameters,
        GenerationConfigThinkingConfig,
        RegisterFilesParameters,
        Fetch,
        AutomaticActivityDetection,
        RealtimeInputConfig,
        SessionResumptionConfig,
        SlidingWindow,
        ContextWindowCompressionConfig,
        ProactivityConfig,
        HistoryConfig,
        CustomizedAvatar,
        AvatarConfig,
        LiveClientSetup,
        LiveClientContent,
        ActivityStart,
        ActivityEnd,
        LiveClientRealtimeInput,
        LiveClientToolResponse,
        LiveClientContextUpdateTools,
        LiveClientContextUpdate,
        LiveClientMessage,
        LiveConnectConfig,
        LiveConnectParameters,
        CreateChatParameters,
        SendMessageParameters,
        LiveSendClientContentParameters,
        LiveSendRealtimeInputParameters,
        LiveSendToolResponseParameters,
        LiveMusicClientSetup,
        WeightedPrompt,
        LiveMusicClientContent,
        LiveMusicGenerationConfig,
        LiveMusicClientMessage,
        LiveMusicServerSetupComplete,
        LiveMusicSourceMetadata,
        AudioChunk,
        LiveMusicServerContent,
        LiveMusicFilteredPrompt,
        LiveMusicServerMessage,
        LiveMusicCallbacks,
        UploadFileParameters,
        CallableTool,
        CallableToolConfig,
        LiveMusicConnectParameters,
        LiveMusicSetConfigParameters,
        LiveMusicSetWeightedPromptsParameters,
        AuthToken,
        LiveConnectConstraints,
        CreateAuthTokenConfig,
        CreateAuthTokenParameters,
        OperationGetParameters,
        CountTokensResult,
        ComputeTokensResult,
        CreateTuningJobParameters,
        EmbedContentParameters,
        UploadToFileSearchStoreResponse,
        UploadToFileSearchStoreOperation,
        DownloadMediaConfig,
        BlobImageUnion,
        PartUnion,
        PartListUnion,
        ContentUnion,
        ContentListUnion,
        SchemaUnion,
        SpeechConfigUnion,
        ToolUnion,
        ToolListUnion,
        DownloadableFileUnion,
        BatchJobSourceUnion,
        BatchJobDestinationUnion
    }
}

/**
 * An error to capture unrecognised or unexpected errors when making HTTP calls.
 */
declare class UnexpectedClientError extends HTTPClientError {
    name: string;
}

/** Optional parameters for caches.update method. */
export declare interface UpdateCachedContentConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The TTL for this resource. The expiration time is computed: now + TTL. It is a duration string, with up to nine fractional digits, terminated by 's'. Example: "3.5s". */
    ttl?: string;
    /** Timestamp of when this resource is considered expired. Uses RFC 3339 format, Example: 2014-10-02T15:01:23Z. */
    expireTime?: string;
}

export declare interface UpdateCachedContentParameters {
    /** The server-generated resource name of the cached content.
     */
    name: string;
    /** Configuration that contains optional parameters.
     */
    config?: UpdateCachedContentConfig;
}

declare type UpdateCredentialGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type UpdateCredentialParams = Omit<UpdateCredentialRequest, "id" | "body"> & UpdateCredentialRequest["body"];

declare type UpdateCredentialRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource ID segment making up resource `name`. It identifies the resource
     *
     * @remarks
     * within its parent collection as described in https://google.aip.dev/122.
     */
    id: string;
    /**
     * Optional. The list of fields to update.
     */
    update_mask?: string | undefined;
    /**
     * Required. The request body.
     */
    body: credentials.CredentialUpdate;
};

/** Configuration for updating a tuned model. */
export declare interface UpdateModelConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    displayName?: string;
    description?: string;
    defaultCheckpointId?: string;
}

/** Configuration for updating a tuned model. */
export declare interface UpdateModelParameters {
    model: string;
    config?: UpdateModelConfig;
}

declare type UpdateTriggerGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type UpdateTriggerParams = Omit<UpdateTriggerRequest, "id" | "body"> & UpdateTriggerRequest["body"];

declare type UpdateTriggerRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. Resource name of the trigger.
     */
    id: string;
    /**
     * Required. The trigger with updated fields.
     */
    body: triggers.TriggerUpdate;
};

declare type UpdateWebhookGlobals = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
};

declare type UpdateWebhookParams = Omit<UpdateWebhookRequest, "id" | "body"> & UpdateWebhookRequest["body"];

declare type UpdateWebhookRequest = {
    /**
     * API version for request routing.
     */
    api_version?: string | undefined;
    /**
     * Required. The ID of the webhook to update.
     */
    id: string;
    /**
     * Optional list of fields to update.
     */
    update_mask?: string | undefined;
    /**
     * Required. The request body.
     */
    body: webhooks.WebhookUpdate;
};

export declare type UploadEnvironmentFileParams = {
    environment: string;
    path: string;
    file: string | Blob | Uint8Array | ArrayBuffer | any;
    mime_type?: string;
    overwrite?: boolean;
    extract?: boolean;
    api_version?: string;
};

declare interface Uploader {
    /**
     * Uploads a file to the given upload url.
     *
     * @param file The file to upload. file is in string type or a Blob.
     * @param uploadUrl The upload URL as a string is where the file will be
     *     uploaded to. The uploadUrl must be a url that was returned by the
     * https://generativelanguage.googleapis.com/upload/v1beta/files endpoint
     * @param apiClient The ApiClient to use for uploading.
     * @return A Promise that resolves to types.File.
     */
    upload(file: string | Blob, uploadUrl: string, apiClient: ApiClient, httpOptions?: HttpOptions): Promise<File_2>;
    /**
     * Uploads a file to file search store via the given upload url.
     *
     * @param file The file to upload. file is in string type or a Blob.
     * @param uploadUrl The upload URL as a string is where the file will be
     *     uploaded to. The uploadUrl must be a url that was returned by the
     * https://generativelanguage.googleapis.com/upload/v1beta/{file_search_store_name}:uploadToFileSearchStore endpoint
     * @param apiClient The ApiClient to use for uploading.
     * @param httpOptions Optional HTTP options to merge.
     * @return A Promise that resolves to types.UploadToFileSearchStoreOperation.
     */
    uploadToFileSearchStore(file: string | Blob, uploadUrl: string, apiClient: ApiClient, httpOptions?: HttpOptions): Promise<UploadToFileSearchStoreOperation>;
    /**
     * Returns the file's mimeType and the size of a given file. If the file is a
     * string path, the file type is determined by the file extension. If the
     * file's type cannot be determined, the type will be set to undefined.
     *
     * @param file The file to get the stat for. Can be a string path or a Blob.
     * @return A Promise that resolves to the file stat of the given file.
     */
    stat(file: string | Blob): Promise<FileStat>;
}

/** Used to override the default configuration. */
export declare interface UploadFileConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** The name of the file in the destination (e.g., 'files/sample-image'. If not provided one will be generated. */
    name?: string;
    /** mime_type: The MIME type of the file. If not provided, it will be inferred from the file extension. */
    mimeType?: string;
    /** Optional display name of the file. */
    displayName?: string;
}

/** Parameters for the upload file method. */
export declare interface UploadFileParameters {
    /** The string path to the file to be uploaded or a Blob object. */
    file: string | globalThis.Blob;
    /** Configuration that contains optional parameters. */
    config?: UploadFileConfig;
}

/** Optional parameters for uploading a file to a FileSearchStore. */
export declare interface UploadToFileSearchStoreConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** MIME type of the file to be uploaded. If not provided, it will be inferred from the file extension. */
    mimeType?: string;
    /** Display name of the created document. */
    displayName?: string;
    /** User provided custom metadata stored as key-value pairs used for querying. */
    customMetadata?: CustomMetadata[];
    /** Config for telling the service how to chunk the file. */
    chunkingConfig?: ChunkingConfig;
}

/** Long-running operation for uploading a file to a FileSearchStore. */
export declare class UploadToFileSearchStoreOperation implements Operation<UploadToFileSearchStoreResponse> {
    /** The server-assigned name, which is only unique within the same service that originally returns it. If you use the default HTTP mapping, the `name` should be a resource name ending with `operations/{unique_id}`. */
    name?: string;
    /** Service-specific metadata associated with the operation. It typically contains progress information and common metadata such as create time. Some services might not provide such metadata.  Any method that returns a long-running operation should document the metadata type, if any. */
    metadata?: Record<string, unknown>;
    /** If the value is `false`, it means the operation is still in progress. If `true`, the operation is completed, and either `error` or `response` is available. */
    done?: boolean;
    /** The error result of the operation in case of failure or cancellation. */
    error?: Record<string, unknown>;
    /** The result of the UploadToFileSearchStore operation, available when the operation is done. */
    response?: UploadToFileSearchStoreResponse;
    /**
     * Instantiates an Operation of the same type as the one being called with the fields set from the API response.
     */
    _fromAPIResponse({ apiResponse, _isVertexAI, }: OperationFromAPIResponseParameters): Operation<UploadToFileSearchStoreResponse>;
    /** The full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** Generates the parameters for the private _upload_to_file_search_store method. */
export declare interface UploadToFileSearchStoreParameters {
    /** The resource name of the FileSearchStore. Example: `fileSearchStores/my-file-search-store-123` */
    fileSearchStoreName: string;
    /** Used to override the default configuration. */
    config?: UploadToFileSearchStoreConfig;
}

/** Parameters for the upload file to file search store method. */
export declare interface UploadToFileSearchStoreParameters {
    /** The name of the file search store to upload. */
    fileSearchStoreName: string;
    /** The string path to the file to be uploaded or a Blob object. */
    file: string | globalThis.Blob;
    /** Configuration that contains optional parameters. */
    config?: UploadToFileSearchStoreConfig;
}

/** The response when long-running operation for uploading a file to a FileSearchStore complete. */
export declare class UploadToFileSearchStoreResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** The name of the FileSearchStore containing Documents. */
    parent?: string;
    /** The identifier for the Document imported. */
    documentName?: string;
}

/** Response for the resumable upload method. */
export declare class UploadToFileSearchStoreResumableResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
}

/** Configuration for upscaling an image.

 For more information on this configuration, refer to
 the `Imagen API reference documentation
 <https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/imagen-api>`_. */
export declare interface UpscaleImageConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
    /** Cloud Storage URI used to store the generated images. */
    outputGcsUri?: string;
    /** Filter level for safety filtering. */
    safetyFilterLevel?: SafetyFilterLevel;
    /** Allows generation of people by the model. */
    personGeneration?: PersonGeneration;
    /** Whether to include a reason for filtered-out images in the
     response. */
    includeRaiReason?: boolean;
    /** The image format that the output should be saved as. */
    outputMimeType?: string;
    /** The level of compression. Only applicable if the
     ``output_mime_type`` is ``image/jpeg``. */
    outputCompressionQuality?: number;
    /** Whether to add an image enhancing step before upscaling.
     It is expected to suppress the noise and JPEG compression artifacts
     from the input image. */
    enhanceInputImage?: boolean;
    /** With a higher image preservation factor, the original image
     pixels are more respected. With a lower image preservation factor, the
     output image will have be more different from the input image, but
     with finer details and less noise. */
    imagePreservationFactor?: number;
    /** User specified labels to track billing usage. */
    labels?: Record<string, string>;
}

/** User-facing config UpscaleImageParameters. */
export declare interface UpscaleImageParameters {
    /** The model to use. */
    model: string;
    /** The input image to upscale. */
    image: Image_2;
    /** The factor to upscale the image (x2 or x4). */
    upscaleFactor: string;
    /** Configuration for upscaling. */
    config?: UpscaleImageConfig;
}

export declare class UpscaleImageResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** Generated images. */
    generatedImages?: GeneratedImage[];
}

declare type URLCitation$ = URLCitation;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A URL citation annotation.
 */
declare type URLCitation = {
    /**
     * End of the attributed segment, exclusive.
     */
    end_index?: number | undefined;
    /**
     * Start of segment of the response that is attributed to this source.
     *
     * @remarks
     *
     * Index indicates the start of the segment, measured in bytes.
     */
    start_index?: number | undefined;
    /**
     * The title of the URL.
     */
    title?: string | undefined;
    type: "url_citation";
    /**
     * The URL.
     */
    url?: string | undefined;
};

declare type URLContext$ = URLContext;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * A tool that can be used by the model to fetch URL context.
 */
declare type URLContext = {
    type: "url_context";
};

/** Tool to support URL context. */
export declare interface UrlContext {
}

declare type URLContextCall$ = URLContextCallDelta;

declare type URLContextCallArguments$ = URLContextCallArguments;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The arguments to pass to the URL context.
 */
declare type URLContextCallArguments = {
    /**
     * The URLs to fetch.
     */
    urls?: Array<string> | undefined;
};

declare type URLContextCallDelta = {
    /**
     * The arguments to pass to the URL context.
     */
    arguments: URLContextCallArguments;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "url_context_call";
};

declare type URLContextCallStep$ = URLContextCallStep;

/**
 * URL context call step.
 */
declare type URLContextCallStep = {
    /**
     * The arguments to pass to the URL context.
     */
    arguments: URLContextCallArguments;
    /**
     * Required. A unique ID for this specific tool call.
     */
    id: string;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "url_context_call";
};

/** Metadata returned when the model uses the `url_context` tool to get information from a user-provided URL. */
export declare interface UrlContextMetadata {
    /** Output only. A list of URL metadata, with one entry for each URL retrieved by the tool. */
    urlMetadata?: UrlMetadata[];
}

declare type URLContextResult$ = URLContextResult;

declare type URLContextResult$2 = URLContextResultDelta;

/**
 * The result of the URL context.
 */
declare type URLContextResult = {
    /**
     * The status of the URL retrieval.
     */
    status?: URLContextResultStatus | undefined;
    /**
     * The URL that was fetched.
     */
    url?: string | undefined;
};

declare type URLContextResultDelta = {
    is_error?: boolean | undefined;
    result: Array<URLContextResult>;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "url_context_result";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The status of the URL retrieval.
 */
declare type URLContextResultStatus = "success" | "error" | "paywall" | "unsafe" | (string & {});

declare type URLContextResultStep$ = URLContextResultStep;

/**
 * URL context result step.
 */
declare type URLContextResultStep = {
    /**
     * Required. ID to match the ID from the function call block.
     */
    call_id: string;
    /**
     * Whether the URL context resulted in an error.
     */
    is_error?: boolean | undefined;
    /**
     * Required. The results of the URL context.
     */
    result: Array<URLContextResult>;
    /**
     * A signature hash for backend validation.
     */
    signature?: string | undefined;
    type: "url_context_result";
};

/** The metadata for a single URL retrieval. */
export declare interface UrlMetadata {
    /** The URL retrieved by the tool. */
    retrievedUrl?: string;
    /** The status of the URL retrieval. */
    urlRetrievalStatus?: UrlRetrievalStatus;
}

/** The status of the URL retrieval. */
export declare enum UrlRetrievalStatus {
    /**
     * Default value. This value is unused.
     */
    URL_RETRIEVAL_STATUS_UNSPECIFIED = "URL_RETRIEVAL_STATUS_UNSPECIFIED",
    /**
     * The URL was retrieved successfully.
     */
    URL_RETRIEVAL_STATUS_SUCCESS = "URL_RETRIEVAL_STATUS_SUCCESS",
    /**
     * The URL retrieval failed.
     */
    URL_RETRIEVAL_STATUS_ERROR = "URL_RETRIEVAL_STATUS_ERROR",
    /**
     * Url retrieval is failed because the content is behind paywall. This enum value is not supported in Vertex AI.
     */
    URL_RETRIEVAL_STATUS_PAYWALL = "URL_RETRIEVAL_STATUS_PAYWALL",
    /**
     * Url retrieval is failed because the content is unsafe. This enum value is not supported in Vertex AI.
     */
    URL_RETRIEVAL_STATUS_UNSAFE = "URL_RETRIEVAL_STATUS_UNSAFE"
}

declare type Usage$ = Usage;

/**
 * Statistics on the interaction request's token usage.
 */
declare type Usage = {
    /**
     * A breakdown of cached token usage by modality.
     */
    cached_tokens_by_modality?: Array<ModalityTokens> | undefined;
    /**
     * Grounding tool count.
     */
    grounding_tool_count?: Array<GroundingToolCount> | undefined;
    /**
     * Number of input tokens used in the first turn of this interaction.
     */
    initial_input_tokens?: number | undefined;
    /**
     * A breakdown of input token usage by modality.
     */
    input_tokens_by_modality?: Array<ModalityTokens> | undefined;
    /**
     * A breakdown of output token usage by modality.
     */
    output_tokens_by_modality?: Array<ModalityTokens> | undefined;
    /**
     * A breakdown of tool-use token usage by modality.
     */
    tool_use_tokens_by_modality?: Array<ModalityTokens> | undefined;
    /**
     * Number of tokens in the cached part of the prompt (the cached content).
     */
    total_cached_tokens?: number | undefined;
    /**
     * Number of tokens in the prompt (context).
     */
    total_input_tokens?: number | undefined;
    /**
     * Total number of tokens across all the generated responses.
     */
    total_output_tokens?: number | undefined;
    /**
     * Number of tokens of thoughts for thinking models.
     */
    total_thought_tokens?: number | undefined;
    /**
     * Total token count for the interaction request (prompt + responses + other
     *
     * @remarks
     * internal tokens).
     */
    total_tokens?: number | undefined;
    /**
     * Number of tokens present in tool-use prompt(s).
     */
    total_tool_use_tokens?: number | undefined;
};

/** Usage metadata about response(s). */
export declare interface UsageMetadata {
    /** Total number of tokens across all the generated response candidates. */
    responseTokenCount?: number;
    /** List of modalities that were returned in the response. */
    responseTokensDetails?: ModalityTokenCount[];
    /** Output only. A detailed breakdown of the token count for each modality in the cached content. */
    cacheTokensDetails?: ModalityTokenCount[];
    /** Output only. The number of tokens in the cached content that was used for this request. */
    cachedContentTokenCount?: number;
    /** The total number of tokens in the prompt. This includes any text, images, or other media provided in the request. When `cached_content` is set, this also includes the number of tokens in the cached content. */
    promptTokenCount?: number;
    /** Output only. A detailed breakdown of the token count for each modality in the prompt. */
    promptTokensDetails?: ModalityTokenCount[];
    /** Output only. The number of tokens that were part of the model's generated "thoughts" output, if applicable. */
    thoughtsTokenCount?: number;
    /** Output only. The number of tokens in the results from tool executions, which are provided back to the model as input, if applicable. */
    toolUsePromptTokenCount?: number;
    /** Output only. A detailed breakdown by modality of the token counts from the results of tool executions, which are provided back to the model as input. */
    toolUsePromptTokensDetails?: ModalityTokenCount[];
    /** The total number of tokens for the entire request. This is the sum of `prompt_token_count`, `candidates_token_count`, `tool_use_prompt_token_count`, and `thoughts_token_count`. */
    totalTokenCount?: number;
    /** Output only. The traffic type for this request. This field is not supported in Gemini API. */
    trafficType?: TrafficType;
    /** Output only. Service tier of the request. This field is not supported in Vertex AI. */
    serviceTier?: ServiceTier;
}

declare type UserInputStep$ = UserInputStep;

/**
 * Input provided by the user.
 */
declare type UserInputStep = {
    content?: Array<Content_2> | undefined;
    type: "user_input";
};

/** The type of the VAD signal. */
export declare enum VadSignalType {
    /**
     * The default is VAD_SIGNAL_TYPE_UNSPECIFIED.
     */
    VAD_SIGNAL_TYPE_UNSPECIFIED = "VAD_SIGNAL_TYPE_UNSPECIFIED",
    /**
     * Start of sentence signal.
     */
    VAD_SIGNAL_TYPE_SOS = "VAD_SIGNAL_TYPE_SOS",
    /**
     * End of sentence signal.
     */
    VAD_SIGNAL_TYPE_EOS = "VAD_SIGNAL_TYPE_EOS"
}

/** Optional parameters for tunings.validate_reward. */
export declare interface ValidateRewardConfig {
    /** Used to override HTTP request options. */
    httpOptions?: HttpOptions;
    /** Abort signal which can be used to cancel the request.

     NOTE: AbortSignal is a client-only operation. Using it to cancel an
     operation will not cancel the request in the service. You will still
     be charged usage for any applicable operations.
     */
    abortSignal?: AbortSignal;
}

/** Parameters for the validate_reward method.

 Validates a reinforcement tuning reward configuration against a sample
 response and example before creating a reinforcement tuning job. */
export declare interface ValidateRewardParameters {
    /** Required. The resource name of the Location to validate the reward in, e.g. `projects/{project}/locations/{location}`. */
    parent: string;
    /** Required. The sample response for validating the reward configuration. */
    sampleResponse: Content;
    /** Required. The example to validate the reward configuration. */
    example: ReinforcementTuningExample;
    /** Single reward function configuration for reinforcement tuning. Mutually exclusive with composite_reward_config. */
    singleRewardConfig?: SingleReinforcementTuningRewardConfig;
    /** Composite reward function configuration for reinforcement tuning. Mutually exclusive with single_reward_config. */
    compositeRewardConfig?: CompositeReinforcementTuningRewardConfig;
    /** Optional parameters for the request. */
    config?: ValidateRewardConfig;
}

/** Response for the validate_reward method.

 Contains the computed reward for a reinforcement tuning reward
 configuration. */
export declare class ValidateRewardResponse {
    /** Used to retain the full HTTP response. */
    sdkHttpResponse?: HttpResponse;
    /** Output only. The overall weighted reward. For a `CompositeReinforcementTuningRewardConfig`, this is the weighted average of all rewards. For a `SingleReinforcementTuningRewardConfig`, this will be the value of the single reward. */
    overallReward?: number;
    /** Output only. In case of an error, this field will be populated with a detailed error message to help with debugging. */
    error?: string;
    /** A map from reward name to reward info. */
    rewardInfoDetails?: Record<string, ReinforcementTuningRewardInfo>;
}

/** Hyperparameters for Veo. This data type is not supported in Gemini API. */
export declare interface VeoHyperParameters {
    /** Optional. The adapter size for LoRA tuning. */
    adapterSize?: AdapterSize;
    /** Optional. Number of complete passes the model makes over the entire training dataset during training. */
    epochCount?: string;
    /** Optional. Multiplier for adjusting the default learning rate. */
    learningRateMultiplier?: number;
    /** The speed of the tuning job. Only supported for Veo 3.0 models. */
    tuningSpeed?: TuningSpeed;
    /** The tuning task for Veo. */
    tuningTask?: TuningTask;
    /** Optional. The ratio of Google internal dataset to use in the training mixture, in range of `[0, 1)`. If `0.2`, it means 20% of Google internal dataset and 80% of user dataset will be used for training. If not set, the default value is 0.1. */
    veoDataMixtureRatio?: number;
}

/** Tuning Spec for Veo LoRA Model Tuning. This data type is not supported in Gemini API. */
export declare interface VeoLoraTuningSpec {
    /** Optional. Hyperparameters for Veo LoRA. */
    hyperParameters?: VeoHyperParameters;
    /** Required. Training dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    trainingDatasetUri?: string;
    /** Optional. Validation dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    validationDatasetUri?: string;
    /** Optional. The orientation of the video. Defaults to LANDSCAPE. */
    videoOrientation?: VideoOrientation;
}

/** Tuning Spec for Veo Model Tuning. This data type is not supported in Gemini API. */
export declare interface VeoTuningSpec {
    /** Optional. Hyperparameters for Veo. */
    hyperParameters?: VeoHyperParameters;
    /** Required. Training dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    trainingDatasetUri?: string;
    /** Optional. Validation dataset used for tuning. The dataset can be specified as either a Cloud Storage path to a JSONL file or as the resource name of a Vertex Multimodal Dataset. */
    validationDatasetUri?: string;
}

declare type Verbatim$ = VerbatimTranscriptionMode;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Configuration for verbatim transcription mode.
 */
declare type VerbatimTranscriptionMode = {
    /**
     * Optional. Configures speaker diarization. Supported values: "speaker".
     */
    diarization_mode?: string | undefined;
    /**
     * Optional. The granularity of timestamps to include in the transcription output.
     *
     * @remarks
     * Supported values: "word". If empty, no timestamps are generated.
     */
    timestamp_granularities?: Array<string> | undefined;
    type: "verbatim";
};

/** Retrieve from Vertex AI Search datastore or engine for grounding. datastore and engine are mutually exclusive. See https://cloud.google.com/products/agent-builder. This data type is not supported in Gemini API. */
export declare interface VertexAISearch {
    /** Specifications that define the specific DataStores to be searched, along with configurations for those data stores. This is only considered for Engines with multiple data stores. It should only be set if engine is used. */
    dataStoreSpecs?: VertexAISearchDataStoreSpec[];
    /** Optional. Fully-qualified Vertex AI Search data store resource ID. Format: `projects/{project}/locations/{location}/collections/{collection}/dataStores/{dataStore}` */
    datastore?: string;
    /** Optional. Fully-qualified Vertex AI Search engine resource ID. Format: `projects/{project}/locations/{location}/collections/{collection}/engines/{engine}` */
    engine?: string;
    /** Optional. Filter strings to be passed to the search API. */
    filter?: string;
    /** Optional. Number of search results to return per query. The default value is 10. The maximumm allowed value is 10. */
    maxResults?: number;
}

declare type VertexAISearchConfig$ = VertexAISearchConfig;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Used to specify configuration for VertexAISearch.
 */
declare type VertexAISearchConfig = {
    /**
     * Optional. Used to specify Vertex AI Search datastores.
     */
    datastores?: Array<string> | undefined;
    /**
     * Optional. Used to specify Vertex AI Search engine.
     */
    engine?: string | undefined;
};

/** Define data stores within engine to filter on in a search call and configurations for those data stores. For more information, see https://cloud.google.com/generative-ai-app-builder/docs/reference/rpc/google.cloud.discoveryengine.v1#datastorespec. This data type is not supported in Gemini API. */
export declare interface VertexAISearchDataStoreSpec {
    /** Full resource name of DataStore, such as Format: `projects/{project}/locations/{location}/collections/{collection}/dataStores/{dataStore}` */
    dataStore?: string;
    /** Optional. Filter specification to filter documents in the data store specified by data_store field. For more information on filtering, see [Filtering](https://cloud.google.com/generative-ai-app-builder/docs/filter-search-metadata) */
    filter?: string;
}

/** This class is experimental and may change in future versions.

 The specification for an output Vertex AI multimodal dataset. */
export declare interface VertexMultimodalDatasetDestination {
    /** The BigQuery destination for the multimodal dataset. */
    bigqueryDestination?: string;
    /** The display name of the multimodal dataset. */
    displayName?: string;
}

/** Retrieve from Vertex RAG Store for grounding. This data type is not supported in Gemini API. */
export declare interface VertexRagStore {
    /** Optional. Deprecated. Please use rag_resources instead. */
    ragCorpora?: string[];
    /** Optional. The representation of the rag source. It can be used to specify corpus only or ragfiles. Currently only support one corpus or multiple files from one corpus. In the future we may open up multiple corpora support. */
    ragResources?: VertexRagStoreRagResource[];
    /** Optional. The retrieval config for the Rag query. */
    ragRetrievalConfig?: RagRetrievalConfig;
    /** Optional. Number of top k results to return from the selected corpora. */
    similarityTopK?: number;
    /** Optional. Currently only supported for Gemini Multimodal Live API. In Gemini Multimodal Live API, if `store_context` bool is specified, Gemini will leverage it to automatically memorize the interactions between the client and Gemini, and retrieve context when needed to augment the response generation for users' ongoing and future interactions. */
    storeContext?: boolean;
    /** Optional. Only return results with vector distance smaller than the threshold. */
    vectorDistanceThreshold?: number;
}

/** The definition of the Rag resource. This data type is not supported in Gemini API. */
export declare interface VertexRagStoreRagResource {
    /** Optional. RagCorpora resource name. Format: `projects/{project}/locations/{location}/ragCorpora/{rag_corpus}` */
    ragCorpus?: string;
    /** Optional. rag_file_id. The files should be in the same rag_corpus set in rag_corpus field. */
    ragFileIds?: string[];
}

declare type Video$ = VideoDelta;

/** A generated video. */
export declare interface Video {
    /** Path to another storage. */
    uri?: string;
    /** Video bytes.
     * @remarks Encoded as base64 string. */
    videoBytes?: string;
    /** Video encoding, for example ``video/mp4``. */
    mimeType?: string;
}

/** Enum that controls the compression quality of the generated videos. */
export declare enum VideoCompressionQuality {
    /**
     * Optimized video compression quality. This will produce videos
     with a compressed, smaller file size.
     */
    OPTIMIZED = "OPTIMIZED",
    /**
     * Lossless video compression quality. This will produce videos
     with a larger file size.
     */
    LOSSLESS = "LOSSLESS"
}

declare type VideoConfig$ = VideoConfig;

/**
 * Configuration options for video generation.
 */
declare type VideoConfig = {
    /**
     * Optional task mode for video generation. If not specified, the model
     *
     * @remarks
     * automatically determines the appropriate mode based on the provided text
     * prompt and input media.
     */
    task?: Task | undefined;
};

declare type VideoContent$ = VideoContent;

/**
 * A video content block.
 */
declare type VideoContent = {
    /**
     * The video content.
     */
    data?: string | undefined;
    /**
     * The mime type of the video.
     */
    mime_type?: VideoContentMimeType | undefined;
    /**
     * A user-defined name for this content block. Can be referenced by the model
     *
     * @remarks
     * in the final response.
     */
    name?: string | undefined;
    /**
     * How the model processes this video for understanding.
     */
    processing?: MediaProcessing_2 | ProcessingEnum | undefined;
    resolution?: MediaResolution_2 | undefined;
    type: "video";
    /**
     * The URI of the video.
     */
    uri?: string | undefined;
};

/**
 * The mime type of the video.
 */
declare type VideoContentMimeType = "video/mp4" | "video/mpeg" | "video/mpg" | "video/mov" | "video/avi" | "video/x-flv" | "video/webm" | "video/wmv" | "video/3gpp" | (string & {});

declare type VideoDelta = {
    data?: string | undefined;
    mime_type?: VideoDeltaMimeType | undefined;
    resolution?: MediaResolution_2 | undefined;
    type: "video";
    uri?: string | undefined;
};

declare type VideoDeltaMimeType = "video/mp4" | "video/mpeg" | "video/mpg" | "video/mov" | "video/avi" | "video/x-flv" | "video/webm" | "video/wmv" | "video/3gpp" | "video/jpeg2000" | (string & {});

/** A mask for video generation. */
export declare interface VideoGenerationMask {
    /** The image mask to use for generating videos. */
    image?: Image_2;
    /** Describes how the mask will be used. Inpainting masks must
     match the aspect ratio of the input video. Outpainting masks can be
     either 9:16 or 16:9. */
    maskMode?: VideoGenerationMaskMode;
}

/** Enum for the mask mode of a video generation mask. */
export declare enum VideoGenerationMaskMode {
    /**
     * The image mask contains a masked rectangular region which is
     applied on the first frame of the input video. The object described in
     the prompt is inserted into this region and will appear in subsequent
     frames.
     */
    INSERT = "INSERT",
    /**
     * The image mask is used to determine an object in the
     first video frame to track. This object is removed from the video.
     */
    REMOVE = "REMOVE",
    /**
     * The image mask is used to determine a region in the
     video. Objects in this region will be removed.
     */
    REMOVE_STATIC = "REMOVE_STATIC",
    /**
     * The image mask contains a masked rectangular region where
     the input video will go. The remaining area will be generated. Video
     masks are not supported.
     */
    OUTPAINT = "OUTPAINT"
}

/** A reference image for video generation. */
export declare interface VideoGenerationReferenceImage {
    /** The reference image. */
    image?: Image_2;
    /** The type of the reference image, which defines how the reference
     image will be used to generate the video. */
    referenceType?: VideoGenerationReferenceType;
}

/** Enum for the reference type of a video generation reference image. */
export declare enum VideoGenerationReferenceType {
    /**
     * A reference image that provides assets to the generated video,
     such as the scene, an object, a character, etc.
     */
    ASSET = "ASSET",
    /**
     * A reference image that provides aesthetics including colors,
     lighting, texture, etc., to be used as the style of the generated video,
     such as 'anime', 'photography', 'origami', etc.
     */
    STYLE = "STYLE"
}

/** Provides metadata for a video, including the start and end offsets for clipping and the frame rate. */
export declare interface VideoMetadata {
    /** Optional. The end offset of the video. */
    endOffset?: string;
    /** Optional. The frame rate of the video sent to the model. If not specified, the default value is 1.0. The valid range is (0.0, 24.0]. */
    fps?: number;
    /** Optional. The start offset of the video. */
    startOffset?: string;
}

/** The orientation of the video. Defaults to LANDSCAPE. This enum is not supported in Gemini API. */
export declare enum VideoOrientation {
    /**
     * Unspecified video orientation. Defaults to landscape.
     */
    VIDEO_ORIENTATION_UNSPECIFIED = "VIDEO_ORIENTATION_UNSPECIFIED",
    /**
     * Landscape orientation (e.g. 16:9, 1280x720).
     */
    LANDSCAPE = "LANDSCAPE",
    /**
     * Portrait orientation (e.g. 9:16, 720x1280).
     */
    PORTRAIT = "PORTRAIT"
}

declare type VideoResponseFormat$ = VideoResponseFormat_2;

/** Configuration for video-specific output formatting. This data type is not supported in Gemini API. */
export declare class VideoResponseFormat {
    /** The aspect ratio for the video output. */
    aspectRatio?: AspectRatio;
    /** Optional. Delivery mode for the generated content. */
    delivery?: Delivery;
    /** Optional. The duration for the video output. */
    duration?: string;
    /** Optional. The Google Cloud Storage URI to store the video output. Required for Vertex if delivery is URI. */
    gcsUri?: string;
    /** Optional. The video output resolution. Supported values: "360p", "720p", "1080p", "4k". */
    resolution?: string;
}

/**
 * Configuration for video output format.
 */
declare type VideoResponseFormat_2 = {
    /**
     * The aspect ratio for the video output.
     */
    aspect_ratio?: VideoResponseFormatAspectRatio | undefined;
    /**
     * The delivery mode for the video output.
     */
    delivery?: VideoResponseFormatDelivery | undefined;
    /**
     * The duration for the video output.
     */
    duration?: string | undefined;
    /**
     * The Cloud Storage URI to store the video output. Required for Vertex if
     *
     * @remarks
     * delivery mode is URI.
     */
    gcs_uri?: string | undefined;
    /**
     * The video output resolution. Defaults to 720p.
     */
    resolution?: Resolution | undefined;
    type: "video";
};

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * The aspect ratio for the video output.
 */
declare type VideoResponseFormatAspectRatio = "16:9" | "9:16" | (string & {});

/**
 * The delivery mode for the video output.
 */
declare type VideoResponseFormatDelivery = "inline" | "uri" | (string & {});

/**
 * Whether to include visualizations in the response.
 */
declare type Visualization = "off" | "auto" | (string & {});

declare type Voice$ = VoiceInput;

declare type Voice$2 = VoiceOutput;

/** Voice activity signal. */
export declare interface VoiceActivity {
    /** The type of the voice activity signal. */
    voiceActivityType?: VoiceActivityType;
    /** The time voice activity detected in audio time, relative to the start of the audio stream. */
    audioOffset?: string;
}

export declare interface VoiceActivityDetectionSignal {
    /** The type of the VAD signal. */
    vadSignalType?: VadSignalType;
}

/** The type of the voice activity signal. */
export declare enum VoiceActivityType {
    /**
     * The default is VOICE_ACTIVITY_TYPE_UNSPECIFIED.
     */
    TYPE_UNSPECIFIED = "TYPE_UNSPECIFIED",
    /**
     * Start of sentence signal.
     */
    ACTIVITY_START = "ACTIVITY_START",
    /**
     * End of sentence signal.
     */
    ACTIVITY_END = "ACTIVITY_END"
}

/** The configuration for the voice to use. */
export declare interface VoiceConfig {
    /** The configuration for a replicated voice, which is a clone of a
     user's voice that can be used for speech synthesis. If this is unset, a
     default voice is used. */
    replicatedVoiceConfig?: ReplicatedVoiceConfig;
    /** The configuration for a prebuilt voice. */
    prebuiltVoiceConfig?: PrebuiltVoiceConfig;
    /** The speaker identifier for synthesis. */
    voice?: string;
}

/** The signature of the voice consent check. */
export declare interface VoiceConsentSignature {
    /** The signature string.
     */
    signature?: string;
}

declare type VoiceCreateParams$ = CreateVoiceRequest;

declare type VoiceDeleteParams$ = DeleteVoiceParams;

declare type VoiceDeleteResponse$ = DeleteVoiceResponse;

declare type VoiceGetParams$ = GetVoiceParams;

/**
 * A voice resource representing either a custom voice (created via
 *
 * @remarks
 * `CreateVoice`) or a prebuilt system voice (returned by `ListVoices`).
 */
declare type VoiceInput = {
    /**
     * Optional. Regional accent descriptor (e.g. "American", "British").
     */
    accent?: string | undefined;
    /**
     * Optional. Optimal usage context or domain (e.g. "Conversational",
     *
     * @remarks
     * "Audiobook", "News").
     */
    context?: string | undefined;
    /**
     * Optional. Descriptive summary of vocal timbre, personality, and tone.
     */
    description?: string | undefined;
    /**
     * Optional. User-provided display name for a stored voice (`store = true`),
     *
     * @remarks
     * or the catalog name for a prebuilt voice.
     */
    display_name?: string | undefined;
    /**
     * Optional. Perceived voice gender presentation (e.g. "female", "male",
     *
     * @remarks
     * "neutral").
     */
    gender?: string | undefined;
    /**
     * Optional. Primary BCP-47 language tag (e.g. "en-US", "fr-FR").
     */
    language_code?: string | undefined;
    /**
     * Optional. The model used to design or replicate the voice.
     *
     * @remarks
     * If omitted in `CreateVoice`, defaults to the latest supported voice design
     * model. Returned in `CreateVoice`, `GetVoice`, and `ListVoices` responses
     * for custom voices (`"prompted"` and `"replicated"`); unset for `"prebuilt"`
     * voices. Created voices can be synthesized across any supported TTS
     * synthesis model.
     */
    model?: string | undefined;
    /**
     * Optional. Intended persona or character archetype (e.g. "Warm, Friendly",
     *
     * @remarks
     * "Narrator").
     */
    persona?: string | undefined;
    pitch?: Pitch | undefined;
    /**
     * Parameters for prompted voice generation.
     *
     * @remarks
     * Required in `CreateVoice` when `type` is `"prompted"`. Returned in
     * `CreateVoice`, `GetVoice`, and `ListVoices` responses for prompted voices.
     */
    prompted?: PromptedVoice | undefined;
    /**
     * Optional. ISO 3166-1 alpha-2 or UN M.49 geographic region code (e.g. "US",
     *
     * @remarks
     * "GB", "001").
     */
    region_code?: string | undefined;
    /**
     * Input only. Parameters for replicated voice generation.
     *
     * @remarks
     * Required on input when `type` is `"replicated"`. Not returned in
     * responses.
     */
    replicated?: ReplicatedVoice | undefined;
    /**
     * Audio payload used for voice creation.
     */
    sample_audio?: AudioData_2 | undefined;
    type: VoiceType;
};

declare type VoiceListParams$ = ListVoicesParams;

declare type VoiceListResponse$ = ListVoicesResponse;

/**
 * A voice resource representing either a custom voice (created via
 *
 * @remarks
 * `CreateVoice`) or a prebuilt system voice (returned by `ListVoices`).
 */
declare type VoiceOutput = {
    /**
     * Optional. Regional accent descriptor (e.g. "American", "British").
     */
    accent?: string | undefined;
    /**
     * Optional. Optimal usage context or domain (e.g. "Conversational",
     *
     * @remarks
     * "Audiobook", "News").
     */
    context?: string | undefined;
    /**
     * Optional. Descriptive summary of vocal timbre, personality, and tone.
     */
    description?: string | undefined;
    /**
     * Optional. User-provided display name for a stored voice (`store = true`),
     *
     * @remarks
     * or the catalog name for a prebuilt voice.
     */
    display_name?: string | undefined;
    /**
     * Output only. The timestamp at which a custom stored voice (`store = true`)
     *
     * @remarks
     * or replicated voice key (`store = false`) expires. For custom stored voices
     * (`store = true`), this expiration time is extended when the voice is used
     * for speech synthesis or as a `base_voice` in `CreateVoice`. Unset for
     * prebuilt catalog voices (`"prebuilt"`), which do not expire.
     */
    expire_time?: string | undefined;
    /**
     * Optional. Perceived voice gender presentation (e.g. "female", "male",
     *
     * @remarks
     * "neutral").
     */
    gender?: string | undefined;
    /**
     * Output only. The unique identifier of the voice.
     *
     * @remarks
     *
     * * For Google-managed custom voices (`store = true`), this is a generated ID
     *   with prefix `voice_` (for example, `voice_abc123def456`). Pass
     *   `voices/{id}` as the `name` in `GetVoice` and `DeleteVoice`, and pass
     *   `{id}` directly to `SpeechConfig.voice_config.voice` (or
     *   `SpeechConfig.voice`) during speech synthesis.
     * * For prebuilt catalog voices (`"prebuilt"` returned by `ListVoices`), this
     *   is the speaker name (for example, `Puck` or `Charon`).
     * * Unset when `CreateVoice` is called with `store = false`.
     */
    id?: string | undefined;
    /**
     * Output only. The client-managed voice replication key (with prefix
     *
     * @remarks
     * `voicekey_`). Returned only by `CreateVoice` when `type` is `"replicated"`
     * and `store` is `false`. Pass this key to `SpeechConfig.voice_config.voice`
     * (or `SpeechConfig.voice`) during speech synthesis.
     */
    key?: string | undefined;
    /**
     * Optional. Primary BCP-47 language tag (e.g. "en-US", "fr-FR").
     */
    language_code?: string | undefined;
    /**
     * Optional. The model used to design or replicate the voice.
     *
     * @remarks
     * If omitted in `CreateVoice`, defaults to the latest supported voice design
     * model. Returned in `CreateVoice`, `GetVoice`, and `ListVoices` responses
     * for custom voices (`"prompted"` and `"replicated"`); unset for `"prebuilt"`
     * voices. Created voices can be synthesized across any supported TTS
     * synthesis model.
     */
    model?: string | undefined;
    /**
     * Optional. Intended persona or character archetype (e.g. "Warm, Friendly",
     *
     * @remarks
     * "Narrator").
     */
    persona?: string | undefined;
    pitch?: Pitch | undefined;
    /**
     * Parameters for prompted voice generation.
     *
     * @remarks
     * Required in `CreateVoice` when `type` is `"prompted"`. Returned in
     * `CreateVoice`, `GetVoice`, and `ListVoices` responses for prompted voices.
     */
    prompted?: PromptedVoice | undefined;
    /**
     * Optional. ISO 3166-1 alpha-2 or UN M.49 geographic region code (e.g. "US",
     *
     * @remarks
     * "GB", "001").
     */
    region_code?: string | undefined;
    /**
     * Audio payload used for voice creation.
     */
    sample_audio?: AudioData_2 | undefined;
    type: VoiceType;
    /**
     * Statistics on the interaction request's token usage.
     */
    usage?: interactions.Usage | undefined;
};

export declare namespace Voices {
    export type AudioData = AudioData$;
    export interface CreateVoiceRequest extends CreateVoiceRequest$ {
    }
    export type Pitch = Pitch$;
    export type PromptedVoice = PromptedVoice$;
    export type ReplicatedVoice = ReplicatedVoice$;
    export type VoiceCreateParams = VoiceCreateParams$;
    export type VoiceDeleteParams = VoiceDeleteParams$;
    export type VoiceDeleteResponse = VoiceDeleteResponse$;
    export type VoiceGetParams = VoiceGetParams$;
    export type VoiceListParams = VoiceListParams$;
    export interface VoiceListResponse extends VoiceListResponse$ {
    }
    export type VoiceType = VoiceType$;
    export namespace CreateVoiceRequest {
        export type Voice = Voice$;
    }
    export namespace VoiceListResponse {
        export type Voice = Voice$2;
    }
}

declare namespace voices {
    export {
        AudioData_2 as AudioData,
        CreateVoiceRequest_2 as CreateVoiceRequest,
        DeleteVoiceResponse,
        ListVoicesResponse,
        Pitch,
        PromptedVoice,
        ReplicatedVoice,
        VoiceInput,
        VoiceOutput,
        VoiceType
    }
}

declare class Voices_2 extends ClientSDK {
    /**
     * Lists custom stored voices owned by the caller (ordered newest first)
     * followed by prebuilt system voices from Google's voice catalog.
     */
    list(params?: ListVoicesParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<voices.ListVoicesResponse>;
    /**
     * Creates a custom voice from a natural-language prompt
     * (`VOICE_TYPE_PROMPTED`) or from reference and consent audio recordings
     * (`VOICE_TYPE_REPLICATED`).
     */
    create(body: voices.CreateVoiceRequest, api_version?: string | undefined, options?: RequestOptions): APIPromise<voices.VoiceOutput>;
    /**
     * Deletes a custom stored voice (`store = true`) by resource name.
     * Prebuilt catalog voices (`VOICE_TYPE_PREBUILT`) cannot be deleted.
     */
    delete(id: string, params?: DeleteVoiceParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<voices.DeleteVoiceResponse>;
    /**
     * Gets a custom stored voice (`store = true`) by resource name.
     * Prebuilt catalog voices (`VOICE_TYPE_PREBUILT`) cannot be retrieved via
     * `GetVoice`; use `ListVoices` instead.
     */
    get(id: string, params?: GetVoiceParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<voices.VoiceOutput>;
}

declare type VoiceType$ = VoiceType;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
declare type VoiceType = "replicated" | "prompted" | "prebuilt" | (string & {});

declare type Webhook$ = Webhook;

/**
 * A Webhook resource.
 */
declare type Webhook = {
    /**
     * Output only. The timestamp when the webhook was created.
     */
    create_time?: string | undefined;
    /**
     * Output only. The ID of the webhook.
     */
    id?: string | undefined;
    /**
     * Optional. The user-provided name of the webhook.
     */
    name?: string | undefined;
    /**
     * Output only. The new signing secret for the webhook. Only populated on create.
     */
    new_signing_secret?: string | undefined;
    /**
     * Output only. The signing secrets associated with this webhook.
     */
    signing_secrets?: Array<SigningSecret> | undefined;
    /**
     * Output only. The state of the webhook.
     */
    state?: WebhookState | undefined;
    /**
     * Required. The events that the webhook is subscribed to.
     *
     * @remarks
     * Available events:
     * - batch.succeeded
     * - batch.expired
     * - batch.failed
     * - interaction.requires_action
     * - interaction.completed
     * - interaction.failed
     * - video.generated
     */
    subscribed_events: Array<WebhookSubscribedEvent>;
    /**
     * Output only. The timestamp when the webhook was last updated.
     */
    update_time?: string | undefined;
    /**
     * Required. The URI to which webhook events will be sent.
     */
    uri: string;
};

declare type WebhookConfig$ = WebhookConfig_2;

/** Configuration for webhook notifications.

 Used to configure webhook endpoints that will receive notifications
 when long-running operations (e.g., batch jobs, video generation) complete. */
export declare interface WebhookConfig {
    /** The webhook URIs to receive notifications. If set, these
     webhook URIs will be used instead of the registered webhooks. */
    uris?: string[];
    /** User metadata that will be included in each webhook event
     notification. Use this to attach custom key-value data to correlate
     webhook events with your internal systems. */
    userMetadata?: Record<string, unknown>;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Message for configuring webhook events for a request.
 */
declare type WebhookConfig_2 = {
    /**
     * Optional. If set, these webhook URIs will be used for webhook events instead of the
     *
     * @remarks
     * registered webhooks.
     */
    uris?: Array<string> | undefined;
    /**
     * Optional. The user metadata that will be returned on each event emission to the
     *
     * @remarks
     * webhooks.
     */
    user_metadata?: {
        [k: string]: any;
    } | undefined;
};

declare type WebhookCreateParams$ = CreateWebhookParams;

declare type WebhookDeleteParams$ = DeleteWebhookParams;

declare type WebhookDeleteResponse$ = Empty;

declare type WebhookGetParams$ = GetWebhookParams;

declare type WebhookInput$ = WebhookInput;

/**
 * A Webhook resource.
 */
declare type WebhookInput = {
    /**
     * Optional. The user-provided name of the webhook.
     */
    name?: string | undefined;
    /**
     * Required. The events that the webhook is subscribed to.
     *
     * @remarks
     * Available events:
     * - batch.succeeded
     * - batch.expired
     * - batch.failed
     * - interaction.requires_action
     * - interaction.completed
     * - interaction.failed
     * - video.generated
     */
    subscribed_events: Array<WebhookSubscribedEvent>;
    /**
     * Required. The URI to which webhook events will be sent.
     */
    uri: string;
};

declare type WebhookListParams$ = ListWebhooksParams;

declare type WebhookListResponse$ = WebhookListResponse;

/**
 * Response message for WebhookService.ListWebhooks.
 */
declare type WebhookListResponse = {
    /**
     * A token, which can be sent as `page_token` to retrieve the next page.
     *
     * @remarks
     * If this field is omitted, there are no subsequent pages.
     */
    next_page_token?: string | undefined;
    /**
     * The webhooks.
     */
    webhooks?: Array<Webhook> | undefined;
};

declare type WebhookPingParams$ = PingWebhookRequest;

declare type WebhookPingResponse$ = WebhookPingResponse;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Response message for WebhookService.PingWebhook.
 */
declare type WebhookPingResponse = {};

declare type WebhookRotateSigningSecretParams$ = RotateSigningSecretRequest;

declare type WebhookRotateSigningSecretResponse$ = WebhookRotateSigningSecretResponse;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Response message for WebhookService.RotateSigningSecret.
 */
declare type WebhookRotateSigningSecretResponse = {
    /**
     * Output only. The newly generated signing secret.
     */
    secret?: string | undefined;
};

export declare namespace Webhooks {
    export type PingWebhookRequest = PingWebhookRequest$;
    export type RotateSigningSecretRequest = RotateSigningSecretRequest$;
    export type SigningSecret = SigningSecret$;
    export type Webhook = Webhook$;
    export type WebhookCreateParams = WebhookCreateParams$;
    export type WebhookDeleteParams = WebhookDeleteParams$;
    export type WebhookDeleteResponse = WebhookDeleteResponse$;
    export type WebhookGetParams = WebhookGetParams$;
    export type WebhookInput = WebhookInput$;
    export type WebhookListParams = WebhookListParams$;
    export type WebhookListResponse = WebhookListResponse$;
    export type WebhookPingParams = WebhookPingParams$;
    export type WebhookPingResponse = WebhookPingResponse$;
    export type WebhookRotateSigningSecretParams = WebhookRotateSigningSecretParams$;
    export type WebhookRotateSigningSecretResponse = WebhookRotateSigningSecretResponse$;
    export type WebhookUpdate = WebhookUpdate$;
    export type WebhookUpdateParams = WebhookUpdateParams$;
}

declare namespace webhooks {
    export {
        PingWebhookRequest,
        RevocationBehavior,
        RotateSigningSecretRequest,
        SigningSecret,
        WebhookListResponse,
        WebhookPingResponse,
        WebhookRotateSigningSecretResponse,
        WebhookUpdateState,
        WebhookUpdateSubscribedEvent,
        WebhookUpdate,
        WebhookState,
        WebhookSubscribedEvent,
        Webhook,
        WebhookInput
    }
}

declare class Webhooks_2 extends ClientSDK {
    /**
     * Lists all Webhooks.
     */
    list(params?: ListWebhooksParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<webhooks.WebhookListResponse>;
    /**
     * Creates a new Webhook.
     */
    create(params: CreateWebhookParams, options?: RequestOptions): APIPromise<webhooks.Webhook>;
    /**
     * Deletes a Webhook.
     */
    delete(id: string, params?: DeleteWebhookParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<interactions.Empty>;
    /**
     * Gets a specific Webhook.
     */
    get(id: string, params?: GetWebhookParams, options?: Omit<RequestOptions, "extra_body">): APIPromise<webhooks.Webhook>;
    /**
     * Updates an existing Webhook.
     */
    update(id: string, params: UpdateWebhookParams, options?: RequestOptions): APIPromise<webhooks.Webhook>;
    /**
     * Sends a ping event to a Webhook.
     */
    ping(id: string, api_version?: string | undefined, body?: webhooks.PingWebhookRequest | undefined, options?: RequestOptions): APIPromise<webhooks.WebhookPingResponse>;
    /**
     * Generates a new signing secret for a Webhook.
     */
    rotateSigningSecret(id: string, body: webhooks.RotateSigningSecretRequest, api_version?: string | undefined, options?: RequestOptions): APIPromise<webhooks.WebhookRotateSigningSecretResponse>;
}

/**
 * Output only. The state of the webhook.
 */
declare type WebhookState = "enabled" | "disabled" | "disabled_due_to_failed_deliveries" | (string & {});

declare type WebhookSubscribedEvent = "batch.succeeded" | "batch.expired" | "batch.failed" | "interaction.requires_action" | "interaction.completed" | "interaction.failed" | "video.generated" | (string & {});

declare type WebhookUpdate$ = WebhookUpdate;

declare type WebhookUpdate = {
    /**
     * Optional. The user-provided name of the webhook.
     */
    name?: string | undefined;
    /**
     * Optional. The state of the webhook.
     */
    state?: WebhookUpdateState | undefined;
    /**
     * Optional. The events that the webhook is subscribed to.
     *
     * @remarks
     * Available events:
     * - batch.succeeded
     * - batch.expired
     * - batch.failed
     * - interaction.requires_action
     * - interaction.completed
     * - interaction.failed
     * - video.generated
     */
    subscribed_events?: Array<WebhookUpdateSubscribedEvent> | undefined;
    /**
     * Optional. The URI to which webhook events will be sent.
     */
    uri?: string | undefined;
};

declare type WebhookUpdateParams$ = WebhookUpdate;

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Optional. The state of the webhook.
 */
declare type WebhookUpdateState = "enabled" | "disabled" | "disabled_due_to_failed_deliveries";

declare type WebhookUpdateSubscribedEvent = "batch.succeeded" | "batch.expired" | "batch.failed" | "interaction.requires_action" | "interaction.completed" | "interaction.failed" | "video.generated" | (string & {});

/** Standard web search for grounding and related configurations. Only text results are returned. */
export declare interface WebSearch {
}

declare interface WebSocket_2 {
    /**
     * Connects the socket to the server.
     */
    connect(): void;
    /**
     * Sends a message to the server.
     */
    send(message: string): void;
    /**
     * Closes the socket connection.
     */
    close(): void;
}

/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
declare interface WebSocketCallbacks {
    onopen: () => void;
    onerror: (e: any) => void;
    onmessage: (e: any) => void;
    onclose: (e: any) => void;
}

declare interface WebSocketFactory {
    /**
     * Whether the WebSocket transport forwards handshake HTTP headers.
     *
     * Browser WebSocket implementations ignore custom headers and set this to
     * `false`. When omitted, header support is assumed.
     */
    readonly supportsHeaders?: boolean;
    /**
     * Returns a new WebSocket instance.
     */
    create(url: string, headers: Record<string, string>, callbacks: WebSocketCallbacks): WebSocket_2;
}

/** Maps a prompt to a relative weight to steer music generation. */
export declare interface WeightedPrompt {
    /** Text prompt. */
    text?: string;
    /** Weight of the prompt. The weight is used to control the relative
     importance of the prompt. Higher weights are more important than lower
     weights.

     Weight must not be 0. Weights of all weighted_prompts in this
     LiveMusicClientContent message will be normalized. */
    weight?: number;
}

/** Configuration for a white space chunking algorithm. */
export declare interface WhiteSpaceConfig {
    /** Maximum number of tokens per chunk. */
    maxTokensPerChunk?: number;
    /** Maximum number of overlapping tokens between two adjacent chunks. */
    maxOverlapTokens?: number;
}

declare type WordInfo$ = WordInfo_2;

/** Information about a single recognized word. */
export declare interface WordInfo {
    /** Transcript of the word.
     */
    word?: string;
    /** Start offset in time of the word relative to the start of the audio.
     */
    startOffset?: string;
    /** End offset in time of the word relative to the start of the audio.
     */
    endOffset?: string;
}

/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 *
 * g3-prettier-ignore-file
 */
/**
 * Word-level ASR annotation for transcription output.
 *
 * @remarks
 * Carries the word text, optional timing, and optional speaker attribution.
 */
declare type WordInfo_2 = {
    /**
     * End of the attributed segment, exclusive.
     */
    end_index?: number | undefined;
    /**
     * End offset in time of the word relative to the start of the audio.
     *
     * @remarks
     * Present when timestamp_granularities contains "word".
     */
    end_offset?: string | undefined;
    /**
     * Optional. Speaker label for this word (e.g. "spk_1", "spk_2").
     *
     * @remarks
     * Present when diarization_mode is set in TranscriptionConfig.
     */
    speaker?: string | undefined;
    /**
     * Start of segment of the response that is attributed to this source.
     *
     * @remarks
     *
     * Index indicates the start of the segment, measured in bytes.
     */
    start_index?: number | undefined;
    /**
     * Start offset in time of the word relative to the start of the audio.
     *
     * @remarks
     * Present when timestamp_granularities contains "word".
     */
    start_offset?: string | undefined;
    /**
     * The transcribed word.
     */
    text?: string | undefined;
    type: "word_info";
};

export { }
