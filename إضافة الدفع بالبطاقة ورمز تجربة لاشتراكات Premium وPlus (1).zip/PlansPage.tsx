import { useAuth } from "@/_core/hooks/useAuth";
import ChatbiShell from "@/components/ChatbiShell";
import PlanCards from "@/components/PlanCards";
import { useLocale } from "@/lib/locale";
import { usePageSeo } from "@/lib/seo";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PlansPage() {
  const { user } = useAuth();
  const { t } = useLocale();
  usePageSeo({ title: `${t("plansTitle")} | chatbi.AI`, description: t("plansSubtitle"), robots: "index, follow" });
  const membership = trpc.membership.summary.useQuery(undefined, { enabled: Boolean(user), retry: false });

  return (
    <ChatbiShell activePath="/plus">
      <main className="chatbi-chat-viewport mx-auto max-w-6xl px-4 pb-14 pt-10 sm:px-7 md:pt-14">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mx-auto mb-4 flex h-11 w-11 items-center justify-center rounded-2xl bg-violet-500/15 text-violet-200"><Sparkles size={20} /></div>
          <p className="text-xs font-semibold uppercase tracking-[.22em] text-violet-300">chatbi.AI Plus</p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">{t("plansTitle")}</h1>
          <p className="mt-3 text-sm leading-6 text-white/50">{t("plansSubtitle")}</p>
        </div>

        <div className="mt-9">
          <PlanCards membership={membership.data ? { plus: membership.data.plus, premium: membership.data.premium } : undefined} onManage={() => { if (user) window.location.href = "/settings"; else startLogin(); }} />
        </div>

        <div className="mx-auto mt-6 max-w-3xl rounded-2xl border border-white/8 bg-white/[.025] px-5 py-4 text-center text-xs leading-6 text-white/45">
          <p>{t("paymentPending")}</p>
          <p className="mt-1">{t("creator")}</p>
        </div>
        {!user && <div className="mt-5 text-center"><Button onClick={() => startLogin()} className="rounded-xl bg-violet-500 hover:bg-violet-400">{t("signIn")}</Button></div>}
      </main>
    </ChatbiShell>
  );
}
