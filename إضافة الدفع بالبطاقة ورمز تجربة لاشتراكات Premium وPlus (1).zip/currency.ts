export const TCMB_DAILY_RATES_URL = "https://www.tcmb.gov.tr/kurlar/today.xml";

export type UsdTryQuote = {
  usdTry: number;
  rateDate: string;
  source: "TCMB";
};

let cachedQuote: { quote: UsdTryQuote; fetchedAt: number } | null = null;
let quoteInFlight: Promise<UsdTryQuote> | null = null;
const CACHE_TTL_MS = 60 * 60 * 1000;
const MAX_FEED_AGE_MS = 7 * 24 * 60 * 60 * 1000;

function strictUtcDate(year: number, month: number, day: number): Date | null {
  if (!Number.isInteger(year) || month < 1 || month > 12 || day < 1 || day > 31) return null;
  const parsed = new Date(0);
  parsed.setUTCFullYear(year, month - 1, day);
  parsed.setUTCHours(0, 0, 0, 0);
  if (
    parsed.getUTCFullYear() !== year
    || parsed.getUTCMonth() !== month - 1
    || parsed.getUTCDate() !== day
  ) return null;
  return parsed;
}

function parseDate(value: string): Date | null {
  const dmy = value.match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/);
  if (dmy) {
    const [, day, month, year] = dmy;
    return strictUtcDate(Number(year), Number(month), Number(day));
  }

  const ymd = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (ymd) {
    const [, year, month, day] = ymd;
    return strictUtcDate(Number(year), Number(month), Number(day));
  }

  return null;
}

export function parseTcmbUsdQuote(xml: string, now = new Date()): UsdTryQuote {
  if (xml.length === 0 || xml.length > 256_000) throw new Error("Invalid TCMB rate feed size.");

  const rootAttributes = xml.match(/<Tarih_Date\b([^>]*)>/i)?.[1];
  const rateDate = rootAttributes?.match(/\bTarih=["']([^"']+)["']/i)?.[1];
  const usdBlock = xml.match(/<Currency\b(?=[^>]*\bCurrencyCode=["']USD["'])[^>]*>([\s\S]*?)<\/Currency>/i)?.[1];
  const rawRate = usdBlock?.match(/<ForexSelling>\s*([0-9.,]+)\s*<\/ForexSelling>/i)?.[1];
  const usdTry = rawRate ? Number(rawRate.replace(",", ".")) : Number.NaN;
  const parsedDate = rateDate ? parseDate(rateDate) : null;

  if (!rateDate || !parsedDate || !Number.isFinite(usdTry) || usdTry <= 0) {
    throw new Error("The TCMB feed did not contain a valid USD selling rate.");
  }

  const ageMs = now.getTime() - parsedDate.getTime();
  if (ageMs < -24 * 60 * 60 * 1000 || ageMs > MAX_FEED_AGE_MS) {
    throw new Error("The TCMB USD selling rate is stale.");
  }

  return { usdTry, rateDate, source: "TCMB" };
}

export async function getUsdTryQuote(): Promise<UsdTryQuote> {
  const now = Date.now();
  if (cachedQuote && now - cachedQuote.fetchedAt < CACHE_TTL_MS) return cachedQuote.quote;
  if (quoteInFlight) return quoteInFlight;

  const request = (async () => {
    const response = await fetch(TCMB_DAILY_RATES_URL, {
      headers: { Accept: "application/xml, text/xml" },
      signal: AbortSignal.timeout(15_000),
    });
    if (!response.ok) throw new Error(`TCMB rate feed returned HTTP ${response.status}.`);

    const xml = await response.text();
    const quote = parseTcmbUsdQuote(xml);
    cachedQuote = { quote, fetchedAt: Date.now() };
    return quote;
  })();

  quoteInFlight = request;
  try {
    return await request;
  } finally {
    if (quoteInFlight === request) quoteInFlight = null;
  }
}
