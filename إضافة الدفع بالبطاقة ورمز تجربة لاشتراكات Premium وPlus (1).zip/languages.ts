import ISO6391 from "iso-639-1";

export const LANGUAGE_CODES = ISO6391.getAllCodes();

export const LANGUAGE_OPTIONS = LANGUAGE_CODES.map((code) => ({
  code,
  englishName: ISO6391.getName(code) || code.toUpperCase(),
  nativeName: ISO6391.getNativeName(code) || ISO6391.getName(code) || code.toUpperCase(),
})).sort((a, b) => a.nativeName.localeCompare(b.nativeName));

export function isLanguageCode(value: string) {
  return value === "auto" || LANGUAGE_CODES.some((code) => code === value);
}
