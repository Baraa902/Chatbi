# PayTR product selection for chatbi.AI (2026-11-15)

Official pre-application form: https://www.paytr.com/uye-isyeri-olun — includes business type "Bireysel Başvuru (Vergi levham yok / Muafım)" and products including Sanal POS, Mobil POS, Linkle Ödeme and Abonelik Yöntemi. This is an application option, not a guarantee of approval.

Official subscription page: https://www.paytr.com/abonelik-yontemi — describes recurring monthly/weekly/yearly collections, automatic card charging after first consent, webhook updates and API integration. It says subscription method requires Sanal POS and links application to direct API payment solutions.

Official direct API onboarding: https://dev.paytr.com/home/direkt-api-entegrasyon-sureci — apply for Sanal POS + Direct API, receive API credentials from merchant panel after approval, test, then request live activation.

Recommendation: for chatbi.AI's online monthly Plus/Premium, select "Bireysel Başvuru" if no tax plate/company applies, and request "Sanal POS" plus "Abonelik Yöntemi". Skip Mobil POS (physical/in-person use) and Linkle Ödeme unless separately wanting manual one-time links. PayTR still must confirm it approves this SaaS activity and individual account, and whether settlement can go to the user's own Turkish IBAN.