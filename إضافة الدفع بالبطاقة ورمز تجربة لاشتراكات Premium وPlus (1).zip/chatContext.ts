export type ContextMessage = {
  role: "user" | "assistant";
  content: string;
};

/** Keep recent context in chronological order while bounding the total prompt text. */
export function buildBoundedChatContext<T extends ContextMessage>(
  messages: readonly T[],
  maxCharacters: number,
  maxMessages: number,
): T[] {
  if (!Number.isInteger(maxCharacters) || maxCharacters < 1) return [];
  if (!Number.isInteger(maxMessages) || maxMessages < 1) return [];

  const recent = messages.slice(-maxMessages);
  const bounded: T[] = [];
  let remaining = maxCharacters;

  for (let index = recent.length - 1; index >= 0 && remaining > 0; index -= 1) {
    const message = recent[index];
    if (!message) continue;
    if (message.content.length <= remaining) {
      bounded.push(message);
      remaining -= message.content.length;
    } else {
      bounded.push({ ...message, content: message.content.slice(-remaining) });
      remaining = 0;
    }
  }

  return bounded.reverse();
}
