import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const { dbMock } = vi.hoisted(() => ({
  dbMock: {
    consumeRateLimit: vi.fn(),
    recordAdminCodeFailure: vi.fn(),
    listPublicStories: vi.fn(),
    submitStory: vi.fn(),
    listMyStories: vi.fn(),
    rateStory: vi.fn(),
    reportStory: vi.fn(),
    getStoryModerationQueue: vi.fn(),
    moderateStory: vi.fn(),
    closeStoryReport: vi.fn(),
  },
}));

vi.mock("./db", () => dbMock);

import { appRouter } from "./routers";

function createContext(id = 7): TrpcContext {
  return {
    user: {
      id,
      openId: `test-user-${id}`,
      name: "Test User",
      email: "test@example.com",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const allowed = { allowed: true, remaining: 4, retryAfterSeconds: 60 };
const limited = { allowed: false, remaining: 0, retryAfterSeconds: 60 };

beforeEach(() => {
  vi.clearAllMocks();
  dbMock.consumeRateLimit.mockResolvedValue(allowed);
});

afterEach(() => {
  vi.unstubAllEnvs();
});

describe("community story access", () => {
  it("shows the code-gated review entry to signed-in users when no owner ID is configured", async () => {
    vi.stubEnv("OWNER_OPEN_ID", "");
    const caller = appRouter.createCaller(createContext(7));

    await expect(caller.stories.canModerate()).resolves.toBe(true);
  });

  it("requires login before accepting a story", async () => {
    const context = { ...createContext(), user: null };
    const caller = appRouter.createCaller(context);

    await expect(caller.stories.submit({ title: "A title", body: "x".repeat(50), pseudonym: "" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(dbMock.submitStory).not.toHaveBeenCalled();
  });

  it("trims submitted text, records the account owner, and stores an empty pseudonym as anonymous", async () => {
    dbMock.submitStory.mockResolvedValue({ id: 42, title: "A title", status: "pending" });
    const caller = appRouter.createCaller(createContext(7));

    await expect(caller.stories.submit({ title: "  A title  ", body: `  ${"x".repeat(50)}  `, pseudonym: "   " })).resolves.toMatchObject({ status: "pending" });
    expect(dbMock.submitStory).toHaveBeenCalledWith({ userId: 7, title: "A title", body: "x".repeat(50), pseudonym: null });
    expect(dbMock.consumeRateLimit).toHaveBeenCalledTimes(2);
  });

  it("blocks story submission when its account rate limit is exhausted", async () => {
    dbMock.consumeRateLimit.mockResolvedValue(limited);
    const caller = appRouter.createCaller(createContext(7));

    await expect(caller.stories.submit({ title: "A title", body: "x".repeat(50), pseudonym: "" })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(dbMock.submitStory).not.toHaveBeenCalled();
  });

  it("rejects ratings outside one to five before touching the database", async () => {
    const caller = appRouter.createCaller(createContext(7));

    await expect(caller.stories.rate({ storyId: 12, rating: 6 })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(dbMock.rateStory).not.toHaveBeenCalled();
  });

  it("does not allow a story owner to rate their own published story", async () => {
    dbMock.rateStory.mockResolvedValue("owner");
    const caller = appRouter.createCaller(createContext(7));

    await expect(caller.stories.rate({ storyId: 12, rating: 5 })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(dbMock.rateStory).toHaveBeenCalledWith(12, 7, 5);
  });

  it("allows the signed-in holder of the separate review code to open the queue when no owner ID is configured", async () => {
    vi.stubEnv("OWNER_OPEN_ID", "");
    vi.stubEnv("CHATBI_STORY_REVIEW_CODE", "unit-test-story-code");
    const queue = { pending: [], reports: [] };
    dbMock.getStoryModerationQueue.mockResolvedValue(queue);
    const caller = appRouter.createCaller(createContext(7));

    await expect(caller.stories.moderationQueue({ code: "unit-test-story-code" })).resolves.toEqual(queue);
    expect(dbMock.getStoryModerationQueue).toHaveBeenCalledTimes(1);
    expect(dbMock.consumeRateLimit).not.toHaveBeenCalled();
  });

  it("rejects a non-owner before checking the code or loading the review queue", async () => {
    vi.stubEnv("OWNER_OPEN_ID", "test-user-7");
    vi.stubEnv("CHATBI_STORY_REVIEW_CODE", "unit-test-story-code");
    const caller = appRouter.createCaller(createContext(8));

    await expect(caller.stories.moderationQueue({ code: "unit-test-story-code" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(dbMock.getStoryModerationQueue).not.toHaveBeenCalled();
    expect(dbMock.consumeRateLimit).not.toHaveBeenCalled();
  });

  it("rate-limits invalid review-code attempts for the owner", async () => {
    vi.stubEnv("OWNER_OPEN_ID", "test-user-7");
    vi.stubEnv("CHATBI_STORY_REVIEW_CODE", "unit-test-story-code");
    const caller = appRouter.createCaller(createContext(7));

    await expect(caller.stories.moderationQueue({ code: "wrong-code" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(dbMock.recordAdminCodeFailure).toHaveBeenCalledWith(7);
    expect(dbMock.getStoryModerationQueue).not.toHaveBeenCalled();
  });
});
