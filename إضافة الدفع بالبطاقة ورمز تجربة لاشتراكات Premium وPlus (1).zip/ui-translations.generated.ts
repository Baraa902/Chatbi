export const generatedTranslations: Record<string, Record<string, string>> = {};
