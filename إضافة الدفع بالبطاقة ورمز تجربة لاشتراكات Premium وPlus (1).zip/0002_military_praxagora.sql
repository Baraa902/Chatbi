CREATE TABLE `admin_code_attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_code_attempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `admin_code_attempts` ADD CONSTRAINT `admin_code_attempts_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `admin_code_attempts_user_created_idx` ON `admin_code_attempts` (`userId`,`createdAt`);