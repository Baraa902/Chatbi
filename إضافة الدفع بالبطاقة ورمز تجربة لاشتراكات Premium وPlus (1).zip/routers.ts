import { randomUUID, timingSafeEqual } from "node:crypto";
import { COOKIE_NAME } from "@shared/const";
import { isLanguageCode } from "@shared/languages";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { generateGeminiReply } from "./_core/gemini";
import { buildBoundedChatContext } from "./_core/chatContext";
import { getSessionCookieOptions } from "./_core/cookies";
import { getUsdTryQuote } from "./_core/currency";
import { systemRouter } from "./_core/systemRouter";
import { ENV } from "./_core/env";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import * as db from "./db";

function secureEqual(provided: string, expected: string) {
  const left = Buffer.from(provided, "utf8");
  const right = Buffer.from(expected, "utf8");
  const size = Math.max(left.length, right.length, 1);
  const leftPadded = Buffer.alloc(size);
  const rightPadded = Buffer.alloc(size);
  left.copy(leftPadded);
  right.copy(rightPadded);
  const sameBytes = timingSafeEqual(leftPadded, rightPadded);
  return left.length === right.length && sameBytes;
}

async function verifyTrialCode(userId: number, provided: string) {
  if (await db.getTrialRedemption(userId)) {
    throw new TRPCError({ code: "CONFLICT", message: "This account has already redeemed a trial code." });
  }

  const expected = process.env.CHATBI_TRIAL_CODE;
  if (!expected) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Trial code redemption is not configured." });
  }

  const [accountRate, globalRate] = await Promise.all([
    db.consumeRateLimit(`trial:user:${userId}`, 10, 60 * 60 * 1000),
    db.consumeRateLimit("trial:global", 100, 60 * 60 * 1000),
  ]);
  if (!accountRate.allowed || !globalRate.allowed) {
    throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Try again later." });
  }

  if (!secureEqual(provided, expected)) {
    await db.recordTrialFailure(userId);
    throw new TRPCError({ code: "BAD_REQUEST", message: "The trial code is not valid." });
  }
}

async function authorizeStoryOwner(user: { id: number; openId: string }, code: string) {
  if (ENV.ownerOpenId && user.openId !== ENV.ownerOpenId) throw new TRPCError({ code: "FORBIDDEN", message: "Owner access required." });
  const expected = process.env.CHATBI_STORY_REVIEW_CODE;
  if (!expected) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Owner moderation is not configured." });
  if (secureEqual(code, expected)) return;
  const [userRate, globalRate] = await Promise.all([
    db.consumeRateLimit(`story-admin:user:${user.id}`, 5, 60 * 60 * 1000),
    db.consumeRateLimit("story-admin:global", 20, 60 * 60 * 1000),
  ]);
  if (!userRate.allowed || !globalRate.allowed) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Try again later." });
  await db.recordAdminCodeFailure(user.id);
  throw new TRPCError({ code: "FORBIDDEN", message: "The access code is not valid." });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  settings: router({
    get: protectedProcedure.query(({ ctx }) => db.getUserSettings(ctx.user.id)),
    setReplyLanguage: protectedProcedure
      .input(z.object({ languageCode: z.string().min(2).max(12) }))
      .mutation(async ({ ctx, input }) => {
        if (!isLanguageCode(input.languageCode)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Choose a supported reply language." });
        }
        return db.setReplyLanguage(ctx.user.id, input.languageCode);
      }),
  }),

  currency: router({
    usdTryQuote: publicProcedure.query(async () => {
      try {
        return await getUsdTryQuote();
      } catch {
        throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "The TRY reference rate is unavailable." });
      }
    }),
  }),

  stories: router({
    listPublic: publicProcedure.query(({ ctx }) => db.listPublicStories(ctx.user?.id)),
    canModerate: protectedProcedure.query(({ ctx }) => !ENV.ownerOpenId || ctx.user.openId === ENV.ownerOpenId),
    submit: protectedProcedure
      .input(z.object({ title: z.string().trim().min(1).max(140), body: z.string().trim().min(50).max(10_000), pseudonym: z.string().trim().max(50).optional().transform((value) => value || null) }))
      .mutation(async ({ ctx, input }) => {
        const [accountLimit, globalLimit] = await Promise.all([
          db.consumeRateLimit(`story-submit:user:${ctx.user.id}`, 5, 60 * 60 * 1000),
          db.consumeRateLimit("story-submit:global", 500, 60 * 60 * 1000),
        ]);
        if (!accountLimit.allowed || !globalLimit.allowed) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many story submissions. Try again later." });
        return db.submitStory({ userId: ctx.user.id, ...input });
      }),
    mySubmissions: protectedProcedure.query(({ ctx }) => db.listMyStories(ctx.user.id)),
    rate: protectedProcedure.input(z.object({ storyId: z.number().int().positive(), rating: z.number().int().min(1).max(5) })).mutation(async ({ ctx, input }) => {
      const [accountLimit, globalLimit] = await Promise.all([
        db.consumeRateLimit(`story-rate:user:${ctx.user.id}`, 60, 60 * 60 * 1000),
        db.consumeRateLimit("story-rate:global", 5_000, 60 * 60 * 1000),
      ]);
      if (!accountLimit.allowed || !globalLimit.allowed) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many rating attempts. Try again later." });
      const result = await db.rateStory(input.storyId, ctx.user.id, input.rating);
      if (result === "missing") throw new TRPCError({ code: "NOT_FOUND", message: "Published story not found." });
      if (result === "owner") throw new TRPCError({ code: "FORBIDDEN", message: "You cannot rate your own story." });
      return { success: true };
    }),
    report: protectedProcedure.input(z.object({ storyId: z.number().int().positive(), reason: z.string().trim().min(1).max(500) })).mutation(async ({ ctx, input }) => {
      const [accountLimit, globalLimit] = await Promise.all([
        db.consumeRateLimit(`story-report:user:${ctx.user.id}`, 10, 60 * 60 * 1000),
        db.consumeRateLimit("story-report:global", 1_000, 60 * 60 * 1000),
      ]);
      if (!accountLimit.allowed || !globalLimit.allowed) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many reports. Try again later." });
      if (await db.reportStory(input.storyId, ctx.user.id, input.reason) === "missing") throw new TRPCError({ code: "NOT_FOUND", message: "Published story not found." });
      return { success: true };
    }),
    moderationQueue: protectedProcedure.input(z.object({ code: z.string().min(1).max(64) })).mutation(async ({ ctx, input }) => {
      await authorizeStoryOwner(ctx.user, input.code);
      return db.getStoryModerationQueue();
    }),
    moderate: protectedProcedure.input(z.object({ code: z.string().min(1).max(64), storyId: z.number().int().positive(), decision: z.enum(["publish", "reject", "closeReport"]), reportId: z.number().int().positive().optional() })).mutation(async ({ ctx, input }) => {
      await authorizeStoryOwner(ctx.user, input.code);
      if (input.decision === "closeReport") {
        if (!input.reportId) throw new TRPCError({ code: "BAD_REQUEST", message: "Report ID is required." });
        await db.closeStoryReport(input.reportId);
        return { success: true };
      }
      const updated = await db.moderateStory(input.storyId, input.decision === "publish" ? "published" : "rejected");
      if (!updated) throw new TRPCError({ code: "NOT_FOUND", message: "Pending story not found." });
      return { success: true };
    }),
  }),

  chat: router({
    listThreads: protectedProcedure.query(({ ctx }) => db.listChatThreads(ctx.user.id)),
    createThread: protectedProcedure.mutation(({ ctx }) => db.createChatThread(ctx.user.id, randomUUID())),
    getThread: protectedProcedure
      .input(z.object({ threadId: z.string().uuid() }))
      .query(async ({ ctx, input }) => {
        const thread = await db.getChatThread(ctx.user.id, input.threadId);
        if (!thread) throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found." });
        const messages = await db.listChatMessages(ctx.user.id, input.threadId);
        return { ...thread, messages };
      }),
    deleteThread: protectedProcedure
      .input(z.object({ threadId: z.string().uuid() }))
      .mutation(async ({ ctx, input }) => {
        const deleted = await db.deleteChatThread(ctx.user.id, input.threadId);
        if (!deleted) throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found." });
        return { deleted: true };
      }),
    sendMessage: protectedProcedure
      .input(z.object({
        threadId: z.string().uuid(),
        clientMessageId: z.string().uuid(),
        content: z.string().trim().min(1).max(8000),
      }))
      .mutation(async ({ ctx, input }) => {
        const thread = await db.getChatThread(ctx.user.id, input.threadId);
        if (!thread) throw new TRPCError({ code: "NOT_FOUND", message: "Conversation not found." });

        const userMessage = await db.ensureUserMessage({
          userId: ctx.user.id,
          threadId: input.threadId,
          clientMessageId: input.clientMessageId,
          content: input.content,
        });
        if (!userMessage) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not save your message." });

        const existingReply = await db.getAssistantReply(ctx.user.id, userMessage.id);
        if (existingReply) return { userMessage, assistantMessage: existingReply };

        const chatRate = await db.consumeRateLimit(`chat:user:${ctx.user.id}`, 10, 60 * 1000);
        if (!chatRate.allowed) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Please wait a minute before sending more messages." });
        }

        await db.touchChatThread(ctx.user.id, input.threadId, input.content);
        const [settings, membership] = await Promise.all([
          db.getUserSettings(ctx.user.id),
          db.getMembershipSummary(ctx.user.id),
        ]);
        const historyLimit = membership.currentPlan === "free" ? 12 : membership.currentPlan === "plus" ? 32 : 60;
        const messages = await db.getRecentChatMessages(ctx.user.id, input.threadId, historyLimit);
        const contextLimit = membership.currentPlan === "free" ? 8_000 : membership.currentPlan === "plus" ? 16_000 : 24_000;

        let answer: string;
        try {
          answer = await generateGeminiReply({
            messages: buildBoundedChatContext(messages, contextLimit, historyLimit),
            language: settings?.replyLanguage ?? "auto",
            plan: membership.currentPlan,
          });
        } catch (error) {
          console.error("[Gemini] Request failed", error instanceof Error ? error.name : "unknown error");
          throw new TRPCError({
            code: "SERVICE_UNAVAILABLE",
            message: "Chatbi could not get a response. Your message is saved; please retry.",
          });
        }

        const assistantMessage = await db.createAssistantReply({
          userId: ctx.user.id,
          threadId: input.threadId,
          replyToMessageId: userMessage.id,
          content: answer,
        });
        if (!assistantMessage) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Could not save the response." });
        return { userMessage, assistantMessage };
      }),
  }),

  membership: router({
    summary: protectedProcedure.query(({ ctx }) => db.getMembershipSummary(ctx.user.id)),
    verifyTrialCode: protectedProcedure
      .input(z.object({ code: z.string().trim().min(1).max(64) }))
      .mutation(async ({ ctx, input }) => {
        await verifyTrialCode(ctx.user.id, input.code);
        return { valid: true } as const;
      }),
    redeemTrialCode: protectedProcedure
      .input(z.object({
        code: z.string().trim().min(1).max(64),
        plus: z.boolean(),
        premium: z.boolean(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (!input.plus && !input.premium) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Choose Plus, Premium, or both." });
        }
        await verifyTrialCode(ctx.user.id, input.code);
        const redeemed = await db.redeemTrial(ctx.user.id, { plus: input.plus, premium: input.premium });
        if (!redeemed) throw new TRPCError({ code: "CONFLICT", message: "This account has already redeemed a trial code." });
        return db.getMembershipSummary(ctx.user.id);
      }),
    updateTrialSelection: protectedProcedure
      .input(z.object({ plus: z.boolean(), premium: z.boolean() }))
      .mutation(async ({ ctx, input }) => {
        const updated = await db.updateTrialSelection(ctx.user.id, { plus: input.plus, premium: input.premium });
        if (!updated) throw new TRPCError({ code: "NOT_FOUND", message: "No trial code has been redeemed on this account." });
        return db.getMembershipSummary(ctx.user.id);
      }),
  }),

  analytics: router({
    unlock: protectedProcedure
      .input(z.object({ code: z.string().trim().min(1).max(64) }))
      .mutation(async ({ ctx, input }) => {
        const expected = process.env.CHATBI_ADMIN_PANEL_CODE;
        if (!expected) {
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Analytics access is not configured." });
        }
        const [adminRate, globalRate] = await Promise.all([
          db.consumeRateLimit(`admin:user:${ctx.user.id}`, 5, 60 * 60 * 1000),
          db.consumeRateLimit("admin:global", 20, 60 * 60 * 1000),
        ]);
        if (!adminRate.allowed || !globalRate.allowed) {
          throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Try again later." });
        }
        if (!secureEqual(input.code, expected)) {
          await db.recordAdminCodeFailure(ctx.user.id);
          throw new TRPCError({ code: "FORBIDDEN", message: "The access code is not valid." });
        }
        return db.getAdminStatistics();
      }),
  }),
});

export type AppRouter = typeof appRouter;
