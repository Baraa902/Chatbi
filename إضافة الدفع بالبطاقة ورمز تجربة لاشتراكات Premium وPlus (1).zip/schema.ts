import {
  boolean,
  index,
  int,
  longtext,
  mysqlEnum,
  mysqlTable,
  timestamp,
  text,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Core user table backing the Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const chatThreads = mysqlTable(
  "chat_threads",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 180 }).notNull().default(""),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    ownerUpdatedIdx: index("chat_threads_owner_updated_idx").on(table.userId, table.updatedAt),
  }),
);

export const chatMessages = mysqlTable(
  "chat_messages",
  {
    id: int("id").autoincrement().primaryKey(),
    threadId: varchar("threadId", { length: 36 })
      .notNull()
      .references(() => chatThreads.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    role: mysqlEnum("role", ["user", "assistant"]).notNull(),
    content: longtext("content").notNull(),
    clientMessageId: varchar("clientMessageId", { length: 36 }),
    replyToMessageId: int("replyToMessageId"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    threadOrderIdx: index("chat_messages_thread_order_idx").on(table.threadId, table.id),
    clientMessageUnique: uniqueIndex("chat_messages_client_message_unique").on(table.clientMessageId),
    replyUnique: uniqueIndex("chat_messages_reply_unique").on(table.replyToMessageId),
  }),
);

export const userSettings = mysqlTable("user_settings", {
  userId: int("userId").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  replyLanguage: varchar("replyLanguage", { length: 12 }).notNull().default("auto"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const userEntitlements = mysqlTable(
  "user_entitlements",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    plan: mysqlEnum("plan", ["plus", "premium"]).notNull(),
    source: mysqlEnum("source", ["trial", "subscription"]).notNull(),
    status: mysqlEnum("status", ["active", "expired", "cancelled"]).notNull().default("active"),
    expiresAt: timestamp("expiresAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    userPlanSourceUnique: uniqueIndex("user_entitlements_user_plan_source_unique").on(
      table.userId,
      table.plan,
      table.source,
    ),
    userStatusIdx: index("user_entitlements_user_status_idx").on(table.userId, table.status),
  }),
);

export const trialRedemptions = mysqlTable("trial_redemptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  plusGranted: boolean("plusGranted").notNull(),
  premiumGranted: boolean("premiumGranted").notNull(),
  redeemedAt: timestamp("redeemedAt").defaultNow().notNull(),
});

export const adminCodeAttempts = mysqlTable(
  "admin_code_attempts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userCreatedIdx: index("admin_code_attempts_user_created_idx").on(table.userId, table.createdAt),
  }),
);

export const trialCodeAttempts = mysqlTable(
  "trial_code_attempts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    userCreatedIdx: index("trial_code_attempts_user_created_idx").on(table.userId, table.createdAt),
    createdIdx: index("trial_code_attempts_created_idx").on(table.createdAt),
  }),
);

export const rateLimitWindows = mysqlTable("rate_limit_windows", {
  scopeKey: varchar("scopeKey", { length: 191 }).primaryKey(),
  windowStartedAt: timestamp("windowStartedAt").notNull(),
  requestCount: int("requestCount").notNull(),
});

export const stories = mysqlTable(
  "stories",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 140 }).notNull(),
    body: longtext("body").notNull(),
    pseudonym: varchar("pseudonym", { length: 50 }),
    status: mysqlEnum("status", ["pending", "published", "rejected"]).notNull().default("pending"),
    submittedAt: timestamp("submittedAt").defaultNow().notNull(),
    moderatedAt: timestamp("moderatedAt"),
  },
  (table) => ({
    statusSubmittedIdx: index("stories_status_submitted_idx").on(table.status, table.submittedAt),
    ownerIdx: index("stories_owner_idx").on(table.userId, table.submittedAt),
  }),
);

export const storyRatings = mysqlTable(
  "story_ratings",
  {
    id: int("id").autoincrement().primaryKey(),
    storyId: int("storyId").notNull().references(() => stories.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    rating: int("rating").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    storyUserUnique: uniqueIndex("story_ratings_story_user_unique").on(table.storyId, table.userId),
    storyIdx: index("story_ratings_story_idx").on(table.storyId),
  }),
);

export const storyReports = mysqlTable(
  "story_reports",
  {
    id: int("id").autoincrement().primaryKey(),
    storyId: int("storyId").notNull().references(() => stories.id, { onDelete: "cascade" }),
    reporterId: int("reporterId").notNull().references(() => users.id, { onDelete: "cascade" }),
    reason: varchar("reason", { length: 500 }).notNull(),
    status: mysqlEnum("status", ["open", "closed"]).notNull().default("open"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => ({
    storyReporterUnique: uniqueIndex("story_reports_story_reporter_unique").on(table.storyId, table.reporterId),
    statusCreatedIdx: index("story_reports_status_created_idx").on(table.status, table.createdAt),
    storyIdx: index("story_reports_story_idx").on(table.storyId),
  }),
);
