import { GoogleGenAI } from "@google/genai";
import ISO6391 from "iso-639-1";
import { readFile, writeFile, rename } from "node:fs/promises";
import { setTimeout as sleep } from "node:timers/promises";
import path from "node:path";

const PROJECT = "/home/ubuntu/chatbiapp";
const SOURCE_PATH = "/tmp/chatbi-ui-master.json";
const PROGRESS_PATH = "/tmp/chatbi-ui-gemini-progress.json";
const OUTPUT_PATH = path.join(PROJECT, "client/src/lib/ui-translations.generated.ts");
const MODEL = "gemini-3.5-flash-lite";
const BATCH_SIZE = 3;
const INTER_REQUEST_MS = 5_200;
const MAX_ATTEMPTS = 3;

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) throw new Error("GEMINI_API_KEY is unavailable in the project environment.");
const ai = new GoogleGenAI({ apiKey });
const source = JSON.parse(await readFile(SOURCE_PATH, "utf8"));
const keys = Object.keys(source);
const placeholderSet = (value) => [...value.matchAll(/\{([A-Za-z0-9_]+)\}/g)].map((match) => match[1]).sort().join("|");
const allCodes = ISO6391.getAllCodes();
const targets = allCodes.filter((code) => code !== "en");
let completed = {};
try {
  completed = JSON.parse(await readFile(PROGRESS_PATH, "utf8"));
} catch {
  completed = {};
}

function isComplete(code, dictionary) {
  if (!dictionary || typeof dictionary !== "object") return false;
  if (Object.keys(dictionary).length !== keys.length) return false;
  return keys.every((key) => typeof dictionary[key] === "string" && dictionary[key].trim().length > 0 && placeholderSet(dictionary[key]) === placeholderSet(source[key]));
}

function batches(items, size) {
  const result = [];
  for (let index = 0; index < items.length; index += size) result.push(items.slice(index, index + size));
  return result;
}

function validateBatch(raw, requestedCodes) {
  const result = raw?.translations ?? raw;
  const issues = [];
  if (!result || typeof result !== "object") return { ok: false, issue: "top-level value is not an object" };
  for (const code of requestedCodes) {
    const dictionary = result[code];
    if (!dictionary || typeof dictionary !== "object") {
      issues.push(`${code}: missing dictionary`);
      continue;
    }
    const received = Object.keys(dictionary);
    const missing = keys.filter((key) => !Object.hasOwn(dictionary, key));
    const extra = received.filter((key) => !Object.hasOwn(source, key));
    if (missing.length) issues.push(`${code}: missing ${missing.slice(0, 8).join(",")}`);
    if (extra.length) issues.push(`${code}: unexpected ${extra.slice(0, 8).join(",")}`);
    for (const key of keys) {
      const value = dictionary[key];
      if (typeof value !== "string" || !value.trim()) issues.push(`${code}: invalid ${key}`);
      else if (placeholderSet(value) !== placeholderSet(source[key])) issues.push(`${code}: placeholder mismatch ${key}`);
    }
  }
  return issues.length ? { ok: false, issue: issues.join("; ") } : { ok: true, data: result };
}

async function translateBatch(requestedCodes) {
  const targetDescription = requestedCodes.map((code) => {
    const englishName = ISO6391.getName(code) || code;
    const nativeName = ISO6391.getNativeName(code) || englishName;
    return `${code}: ${nativeName} (${englishName})`;
  }).join("\n");
  let previousIssue = "";
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const prompt = [
      "You are a professional software localization translator. Translate every English UI string into each requested language.",
      "Return valid JSON only, shaped as {\"translations\": {\"<language-code>\": {\"<message-key>\": \"translated string\"}}}.",
      "The top-level language codes and message keys must be exact. Include every key exactly once for every requested language and add no extra keys.",
      "Preserve placeholders exactly, including braces and spelling, such as {formatted}, {date}, and {count}.",
      "Keep chatbi.AI, Free, Plus, Premium, TCMB, USD, TRY and +18 unchanged. Preserve digits and punctuation that form codes, prices, or placeholders.",
      "Use concise, natural, respectful wording appropriate for interface labels, buttons, alerts, and help text. Use each language's native writing system. Translate the adult-content policy accurately; do not soften or omit it.",
      previousIssue ? `Your previous result failed validation. Correct all of these issues: ${previousIssue}` : "",
      "Requested target languages:\n" + targetDescription,
      "English message map:\n" + JSON.stringify(source),
    ].filter(Boolean).join("\n\n");
    try {
      const response = await ai.models.generateContent({
        model: MODEL,
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        config: {
          responseMimeType: "application/json",
          maxOutputTokens: 8192,
          temperature: 0.1,
          httpOptions: { timeout: 60_000 },
        },
      });
      const text = response.text?.trim();
      if (!text) throw new Error("Empty translation response");
      let parsed;
      try {
        parsed = JSON.parse(text);
      } catch {
        throw new Error("Response was not valid JSON");
      }
      const validation = validateBatch(parsed, requestedCodes);
      if (!validation.ok) {
        previousIssue = validation.issue;
        if (attempt < MAX_ATTEMPTS) continue;
        throw new Error(`Translation validation failed: ${validation.issue}`);
      }
      for (const code of requestedCodes) completed[code] = validation.data.translations?.[code] ?? validation.data[code];
      const temp = `${PROGRESS_PATH}.tmp`;
      await writeFile(temp, JSON.stringify(completed), "utf8");
      await rename(temp, PROGRESS_PATH);
      return;
    } catch (error) {
      if (attempt === MAX_ATTEMPTS) {
        const name = error instanceof Error ? error.name : "unknown error";
        throw new Error(`Translation batch failed for ${requestedCodes.join(",")}; final error type: ${name}`);
      }
      await sleep(Math.min(30_000, attempt * 8_000));
    }
  }
}

const missing = targets.filter((code) => !isComplete(code, completed[code]));
const queue = batches(missing, BATCH_SIZE);
console.log(`Gemini localization: ${missing.length}/${targets.length} locales remaining; ${keys.length} UI messages; ${queue.length} batches.`);
for (let index = 0; index < queue.length; index++) {
  const batch = queue[index];
  if (index > 0) await sleep(INTER_REQUEST_MS);
  await translateBatch(batch);
  console.log(`Completed ${index + 1}/${queue.length}: ${batch.join(", ")}`);
}

const incomplete = targets.filter((code) => !isComplete(code, completed[code]));
if (incomplete.length) throw new Error(`Incomplete locale dictionaries: ${incomplete.join(", ")}`);
const generated = {
  ar: completed.ar,
  ...Object.fromEntries(targets.filter((code) => code !== "ar").map((code) => [code, completed[code]])),
};
const output = `export const generatedTranslations: Record<string, Record<string, string>> = ${JSON.stringify(generated)};\n`;
const outputTemp = `${OUTPUT_PATH}.tmp`;
await writeFile(outputTemp, output, "utf8");
await rename(outputTemp, OUTPUT_PATH);
console.log(`Saved ${Object.keys(generated).length} complete locale dictionaries to ${OUTPUT_PATH}.`);
