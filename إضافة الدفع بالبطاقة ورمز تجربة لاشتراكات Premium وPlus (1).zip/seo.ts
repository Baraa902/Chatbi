import { PUBLIC_SITE_ORIGIN } from "@shared/site";

const BRAND_IMAGE = "https://files.manuscdn.com/user_upload_by_module/session_file/310519664079402183/ONNeHqArLEOhoeit.png";
const PUBLIC_ORIGIN = (process.env.CHATBI_PUBLIC_ORIGIN ?? PUBLIC_SITE_ORIGIN).replace(/\/+$/, "");

export type SeoPage = {
  title: string;
  description: string;
  robots: string;
  status: number;
  body: string;
  private: boolean;
};

const homePage: SeoPage = {
  title: "chatbi.AI | مساعد ذكاء اصطناعي متعدد اللغات",
  description: "chatbi.AI مساعد ذكاء اصطناعي للمحادثة والكتابة والإجابات السريعة بلغتك. ابدأ مجاناً بأكثر من 100 لغة، أو قارن خطط Plus وPremium.",
  robots: "index, follow",
  status: 200,
  private: false,
  body: `
    <main class="seo-fallback" lang="ar" dir="rtl">
      <h1>chatbi.AI — مساعدك الذكي بلغتك</h1>
      <p>تحدّث مع chatbi.AI بالعربية أو بأكثر من 100 لغة. ابدأ بإجابات مجانية قصيرة وسريعة، واحفظ محادثاتك بعد تسجيل الدخول.</p>
      <h2>ابدأ محادثة أو قارن الخطط</h2>
      <p>اختر لغة الإجابة من إعداداتك، واستكشف مزايا خطط chatbi.AI Plus وPremium.</p>
      <p><a href="/plus">قارن خطط chatbi.AI وأسعارها</a> · <a href="/settings">إعدادات الحساب واللغة</a></p>
    </main>`,
};

const plansPage: SeoPage = {
  title: "خطط chatbi.AI Plus وPremium | الأسعار والمزايا",
  description: "قارن خطط chatbi.AI: Free مجاناً، وPlus مقابل 10 دولارات شهرياً، وPremium مقابل 25 دولاراً شهرياً. اطّلع على المزايا قبل اختيار خطتك.",
  robots: "index, follow",
  status: 200,
  private: false,
  body: `
    <main class="seo-fallback" lang="ar" dir="rtl">
      <h1>خطط chatbi.AI: Free وPlus وPremium</h1>
      <p>اختر الخطة التي تناسب محادثاتك مع مساعد chatbi.AI متعدد اللغات.</p>
      <section><h2>Free — مجاناً</h2><p>إجابات قصيرة وسريعة؛ يفهم ويجيب بأكثر من 100 لغة. السعر: 0 دولار.</p></section>
      <section><h2>Plus — 10 دولارات شهرياً</h2><p>إجابات دقيقة ومفصلة، شرح بعناوين ونقاط وأمثلة، ذاكرة أطول للمحادثة وأولوية في الردود.</p></section>
      <section><h2>Premium — 25 دولاراً شهرياً</h2><p>ذاكرة ذكية قابلة للتحكم، تفكير متقدم وبحث عميق، فهم الصور وتحليل الملفات، ترجمة وكتابة وإنشاء محتوى.</p></section>
      <p>التحويل إلى IBAN Kuveyt Türk قيد الإعداد؛ لا ترسل أي مبلغ الآن. عند التفعيل، يلزم تحويل جديد لكل تجديد شهري.</p>
      <p>الصانع: Baraa seyam · <a href="/">افتح chatbi.AI</a></p>
    </main>`,
};

const settingsPage: SeoPage = {
  title: "إعدادات حساب chatbi.AI",
  description: "إعدادات حساب chatbi.AI خاصة بالمستخدمين المسجلين.",
  robots: "noindex, nofollow",
  status: 200,
  private: true,
  body: `
    <main class="seo-fallback" lang="ar" dir="rtl">
      <h1>إعدادات chatbi.AI</h1>
      <p>سجّل الدخول للوصول إلى إعدادات الحساب واللغة والاشتراك.</p>
      <p><a href="/">العودة إلى chatbi.AI</a></p>
    </main>`,
};

const privateChatPage: SeoPage = {
  title: "محادثة chatbi.AI خاصة",
  description: "المحادثات خاصة بحساب صاحبها.",
  robots: "noindex, nofollow",
  status: 200,
  private: true,
  body: `
    <main class="seo-fallback" lang="ar" dir="rtl">
      <h1>محادثة chatbi.AI خاصة</h1>
      <p>سجّل الدخول لعرض محادثاتك المحفوظة.</p>
      <p><a href="/">العودة إلى chatbi.AI</a></p>
    </main>`,
};

const notFoundPage: SeoPage = {
  title: "الصفحة غير موجودة | chatbi.AI",
  description: "تعذر العثور على صفحة chatbi.AI المطلوبة.",
  robots: "noindex, nofollow",
  status: 404,
  private: true,
  body: `
    <main class="seo-fallback" lang="ar" dir="rtl">
      <h1>الصفحة غير موجودة</h1>
      <p>تحقق من الرابط أو ارجع إلى الصفحة الرئيسية.</p>
      <p><a href="/">العودة إلى chatbi.AI</a></p>
    </main>`,
};

export function resolveSeoPage(pathname: string): SeoPage | null {
  const path = pathname.split("?", 1)[0] || "/";
  if (path === "/") return homePage;
  if (path === "/plus") return plansPage;
  if (path === "/stories") {
    return {
      title: "قصص مجتمع chatbi.AI",
      description: "اقرأ القصص التي وافق المالك يدوياً على نشرها في مجتمع chatbi.AI.",
      robots: "noindex, nofollow",
      status: 200,
      private: false,
      body: `
        <main class="seo-fallback" lang="ar" dir="rtl">
          <h1>قصص مجتمع chatbi.AI</h1>
          <p>تظهر هنا القصص التي وافق المالك يدوياً على نشرها؛ تبقى جميع القصص المرسلة بانتظار المراجعة قبل ظهورها للعامة.</p>
          <p><a href="/stories">عرض القصص المنشورة</a> · <a href="/">العودة إلى الدردشة</a></p>
        </main>`,
    };
  }
  if (path === "/settings") return settingsPage;
  if (/^\/chat\/[^/]+$/.test(path)) return privateChatPage;
  if (path === "/404") return notFoundPage;
  return null;
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[character] ?? character);
}

export function renderSeoHtml(template: string, pathname: string, forceNotFound = false) {
  const page = forceNotFound ? notFoundPage : resolveSeoPage(pathname) ?? notFoundPage;
  const title = escapeHtml(page.title);
  const description = escapeHtml(page.description);
  const canonicalPath = pathname.split("?", 1)[0] || "/";
  const publicUrl = PUBLIC_ORIGIN ? `${PUBLIC_ORIGIN}${canonicalPath}` : "";
  const tags = [
    `<meta name="keywords" content="chatbi.AI, مساعد ذكاء اصطناعي, AI assistant, مساعد متعدد اللغات, chatbot" />`,
    `<meta name="robots" content="${page.robots}" />`,
    `<meta property="og:type" content="website" />`,
    `<meta property="og:title" content="${title}" />`,
    `<meta property="og:description" content="${description}" />`,
    `<meta property="og:site_name" content="chatbi.AI" />`,
    `<meta property="og:image" content="${BRAND_IMAGE}" />`,
    `<meta name="twitter:card" content="summary_large_image" />`,
    `<meta name="twitter:title" content="${title}" />`,
    `<meta name="twitter:description" content="${description}" />`,
    `<meta name="twitter:image" content="${BRAND_IMAGE}" />`,
  ];
  if (publicUrl && !page.private) {
    const safeUrl = escapeHtml(publicUrl);
    tags.push(`<link rel="canonical" href="${safeUrl}" />`);
    tags.push(`<meta property="og:url" content="${safeUrl}" />`);
  }

  let html = template.replace(/<title>[\s\S]*?<\/title>/i, `<title>${title}</title>`);
  html = html.replace(/<meta\s+name=["']description["'][^>]*>/i, `<meta name="description" content="${description}" />`);
  html = html.replace("</head>", `${tags.join("\n    ")}\n  </head>`);
  html = html.replace('<div id="root"></div>', `<div id="root">${page.body}</div>`);
  return { html, page };
}
