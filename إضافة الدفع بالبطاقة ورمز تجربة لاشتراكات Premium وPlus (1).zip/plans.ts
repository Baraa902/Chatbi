export type PlanId = "free" | "plus" | "premium";

export type PlanFeatureKey =
  | "featureFreeShortFast"
  | "featureFreeLanguages"
  | "featurePlusAccurate"
  | "featurePlusHeadings"
  | "featurePlusMemory"
  | "featurePlusPriority"
  | "featurePremiumMemory"
  | "featurePremiumResearch"
  | "featurePremiumFiles"
  | "featurePremiumWriting"
  | "featurePremiumCreation";

export const PLAN_CATALOG: Record<PlanId, {
  price: number;
  interval: "month" | null;
  features: PlanFeatureKey[];
}> = {
  free: {
    price: 0,
    interval: null,
    features: ["featureFreeShortFast", "featureFreeLanguages"],
  },
  plus: {
    price: 10,
    interval: "month",
    features: ["featurePlusAccurate", "featurePlusHeadings", "featurePlusMemory", "featurePlusPriority"],
  },
  premium: {
    price: 25,
    interval: "month",
    features: ["featurePremiumMemory", "featurePremiumResearch", "featurePremiumFiles", "featurePremiumWriting", "featurePremiumCreation"],
  },
};
