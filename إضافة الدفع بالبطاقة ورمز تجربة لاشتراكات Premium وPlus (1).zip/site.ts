// The project deployment notification confirmed this stable public domain.
// Do not derive canonical URLs from Preview or request Host headers.
export const PUBLIC_SITE_ORIGIN = "https://chatbiapp-y4tmxkdn.manus.space";
