import { describe, expect, it } from "vitest";
import { buildBoundedChatContext, type ContextMessage } from "./chatContext";

const messages: ContextMessage[] = [
  { role: "user", content: "old" },
  { role: "assistant", content: "answer" },
  { role: "user", content: "new" },
];

describe("buildBoundedChatContext", () => {
  it("keeps recent messages in chronological order within the character budget", () => {
    const result = buildBoundedChatContext(messages, 7, 3);
    expect(result).toEqual([
      { role: "assistant", content: "swer" },
      { role: "user", content: "new" },
    ]);
    expect(result.reduce((total, message) => total + message.content.length, 0)).toBe(7);
  });

  it("limits history length and leaves the newest message available", () => {
    const result = buildBoundedChatContext(messages, 20, 2);
    expect(result).toEqual(messages.slice(-2));
  });

  it("returns an empty context for invalid bounds", () => {
    expect(buildBoundedChatContext(messages, 0, 3)).toEqual([]);
    expect(buildBoundedChatContext(messages, 10, 0)).toEqual([]);
  });
});
